<?php
$file = __DIR__ . '/products.php';
$content = file_get_contents($file);

// Fix quick tags — replace broken emoji with Bootstrap Icons
$new_tags = '                <!-- Quick Search Tags -->
                <div class="quick-tags">
                    <a href="products.php?search=panadol" class="quick-tag"><i class="bi bi-capsule-pill me-1"></i>Panadol</a>
                    <a href="products.php?search=antibiotic" class="quick-tag"><i class="bi bi-shield-plus me-1"></i>Antibiotics</a>
                    <a href="products.php?search=pain" class="quick-tag"><i class="bi bi-bandaid me-1"></i>Pain Relief</a>
                    <a href="products.php?search=fever" class="quick-tag"><i class="bi bi-thermometer-half me-1"></i>Fever</a>
                    <a href="products.php?search=vitamin" class="quick-tag"><i class="bi bi-heart-pulse me-1"></i>Vitamins</a>
                    <a href="products.php?search=gel" class="quick-tag"><i class="bi bi-droplet me-1"></i>Gels</a>
                    <a href="products.php?search=allergy" class="quick-tag"><i class="bi bi-flower1 me-1"></i>Allergy</a>
                    <a href="products.php?search=cough" class="quick-tag"><i class="bi bi-lungs me-1"></i>Cough</a>
                </div>';

// Replace the entire quick-tags div using regex
$content = preg_replace(
    '/<!-- Quick Search Tags -->\s*<div class="quick-tags">.*?<\/div>/s',
    $new_tags,
    $content
);

file_put_contents($file, $content);
echo "<p style='color:green;font-family:sans-serif;padding:1rem'>✅ Products page quick tags fixed!</p>";

// Also fix index.html banner text colors
$index = __DIR__ . '/index.html';
$html = file_get_contents($index);

// Fix promo banner text color (dark text on red = unreadable)
$html = preg_replace(
    '/(<section class="promo-banner"[^>]*>.*?<h3 class="fw-bold mb-2">)(.*?)(<\/h3>)/s',
    '$1$2$3',
    $html
);

// Fix app banner text
$html = str_replace(
    'class="ad-banner-content"',
    'class="ad-banner-content" style="color:white"',
    $html
);

// Fix about page header text
// Fix footer payment buttons in about.html and contact.html
foreach (['about.html', 'contact.html'] as $f) {
    $path = __DIR__ . '/' . $f;
    if (!file_exists($path)) continue;
    $fc = file_get_contents($path);
    // Remove old top-bar if present
    $fc = preg_replace('/<div class="top-bar">.*?<\/div>\s*/s', '', $fc);
    file_put_contents($path, $fc);
}

file_put_contents($index, $html);
echo "<p style='color:green;font-family:sans-serif;padding:1rem'>✅ All fixes applied!</p>";
echo "<p style='font-family:sans-serif;padding:0 1rem'><a href='products.php'>View Products</a> | <a href='index.php'>View Homepage</a></p>";
?>
