﻿<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) { header('Location: login.php'); exit(); }
require_once('../api/config.php');
if (!$conn) { die('<h3 style="color:red;padding:2rem">Database connection failed.</h3>'); }

// â”€â”€ Date range filter â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
$range  = $_GET['range'] ?? '30';
$custom_from = $_GET['from'] ?? '';
$custom_to   = $_GET['to']   ?? '';

if ($custom_from && $custom_to) {
    $date_from = $custom_from;
    $date_to   = $custom_to;
    $label     = "Custom: $date_from to $date_to";
} else {
    $date_to   = date('Y-m-d');
    $date_from = date('Y-m-d', strtotime("-{$range} days"));
    $labels    = ['1'=>'Today','7'=>'Last 7 Days','30'=>'Last 30 Days','90'=>'Last 90 Days','365'=>'Last Year'];
    $label     = $labels[$range] ?? "Last $range Days";
    if ($range == '1') {
        $date_from = date('Y-m-d'); // Today only
    }
}

// â”€â”€ Key Metrics â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€â”€
$total_revenue  = $conn->query("SELECT COALESCE(SUM(total_amount),0) as v FROM orders WHERE DATE(created_at) BETWEEN '$date_from' AND '$date_to'")->fetch_assoc()['v'] ?? 0;
$total_orders   = $conn->query("SELECT COUNT(*) as v FROM orders WHERE DATE(created_at) BETWEEN '$date_from' AND '$date_to'")->fetch_assoc()['v'] ?? 0;
$total_customers= $conn->query("SELECT COUNT(DISTINCT customer_email) as v FROM orders WHERE DATE(created_at) BETWEEN '$date_from' AND '$date_to' AND customer_email IS NOT NULL AND customer_email != ''")->fetch_assoc()['v'] ?? 0;
$avg_order      = $total_orders > 0 ? $total_revenue / $total_orders : 0;

// Today
$today_rev      = $conn->query("SELECT COALESCE(SUM(total_amount),0) as v FROM orders WHERE DATE(created_at) = CURDATE()")->fetch_assoc()['v'] ?? 0;
$today_orders   = $conn->query("SELECT COUNT(*) as v FROM orders WHERE DATE(created_at) = CURDATE()")->fetch_assoc()['v'] ?? 0;

// This month
$month_rev      = $conn->query("SELECT COALESCE(SUM(total_amount),0) as v FROM orders WHERE MONTH(created_at)=MONTH(NOW()) AND YEAR(created_at)=YEAR(NOW())")->fetch_assoc()['v'] ?? 0;
$month_orders   = $conn->query("SELECT COUNT(*) as v FROM orders WHERE MONTH(created_at)=MONTH(NOW()) AND YEAR(created_at)=YEAR(NOW())")->fetch_assoc()['v'] ?? 0;

// Status breakdown
$status_data = [];
$sr = $conn->query("SELECT status, COUNT(*) as cnt, COALESCE(SUM(total_amount),0) as rev FROM orders WHERE DATE(created_at) BETWEEN '$date_from' AND '$date_to' GROUP BY status");
while ($row = $sr->fetch_assoc()) $status_data[$row['status']] = $row;

// Daily revenue for chart (last 14 days)
$daily = [];
$dr = $conn->query("SELECT DATE(created_at) as d, COUNT(*) as cnt, COALESCE(SUM(total_amount),0) as rev FROM orders WHERE DATE(created_at) >= DATE_SUB(CURDATE(), INTERVAL 14 DAY) GROUP BY DATE(created_at) ORDER BY d ASC");
while ($row = $dr->fetch_assoc()) $daily[$row['d']] = $row;

// Fill missing days
$chart_labels = [];
$chart_revenue = [];
$chart_orders  = [];
for ($i = 13; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-{$i} days"));
    $chart_labels[]  = date('M d', strtotime($d));
    $chart_revenue[] = isset($daily[$d]) ? (float)$daily[$d]['rev'] : 0;
    $chart_orders[]  = isset($daily[$d]) ? (int)$daily[$d]['cnt'] : 0;
}

// Top selling products
$top_products = $conn->query("SELECT p.name, p.category, SUM(oi.quantity) as qty, SUM(oi.quantity * oi.price) as rev FROM order_items oi JOIN products p ON oi.product_id = p.id JOIN orders o ON oi.order_id = o.id WHERE DATE(o.created_at) BETWEEN '$date_from' AND '$date_to' GROUP BY p.id ORDER BY qty DESC LIMIT 8");

// Recent orders
$recent = $conn->query("SELECT o.id, COALESCE(o.customer_name, 'Guest') as cname, o.total_amount, o.status, o.created_at FROM orders o ORDER BY o.created_at DESC LIMIT 8");

// Payment method breakdown
$pm_data = [];
$pmr = $conn->query("SELECT COALESCE(payment_method,'Cash on Delivery') as pm, COUNT(*) as cnt, COALESCE(SUM(total_amount),0) as rev FROM orders WHERE DATE(created_at) BETWEEN '$date_from' AND '$date_to' GROUP BY pm ORDER BY cnt DESC");
if ($pmr) while ($row = $pmr->fetch_assoc()) $pm_data[] = $row;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Reports - MEDIX Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
:root{--sw:280px;--red:#B91C1C}
*{box-sizing:border-box}
body{font-family:'Inter',sans-serif;background:#F3F4F6;margin:0}
.sidebar{position:fixed;top:0;left:0;width:var(--sw);height:100vh;background:linear-gradient(180deg,#B91C1C,#7F1D1D);overflow-y:auto;z-index:1000}
.sb-brand{padding:1.5rem;border-bottom:1px solid rgba(255,255,255,.1);color:white}
.mi{display:flex;align-items:center;gap:.75rem;padding:.875rem 1.5rem;color:rgba(255,255,255,.8);text-decoration:none;border-left:3px solid transparent;transition:all .2s;font-weight:500}
.mi:hover,.mi.active{background:rgba(255,255,255,.15);color:white;border-left-color:white}
.mi i{width:20px}
.mdiv{height:1px;background:rgba(255,255,255,.1);margin:.5rem 1.5rem}
.main{margin-left:var(--sw);padding:2rem;min-height:100vh}
.topbar{background:white;border-bottom:3px solid var(--red);padding:1.25rem 2rem;margin:-2rem -2rem 2rem;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:1rem;box-shadow:0 2px 6px rgba(0,0,0,.08)}
.card{background:white;border-radius:16px;padding:1.5rem;box-shadow:0 1px 3px rgba(0,0,0,.08);border:1px solid #f1f5f9}
.metric-card{border-top:3px solid var(--red);transition:transform .2s}
.metric-card:hover{transform:translateY(-3px)}
.metric-val{font-size:1.75rem;font-weight:800;color:#1e293b}
.metric-lbl{font-size:.8rem;color:#64748b;font-weight:500;text-transform:uppercase;letter-spacing:.5px}
.metric-sub{font-size:.75rem;margin-top:.3rem;font-weight:600}
.metric-icon{width:48px;height:48px;border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.3rem;flex-shrink:0}
.table thead th{font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;border-bottom:2px solid #e2e8f0;padding:.75rem 1rem;background:#f8fafc}
.table tbody td{padding:.75rem 1rem;vertical-align:middle;font-size:.875rem;border-bottom:1px solid #f8fafc}
.table tbody tr:hover{background:#f8fafc}
.filter-btn{padding:.4rem .875rem;border-radius:8px;border:1.5px solid #e2e8f0;background:white;font-size:.8rem;font-weight:600;cursor:pointer;transition:all .2s;color:#64748b}
.filter-btn:hover,.filter-btn.active{background:var(--red);border-color:var(--red);color:white}
.progress{height:8px;border-radius:4px}
</style>
</head>
<body>
<div class="sidebar">
    <div class="sb-brand"><h4 class="mb-0 fw-bold"><i class="bi bi-heart-pulse-fill me-2"></i>MEDIX</h4><small style="opacity:.6">Admin Portal</small></div>
    <a href="index.php" class="mi"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="products.php" class="mi"><i class="bi bi-box-seam"></i>Products</a>
    <a href="offers.php" class="mi"><i class="bi bi-tag-fill"></i>Offers</a>
    <a href="orders.php" class="mi"><i class="bi bi-cart-check"></i>Orders</a>
    <a href="customers.php" class="mi"><i class="bi bi-people"></i>Customers</a>
    <a href="categories.php" class="mi"><i class="bi bi-tags"></i>Categories</a>
    <a href="messages.php" class="mi"><i class="bi bi-envelope"></i>Messages</a>
    <a href="reports.php" class="mi active"><i class="bi bi-graph-up"></i>Reports</a>
    <a href="settings.php" class="mi"><i class="bi bi-gear"></i>Settings</a>
    <div class="mdiv"></div>
    <a href="database.php" class="mi"><i class="bi bi-database"></i>Database</a>
    <a href="import_medicines.php" class="mi" style="color:#10B981"><i class="bi bi-capsule-pill"></i>Import Medicines</a>
    <div class="mdiv"></div>
    <a href="logout.php" class="mi"><i class="bi bi-box-arrow-right"></i>Logout</a>
</div>

<div class="main">
    <div class="topbar">
        <div>
            <h4 class="mb-0 fw-bold"><i class="bi bi-graph-up me-2 text-danger"></i>Reports & Analytics</h4>
            <small class="text-muted"><?= $label ?></small>
        </div>
        <form method="GET" class="d-flex align-items-center gap-2 flex-wrap">
            <button type="submit" name="range" value="1"  class="filter-btn <?= $range=='1'  && !$custom_from ? 'active' : '' ?>">Today</button>
            <button type="submit" name="range" value="7"  class="filter-btn <?= $range=='7'  && !$custom_from ? 'active' : '' ?>">7 Days</button>
            <button type="submit" name="range" value="30" class="filter-btn <?= $range=='30' && !$custom_from ? 'active' : '' ?>">30 Days</button>
            <button type="submit" name="range" value="90" class="filter-btn <?= $range=='90' && !$custom_from ? 'active' : '' ?>">90 Days</button>
            <button type="submit" name="range" value="365" class="filter-btn <?= $range=='365' && !$custom_from ? 'active' : '' ?>">1 Year</button>
            <input type="date" name="from" class="form-control form-control-sm" style="width:140px" value="<?= $custom_from ?>">
            <input type="date" name="to"   class="form-control form-control-sm" style="width:140px" value="<?= $custom_to ?>">
            <button type="submit" class="btn btn-sm btn-danger px-3">Apply</button>
        </form>
    </div>

    <!-- Today & Month Quick Stats -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3">
            <div class="card metric-card">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <div class="metric-val">PKR <?= number_format($today_rev, 0) ?></div>
                        <div class="metric-lbl">Today's Revenue</div>
                        <div class="metric-sub text-info"><?= $today_orders ?> orders today</div>
                    </div>
                    <div class="metric-icon" style="background:#dbeafe;color:#2563eb"><i class="bi bi-calendar-day"></i></div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card metric-card">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <div class="metric-val">PKR <?= number_format($month_rev, 0) ?></div>
                        <div class="metric-lbl">This Month</div>
                        <div class="metric-sub text-success"><?= $month_orders ?> orders</div>
                    </div>
                    <div class="metric-icon" style="background:#d1fae5;color:#059669"><i class="bi bi-calendar-month"></i></div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card metric-card">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <div class="metric-val">PKR <?= number_format($total_revenue, 0) ?></div>
                        <div class="metric-lbl">Period Revenue</div>
                        <div class="metric-sub text-muted"><?= $total_orders ?> orders</div>
                    </div>
                    <div class="metric-icon" style="background:#fee2e2;color:#B91C1C"><i class="bi bi-cash-stack"></i></div>
                </div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="card metric-card">
                <div class="d-flex justify-content-between align-items-start">
                    <div>
                        <div class="metric-val">PKR <?= number_format($avg_order, 0) ?></div>
                        <div class="metric-lbl">Avg Order Value</div>
                        <div class="metric-sub text-muted"><?= $total_customers ?> customers</div>
                    </div>
                    <div class="metric-icon" style="background:#f3e8ff;color:#9333ea"><i class="bi bi-receipt"></i></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Revenue Chart -->
    <div class="row g-3 mb-4">
        <div class="col-lg-8">
            <div class="card">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h6 class="mb-0 fw-bold"><i class="bi bi-bar-chart me-2 text-danger"></i>Revenue â€” Last 14 Days</h6>
                </div>
                <canvas id="revenueChart" height="100"></canvas>
            </div>
        </div>
        <div class="col-lg-4">
            <div class="card h-100">
                <h6 class="mb-3 fw-bold"><i class="bi bi-pie-chart me-2 text-danger"></i>Order Status</h6>
                <?php
                $statuses = ['pending'=>['warning','clock-history'],'processing'=>['info','truck'],'delivered'=>['success','check-circle'],'cancelled'=>['danger','x-circle']];
                $total_s = array_sum(array_column($status_data, 'cnt')) ?: 1;
                foreach ($statuses as $st => [$color, $icon]):
                    $cnt = $status_data[$st]['cnt'] ?? 0;
                    $rev = $status_data[$st]['rev'] ?? 0;
                    $pct = round($cnt / $total_s * 100);
                ?>
                <div class="mb-3">
                    <div class="d-flex justify-content-between mb-1">
                        <span class="small fw-semibold"><i class="bi bi-<?= $icon ?> text-<?= $color ?> me-1"></i><?= ucfirst($st) ?></span>
                        <span class="small text-muted"><?= $cnt ?> orders (<?= $pct ?>%)</span>
                    </div>
                    <div class="progress">
                        <div class="progress-bar bg-<?= $color ?>" style="width:<?= $pct ?>%"></div>
                    </div>
                    <div class="small text-muted mt-1">PKR <?= number_format($rev, 0) ?></div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Top Products & Payment Methods -->
    <div class="row g-3 mb-4">
        <div class="col-lg-7">
            <div class="card">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h6 class="mb-0 fw-bold"><i class="bi bi-trophy me-2 text-danger"></i>Top Selling Products</h6>
                    <a href="products.php" class="small text-danger text-decoration-none">View All  &rarr;</a>
                </div>
                <?php if ($top_products && $top_products->num_rows > 0): ?>
                <div class="table-responsive">
                <table class="table mb-0">
                    <thead><tr><th>#</th><th>Product</th><th>Category</th><th>Qty Sold</th><th>Revenue</th></tr></thead>
                    <tbody>
                    <?php $rank = 1; while ($p = $top_products->fetch_assoc()): ?>
                    <tr>
                        <td><span class="badge bg-danger"><?= $rank++ ?></span></td>
                        <td class="fw-semibold"><?= htmlspecialchars(substr($p['name'], 0, 35)) ?><?= strlen($p['name']) > 35 ? '...' : '' ?></td>
                        <td><span class="badge bg-light text-dark"><?= ucfirst($p['category']) ?></span></td>
                        <td><strong><?= $p['qty'] ?></strong> units</td>
                        <td class="text-danger fw-bold">PKR <?= number_format($p['rev'], 0) ?></td>
                    </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
                </div>
                <?php else: ?>
                <div class="text-center py-4 text-muted"><i class="bi bi-inbox" style="font-size:2rem;display:block;margin-bottom:.5rem"></i>No sales data for this period</div>
                <?php endif; ?>
            </div>
        </div>
        <div class="col-lg-5">
            <div class="card">
                <h6 class="mb-3 fw-bold"><i class="bi bi-credit-card me-2 text-danger"></i>Payment Methods</h6>
                <?php if (!empty($pm_data)): ?>
                <?php $total_pm = array_sum(array_column($pm_data, 'cnt')) ?: 1; ?>
                <?php foreach ($pm_data as $pm): $pct = round($pm['cnt'] / $total_pm * 100); ?>
                <div class="mb-3">
                    <div class="d-flex justify-content-between mb-1">
                        <span class="small fw-semibold"><?= htmlspecialchars($pm['pm']) ?></span>
                        <span class="small text-muted"><?= $pm['cnt'] ?> (<?= $pct ?>%)</span>
                    </div>
                    <div class="progress">
                        <div class="progress-bar bg-danger" style="width:<?= $pct ?>%;opacity:<?= 0.4 + ($pct/100)*0.6 ?>"></div>
                    </div>
                    <div class="small text-muted mt-1">PKR <?= number_format($pm['rev'], 0) ?></div>
                </div>
                <?php endforeach; ?>
                <?php else: ?>
                <div class="text-center py-4 text-muted">No payment data</div>
                <?php endif; ?>
            </div>

            <!-- Recent Orders -->
            <div class="card mt-3">
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <h6 class="mb-0 fw-bold"><i class="bi bi-clock-history me-2 text-danger"></i>Recent Orders</h6>
                    <a href="orders.php" class="small text-danger text-decoration-none">View All  &rarr;</a>
                </div>
                <?php if ($recent && $recent->num_rows > 0): while ($o = $recent->fetch_assoc()):
                    $badge = ['pending'=>'warning','processing'=>'info','delivered'=>'success','cancelled'=>'danger'][$o['status']] ?? 'secondary';
                ?>
                <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
                    <div>
                        <div class="fw-semibold small"><?= htmlspecialchars($o['cname']) ?></div>
                        <div class="text-muted" style="font-size:.72rem"><?= date('M d, h:i A', strtotime($o['created_at'])) ?></div>
                    </div>
                    <div class="text-end">
                        <div class="fw-bold small text-danger">PKR <?= number_format($o['total_amount'], 0) ?></div>
                        <span class="badge bg-<?= $badge ?>" style="font-size:.65rem"><?= ucfirst($o['status']) ?></span>
                    </div>
                </div>
                <?php endwhile; else: ?>
                <div class="text-center py-3 text-muted small">No recent orders</div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Revenue Chart
const ctx = document.getElementById('revenueChart').getContext('2d');
new Chart(ctx, {
    type: 'bar',
    data: {
        labels: <?= json_encode($chart_labels) ?>,
        datasets: [{
            label: 'Revenue (PKR)',
            data: <?= json_encode($chart_revenue) ?>,
            backgroundColor: 'rgba(185,28,28,0.15)',
            borderColor: '#B91C1C',
            borderWidth: 2,
            borderRadius: 6,
            yAxisID: 'y'
        },{
            label: 'Orders',
            data: <?= json_encode($chart_orders) ?>,
            type: 'line',
            borderColor: '#2563eb',
            backgroundColor: 'rgba(37,99,235,0.1)',
            borderWidth: 2,
            pointRadius: 4,
            pointBackgroundColor: '#2563eb',
            tension: 0.4,
            yAxisID: 'y1'
        }]
    },
    options: {
        responsive: true,
        interaction: { mode: 'index', intersect: false },
        plugins: {
            legend: { position: 'top' },
            tooltip: {
                callbacks: {
                    label: function(c) {
                        if (c.datasetIndex === 0) return ' PKR ' + c.raw.toLocaleString();
                        return ' ' + c.raw + ' orders';
                    }
                }
            }
        },
        scales: {
            y:  { type:'linear', position:'left',  beginAtZero:true, grid:{color:'#f1f5f9'}, ticks:{callback:v=>'PKR '+v.toLocaleString()} },
            y1: { type:'linear', position:'right', beginAtZero:true, grid:{drawOnChartArea:false}, ticks:{stepSize:1} }
        }
    }
});
</script>
</body>
</html>

