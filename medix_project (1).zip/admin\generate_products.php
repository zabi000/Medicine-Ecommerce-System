﻿<?php
// Generate 1000 Medicine Products
require_once('../api/config.php');

if (!$conn) {
    die("Database connection failed!");
}

// Medicine names, types, and categories
$medicine_prefixes = ['Tab', 'Cap', 'Syp', 'Inj', 'Susp', 'Drops', 'Cream', 'Ointment', 'Gel', 'Powder'];
$medicine_names = [
    'Paracetamol', 'Ibuprofen', 'Aspirin', 'Amoxicillin', 'Azithromycin', 'Ciprofloxacin',
    'Metformin', 'Omeprazole', 'Losartan', 'Amlodipine', 'Atorvastatin', 'Simvastatin',
    'Cetirizine', 'Loratadine', 'Montelukast', 'Salbutamol', 'Prednisolone', 'Dexamethasone',
    'Diclofenac', 'Naproxen', 'Tramadol', 'Codeine', 'Morphine', 'Fentanyl',
    'Insulin', 'Glimepiride', 'Gliclazide', 'Metoprolol', 'Bisoprolol', 'Carvedilol',
    'Furosemide', 'Spironolactone', 'Hydrochlorothiazide', 'Ramipril', 'Enalapril', 'Lisinopril',
    'Warfarin', 'Clopidogrel', 'Rivaroxaban', 'Apixaban', 'Digoxin', 'Amiodarone',
    'Levothyroxine', 'Propylthiouracil', 'Carbimazole', 'Calcium', 'Vitamin D', 'Vitamin B12',
    'Folic Acid', 'Iron', 'Zinc', 'Magnesium', 'Potassium', 'Multivitamin'
];

$dosages = ['50mg', '100mg', '200mg', '250mg', '500mg', '1000mg', '5mg', '10mg', '20mg', '40mg', '80mg'];
$categories = ['prescription', 'vitamins', 'firstaid', 'devices', 'personal', 'baby'];
$icons = ['ðŸ’Š', 'ðŸ’‰', 'ðŸ©¹', 'ðŸŒ¡ï¸', 'ðŸ§´', 'ðŸ‘¶'];

echo "<h1>Generating 1000 Products...</h1>";
echo "<hr>";

$inserted = 0;
$errors = 0;

for ($i = 1; $i <= 1000; $i++) {
    // Generate random product
    $prefix = $medicine_prefixes[array_rand($medicine_prefixes)];
    $name = $medicine_names[array_rand($medicine_names)];
    $dosage = $dosages[array_rand($dosages)];
    $category = $categories[array_rand($categories)];
    $icon = $icons[array_rand($icons)];
    
    $product_name = "$prefix $name $dosage";
    $description = "High quality $name medication for effective treatment. Manufactured under strict quality control.";
    
    // PKR prices between 50 and 5000
    $price = rand(50, 5000);
    
    // Stock between 10 and 500
    $stock = rand(10, 500);
    
    // Insert into database
    $stmt = $conn->prepare("INSERT INTO products (name, description, price, category, stock_quantity, icon) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssdsis", $product_name, $description, $price, $category, $stock, $icon);
    
    if ($stmt->execute()) {
        $inserted++;
        if ($i % 100 == 0) {
            echo "<p>âœ“ Inserted $i products...</p>";
            flush();
        }
    } else {
        $errors++;
    }
}

echo "<hr>";
echo "<h2>âœ… Complete!</h2>";
echo "<p><strong>Successfully inserted:</strong> $inserted products</p>";
echo "<p><strong>Errors:</strong> $errors</p>";
echo "<hr>";
echo "<a href='products.php' style='padding: 10px 20px; background: #B91C1C; color: white; text-decoration: none; border-radius: 5px;'>View Products</a>";
echo " ";
echo "<a href='../products.php' style='padding: 10px 20px; background: #6B7280; color: white; text-decoration: none; border-radius: 5px;'>View on Website</a>";
?>

