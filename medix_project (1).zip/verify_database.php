<?php
require_once('api/config.php');

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Database Verification</h1>";

if (!$conn) {
    die("<p style='color: red;'>Database connection failed!</p>");
}

echo "<p style='color: green;'>✓ Database connected successfully</p>";

// Check orders table structure
echo "<h2>Orders Table Structure:</h2>";
$result = $conn->query("DESCRIBE orders");
if ($result) {
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>{$row['Field']}</td>";
        echo "<td>{$row['Type']}</td>";
        echo "<td>{$row['Null']}</td>";
        echo "<td>{$row['Key']}</td>";
        echo "<td>{$row['Default']}</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color: red;'>Orders table not found!</p>";
}

// Check order_items table structure
echo "<h2>Order Items Table Structure:</h2>";
$result = $conn->query("DESCRIBE order_items");
if ($result) {
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>{$row['Field']}</td>";
        echo "<td>{$row['Type']}</td>";
        echo "<td>{$row['Null']}</td>";
        echo "<td>{$row['Key']}</td>";
        echo "<td>{$row['Default']}</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color: red;'>Order_items table not found!</p>";
}

// Count orders
$count_result = $conn->query("SELECT COUNT(*) as count FROM orders");
$count = $count_result->fetch_assoc()['count'];
echo "<h2>Total Orders: $count</h2>";

// Show recent orders
echo "<h2>Recent Orders:</h2>";
$orders = $conn->query("SELECT * FROM orders ORDER BY created_at DESC LIMIT 5");
if ($orders && $orders->num_rows > 0) {
    echo "<table border='1' cellpadding='5'>";
    echo "<tr><th>ID</th><th>User ID</th><th>Total</th><th>Status</th><th>Address</th><th>Created</th></tr>";
    while ($order = $orders->fetch_assoc()) {
        echo "<tr>";
        echo "<td>{$order['id']}</td>";
        echo "<td>{$order['user_id']}</td>";
        echo "<td>PKR " . number_format($order['total_amount'], 2) . "</td>";
        echo "<td>{$order['status']}</td>";
        echo "<td>{$order['shipping_address']}</td>";
        echo "<td>{$order['created_at']}</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>No orders found</p>";
}

echo "<hr>";
echo "<h2>Test Links:</h2>";
echo "<p><a href='products.php'>Add Products to Cart</a></p>";
echo "<p><a href='cart.php'>View Cart</a></p>";
echo "<p><a href='checkout.php'>Checkout</a></p>";
echo "<p><a href='admin/orders.php'>View Orders (Admin)</a></p>";
echo "<p><a href='admin/test_cart_system.php'>Full Diagnostic</a></p>";
?>
