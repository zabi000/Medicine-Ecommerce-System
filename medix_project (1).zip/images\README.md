# Images Directory

## Product Images
Place product images in `products/` folder with naming convention:
- product-1.jpg
- product-2.jpg
- etc.

## Brand Logos
Place brand logos in `brands/` folder with naming convention:
- pfizer.png
- gsk.png
- johnson-johnson.png
- etc.

## Recommended Image Sizes
- Product images: 500x500px (square)
- Brand logos: 200x100px (landscape)

## Supported Formats
- JPG, PNG, WebP
