﻿<?php
// Add 1000 Pakistani Medicine Products
require_once('../api/config.php');

if (!$conn) {
    die("<h1>âŒ Database connection failed!</h1><p>Please import database first: <a href='setup.php'>Go to Setup</a></p>");
}

set_time_limit(300); // 5 minutes

echo "<!DOCTYPE html><html><head><title>Adding 1000 Products</title>";
echo "<style>body{font-family:Arial;padding:20px;background:#f5f5f5;}";
echo ".progress{background:#e0e0e0;height:30px;border-radius:5px;overflow:hidden;}";
echo ".bar{background:#B91C1C;height:100%;transition:width 0.3s;color:white;text-align:center;line-height:30px;}";
echo "</style></head><body>";

echo "<h1>ðŸ¥ Adding 1000 Medicine Products</h1><hr>";

// Real Pakistani Medicines
$medicines = [
    // Pain & Fever
    ['Panadol', 'Paracetamol 500mg', 'prescription', 15, 200],
    ['Disprin', 'Aspirin 300mg', 'prescription', 12, 180],
    ['Brufen', 'Ibuprofen 400mg', 'prescription', 25, 150],
    ['Ponstan', 'Mefenamic Acid 500mg', 'prescription', 35, 120],
    ['Calpol', 'Paracetamol Suspension', 'prescription', 85, 100],
    
    // Antibiotics
    ['Augmentin', 'Amoxicillin 625mg', 'prescription', 180, 80],
    ['Zithromax', 'Azithromycin 500mg', 'prescription', 250, 60],
    ['Ciproxin', 'Ciprofloxacin 500mg', 'prescription', 120, 90],
    ['Flagyl', 'Metronidazole 400mg', 'prescription', 45, 110],
    ['Cefspan', 'Cefixime 200mg', 'prescription', 195, 70],
    
    // Diabetes
    ['Glucophage', 'Metformin 500mg', 'prescription', 65, 200],
    ['Diamicron', 'Gliclazide 80mg', 'prescription', 145, 90],
    ['Amaryl', 'Glimepiride 2mg', 'prescription', 125, 85],
    ['Januvia', 'Sitagliptin 100mg', 'prescription', 850, 40],
    
    // Blood Pressure
    ['Concor', 'Bisoprolol 5mg', 'prescription', 95, 100],
    ['Norvasc', 'Amlodipine 5mg', 'prescription', 75, 120],
    ['Diovan', 'Valsartan 80mg', 'prescription', 185, 70],
    ['Lasix', 'Furosemide 40mg', 'prescription', 35, 150],
    
    // Vitamins
    ['Centrum', 'Multivitamin', 'vitamins', 450, 80],
    ['Neurobion', 'Vitamin B Complex', 'vitamins', 125, 100],
    ['Ossopan', 'Calcium 500mg', 'vitamins', 285, 90],
    ['Fefol', 'Iron + Folic Acid', 'vitamins', 95, 110],
    ['Evion', 'Vitamin E 400IU', 'vitamins', 165, 75],
];

$generated = 0;
$batch_size = 50;

echo "<div class='progress'><div class='bar' id='progressBar'>0%</div></div>";
echo "<p id='status'>Starting...</p>";
echo "<script>function updateProgress(p,s){document.getElementById('progressBar').style.width=p+'%';document.getElementById('progressBar').innerText=p+'%';document.getElementById('status').innerText=s;}</script>";

for ($i = 1; $i <= 1000; $i++) {
    $base = $medicines[array_rand($medicines)];
    
    // Create variations
    $variations = ['Tab', 'Cap', 'Syp', 'Inj', 'Susp'];
    $dosages = ['50mg', '100mg', '200mg', '250mg', '500mg', '1000mg'];
    $brands = ['', 'Plus', 'Forte', 'SR', 'XR', 'DS', 'MR'];
    
    $variation = $variations[array_rand($variations)];
    $brand_suffix = $brands[array_rand($brands)];
    $dosage = $dosages[array_rand($dosages)];
    
    $name = $variation . ' ' . $base[0] . ($brand_suffix ? ' ' . $brand_suffix : '') . ' ' . $dosage;
    $description = $base[1] . ' - High quality pharmaceutical product. Manufactured under GMP standards.';
    $category = $base[2];
    
    // PKR prices with variation
    $base_price = $base[3];
    $price = $base_price + rand(-10, 50);
    if ($price < 10) $price = 10;
    
    // Stock
    $stock = rand(20, 300);
    
    // Icon based on category
    $icons = [
        'prescription' => 'ðŸ’Š',
        'vitamins' => 'ðŸ’‰',
        'firstaid' => 'ðŸ©¹',
        'devices' => 'ðŸŒ¡ï¸',
        'personal' => 'ðŸ§´',
        'baby' => 'ðŸ‘¶'
    ];
    $icon = $icons[$category];
    
    // Insert
    $stmt = $conn->prepare("INSERT INTO products (name, description, price, category, stock_quantity, icon) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssdsis", $name, $description, $price, $category, $stock, $icon);
    
    if ($stmt->execute()) {
        $generated++;
    }
    
    // Update progress every 50 products
    if ($i % $batch_size == 0) {
        $percent = round(($i / 1000) * 100);
        echo "<script>updateProgress($percent, 'Inserted $i / 1000 products...');</script>";
        flush();
        ob_flush();
    }
}

echo "<script>updateProgress(100, 'Complete!');</script>";
echo "<hr>";
echo "<h2>âœ… Successfully Added $generated Products!</h2>";
echo "<p><strong>Total Products:</strong> $generated medicines in PKR</p>";
echo "<p><strong>Price Range:</strong> PKR 10 - PKR 5000</p>";
echo "<p><strong>Stock Range:</strong> 20 - 300 units</p>";
echo "<hr>";
echo "<a href='products.php' style='padding:15px 30px;background:#B91C1C;color:white;text-decoration:none;border-radius:8px;display:inline-block;margin:10px;'>ðŸ“¦ View in Admin</a>";
echo "<a href='../products.php' style='padding:15px 30px;background:#10B981;color:white;text-decoration:none;border-radius:8px;display:inline-block;margin:10px;'>ðŸ›’ View on Website</a>";
echo "<a href='setup.php' style='padding:15px 30px;background:#6B7280;color:white;text-decoration:none;border-radius:8px;display:inline-block;margin:10px;'>âš™ï¸ Back to Setup</a>";
echo "</body></html>";
?>

