# 🔧 Fix Messages Blank Page

## Problem
The admin messages page shows a blank page.

## Possible Causes & Solutions

### 1. Table Doesn't Exist Yet

**Solution:** Run the setup script
```
http://localhost/setup_contact_messages.php
```

This will create the `contact_messages` table.

---

### 2. Check What's Wrong

**Run the debug script:**
```
http://localhost/admin/test_messages.php
```

This will show you:
- ✅ Database connection status
- ✅ If table exists
- ✅ Table structure
- ✅ Message count
- ✅ Recent messages
- ✅ Admin login status

---

### 3. PHP Errors Hidden

**Enable error display:**

Add to top of `admin/messages.php`:
```php
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
```

Then refresh the page to see any errors.

---

### 4. Database Connection Issue

**Check `api/config.php`:**
```php
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'your_database_name';
```

Make sure these are correct.

---

### 5. Admin Not Logged In

**Login first:**
```
http://localhost/admin/login.php
```

Default credentials (if using test setup):
- Username: admin
- Password: admin123

---

## Quick Fix Steps

### Step 1: Run Setup
```
http://localhost/setup_contact_messages.php
```

### Step 2: Check Debug
```
http://localhost/admin/test_messages.php
```

### Step 3: Login to Admin
```
http://localhost/admin/login.php
```

### Step 4: View Messages
```
http://localhost/admin/messages.php
```

---

## If Still Blank

### Check Browser Console
1. Open browser (F12)
2. Go to Console tab
3. Look for JavaScript errors

### Check PHP Error Log
Look in your server error log:
- XAMPP: `xampp/apache/logs/error.log`
- WAMP: `wamp/logs/php_error.log`

### Manual Table Creation

If setup script fails, run this SQL manually in phpMyAdmin:

```sql
CREATE TABLE IF NOT EXISTS contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    email VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    subject VARCHAR(100) NOT NULL,
    message TEXT NOT NULL,
    status ENUM('new', 'read', 'replied') DEFAULT 'new',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
```

---

## Test the System

### 1. Submit a Test Message
```
http://localhost/contact.html
```
Fill out and submit the form.

### 2. Check Debug Page
```
http://localhost/admin/test_messages.php
```
Should show 1 message.

### 3. View in Admin
```
http://localhost/admin/messages.php
```
Should show the message.

---

## Common Issues

### Issue: "Table doesn't exist"
**Fix:** Run `setup_contact_messages.php`

### Issue: "Access denied"
**Fix:** Check database credentials in `api/config.php`

### Issue: "Not logged in"
**Fix:** Login at `admin/login.php`

### Issue: "Blank page, no errors"
**Fix:** Enable PHP error display

---

## Success Indicators

When working correctly, you should see:
- ✅ Statistics cards (Total, New, Read, Replied)
- ✅ Filter buttons
- ✅ Message cards (if any messages exist)
- ✅ "No messages found" if empty (not blank page)

---

## Need More Help?

1. Run debug script: `admin/test_messages.php`
2. Check what it reports
3. Follow the specific fix for your issue

The debug script will tell you exactly what's wrong!
