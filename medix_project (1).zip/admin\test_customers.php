﻿<?php
// Simple test to see what's happening
session_start();

// Bypass login for testing
$_SESSION['admin_logged_in'] = true;

echo "<h1>Testing Customers Page</h1>";
echo "<hr>";

// Test database connection
require_once('../api/config.php');

echo "<h2>1. Database Connection Test:</h2>";
if ($conn) {
    echo "âœ… Database connection exists<br>";
} else {
    echo "âŒ No database connection (this is OK - we'll use fake data)<br>";
}

echo "<hr>";

// Test query
echo "<h2>2. Query Test:</h2>";
$result = @$conn->query("SELECT u.*, COUNT(o.id) as total_orders, SUM(o.total_amount) as total_spent FROM users u LEFT JOIN orders o ON u.id = o.user_id GROUP BY u.id ORDER BY u.created_at DESC");

if ($result && $result->num_rows > 0) {
    echo "âœ… Found " . $result->num_rows . " customers in database<br>";
} else {
    echo "âŒ No customers in database (will use fake data)<br>";
}

echo "<hr>";

// Create fake data
echo "<h2>3. Fake Data Test:</h2>";
if (!$result || $result->num_rows == 0) {
    $fake_customers = [
        ['id' => 1, 'username' => 'Ahmed Khan', 'email' => 'ahmed.khan@email.com', 'phone' => '+92-300-1234567', 'total_orders' => 12, 'total_spent' => 15678.50, 'created_at' => '2024-01-15'],
        ['id' => 2, 'username' => 'Fatima Ali', 'email' => 'fatima.ali@email.com', 'phone' => '+92-321-9876543', 'total_orders' => 8, 'total_spent' => 9234.00, 'created_at' => '2024-02-20'],
    ];
    
    echo "âœ… Created fake data with " . count($fake_customers) . " customers<br>";
    echo "<pre>";
    print_r($fake_customers);
    echo "</pre>";
}

echo "<hr>";
echo "<h2>4. Result:</h2>";
echo "<a href='customers.php' style='padding: 10px 20px; background: #B91C1C; color: white; text-decoration: none; border-radius: 5px;'>Go to Customers Page</a>";
?>

