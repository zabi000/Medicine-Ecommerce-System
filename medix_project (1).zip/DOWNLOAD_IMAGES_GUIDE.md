# 📸 How to Add Real Medicine Images & Ads

## 🎯 Quick Start - Download Real Medicine Images

### Step 1: Download Product Images

Visit these FREE stock photo sites and download medicine images:

#### **Unsplash** (Best Quality)
1. Go to: https://unsplash.com/s/photos/medicine
2. Search for:
   - "paracetamol bottle"
   - "vitamin pills"
   - "first aid kit"
   - "thermometer"
   - "blood pressure monitor"
   - "medicine bottle"
   - "pills blister pack"
   - "hand sanitizer"
   - "face mask"
   - "medical device"

#### **Pexels** (Free Commercial Use)
1. Go to: https://www.pexels.com/search/pharmacy/
2. Download images for each product category

#### **Pixabay** (No Attribution Required)
1. Go to: https://pixabay.com/images/search/medicine/
2. Filter by "Photos" only

### Step 2: Prepare Images

1. **Download** high-quality images (at least 800x800px)
2. **Rename** them exactly as:
   ```
   product-1.jpg  → Paracetamol
   product-2.jpg  → Ibuprofen
   product-3.jpg  → Vitamin C
   product-4.jpg  → First Aid Kit
   product-5.jpg  → Digital Thermometer
   product-6.jpg  → Vitamin D3
   product-7.jpg  → Bandages
   product-8.jpg  → Blood Pressure Monitor
   product-9.jpg  → Aspirin
   product-10.jpg → Multivitamin
   product-11.jpg → Hand Sanitizer
   product-12.jpg → Face Masks
   product-13.jpg → Omega-3
   product-14.jpg → Glucose Meter
   product-15.jpg → Antiseptic Cream
   product-16.jpg → Calcium
   product-17.jpg → Pulse Oximeter
   product-18.jpg → Cough Syrup
   product-19.jpg → Probiotic
   product-20.jpg → Infrared Thermometer
   ```

3. **Place** all images in: `C:\xampp\htdocs\ppp\images\products\`

### Step 3: Optimize Images (Optional but Recommended)

Use online tools to compress images:
- **TinyPNG**: https://tinypng.com/
- **Squoosh**: https://squoosh.app/
- Target size: 100-200KB per image

---

## 🎨 Download Brand Logos

### Pharmaceutical Company Logos

Download official logos from:

1. **Pfizer**: Search "Pfizer logo PNG transparent"
2. **GSK**: Search "GSK logo PNG"
3. **Johnson & Johnson**: Search "Johnson and Johnson logo PNG"
4. **Novartis**: Search "Novartis logo PNG"
5. **Bayer**: Search "Bayer logo PNG"
6. **Abbott**: Search "Abbott logo PNG"
7. **Roche**: Search "Roche logo PNG"
8. **Merck**: Search "Merck logo PNG"

**Save as:**
```
pfizer.png
gsk.png
johnson-johnson.png
novartis.png
bayer.png
abbott.png
roche.png
merck.png
```

**Place in:** `C:\xampp\htdocs\ppp\images\brands\`

---

## 📢 Create Advertisement Banners

### Option 1: Use Canva (Free & Easy)

1. Go to: https://www.canva.com/
2. Create account (free)
3. Search templates: "Pharmacy Banner" or "Medical Ad"
4. Customize with your text:
   - "50% OFF on Vitamins"
   - "Free Delivery on Orders Over $50"
   - "New Arrivals - Check Now"
5. Download as JPG (1200x400px)
6. Save as: `ad-1.jpg`, `ad-2.jpg`, `ad-3.jpg`

### Option 2: Download Free Ad Templates

Visit:
- **Freepik**: https://www.freepik.com/free-photos-vectors/pharmacy-banner
- **Vecteezy**: https://www.vecteezy.com/free-vector/pharmacy-banner

### Option 3: Use AI Image Generators

- **Bing Image Creator**: https://www.bing.com/images/create
- Prompt: "Professional pharmacy advertisement banner, blue theme, medicine products, modern design"

**Save ads as:**
```
ad-banner-1.jpg  (1200x400px)
ad-banner-2.jpg  (1200x400px)
ad-banner-3.jpg  (1200x400px)
```

**Place in:** `C:\xampp\htdocs\ppp\images\ads\`

---

## 🚀 Quick Download Links

### Recommended Free Images:

**Medicine Bottles:**
- https://unsplash.com/photos/white-medication-pill-on-green-plastic-container-nss2eRzQwgw
- https://unsplash.com/photos/person-holding-amber-glass-bottle-UOwvwZ9Dy6w

**Vitamins:**
- https://unsplash.com/photos/yellow-and-white-plastic-bottle-505eectW54k
- https://unsplash.com/photos/orange-medication-pill-on-persons-hand-L8tWZT4CcVQ

**Medical Devices:**
- https://unsplash.com/photos/white-and-black-digital-device-rDLBArZUl1c
- https://unsplash.com/photos/person-holding-white-and-blue-plastic-bottle-8YG31Xn4dSw

**First Aid:**
- https://unsplash.com/photos/red-and-white-plastic-pack-lot-aJTiW00qqtI

---

## ✅ Verification Checklist

After adding images, check:

- [ ] All 20 product images in `images/products/`
- [ ] All 8 brand logos in `images/brands/`
- [ ] At least 3 ad banners in `images/ads/`
- [ ] Images are JPG or PNG format
- [ ] File names match exactly (case-sensitive)
- [ ] Images load on website (refresh browser)

---

## 🎯 Expected Result

Once you add images:
- ✅ Real medicine photos on product cards
- ✅ Professional brand logos
- ✅ Rotating advertisement banners
- ✅ Professional pharmacy look
- ✅ Faster loading with optimized images

---

## 💡 Pro Tips

1. **Use white background** images for products
2. **Compress images** before uploading (use TinyPNG)
3. **Keep consistent** image sizes
4. **Use PNG** for logos (transparent background)
5. **Use JPG** for photos (smaller file size)
6. **Test on mobile** after adding images

---

## 🆘 Need Help?

If images don't show:
1. Check file names (must be exact)
2. Check file location (correct folder)
3. Clear browser cache (Ctrl + Shift + R)
4. Check file permissions (should be readable)
5. Open browser console (F12) to see errors

---

## 📱 Mobile App Screenshots

For the hero section, you can also add:
- Pharmacy app screenshots
- Mobile interface mockups
- Download from: https://www.mockupworld.co/free/category/mobile/

Save as: `app-screenshot.png` in `images/`
