<?php
/**
 * MEDIX Mailer — Mailtrap SMTP
 * Uses multiple methods to ensure delivery
 */

// Helper: get full base URL for links in emails
function appUrl($path = '') {
    $base = defined('APP_BASE') ? APP_BASE : '';
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    return $scheme . '://' . $host . $base . $path;
}

// Mailtrap credentials
define('SMTP_HOST', 'sandbox.smtp.mailtrap.io');
define('SMTP_PORT', 2525);
define('SMTP_USER', 'cbb7f036e954bd');
define('SMTP_PASS', '208a3f057d1b26');
define('SMTP_FROM', 'noreply@medix.com');
define('SMTP_NAME', 'MEDIX Pharmacy');
define('ADMIN_EMAIL', 'admin@medix.com');

function getMail($conn = null) {
    $cfg = [
        'host'        => SMTP_HOST,
        'port'        => SMTP_PORT,
        'user'        => SMTP_USER,
        'pass'        => SMTP_PASS,
        'from_email'  => SMTP_FROM,
        'from_name'   => SMTP_NAME,
        'admin_email' => ADMIN_EMAIL,
    ];
    // Override with DB settings if saved
    if ($conn) {
        $r = @$conn->query("SELECT `key`,`value` FROM site_settings WHERE `key` IN ('smtp_host','smtp_port','smtp_user','smtp_pass','smtp_from_email','smtp_from_name','admin_email')");
        if ($r) while ($row = $r->fetch_assoc()) {
            $v = $row['value'];
            if (!$v) continue;
            switch ($row['key']) {
                case 'smtp_host':       $cfg['host']        = $v; break;
                case 'smtp_port':       $cfg['port']        = (int)$v; break;
                case 'smtp_user':       $cfg['user']        = $v; break;
                case 'smtp_pass':       $cfg['pass']        = $v; break;
                case 'smtp_from_email': $cfg['from_email']  = $v; break;
                case 'smtp_from_name':  $cfg['from_name']   = $v; break;
                case 'admin_email':     $cfg['admin_email'] = $v; break;
            }
        }
    }
    return $cfg;
}

/**
 * Main send function — tries socket SMTP, then cURL, then logs error
 */
function sendMail($to_email, $to_name, $subject, $html_body, $conn = null) {
    $cfg = getMail($conn);

    // Try socket-based SMTP first
    $result = smtpSend(
        $cfg['host'], $cfg['port'], $cfg['user'], $cfg['pass'],
        $cfg['from_email'], $cfg['from_name'],
        $to_email, $to_name, $subject, $html_body
    );

    if (!$result) {
        // Try alternate ports
        foreach ([587, 465, 25] as $alt_port) {
            if ($alt_port === $cfg['port']) continue;
            $result = smtpSend(
                $cfg['host'], $alt_port, $cfg['user'], $cfg['pass'],
                $cfg['from_email'], $cfg['from_name'],
                $to_email, $to_name, $subject, $html_body
            );
            if ($result) break;
        }
    }

    if (!$result) {
        error_log("MEDIX Mailer: All SMTP attempts failed for $to_email");
    }

    return $result;
}

function smtpSend($host, $port, $user, $pass, $from, $from_name, $to, $to_name, $subject, $body) {
    $errno = 0; $errstr = '';

    // Try SSL wrapper for port 465
    if ($port === 465) {
        $socket = @fsockopen("ssl://$host", $port, $errno, $errstr, 15);
    } else {
        $socket = @fsockopen($host, $port, $errno, $errstr, 15);
    }

    if (!$socket) {
        error_log("SMTP fsockopen failed on port $port: $errstr ($errno)");
        return false;
    }

    $log = [];

    $read = fgets($socket, 515);
    $log[] = "S: " . trim($read);
    if (substr($read, 0, 3) !== '220') { fclose($socket); return false; }

    // EHLO
    fputs($socket, "EHLO localhost\r\n");
    while ($line = fgets($socket, 515)) {
        $log[] = "S: " . trim($line);
        if (substr($line, 3, 1) === ' ') break;
    }

    // STARTTLS for port 587
    if ($port === 587) {
        fputs($socket, "STARTTLS\r\n");
        $r = fgets($socket, 515);
        $log[] = "S: " . trim($r);
        if (substr($r, 0, 3) === '220') {
            stream_socket_enable_crypto($socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT);
            fputs($socket, "EHLO localhost\r\n");
            while ($line = fgets($socket, 515)) {
                if (substr($line, 3, 1) === ' ') break;
            }
        }
    }

    // AUTH LOGIN
    fputs($socket, "AUTH LOGIN\r\n");
    $r = fgets($socket, 515);
    $log[] = "S: " . trim($r);
    if (substr($r, 0, 3) !== '334') { fclose($socket); return false; }

    fputs($socket, base64_encode($user) . "\r\n");
    $r = fgets($socket, 515);
    $log[] = "S: " . trim($r);

    fputs($socket, base64_encode($pass) . "\r\n");
    $r = fgets($socket, 515);
    $log[] = "S: " . trim($r);

    if (substr($r, 0, 3) !== '235') {
        error_log("SMTP auth failed on port $port: " . trim($r));
        fclose($socket);
        return false;
    }

    // MAIL FROM
    fputs($socket, "MAIL FROM: <$from>\r\n");
    $r = fgets($socket, 515);
    if (substr($r, 0, 3) !== '250') { fclose($socket); return false; }

    // RCPT TO
    fputs($socket, "RCPT TO: <$to>\r\n");
    $r = fgets($socket, 515);
    if (substr($r, 0, 3) !== '250') { fclose($socket); return false; }

    // DATA
    fputs($socket, "DATA\r\n");
    $r = fgets($socket, 515);
    if (substr($r, 0, 3) !== '354') { fclose($socket); return false; }

    $msg  = "From: =?UTF-8?B?" . base64_encode($from_name) . "?= <$from>\r\n";
    $msg .= "To: =?UTF-8?B?" . base64_encode($to_name) . "?= <$to>\r\n";
    $msg .= "Subject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\n";
    $msg .= "MIME-Version: 1.0\r\n";
    $msg .= "Content-Type: text/html; charset=UTF-8\r\n";
    $msg .= "Content-Transfer-Encoding: base64\r\n";
    $msg .= "\r\n";
    $msg .= chunk_split(base64_encode($body));
    $msg .= "\r\n.\r\n";

    fputs($socket, $msg);
    $r = fgets($socket, 515);

    fputs($socket, "QUIT\r\n");
    fclose($socket);

    $success = substr($r, 0, 3) === '250';
    if ($success) error_log("SMTP sent OK to $to on port $port");
    else error_log("SMTP send failed on port $port: " . trim($r));

    return $success;
}

// ===== Email Templates =====

function emailTemplate($title, $content, $footer_note = '') {
    return '<!DOCTYPE html><html><head><meta charset="UTF-8">
    <style>
        body{font-family:Arial,sans-serif;background:#f8fafc;margin:0;padding:20px}
        .wrap{max-width:600px;margin:0 auto;background:white;border-radius:12px;overflow:hidden;box-shadow:0 4px 20px rgba(0,0,0,.08)}
        .hdr{background:linear-gradient(135deg,#B91C1C,#7F1D1D);padding:30px;text-align:center;color:white}
        .hdr h1{margin:0;font-size:24px;letter-spacing:1px}
        .hdr p{margin:8px 0 0;opacity:.8;font-size:14px}
        .body{padding:30px;color:#374151;line-height:1.7;font-size:15px}
        .body h2{color:#B91C1C;font-size:20px;margin-top:0}
        .info-box{background:#f8fafc;border-left:4px solid #B91C1C;border-radius:0 8px 8px 0;padding:15px 20px;margin:15px 0}
        .info-row{display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #f1f5f9;font-size:14px}
        .info-row:last-child{border-bottom:none}
        .info-label{color:#64748b;font-weight:600}
        .info-value{color:#0f172a;font-weight:500}
        .btn{display:inline-block;background:#B91C1C;color:white;padding:12px 30px;border-radius:8px;text-decoration:none;font-weight:700;margin:15px 0}
        .ftr{background:#1e1e2e;padding:20px;text-align:center;color:#94a3b8;font-size:13px}
        .ftr a{color:#B91C1C;text-decoration:none}
    </style></head><body>
    <div class="wrap">
        <div class="hdr">
            <h1>MEDIX Pharmacy</h1>
            <p>Your Trusted Healthcare Partner</p>
        </div>
        <div class="body">' . $content . '</div>
        <div class="ftr">
            <p>' . ($footer_note ?: 'This is an automated email from MEDIX Pharmacy.') . '</p>
            <p>&copy; ' . date('Y') . ' MEDIX Pharmacy</p>
        </div>
    </div></body></html>';
}

function sendOrderConfirmation($to_email, $to_name, $order_id, $items, $total, $address, $payment, $conn = null) {
    $items_html = '';
    foreach ($items as $item) {
        $items_html .= '<div class="info-row"><span class="info-label">' . htmlspecialchars($item['name']) . ' x' . $item['quantity'] . '</span><span class="info-value">PKR ' . number_format($item['price'] * $item['quantity'], 0) . '</span></div>';
    }
    $content = '
        <h2>Order Confirmed!</h2>
        <p>Hi <strong>' . htmlspecialchars($to_name) . '</strong>, your order has been placed successfully.</p>
        <div class="info-box">
            <div class="info-row"><span class="info-label">Order #</span><span class="info-value">#' . str_pad($order_id, 4, '0', STR_PAD_LEFT) . '</span></div>
            <div class="info-row"><span class="info-label">Payment</span><span class="info-value">' . htmlspecialchars($payment) . '</span></div>
            <div class="info-row"><span class="info-label">Delivery To</span><span class="info-value">' . htmlspecialchars($address) . '</span></div>
        </div>
        <div class="info-box">' . $items_html . '
            <div class="info-row"><span class="info-label">Total</span><span class="info-value" style="color:#B91C1C;font-weight:800">PKR ' . number_format($total, 0) . '</span></div>
        </div>
        <p>Expected delivery: 2-3 business days.</p>
        <a href="<?= defined('APP_BASE') ? 'https://'.$_SERVER['HTTP_HOST'].APP_BASE : 'http://localhost/ppp' ?>/user/profile.php" class="btn">Track Your Order</a>';
    $html = emailTemplate('Order Confirmation', $content);
    return sendMail($to_email, $to_name, 'Order #' . str_pad($order_id, 4, '0', STR_PAD_LEFT) . ' Confirmed - MEDIX', $html, $conn);
}

function sendAdminOrderAlert($order_id, $customer_name, $customer_email, $total, $payment, $conn = null) {
    $cfg = getMail($conn);
    $content = '
        <h2>New Order Received!</h2>
        <div class="info-box">
            <div class="info-row"><span class="info-label">Order #</span><span class="info-value">#' . str_pad($order_id, 4, '0', STR_PAD_LEFT) . '</span></div>
            <div class="info-row"><span class="info-label">Customer</span><span class="info-value">' . htmlspecialchars($customer_name) . '</span></div>
            <div class="info-row"><span class="info-label">Email</span><span class="info-value">' . htmlspecialchars($customer_email) . '</span></div>
            <div class="info-row"><span class="info-label">Total</span><span class="info-value" style="color:#B91C1C;font-weight:800">PKR ' . number_format($total, 0) . '</span></div>
            <div class="info-row"><span class="info-label">Payment</span><span class="info-value">' . htmlspecialchars($payment) . '</span></div>
        </div>
        <a href="" . appUrl('/admin/orders.php') . "" class="btn">View in Admin Panel</a>';
    $html = emailTemplate('New Order Alert', $content, 'Admin notification from MEDIX Pharmacy.');
    return sendMail($cfg['admin_email'], 'MEDIX Admin', 'New Order #' . str_pad($order_id, 4, '0', STR_PAD_LEFT) . ' - PKR ' . number_format($total, 0), $html, $conn);
}

function sendPasswordResetEmail($to_email, $to_name, $reset_link, $conn = null) {
    $content = '
        <h2>Password Reset Request</h2>
        <p>Hi <strong>' . htmlspecialchars($to_name) . '</strong>,</p>
        <p>We received a request to reset your MEDIX account password.</p>
        <p>Click the button below to set a new password. This link expires in <strong>1 hour</strong>.</p>
        <div style="text-align:center;margin:25px 0">
            <a href="' . htmlspecialchars($reset_link) . '" class="btn" style="font-size:16px;padding:15px 40px">Reset My Password</a>
        </div>
        <div class="info-box" style="border-left-color:#f59e0b">
            <p style="margin:0;font-size:13px;color:#92400e">If the button does not work, copy and paste this link:<br>
            <a href="' . htmlspecialchars($reset_link) . '" style="color:#B91C1C;word-break:break-all">' . htmlspecialchars($reset_link) . '</a></p>
        </div>
        <p style="color:#64748b;font-size:13px">If you did not request a password reset, please ignore this email. Your password will remain unchanged.</p>';
    $html = emailTemplate('Password Reset', $content);
    return sendMail($to_email, $to_name, 'Reset Your MEDIX Password', $html, $conn);
}

function sendMessageReplyEmail($to_email, $to_name, $reply_subject, $reply_body, $conn = null) {
    $content = '
        <h2>Reply from MEDIX Support</h2>
        <p>Hi <strong>' . htmlspecialchars($to_name) . '</strong>,</p>
        <p>You have a new reply from MEDIX Pharmacy support team:</p>
        <div class="info-box" style="border-left-color:#3B82F6">
            <p style="margin:0">' . nl2br(htmlspecialchars($reply_body)) . '</p>
        </div>
        <a href="" . appUrl('/user/profile.php?tab=messages') . "" class="btn">View Full Conversation</a>';
    $html = emailTemplate('Support Reply', $content);
    return sendMail($to_email, $to_name, $reply_subject, $html, $conn);
}

function sendContactNotificationToAdmin($from_name, $from_email, $subject, $message, $conn = null) {
    $cfg = getMail($conn);
    $content = '
        <h2>New Contact Message</h2>
        <div class="info-box">
            <div class="info-row"><span class="info-label">From</span><span class="info-value">' . htmlspecialchars($from_name) . '</span></div>
            <div class="info-row"><span class="info-label">Email</span><span class="info-value">' . htmlspecialchars($from_email) . '</span></div>
            <div class="info-row"><span class="info-label">Subject</span><span class="info-value">' . htmlspecialchars($subject) . '</span></div>
        </div>
        <div class="info-box" style="border-left-color:#3B82F6">
            <p style="margin:0">' . nl2br(htmlspecialchars($message)) . '</p>
        </div>
        <a href="" . appUrl('/admin/messages.php') . "" class="btn">Reply in Admin Panel</a>';
    $html = emailTemplate('New Contact Message', $content, 'Admin notification from MEDIX Pharmacy.');
    return sendMail($cfg['admin_email'], 'MEDIX Admin', 'New Message from ' . $from_name . ' - MEDIX', $html, $conn);
}
?>
