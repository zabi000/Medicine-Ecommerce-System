<?php
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');
ini_set('session.gc_maxlifetime', 28800);
session_set_cookie_params(['lifetime' => 28800, 'path' => '/', 'samesite' => 'Lax']);
session_start();
if (isset($_SESSION['user_id']) && $_SESSION['user_id'] > 0) {
    echo json_encode([
        'logged_in' => true,
        'name'      => $_SESSION['user_name'] ?? 'User',
        'email'     => $_SESSION['user_email'] ?? ''
    ]);
} else {
    echo json_encode(['logged_in' => false]);
}
?>
