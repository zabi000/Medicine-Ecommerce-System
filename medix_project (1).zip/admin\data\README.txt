PLACE YOUR KAGGLE CSV FILE HERE
================================

Instructions:
1. Download the CSV from: https://www.kaggle.com/datasets/muhammadabdullah222/pakistan-medicines-dataset
2. Extract the ZIP file
3. Place the CSV file in this folder as: pakistan_medicines.csv

Expected file location:
admin/data/pakistan_medicines.csv

Then run the import script:
http://localhost/your-project/import_kaggle_medicines.php

Or open:
IMPORT_KAGGLE_DATA.html
