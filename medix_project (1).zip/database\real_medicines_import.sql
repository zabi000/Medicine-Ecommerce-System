-- ============================================
-- MEDIX PHARMACY - REAL MEDICINES DATABASE
-- Import this file in phpMyAdmin
-- ============================================

-- Create database
CREATE DATABASE IF NOT EXISTS medicare_db;
USE medicare_db;

-- Drop existing tables to start fresh
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS medicines;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS companies;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS users;

-- ============================================
-- CREATE TABLES
-- ============================================

-- 1. Create Users Table (For Login)
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    password VARCHAR(255) NOT NULL,
    role ENUM('admin', 'customer') DEFAULT 'customer',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Create Companies Table (For Logos)
CREATE TABLE companies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    logo_url VARCHAR(255), -- URL to the company logo image
    website VARCHAR(100)
);

-- 3. Create Categories Table
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. Create Medicines Table (With Product Details)
CREATE TABLE medicines (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    category VARCHAR(50),
    price DECIMAL(10,2) NOT NULL,
    stock INT DEFAULT 0,
    company_id INT,
    description TEXT,
    image_url VARCHAR(255),
    FOREIGN KEY (company_id) REFERENCES companies(id)
);

-- 5. Create Products Table (For compatibility with existing code)
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    category VARCHAR(50) NOT NULL,
    stock INT DEFAULT 0,
    stock_quantity INT DEFAULT 0,
    icon VARCHAR(10) DEFAULT '💊',
    company_id INT,
    image_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (company_id) REFERENCES companies(id)
);

-- 6. Create Orders Table (For Checkout)
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    order_number VARCHAR(50),
    customer_name VARCHAR(100),
    customer_email VARCHAR(100),
    customer_phone VARCHAR(20),
    customer_address TEXT,
    payment_method VARCHAR(50),
    total_amount DECIMAL(10,2),
    status VARCHAR(50) DEFAULT 'pending',
    shipping_address TEXT,
    order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- 7. Create Order Items Table
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT,
    product_name VARCHAR(200),
    quantity INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- =============================================
-- DATA INSERTION (Real Medicine & Logos)
-- =============================================

-- Insert Admin User (Password: admin123)
INSERT INTO users (username, name, email, password, role) VALUES 
('admin', 'Admin', 'admin@medix.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- Insert Sample Customer
INSERT INTO users (username, name, email, phone, password, role) VALUES 
('customer1', 'John Doe', 'john@example.com', '+92 300 1234567', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'customer');

-- Insert Companies (With Real Logos)
INSERT INTO companies (name, logo_url, website) VALUES
('GSK', 'https://upload.wikimedia.org/wikipedia/en/thumb/5/5e/GSK_logo_2022.svg/1200px-GSK_logo_2022.svg.png', 'www.gsk.com'),
('Pfizer', 'https://upload.wikimedia.org/wikipedia/commons/5/57/Pfizer_%282021%29.svg', 'www.pfizer.com'),
('Abbott', 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/c5/Abbott_Laboratories_Logo.svg/1200px-Abbott_Laboratories_Logo.svg.png', 'www.abbott.com'),
('Novartis', 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/03/Novartis_Logo.svg/1200px-Novartis_Logo.svg.png', 'www.novartis.com'),
('Bayer', 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f7/Bayer_logo.svg/1200px-Bayer_logo.svg.png', 'www.bayer.com'),
('Johnson & Johnson', 'https://upload.wikimedia.org/wikipedia/commons/thumb/0/0e/Johnson_%26_Johnson_Logo.svg/1200px-Johnson_%26_Johnson_Logo.svg.png', 'www.jnj.com'),
('Roche', 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f5/Hoffmann-La_Roche_logo.svg/1200px-Hoffmann-La_Roche_logo.svg.png', 'www.roche.com'),
('Merck', 'https://upload.wikimedia.org/wikipedia/commons/thumb/2/24/Merck_Logo.svg/1200px-Merck_Logo.svg.png', 'www.merck.com');

-- Insert Categories
INSERT INTO categories (name, description) VALUES
('prescription', 'Doctor prescribed medicines'),
('vitamins', 'Health supplements and vitamins'),
('firstaid', 'Emergency medical supplies'),
('devices', 'Medical devices and equipment'),
('personal', 'Personal care and hygiene'),
('pain-relief', 'Pain relief medications'),
('antibiotics', 'Antibiotic medicines'),
('anti-inflammatory', 'Anti-inflammatory drugs'),
('blood-thinner', 'Blood thinning medications'),
('mens-health', 'Men health products');

-- Insert Real Medicines (Your Data) - Updated with better image URLs
INSERT INTO medicines (name, category, price, stock, company_id, description, image_url) VALUES
('Panadol Extra', 'pain-relief', 50.00, 200, 1, 'For tough pain and fever.', 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=300&h=300&fit=crop'),
('Augmentin 625mg', 'antibiotics', 240.00, 100, 1, 'Broad spectrum antibiotic.', 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=300&h=300&fit=crop'),
('Brufen 400mg', 'anti-inflammatory', 35.00, 150, 3, 'Relief from inflammation and pain.', 'https://images.unsplash.com/photo-1471864190281-a93a3070b6de?w=300&h=300&fit=crop'),
('Disprin', 'blood-thinner', 15.00, 500, 4, 'Dissolvable aspirin for heart health.', 'https://images.unsplash.com/photo-1550572017-edd951aa8ca6?w=300&h=300&fit=crop'),
('Viagra 100mg', 'mens-health', 800.00, 50, 2, 'Treatment for erectile dysfunction.', 'https://images.unsplash.com/photo-1559757175-0eb30cd8c063?w=300&h=300&fit=crop');

-- Insert Products (For compatibility with existing frontend) - Updated with better image URLs
INSERT INTO products (name, description, price, category, stock, stock_quantity, icon, company_id, image_url) VALUES
('Panadol Extra', 'For tough pain and fever - effective pain relief medication', 50.00, 'prescription', 200, 200, '💊', 1, 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=300&h=300&fit=crop'),
('Augmentin 625mg', 'Broad spectrum antibiotic - treats bacterial infections', 240.00, 'prescription', 100, 100, '💊', 1, 'https://images.unsplash.com/photo-1559757148-5c350d0d3c56?w=300&h=300&fit=crop'),
('Brufen 400mg', 'Relief from inflammation and pain - anti-inflammatory medication', 35.00, 'prescription', 150, 150, '💊', 3, 'https://images.unsplash.com/photo-1471864190281-a93a3070b6de?w=300&h=300&fit=crop'),
('Disprin', 'Dissolvable aspirin for heart health - blood thinner', 15.00, 'prescription', 500, 500, '💊', 4, 'https://images.unsplash.com/photo-1550572017-edd951aa8ca6?w=300&h=300&fit=crop'),
('Viagra 100mg', 'Treatment for erectile dysfunction - mens health medication', 800.00, 'prescription', 50, 50, '💊', 2, 'https://images.unsplash.com/photo-1559757175-0eb30cd8c063?w=300&h=300&fit=crop'),

-- Additional Products for variety
('Vitamin C 1000mg', 'Immune system support - boosts immunity and antioxidant protection', 12.99, 'vitamins', 200, 200, '💉', 3, NULL),
('Vitamin D3 2000IU', 'Bone health and immunity - supports calcium absorption', 14.99, 'vitamins', 180, 180, '💉', 6, NULL),
('Multivitamin Complex', 'Complete daily nutrition - all essential vitamins and minerals', 19.99, 'vitamins', 150, 150, '💉', 7, NULL),
('Omega-3 Fish Oil', 'Heart and brain health - supports cardiovascular function', 24.99, 'vitamins', 100, 100, '💉', 8, NULL),
('Calcium + Vitamin D', 'Bone strength supplement - prevents osteoporosis', 16.99, 'vitamins', 140, 140, '💉', 5, NULL),
('First Aid Kit', 'Complete emergency medical kit - includes bandages, antiseptic, gauze', 29.99, 'firstaid', 50, 50, '🩹', NULL, NULL),
('Bandages Pack', 'Assorted sterile bandages - various sizes for different wounds', 8.99, 'firstaid', 120, 120, '🩹', NULL, NULL),
('Antiseptic Cream', 'Wound care and infection prevention - prevents bacterial infection', 7.99, 'firstaid', 180, 180, '🩹', NULL, NULL),
('Digital Thermometer', 'Fast and accurate temperature reading - quick results in 10 seconds', 15.99, 'devices', 75, 75, '🌡️', NULL, NULL),
('Blood Pressure Monitor', 'Digital BP measurement device - automatic and easy to use', 45.99, 'devices', 40, 40, '🌡️', NULL, NULL),
('Hand Sanitizer 500ml', 'Antibacterial hand gel - kills 99.9% of germs', 4.99, 'personal', 300, 300, '🧴', NULL, NULL),
('Face Masks (50 Pack)', 'Disposable surgical masks - 3-ply protection', 12.99, 'personal', 250, 250, '😷', NULL, NULL);

-- Insert Sample Orders
INSERT INTO orders (user_id, order_number, customer_name, customer_email, customer_phone, customer_address, payment_method, total_amount, status) VALUES
(2, 'ORD-20260207-1001', 'John Doe', 'john@example.com', '+92 300 1234567', '123 Main Street, Karachi, Pakistan', 'jazzcash', 290.00, 'delivered'),
(2, 'ORD-20260207-1002', 'John Doe', 'john@example.com', '+92 300 1234567', '123 Main Street, Karachi, Pakistan', 'cod', 65.00, 'processing');

-- Insert Sample Order Items
INSERT INTO order_items (order_id, product_id, product_name, quantity, price) VALUES
(1, 1, 'Panadol Extra', 2, 50.00),
(1, 2, 'Augmentin 625mg', 1, 240.00),
(2, 3, 'Brufen 400mg', 1, 35.00),
(2, 4, 'Disprin', 2, 15.00);

-- Verify data
SELECT 'Companies' as table_name, COUNT(*) as count FROM companies
UNION ALL
SELECT 'Products', COUNT(*) FROM products
UNION ALL
SELECT 'Medicines', COUNT(*) FROM medicines
UNION ALL
SELECT 'Users', COUNT(*) FROM users
UNION ALL
SELECT 'Orders', COUNT(*) FROM orders;