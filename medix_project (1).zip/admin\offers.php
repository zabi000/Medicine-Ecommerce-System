<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) { header('Location: login.php'); exit(); }
require_once('../api/config.php');

if (!$conn) die('<div style="padding:2rem;color:red">Database connection failed.</div>');

// Create offers table if missing
$conn->query("CREATE TABLE IF NOT EXISTS offers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    discount_percent DECIMAL(5,2) NOT NULL,
    offer_label VARCHAR(100) DEFAULT 'SALE',
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    is_active TINYINT(1) DEFAULT 1,
    show_on_homepage TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$success = $error = '';

// Add offer
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add') {
    $pid      = intval($_POST['product_id']);
    $disc     = floatval($_POST['discount_percent']);
    $label    = trim($_POST['offer_label']) ?: 'SALE';
    $start    = $_POST['start_date'];
    $end      = $_POST['end_date'];
    $homepage = isset($_POST['show_on_homepage']) ? 1 : 0;

    if ($pid <= 0 || $disc <= 0 || $disc > 100 || !$start || !$end) {
        $error = 'Please fill all fields correctly. Discount must be 1–100%.';
    } elseif ($end < $start) {
        $error = 'End date cannot be before start date.';
    } else {
        $stmt = $conn->prepare("INSERT INTO offers (product_id, discount_percent, offer_label, start_date, end_date, show_on_homepage) VALUES (?,?,?,?,?,?)");
        $stmt->bind_param("idsssi", $pid, $disc, $label, $start, $end, $homepage);
        $stmt->execute() ? $success = "Offer created successfully!" : $error = "Error: " . $conn->error;
    }
}

// Toggle active
if (isset($_GET['toggle'])) {
    $id = intval($_GET['toggle']);
    $conn->query("UPDATE offers SET is_active = NOT is_active WHERE id=$id");
    header('Location: offers.php'); exit();
}

// Delete offer
if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM offers WHERE id=$id");
    $success = "Offer deleted.";
}

// Edit offer
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'edit') {
    $id    = intval($_POST['offer_id']);
    $disc  = floatval($_POST['discount_percent']);
    $label = trim($_POST['offer_label']) ?: 'SALE';
    $start = $_POST['start_date'];
    $end   = $_POST['end_date'];
    $hp    = isset($_POST['show_on_homepage']) ? 1 : 0;
    $stmt  = $conn->prepare("UPDATE offers SET discount_percent=?,offer_label=?,start_date=?,end_date=?,show_on_homepage=? WHERE id=?");
    $stmt->bind_param("dssiii", $disc, $label, $start, $end, $hp, $id);
    $stmt->execute() ? $success = "Offer updated!" : $error = "Update failed.";
}

// Fetch all products for dropdown
$products = $conn->query("SELECT id, name, price FROM products ORDER BY name ASC");

// Fetch all offers with product info
$offers = $conn->query("
    SELECT o.*, p.name AS product_name, p.price AS original_price,
           ROUND(p.price * (1 - o.discount_percent/100), 2) AS sale_price,
           CURDATE() BETWEEN o.start_date AND o.end_date AS is_live
    FROM offers o
    JOIN products p ON o.product_id = p.id
    ORDER BY o.created_at DESC
");

// Stats
$active_now = $conn->query("SELECT COUNT(*) c FROM offers WHERE is_active=1 AND CURDATE() BETWEEN start_date AND end_date")->fetch_assoc()['c'] ?? 0;
$total_off  = $conn->query("SELECT COUNT(*) c FROM offers")->fetch_assoc()['c'] ?? 0;
$homepage_c = $conn->query("SELECT COUNT(*) c FROM offers WHERE show_on_homepage=1 AND is_active=1 AND CURDATE() BETWEEN start_date AND end_date")->fetch_assoc()['c'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Offers - MEDIX Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root { --sw:280px; --red:#B91C1C; --red2:#7F1D1D; }
body { font-family:'Inter',sans-serif; background:#f8fafc; }
.sidebar { position:fixed;top:0;left:0;width:var(--sw);height:100vh;background:linear-gradient(180deg,var(--red),var(--red2));overflow-y:auto;z-index:1000; }
.sb-brand { padding:1.5rem;border-bottom:1px solid rgba(255,255,255,.1);color:white; }
.mi { display:flex;align-items:center;gap:.75rem;padding:.875rem 1.5rem;color:rgba(255,255,255,.8);text-decoration:none;border-left:3px solid transparent;transition:all .2s;font-weight:500; }
.mi:hover,.mi.active { background:rgba(255,255,255,.15);color:white;border-left-color:white; }
.mi i { width:20px; }
.mdiv { height:1px;background:rgba(255,255,255,.1);margin:.5rem 1.5rem; }
.main { margin-left:var(--sw);padding:2rem; }
.topbar { background:white;border-bottom:1px solid #e2e8f0;padding:1rem 2rem;margin:-2rem -2rem 2rem;box-shadow:0 1px 3px rgba(0,0,0,.06); }
.sc { background:white;border-radius:12px;padding:1.5rem;box-shadow:0 1px 4px rgba(0,0,0,.06);border:1px solid #f1f5f9; }
.table th { font-size:.75rem;text-transform:uppercase;color:#64748b;font-weight:700;background:#f8fafc;padding:.75rem 1rem; }
.table td { padding:.75rem 1rem;vertical-align:middle;font-size:.875rem; }
.badge-live { background:#d1fae5;color:#065f46;padding:.3rem .75rem;border-radius:20px;font-size:.75rem;font-weight:700; }
.badge-expired { background:#f1f5f9;color:#64748b;padding:.3rem .75rem;border-radius:20px;font-size:.75rem;font-weight:700; }
.badge-inactive { background:#fef3c7;color:#92400e;padding:.3rem .75rem;border-radius:20px;font-size:.75rem;font-weight:700; }
.disc-pill { background:linear-gradient(135deg,#B91C1C,#DC2626);color:white;padding:.3rem .875rem;border-radius:20px;font-size:.8rem;font-weight:800;letter-spacing:.3px; }
</style>
</head>
<body>
<div class="sidebar">
    <div class="sb-brand"><h4 class="mb-0 fw-bold"><i class="bi bi-heart-pulse-fill me-2"></i>MEDIX</h4><small style="opacity:.6">Admin Portal</small></div>
    <a href="index.php"      class="mi"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="products.php"   class="mi"><i class="bi bi-box-seam"></i>Products</a>
    <a href="offers.php"     class="mi active"><i class="bi bi-tag-fill"></i>Offers</a>
    <a href="orders.php"     class="mi"><i class="bi bi-cart-check"></i>Orders</a>
    <a href="customers.php"  class="mi"><i class="bi bi-people"></i>Customers</a>
    <a href="categories.php" class="mi"><i class="bi bi-tags"></i>Categories</a>
    <a href="messages.php"   class="mi"><i class="bi bi-envelope"></i>Messages</a>
    <a href="reports.php"    class="mi"><i class="bi bi-graph-up"></i>Reports</a>
    <a href="settings.php"   class="mi"><i class="bi bi-gear"></i>Settings</a>
    <div class="mdiv"></div>
    <a href="database.php"   class="mi"><i class="bi bi-database"></i>Database</a>
    <a href="import_medicines.php" class="mi" style="color:#10B981"><i class="bi bi-capsule-pill"></i>Import Medicines</a>
    <div class="mdiv"></div>
    <a href="logout.php" class="mi"><i class="bi bi-box-arrow-right"></i>Logout</a>
</div>

<div class="main">
<div class="topbar d-flex justify-content-between align-items-center">
    <div>
        <h4 class="mb-0 fw-bold"><i class="bi bi-tag-fill me-2 text-danger"></i>Offers & Discounts</h4>
        <small class="text-muted">Create offers linked to products — visible on homepage & product pages</small>
    </div>
    <button class="btn btn-danger px-4" data-bs-toggle="modal" data-bs-target="#addModal">
        <i class="bi bi-plus-circle me-2"></i>New Offer
    </button>
</div>

<?php if ($success): ?>
<div class="alert alert-success alert-dismissible fade show"><i class="bi bi-check-circle me-2"></i><?= htmlspecialchars($success) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
<?php endif; ?>
<?php if ($error): ?>
<div class="alert alert-danger alert-dismissible fade show"><i class="bi bi-exclamation-triangle me-2"></i><?= htmlspecialchars($error) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
<?php endif; ?>

<!-- Stats -->
<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="sc text-center">
            <i class="bi bi-lightning-charge-fill text-success" style="font-size:2rem"></i>
            <h3 class="mt-2 mb-0 fw-bold text-success"><?= $active_now ?></h3>
            <p class="text-muted small mb-0">Live Offers Right Now</p>
        </div>
    </div>
    <div class="col-md-4">
        <div class="sc text-center">
            <i class="bi bi-house-heart-fill text-danger" style="font-size:2rem"></i>
            <h3 class="mt-2 mb-0 fw-bold"><?= $homepage_c ?></h3>
            <p class="text-muted small mb-0">Showing on Homepage</p>
        </div>
    </div>
    <div class="col-md-4">
        <div class="sc text-center">
            <i class="bi bi-tag-fill text-primary" style="font-size:2rem"></i>
            <h3 class="mt-2 mb-0 fw-bold"><?= $total_off ?></h3>
            <p class="text-muted small mb-0">Total Offers Created</p>
        </div>
    </div>
</div>

<!-- Offers Table -->
<div class="sc">
    <h6 class="fw-bold mb-3"><i class="bi bi-tag me-2 text-danger"></i>All Offers</h6>
    <div class="table-responsive">
    <table class="table table-hover">
    <thead><tr>
        <th>Product</th><th>Original Price</th><th>Discount</th><th>Sale Price</th>
        <th>Label</th><th>Period</th><th>Status</th><th>Homepage</th><th>Actions</th>
    </tr></thead>
    <tbody>
    <?php if ($offers && $offers->num_rows > 0):
        while ($o = $offers->fetch_assoc()):
            $is_live = $o['is_live'] && $o['is_active'];
            $expired = $o['end_date'] < date('Y-m-d');
    ?>
    <tr>
        <td class="fw-semibold"><?= htmlspecialchars($o['product_name']) ?></td>
        <td class="text-muted text-decoration-line-through">PKR <?= number_format($o['original_price'], 0) ?></td>
        <td><span class="disc-pill">-<?= number_format($o['discount_percent'], 0) ?>%</span></td>
        <td class="fw-bold text-danger">PKR <?= number_format($o['sale_price'], 0) ?></td>
        <td><span class="badge bg-danger"><?= htmlspecialchars($o['offer_label']) ?></span></td>
        <td class="small text-muted">
            <?= date('M d', strtotime($o['start_date'])) ?> – <?= date('M d, Y', strtotime($o['end_date'])) ?>
        </td>
        <td>
            <?php if (!$o['is_active']): ?>
                <span class="badge-inactive">Paused</span>
            <?php elseif ($expired): ?>
                <span class="badge-expired">Expired</span>
            <?php else: ?>
                <span class="badge-live">Live</span>
            <?php endif; ?>
        </td>
        <td>
            <?php if ($o['show_on_homepage']): ?>
                <i class="bi bi-check-circle-fill text-success"></i>
            <?php else: ?>
                <i class="bi bi-dash-circle text-muted"></i>
            <?php endif; ?>
        </td>
        <td>
            <div class="d-flex gap-1">
                <button class="btn btn-sm btn-outline-primary" onclick="editOffer(<?= htmlspecialchars(json_encode($o)) ?>)" title="Edit">
                    <i class="bi bi-pencil"></i>
                </button>
                <a href="?toggle=<?= $o['id'] ?>" class="btn btn-sm btn-outline-<?= $o['is_active'] ? 'warning' : 'success' ?>" title="<?= $o['is_active'] ? 'Pause' : 'Activate' ?>">
                    <i class="bi bi-<?= $o['is_active'] ? 'pause-fill' : 'play-fill' ?>"></i>
                </a>
                <a href="?delete=<?= $o['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this offer?')" title="Delete">
                    <i class="bi bi-trash"></i>
                </a>
            </div>
        </td>
    </tr>
    <?php endwhile; else: ?>
    <tr><td colspan="9" class="text-center py-5 text-muted">
        <i class="bi bi-tag" style="font-size:3rem;display:block;margin-bottom:.75rem"></i>
        No offers yet. Create your first offer!
    </td></tr>
    <?php endif; ?>
    </tbody>
    </table>
    </div>
</div>
</div>

<!-- Add Modal -->
<div class="modal fade" id="addModal" tabindex="-1">
<div class="modal-dialog modal-lg"><div class="modal-content">
<div class="modal-header bg-danger text-white">
    <h5 class="modal-title"><i class="bi bi-plus-circle me-2"></i>Create New Offer</h5>
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
</div>
<form method="POST"><div class="modal-body">
    <input type="hidden" name="action" value="add">
    <div class="row g-3">
        <div class="col-md-8">
            <label class="form-label fw-semibold">Select Product <span class="text-danger">*</span></label>
            <select name="product_id" class="form-select" required onchange="updatePreview(this)">
                <option value="">-- Choose a product --</option>
                <?php if ($products): $products->data_seek(0); while ($p = $products->fetch_assoc()): ?>
                <option value="<?= $p['id'] ?>" data-price="<?= $p['price'] ?>">
                    <?= htmlspecialchars($p['name']) ?> — PKR <?= number_format($p['price'], 0) ?>
                </option>
                <?php endwhile; endif; ?>
            </select>
        </div>
        <div class="col-md-4">
            <label class="form-label fw-semibold">Discount % <span class="text-danger">*</span></label>
            <div class="input-group">
                <input type="number" name="discount_percent" id="discInput" class="form-control" min="1" max="99" step="0.5" placeholder="20" required oninput="updatePreview()">
                <span class="input-group-text">%</span>
            </div>
        </div>
        <div class="col-md-4">
            <label class="form-label fw-semibold">Offer Label</label>
            <input type="text" name="offer_label" class="form-control" value="SALE" placeholder="SALE, HOT DEAL, etc.">
            <small class="text-muted">Shown as badge on product</small>
        </div>
        <div class="col-md-4">
            <label class="form-label fw-semibold">Start Date <span class="text-danger">*</span></label>
            <input type="date" name="start_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
        </div>
        <div class="col-md-4">
            <label class="form-label fw-semibold">End Date <span class="text-danger">*</span></label>
            <input type="date" name="end_date" class="form-control" value="<?= date('Y-m-d', strtotime('+7 days')) ?>" required>
        </div>
        <div class="col-12">
            <div class="form-check form-switch">
                <input class="form-check-input" type="checkbox" name="show_on_homepage" id="showHP" checked>
                <label class="form-check-label fw-semibold" for="showHP">
                    Show on Homepage <small class="text-muted fw-normal">(appears in Today's Best Deals section)</small>
                </label>
            </div>
        </div>
        <!-- Live Preview -->
        <div class="col-12">
            <div id="offerPreview" style="display:none;background:linear-gradient(135deg,#fef2f2,#fff);border:2px solid #B91C1C;border-radius:12px;padding:1rem">
                <div class="d-flex justify-content-between align-items-center">
                    <div>
                        <div class="small text-muted">Sale Price Preview</div>
                        <div id="prevOriginal" class="text-muted text-decoration-line-through small"></div>
                        <div id="prevSale" class="fw-bold text-danger fs-5"></div>
                    </div>
                    <div id="prevBadge" class="disc-pill fs-5"></div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
    <button type="submit" class="btn btn-danger px-4"><i class="bi bi-check-circle me-1"></i>Create Offer</button>
</div>
</form></div></div></div>

<!-- Edit Modal -->
<div class="modal fade" id="editModal" tabindex="-1">
<div class="modal-dialog modal-lg"><div class="modal-content">
<div class="modal-header bg-primary text-white">
    <h5 class="modal-title"><i class="bi bi-pencil me-2"></i>Edit Offer</h5>
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
</div>
<form method="POST"><div class="modal-body">
    <input type="hidden" name="action" value="edit">
    <input type="hidden" name="offer_id" id="editId">
    <div class="row g-3">
        <div class="col-12">
            <label class="form-label fw-semibold">Product</label>
            <input type="text" class="form-control" id="editProductName" disabled>
        </div>
        <div class="col-md-4">
            <label class="form-label fw-semibold">Discount %</label>
            <div class="input-group">
                <input type="number" name="discount_percent" id="editDisc" class="form-control" min="1" max="99" step="0.5" required>
                <span class="input-group-text">%</span>
            </div>
        </div>
        <div class="col-md-4">
            <label class="form-label fw-semibold">Offer Label</label>
            <input type="text" name="offer_label" id="editLabel" class="form-control">
        </div>
        <div class="col-md-4"></div>
        <div class="col-md-6">
            <label class="form-label fw-semibold">Start Date</label>
            <input type="date" name="start_date" id="editStart" class="form-control" required>
        </div>
        <div class="col-md-6">
            <label class="form-label fw-semibold">End Date</label>
            <input type="date" name="end_date" id="editEnd" class="form-control" required>
        </div>
        <div class="col-12">
            <div class="form-check form-switch">
                <input class="form-check-input" type="checkbox" name="show_on_homepage" id="editHP">
                <label class="form-check-label fw-semibold" for="editHP">Show on Homepage</label>
            </div>
        </div>
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
    <button type="submit" class="btn btn-primary px-4"><i class="bi bi-save me-1"></i>Save Changes</button>
</div>
</form></div></div></div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function updatePreview() {
    const sel = document.querySelector('select[name="product_id"]');
    const disc = parseFloat(document.getElementById('discInput').value);
    const opt = sel.options[sel.selectedIndex];
    if (!opt || !opt.dataset.price || !disc) { document.getElementById('offerPreview').style.display='none'; return; }
    const orig = parseFloat(opt.dataset.price);
    const sale = orig * (1 - disc / 100);
    document.getElementById('prevOriginal').textContent = 'PKR ' + orig.toLocaleString();
    document.getElementById('prevSale').textContent = 'PKR ' + Math.round(sale).toLocaleString();
    document.getElementById('prevBadge').textContent = '-' + disc + '%';
    document.getElementById('offerPreview').style.display = 'block';
}
document.querySelector('select[name="product_id"]').addEventListener('change', updatePreview);

function editOffer(o) {
    document.getElementById('editId').value = o.id;
    document.getElementById('editProductName').value = o.product_name;
    document.getElementById('editDisc').value = o.discount_percent;
    document.getElementById('editLabel').value = o.offer_label;
    document.getElementById('editStart').value = o.start_date;
    document.getElementById('editEnd').value = o.end_date;
    document.getElementById('editHP').checked = o.show_on_homepage == 1;
    new bootstrap.Modal(document.getElementById('editModal')).show();
}

setTimeout(function() {
    document.querySelectorAll('.alert').forEach(function(a) { bootstrap.Alert.getOrCreateInstance(a)?.close(); });
}, 4000);
</script>
</body>
</html>
