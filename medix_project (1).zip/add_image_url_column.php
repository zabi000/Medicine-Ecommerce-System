<?php
require_once('api/config.php');

if (!$conn) {
    die("Database connection failed");
}

echo "<h2 style='font-family:Arial;padding:1rem'>Fixing Database...</h2>";

// Fix 1: Add image_url column
$r = $conn->query("SHOW COLUMNS FROM products LIKE 'image_url'");
if ($r->num_rows == 0) {
    if ($conn->query("ALTER TABLE products ADD COLUMN image_url VARCHAR(500) DEFAULT NULL")) {
        echo "<p style='color:green;font-family:Arial;padding:.5rem 1rem'>✅ image_url column added!</p>";
    } else {
        echo "<p style='color:red;font-family:Arial;padding:.5rem 1rem'>❌ Error: " . $conn->error . "</p>";
    }
} else {
    echo "<p style='color:blue;font-family:Arial;padding:.5rem 1rem'>ℹ️ image_url column already exists.</p>";
}

// Fix 2: Add stock_quantity column if missing
$r2 = $conn->query("SHOW COLUMNS FROM products LIKE 'stock_quantity'");
if ($r2->num_rows == 0) {
    $conn->query("ALTER TABLE products ADD COLUMN stock_quantity INT DEFAULT 100");
    echo "<p style='color:green;font-family:Arial;padding:.5rem 1rem'>✅ stock_quantity column added!</p>";
} else {
    echo "<p style='color:blue;font-family:Arial;padding:.5rem 1rem'>ℹ️ stock_quantity column already exists.</p>";
}

// Show current columns
echo "<h3 style='font-family:Arial;padding:.5rem 1rem'>Current products table columns:</h3>";
$cols = $conn->query("SHOW COLUMNS FROM products");
echo "<ul style='font-family:Arial'>";
while ($c = $cols->fetch_assoc()) {
    echo "<li><strong>" . $c['Field'] . "</strong> (" . $c['Type'] . ")</li>";
}
echo "</ul>";

echo "<div style='padding:1rem'>";
echo "<a href='admin/products.php' style='padding:12px 24px;background:#B91C1C;color:white;text-decoration:none;border-radius:8px;font-family:Arial;margin-right:1rem'>Go to Products</a>";
echo "<a href='test_checkout.php' style='padding:12px 24px;background:#2563eb;color:white;text-decoration:none;border-radius:8px;font-family:Arial'>Test Checkout</a>";
echo "</div>";
?>
