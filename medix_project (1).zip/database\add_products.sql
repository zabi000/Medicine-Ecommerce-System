-- Add Products to MEDIX Database
-- Run this SQL file to populate the products table with sample medicines

USE medicare_db;

-- Clear existing products (optional - comment out if you want to keep existing products)
-- DELETE FROM products;

-- Insert 20 Sample Products
INSERT INTO products (name, description, price, category, icon, stock) VALUES
('Paracetamol 500mg', 'Pain relief and fever reducer - effective for headaches and body aches', 5.99, 'prescription', '💊', 100),
('Ibuprofen 400mg', 'Anti-inflammatory pain reliever - reduces inflammation and pain', 7.99, 'prescription', '💊', 150),
('Aspirin 100mg', 'Blood thinner and pain relief - for heart health and pain management', 6.99, 'prescription', '💊', 200),
('Cough Syrup', 'Relief from dry and wet cough - soothing throat irritation', 8.99, 'prescription', '💊', 120),
('Vitamin C 1000mg', 'Immune system support - boosts immunity and antioxidant protection', 12.99, 'vitamins', '💉', 200),
('Vitamin D3 2000IU', 'Bone health and immunity - supports calcium absorption', 14.99, 'vitamins', '💉', 180),
('Multivitamin Complex', 'Complete daily nutrition - all essential vitamins and minerals', 19.99, 'vitamins', '💉', 150),
('Omega-3 Fish Oil', 'Heart and brain health - supports cardiovascular function', 24.99, 'vitamins', '💉', 100),
('Calcium + Vitamin D', 'Bone strength supplement - prevents osteoporosis', 16.99, 'vitamins', '💉', 140),
('Probiotic Capsules', 'Digestive health support - improves gut bacteria balance', 22.99, 'vitamins', '💉', 110),
('First Aid Kit', 'Complete emergency medical kit - includes bandages, antiseptic, gauze', 29.99, 'firstaid', '🩹', 50),
('Bandages Pack', 'Assorted sterile bandages - various sizes for different wounds', 8.99, 'firstaid', '🩹', 120),
('Antiseptic Cream', 'Wound care and infection prevention - prevents bacterial infection', 7.99, 'firstaid', '🩹', 180),
('Digital Thermometer', 'Fast and accurate temperature reading - quick results in 10 seconds', 15.99, 'devices', '🌡️', 75),
('Blood Pressure Monitor', 'Digital BP measurement device - automatic and easy to use', 45.99, 'devices', '🌡️', 40),
('Infrared Thermometer', 'Non-contact temperature scanner - safe and hygienic measurement', 34.99, 'devices', '🌡️', 55),
('Glucose Meter Kit', 'Blood sugar monitoring system - includes lancets and test strips', 39.99, 'devices', '🩺', 60),
('Pulse Oximeter', 'Oxygen saturation monitor - tracks SpO2 and heart rate', 29.99, 'devices', '🩺', 80),
('Hand Sanitizer 500ml', 'Antibacterial hand gel - kills 99.9% of germs', 4.99, 'personal', '🧴', 300),
('Face Masks (50 Pack)', 'Disposable surgical masks - 3-ply protection', 12.99, 'personal', '😷', 250);

-- Verify products were added
SELECT COUNT(*) as total_products FROM products;
SELECT * FROM products ORDER BY id DESC LIMIT 5;
