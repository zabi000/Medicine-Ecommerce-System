<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
set_time_limit(300);

// Direct database connection
$host = 'localhost';
$user = 'root';
$pass = '';

// Connect without database first
$conn = new mysqli($host, $user, $pass);

if ($conn->connect_error) {
    die("<div style='color:red; font-family:Arial; padding:20px;'>
        ❌ MySQL Connection Failed: " . $conn->connect_error . "
        <br><br>Make sure XAMPP MySQL is running!
    </div>");
}

// Create database
$conn->query("CREATE DATABASE IF NOT EXISTS medicare_db");
$conn->select_db("medicare_db");

// Create products table
$conn->query("CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) DEFAULT 0,
    category VARCHAR(100) DEFAULT 'prescription',
    stock_quantity INT DEFAULT 100,
    image_url VARCHAR(500) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// Create users table
$conn->query("CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    email VARCHAR(100) UNIQUE,
    phone VARCHAR(20),
    password VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// Create orders table
$conn->query("CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    total_amount DECIMAL(10,2),
    status VARCHAR(50) DEFAULT 'pending',
    shipping_address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// Create order_items table
$conn->query("CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT,
    product_id INT,
    quantity INT,
    price DECIMAL(10,2)
)");

// All medicines data
$medicines = [
    // ===== PANADOL FAMILY =====
    ['Panadol', 'GSK', '500mg', 'Tablet', 'Fever, mild pain, headache', 'Liver damage (high dose)', 'No', 35.0, 'prescription'],
    ['Panadol Extra', 'GSK', '500mg + 65mg', 'Tablet', 'Headache, fatigue, strong pain relief', 'Liver issues, jitteriness', 'No', 70.0, 'prescription'],
    ['Panadol Extend', 'GSK', '665mg', 'Tablet', 'Long-lasting pain relief, arthritis', 'Liver damage (high dose)', 'No', 100.0, 'prescription'],
    ['Panadol Cold & Flu', 'GSK', '500mg + 30mg', 'Tablet', 'Cold, flu, fever, body aches', 'Drowsiness, dry mouth', 'No', 80.0, 'prescription'],
    ['Panadol Night', 'GSK', '500mg + 25mg', 'Tablet', 'Nighttime pain relief, insomnia with pain', 'Drowsiness, dry mouth', 'No', 90.0, 'prescription'],
    ['Panadol Actifast', 'GSK', '500mg', 'Tablet', 'Fast-acting fever and pain relief', 'Liver damage (high dose)', 'No', 85.0, 'prescription'],
    ['Panadol Baby Syrup', 'GSK', '120mg/5ml', 'Syrup', 'Fever and pain in infants and children', 'Rare skin rash', 'No', 120.0, 'prescription'],
    // ===== ANTIBIOTICS =====
    ['Amoxicillin', 'Various', '500mg', 'Capsule', 'Bacterial infections, throat, ear, chest infections', 'Nausea, diarrhea, allergy', 'Yes', 150.0, 'prescription'],
    ['Amoxil', 'GSK', '500mg', 'Capsule', 'Bacterial infections, pneumonia, tonsillitis', 'Nausea, allergy, rash', 'Yes', 160.0, 'prescription'],
    ['Augmentin', 'GSK', '625mg', 'Tablet', 'Strong bacterial infections, sinusitis, pneumonia', 'Diarrhea, nausea', 'Yes', 600.0, 'prescription'],
    ['Augmentin 1g', 'GSK', '1000mg', 'Tablet', 'Severe bacterial infections, hospital infections', 'Diarrhea, nausea, rash', 'Yes', 900.0, 'prescription'],
    ['Flagyl', 'Pfizer', '400mg', 'Tablet', 'Stomach & intestinal infections, amoebiasis', 'Metallic taste, nausea', 'Yes', 80.0, 'prescription'],
    ['Metronidazole', 'Various', '400mg', 'Tablet', 'Bacterial and parasitic infections, dental infections', 'Metallic taste, nausea', 'Yes', 60.0, 'prescription'],
    ['Ciproxin', 'Bayer', '500mg', 'Tablet', 'Urinary tract infections, GI infections, typhoid', 'Nausea, dizziness, tendon risk', 'Yes', 300.0, 'prescription'],
    ['Cipro', 'Various', '500mg', 'Tablet', 'Urinary infections, respiratory infections', 'Nausea, dizziness', 'Yes', 250.0, 'prescription'],
    ['Azomax', 'Pfizer', '500mg', 'Tablet', 'Respiratory infections, skin infections, typhoid', 'Diarrhea, nausea', 'Yes', 500.0, 'prescription'],
    ['Azithromycin', 'Various', '500mg', 'Tablet', 'Chest infections, throat infections, STIs', 'Diarrhea, stomach pain', 'Yes', 400.0, 'prescription'],
    ['Cefspan', 'Searle', '400mg', 'Capsule', 'Throat, ear, sinus, urinary infections', 'Diarrhea, rash', 'Yes', 350.0, 'prescription'],
    ['Cefixime', 'Various', '400mg', 'Capsule', 'Bacterial infections, gonorrhea, typhoid', 'Diarrhea, stomach pain', 'Yes', 280.0, 'prescription'],
    ['Levoflox', 'Getz', '500mg', 'Tablet', 'Urinary & respiratory infections, pneumonia', 'Dizziness, nausea, tendon risk', 'Yes', 220.0, 'prescription'],
    ['Claritek', 'Getz Pharma', '500mg', 'Tablet', 'Throat, lung, skin infections, H. pylori', 'Nausea, diarrhea, metallic taste', 'Yes', 65.0, 'prescription'],
    ['Clarithromycin', 'Various', '500mg', 'Tablet', 'Respiratory infections, H. pylori treatment', 'Nausea, diarrhea', 'Yes', 200.0, 'prescription'],
    ['Erythrocin', 'Bosch', '250mg', 'Tablet', 'Skin & respiratory infections, acne', 'Nausea, cramps, stomach upset', 'Yes', 50.0, 'prescription'],
    ['Doxycycline', 'Various', '100mg', 'Capsule', 'Chest infections, acne, malaria prevention', 'Photosensitivity, nausea', 'Yes', 180.0, 'prescription'],
    ['Tetracycline', 'Various', '250mg', 'Capsule', 'Bacterial infections, acne, H. pylori', 'Photosensitivity, tooth discoloration', 'Yes', 120.0, 'prescription'],
    ['Entamizole', 'Searle', '400mg + 500mg', 'Tablet', 'Amoebiasis, GI infection, dysentery', 'Metallic taste, nausea', 'Yes', 120.0, 'prescription'],
    ['Zentel', 'GSK', '400mg', 'Tablet', 'Worm infestation, roundworm, tapeworm', 'Abdominal pain, nausea', 'No', 60.0, 'prescription'],
    ['Mebendazole', 'Various', '100mg', 'Tablet', 'Worm infections, pinworm, hookworm', 'Stomach pain, diarrhea', 'No', 45.0, 'prescription'],
    ['Cephalexin', 'Various', '500mg', 'Capsule', 'Skin, throat, urinary infections', 'Nausea, diarrhea', 'Yes', 200.0, 'prescription'],
    ['Cloxacillin', 'Various', '500mg', 'Capsule', 'Staphylococcal infections, skin infections', 'Nausea, allergy', 'Yes', 180.0, 'prescription'],
    // ===== PRESCRIPTION MEDICINES =====
    ['Brufen', 'Abbott', '400mg', 'Tablet', 'Pain, inflammation, fever', 'Stomach upset, ulcer risk', 'No', 70.0, 'prescription'],
    ['Brufen', 'Abbott', '400mg', 'Tablet', 'Pain, inflammation', 'Stomach upset', 'No', 70.0, 'prescription'],
    ['Azomax', 'Pfizer', '500mg', 'Tablet', 'Infections (respiratory, skin)', 'Diarrhea, nausea', 'Yes', 500.0, 'prescription'],
    ['Augmentin', 'GSK', '625mg', 'Tablet', 'Strong bacterial infections', 'Diarrhea, nausea', 'Yes', 600.0, 'prescription'],
    ['Flagyl', 'Pfizer', '400mg', 'Tablet', 'Stomach & intestinal infections', 'Metallic taste, nausea', 'Yes', 80.0, 'prescription'],
    ['Disprin', 'Various', '300mg', 'Tablet', 'Headache, blood thinner', 'Stomach bleeding', 'No', 30.0, 'prescription'],
    ['Risek', 'Getz Pharma', '20mg', 'Tablet', 'Acidity, ulcers', 'Headache, stomach pain', 'Yes', 100.0, 'prescription'],
    ['Ponstan', 'Pfizer', '250mg', 'Tablet', 'Cramps, toothache, pain relief', 'Nausea, headache', 'Yes', 20.0, 'prescription'],
    ['Paracetamol', 'Various', '500mg', 'Tablet', 'Fever, pain relief', 'Liver issues (overdose)', 'No', 30.0, 'prescription'],
    ['Calpol', 'GSK', '500mg', 'Tablet', 'Fever and pain in children', 'Rare skin rash', 'No', 45.0, 'prescription'],
    ['Panadol Extra', 'GSK', '500mg + 65mg', 'Tablet', 'Headache, fatigue, pain relief', 'Liver issues, jitteriness', 'No', 70.0, 'prescription'],
    ['Panadol Extend', 'GSK', '665mg', 'Tablet', 'Long-lasting pain relief', 'Liver damage (high dose)', 'No', 100.0, 'prescription'],
    ['Arinac Forte', 'Abbott', '400mg + 60mg', 'Tablet', 'Cold, flu, fever, nasal congestion', 'Nausea, dizziness, dry mouth', 'Yes', 85.0, 'prescription'],
    ['Amoxil', 'GSK', '500mg', 'Capsule', 'Bacterial infections', 'Nausea, allergy', 'Yes', 150.0, 'prescription'],
    ['Disprol', 'Various', '500mg', 'Tablet', 'Fever, pain', 'Rash, allergy', 'No', 40.0, 'prescription'],
    ['Naproxen', 'Bosch', '250mg', 'Tablet', 'Joint pain, cramps, pain relief', 'Nausea, dizziness', 'Yes', 15.0, 'prescription'],
    ['Celebrex', 'Pfizer', '200mg', 'Capsule', 'Arthritis, back pain', 'Stomach issues', 'Yes', 250.0, 'prescription'],
    ['Cefspan', 'Searle', '400mg', 'Tablet', 'Throat, ear, sinus infections', 'Diarrhea, rash', 'Yes', 180.0, 'prescription'],
    ['Levoflox', 'Getz', '500mg', 'Tablet', 'Urinary & respiratory infections', 'Dizziness, nausea', 'Yes', 220.0, 'prescription'],
    ['Erythrocin', 'Bosch', '250mg', 'Tablet', 'Skin & respiratory infections', 'Nausea, cramps', 'Yes', 50.0, 'prescription'],
    ['Ciproxin', 'Bayer', '500mg', 'Tablet', 'Urinary and GI infections', 'Nausea, dizziness', 'Yes', 300.0, 'prescription'],
    ['Zentel', 'GSK', '400mg', 'Tablet', 'Worm infestation', 'Abdominal pain, nausea', 'No', 60.0, 'prescription'],
    ['Losec', 'AstraZeneca', '20mg', 'Tablet', 'GERD, ulcers, acidity', 'Constipation, headache', 'Yes', 45.0, 'prescription'],
    ['Zantac', 'GSK', '150mg', 'Tablet', 'Acid reflux, ulcers', 'Constipation, headache', 'Yes', 90.0, 'prescription'],
    ['Imodium', 'Janssen', '2mg', 'Tablet', 'Diarrhea', 'Drowsiness, dry mouth', 'No', 75.0, 'prescription'],
    ['Clarinase', 'MSD', '5mg + 120mg', 'Tablet', 'Cold, sinus, nasal congestion', 'Insomnia, dry mouth', 'Yes', 90.0, 'prescription'],
    ['Claritek', 'Getz Pharma', '500mg', 'Tablet', 'Throat, lung infections', 'Nausea, diarrhea', 'Yes', 65.0, 'prescription'],
    ['Nuberol Forte', 'Sami Pharma', '450mg + 35mg', 'Tablet', 'Pain relief, muscle pain', 'Drowsiness', 'Yes', 55.0, 'prescription'],
    ['Gravinate', 'Platinum Pharma', '50mg', 'Tablet', 'Nausea, vomiting, motion sickness', 'Drowsiness', 'No', 50.0, 'prescription'],
    ['Tamsol D', 'Himont', '0.4mg + 0.5mg', 'Tablet', 'Prostate enlargement', 'Dizziness, low BP', 'Yes', 200.0, 'prescription'],
    ['Rivotril', 'Roche', '0.5mg', 'Tablet', 'Anxiety, seizures', 'Drowsiness, dependency risk', 'Yes', 180.0, 'prescription'],
    ['Entamizole', 'Searle', '400mg + 500mg', 'Tablet', 'Amoebiasis, GI infection', 'Metallic taste, nausea', 'Yes', 120.0, 'prescription'],
    ['Lomotil', 'Jonas Pharma', '2.5mg', 'Tablet', 'Diarrhea', 'Dry mouth, constipation', 'Yes', 95.0, 'prescription'],
    ['Spasfon', 'PharmEvo', '80mg', 'Tablet', 'Abdominal cramps', 'Nausea, dizziness', 'Yes', 110.0, 'prescription'],
    ['Ventolin', 'GSK', '4mg', 'Inhaler', 'Asthma, breathing issues', 'Tremors, fast heartbeat', 'Yes', 350.0, 'devices'],
    // Allergy & Cold
    ['Cetirizine', 'AGP', '10mg', 'Tablet', 'Allergy, sneezing, runny nose', 'Drowsiness, dizziness', 'No', 35.0, 'prescription'],
    ['Rigix', 'AGP', '10mg', 'Tablet', 'Allergy, sneezing', 'Drowsiness', 'No', 50.0, 'prescription'],
    ['Piriton', 'GSK', 'N/A', 'Tablet', 'Allergies, flu symptoms', 'Drowsiness', 'No', 60.0, 'prescription'],
    ['Zyrtec', 'UCB', '10mg', 'Tablet', 'Allergy, runny nose', 'Drowsiness, dry mouth', 'No', 120.0, 'prescription'],
    ['Telfast', 'Sanofi', '120mg', 'Tablet', 'Seasonal allergies', 'Dry mouth, headache', 'No', 150.0, 'prescription'],
    ['Histac', 'AGP', '10mg', 'Tablet', 'Allergy, skin rash', 'Drowsiness', 'No', 8.0, 'prescription'],
    ['Histazine', 'Hilton Pharma', '10mg', 'Tablet', 'Allergy, flu', 'Drowsiness', 'No', 80.0, 'prescription'],
    ['Montiget', 'Getz Pharma', '10mg', 'Tablet', 'Allergy, asthma', 'Headache, abdominal pain', 'Yes', 40.0, 'prescription'],
    ['Myteka', 'Getz Pharma', '10mg', 'Tablet', 'Asthma, allergy', 'Headache, behavior change', 'Yes', 85.0, 'prescription'],
    ['Actifed', 'GSK', 'N/A', 'Tablet', 'Cold, runny nose, cough', 'Drowsiness, dry mouth', 'No', 40.0, 'prescription'],
    ['Coughnil', 'Sami Pharma', 'N/A', 'Syrup', 'Cough, throat irritation', 'Drowsiness', 'No', 35.0, 'prescription'],
    ['Broxol', 'Searle', 'N/A', 'Syrup', 'Cough with mucus', 'Stomach upset', 'No', 20.0, 'prescription'],
    ['Benylin', 'Janssen', 'N/A', 'Syrup', 'Flu, dry cough', 'Drowsiness, dizziness', 'No', 55.0, 'prescription'],
    ['Hydryllin', 'Searle', 'N/A', 'Syrup', 'Cough, congestion', 'Drowsiness', 'No', 65.0, 'prescription'],
    // Vitamins & Supplements
    ['Caviplex', 'ATCO Pharma', 'Multivitamin', 'Tablet', 'Multivitamin supplement, daily nutrition', 'Nausea (rare)', 'No', 100.0, 'vitamins'],
    ['Neurobion', 'Merck', 'B-Complex', 'Tablet', 'B12 & nerve pain, vitamin deficiency', 'Injection site pain', 'No', 120.0, 'vitamins'],
    ['Vitamin C 1000mg', 'Various', '1000mg', 'Tablet', 'Immune system support, vitamin C supplement', 'Stomach upset (high dose)', 'No', 150.0, 'vitamins'],
    ['Vitamin D3', 'Various', '2000IU', 'Tablet', 'Bone health, vitamin D supplement', 'Nausea (high dose)', 'No', 180.0, 'vitamins'],
    ['Omega-3 Fish Oil', 'Various', '1000mg', 'Capsule', 'Heart health, brain health supplement', 'Fishy aftertaste', 'No', 250.0, 'vitamins'],
    ['Calcium + Vitamin D', 'Various', '500mg', 'Tablet', 'Bone strength supplement, calcium deficiency', 'Constipation', 'No', 200.0, 'vitamins'],
    ['Multivitamin Complex', 'Various', 'Multi', 'Tablet', 'Complete daily nutrition, multivitamin', 'Nausea (rare)', 'No', 300.0, 'vitamins'],
    ['Zinc Supplement', 'Various', '50mg', 'Tablet', 'Immune support, zinc deficiency', 'Nausea', 'No', 120.0, 'vitamins'],
    ['Iron Supplement', 'Various', '65mg', 'Tablet', 'Iron deficiency, anemia treatment', 'Constipation, dark stools', 'No', 90.0, 'vitamins'],
    ['Folic Acid', 'Various', '5mg', 'Tablet', 'Pregnancy supplement, folic acid deficiency', 'Nausea (rare)', 'No', 80.0, 'vitamins'],
    ['ORS Sachets', 'Various', 'N/A', 'Oral Powder', 'Dehydration, electrolyte replacement', 'None', 'No', 25.0, 'vitamins'],
    // Skincare & Topical
    ['Volini Gel', 'Reckitt', '1% Diclofenac', 'Gel', 'Muscle pain, sprain, joint pain', 'Skin irritation', 'No', 90.0, 'skincare'],
    ['Fastum Gel', 'Menarini', '2.5% Ketoprofen', 'Gel', 'Joint/muscle pain, inflammation', 'Redness, itching', 'No', 90.0, 'skincare'],
    ['Moov Gel', 'Reckitt Benckiser', '1.16% Diclofenac', 'Gel', 'Back pain, sprain, muscle relief', 'Warmth, rash', 'No', 150.0, 'skincare'],
    ['Iodex Ultra Gel', 'GSK', '5% Iodine Complex', 'Gel', 'Joint/muscle relief, pain', 'Burning, redness', 'No', 75.0, 'skincare'],
    ['Dicloran Gel', 'Sami Pharma', '1% Diclofenac', 'Gel', 'Arthritis, pain, inflammation', 'Peeling, redness', 'Yes', 100.0, 'skincare'],
    ['Metrogyl Gel', 'Abbott', '2% Metronidazole', 'Gel', 'Acne, rosacea, skin infection', 'Burning, itching', 'Yes', 140.0, 'skincare'],
    ['Silverex Gel', 'Maxitech Pharma', '1% Silver Sulfadiazine', 'Gel', 'Burns, wounds, skin healing', 'Skin dryness', 'Yes', 110.0, 'skincare'],
    ['Betnovate', 'GSK', '0.1% Betamethasone', 'Cream', 'Skin allergies, eczema, psoriasis', 'Burning, thinning skin', 'Yes', 120.0, 'skincare'],
    ['Betnovate-N Gel', 'GSK', '0.1% Betamethasone + 0.5% Neomycin', 'Gel', 'Eczema, psoriasis, skin inflammation', 'Skin thinning', 'Yes', 250.0, 'skincare'],
    ['Daktarin', 'Janssen', '2% Miconazole', 'Cream', 'Fungal infections, skin fungus', 'Irritation, redness', 'Yes', 130.0, 'skincare'],
    ['Canesten', 'Bayer', '1% Clotrimazole', 'Cream', 'Fungal infections, skin fungus', 'Irritation', 'No', 130.0, 'skincare'],
    ['Lamisil Gel', 'NOVARTIS', '1% Terbinafine', 'Gel', 'Fungal infections, athletes foot', 'Peeling, dryness', 'Yes', 100.0, 'skincare'],
    ['Neosporin Ointment', 'GSK', '5000 IU Bacitracin', 'Ointment', 'Infected cuts, wounds, skin infections', 'Allergy, itching', 'No', 125.0, 'skincare'],
    ['Soframycin', 'Franco-Indian Pharma', '1% Framycetin', 'Gel', 'Wound healing, cuts, burns', 'Allergy, redness', 'No', 190.0, 'skincare'],
    ['Burnol Gel', 'Dr. Morepen', '0.2% Nitrofurazone', 'Gel', 'Minor burns, wound care', 'Stinging, yellow stain', 'No', 95.0, 'skincare'],
    ['Zindaclin Gel', 'GSK', '1% Clindamycin', 'Gel', 'Acne vulgaris, pimples', 'Dry skin, peeling', 'Yes', 180.0, 'skincare'],
    ['Retin-A Gel', 'Janssen', '0.025% Tretinoin', 'Gel', 'Acne, anti-aging, skin renewal', 'Redness, peeling', 'Yes', 170.0, 'skincare'],
    ['Aloe Vera Gel', 'Pure Leaf', 'Natural', 'Gel', 'Skin moisturizing, sunburn, skin care', 'No major side effects', 'No', 60.0, 'skincare'],
    ['Dermovate', 'Novo Nordisk', '0.05% Clobetasol', 'Cream', 'Severe eczema, psoriasis', 'Skin thinning, redness', 'Yes', 60.0, 'skincare'],
    ['Dologel', 'Macleods', '2% Lidocaine', 'Gel', 'Mouth ulcers, oral pain, gum pain', 'Temporary numbness', 'No', 95.0, 'skincare'],
    ['Zytee Gel', 'Shield', '8% Choline Salicylate', 'Gel', 'Mouth ulcers, gum pain', 'Burning, numbness', 'No', 170.0, 'skincare'],
    ['Refresh Eye Gel', 'Allergan', '0.3% Carboxymethylcellulose', 'Eye Gel', 'Eye dryness, strain, eye care', 'Burning, blurred vision', 'No', 180.0, 'skincare'],
    ['Candid-B Cream', 'Glenmark', '1% Clotrimazole', 'Cream', 'Fungal infections & inflammation', 'Skin thinning, irritation', 'Yes', 100.0, 'skincare'],
    // First Aid
    ['Digital Thermometer', 'Various', 'N/A', 'Device', 'Temperature measurement, fever check', 'None', 'No', 350.0, 'firstaid'],
    ['Blood Pressure Monitor', 'Various', 'N/A', 'Device', 'Blood pressure measurement', 'None', 'No', 2500.0, 'devices'],
    ['Pulse Oximeter', 'Various', 'N/A', 'Device', 'Oxygen saturation monitoring', 'None', 'No', 1200.0, 'devices'],
    ['First Aid Kit', 'Various', 'N/A', 'Kit', 'Emergency medical supplies, first aid', 'None', 'No', 800.0, 'firstaid'],
    ['Bandages Pack', 'Various', 'N/A', 'Pack', 'Wound dressing, cuts, first aid', 'None', 'No', 150.0, 'firstaid'],
    ['Antiseptic Cream', 'Various', 'N/A', 'Cream', 'Wound care, infection prevention', 'Mild irritation', 'No', 120.0, 'firstaid'],
    ['Hand Sanitizer', 'Various', '70% Alcohol', 'Gel', 'Hand hygiene, antibacterial protection', 'Dryness', 'No', 80.0, 'firstaid'],
    ['Face Masks Pack', 'Various', 'N/A', 'Pack', 'Protection, hygiene, safety', 'None', 'No', 200.0, 'firstaid'],
    ['Glucose Meter Kit', 'Various', 'N/A', 'Device', 'Blood sugar monitoring, diabetes care', 'None', 'No', 1500.0, 'devices'],
    ['Infrared Thermometer', 'Various', 'N/A', 'Device', 'Non-contact temperature measurement', 'None', 'No', 1800.0, 'devices'],
];

// Clear existing products and re-import
$conn->query("TRUNCATE TABLE products");

$imported = 0;
$stmt = $conn->prepare("INSERT INTO products (name, description, price, category, stock_quantity) VALUES (?, ?, ?, ?, ?)");

foreach ($medicines as $med) {
    list($drug_name, $manufacturer, $strength, $form, $indication, $side_effects, $prescription, $price, $category) = $med;
    
    $name = $drug_name . ' ' . $strength . ' (' . $form . ')';
    $description = "Manufacturer: $manufacturer | Uses: $indication | Side Effects: $side_effects";
    if ($prescription == 'Yes') $description .= " | ⚠️ Prescription Required";
    $stock = rand(50, 200);
    
    $stmt->bind_param("ssdsi", $name, $description, $price, $category, $stock);
    if ($stmt->execute()) $imported++;
}

echo "<!DOCTYPE html>
<html>
<head>
    <title>Setup Complete</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css' rel='stylesheet'>
</head>
<body style='background:#f8f9fa; padding:2rem;'>
<div class='container' style='max-width:600px; margin:0 auto;'>
    <div class='card shadow border-0 rounded-4'>
        <div class='card-body p-5 text-center'>
            <div style='font-size:4rem;'>✅</div>
            <h2 class='mt-3 text-success'>Setup Complete!</h2>
            <p class='text-muted'>Database created and products imported successfully</p>
            <hr>
            <h4 class='text-primary'>$imported products imported</h4>
            <p class='text-muted'>Including medicines, vitamins, skincare, devices & first aid</p>
            <hr>
            <div class='d-grid gap-2'>
                <a href='products.php' class='btn btn-danger btn-lg'>
                    🛍️ View Products Page
                </a>
                <a href='products.php?search=panadol' class='btn btn-outline-danger'>
                    🔍 Test Search: Panadol
                </a>
                <a href='products.php?search=pain' class='btn btn-outline-danger'>
                    🔍 Test Search: Pain
                </a>
                <a href='admin/quick_login.php' class='btn btn-outline-primary'>
                    ⚙️ Go to Admin Panel
                </a>
            </div>
        </div>
    </div>
</div>
</body>
</html>";
?>
