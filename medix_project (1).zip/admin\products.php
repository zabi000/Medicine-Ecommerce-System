<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Simple authentication check
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Database connection
require_once('../api/config.php');

// Handle Add Product
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    try {
        $name        = trim($_POST['name']);
        $description = trim($_POST['description']);
        $price       = floatval($_POST['price']);
        $category    = trim($_POST['category']);
        $stock       = intval($_POST['stock']);
        $image_url   = trim($_POST['image_url'] ?? '');

        // Handle file upload if a file was selected
        if (!empty($_FILES['product_image']['name'])) {
            $file = $_FILES['product_image'];
            $upload_dir = $_SERVER['DOCUMENT_ROOT'] . (defined('APP_BASE') ? APP_BASE : '/ppp') . '/uploads/products/';
            if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $filename = 'product_' . time() . '_' . rand(1000,9999) . '.' . $ext;
            if (move_uploaded_file($file['tmp_name'], $upload_dir . $filename)) {
                $image_url = 'uploads/products/' . $filename;
            }
        }
        
        // Validation
        if (empty($name) || empty($description) || $price <= 0 || $stock < 0) {
            throw new Exception("Please fill all required fields with valid values.");
        }
        
        // Check if database connection exists
        if (!$conn) {
            throw new Exception("Database connection failed. Please check your database configuration.");
        }
        
        // Insert product
        $stmt = $conn->prepare("INSERT INTO products (name, description, price, category, stock_quantity, image_url) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssdsis", $name, $description, $price, $category, $stock, $image_url);
        
        if ($stmt->execute()) {
            $_SESSION['success_message'] = "Product added successfully!";
            header('Location: products.php');
            exit();
        } else {
            throw new Exception("Error adding product: " . $conn->error);
        }
    } catch (Exception $e) {
        $_SESSION['error_message'] = $e->getMessage();
        header('Location: products.php');
        exit();
    }
}

// Handle Edit Product
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit') {
    try {
        $id = intval($_POST['id']);
        $name = trim($_POST['name']);
        $description = trim($_POST['description']);
        $price = floatval($_POST['price']);
        $category = trim($_POST['category']);
        $stock = intval($_POST['stock']);
        $image_url = trim($_POST['image_url'] ?? '');

        // Handle file upload (takes priority over URL)
        if (isset($_FILES['image_file']) && $_FILES['image_file']['error'] === UPLOAD_ERR_OK) {
            $file = $_FILES['image_file'];
            $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
            $allowed = ['jpg','jpeg','png','gif','webp'];
            if (in_array($ext, $allowed) && $file['size'] <= 5*1024*1024) {
                $upload_dir = __DIR__ . '/../uploads/products/';
                if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);
                $filename = 'product_' . time() . '_' . rand(1000,9999) . '.' . $ext;
                if (move_uploaded_file($file['tmp_name'], $upload_dir . $filename)) {
                    $image_url = 'uploads/products/' . $filename;
                }
            }
        }

        // If no new image provided, keep existing
        if (empty($image_url)) {
            $existing = $conn->query("SELECT image_url FROM products WHERE id=$id");
            if ($existing && $row = $existing->fetch_assoc()) {
                $image_url = $row['image_url'];
            }
        }
        
        // Validation
        if (empty($name) || empty($description) || $price <= 0 || $stock < 0) {
            throw new Exception("Please fill all required fields with valid values.");
        }
        
        if (!$conn) {
            throw new Exception("Database connection failed.");
        }
        
        $stmt = $conn->prepare("UPDATE products SET name=?, description=?, price=?, category=?, stock_quantity=?, image_url=? WHERE id=?");
        $stmt->bind_param("ssdsisi", $name, $description, $price, $category, $stock, $image_url, $id);
        
        if ($stmt->execute()) {
            $_SESSION['success_message'] = "Product updated successfully!";
            header('Location: products.php');
            exit();
        } else {
            throw new Exception("Error updating product: " . $conn->error);
        }
    } catch (Exception $e) {
        $_SESSION['error_message'] = $e->getMessage();
        header('Location: products.php');
        exit();
    }
}

// Handle Delete Product
if (isset($_GET['delete'])) {
    try {
        $id = intval($_GET['delete']);
        
        if (!$conn) {
            throw new Exception("Database connection failed.");
        }
        
        // Delete order_items referencing this product first (foreign key constraint)
        $conn->query("DELETE FROM order_items WHERE product_id = $id");
        
        // Now delete the product
        $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
        $stmt->bind_param("i", $id);
        
        if ($stmt->execute()) {
            $_SESSION['success_message'] = "Product deleted successfully!";
        } else {
            throw new Exception("Error deleting product: " . $conn->error);
        }
    } catch (Exception $e) {
        $_SESSION['error_message'] = $e->getMessage();
    }
    
    header('Location: products.php');
    exit();
}

// Get success/error messages from session
$success_message = $_SESSION['success_message'] ?? null;
$error_message = $_SESSION['error_message'] ?? null;
unset($_SESSION['success_message'], $_SESSION['error_message']);

// Fetch categories from database
$db_categories = [];
$cat_result = $conn ? $conn->query("SELECT name FROM categories ORDER BY name ASC") : false;
if ($cat_result && $cat_result->num_rows > 0) {
    while ($cat = $cat_result->fetch_assoc()) {
        $db_categories[] = $cat['name'];
    }
}
// Always include these defaults
$default_cats = ['vitamins', 'skincare', 'prescription', 'firstaid', 'devices', 'personal', 'baby'];
$all_categories = array_unique(array_merge($db_categories, $default_cats));
sort($all_categories);

// Fetch all products
$result = @$conn->query("SELECT * FROM products ORDER BY id DESC");

// If no database, create fake data
if (!$result || $result->num_rows == 0) {
    $fake_products = [];
    $medicines = ['Panadol', 'Brufen', 'Augmentin', 'Disprin', 'Calpol', 'Flagyl', 'Glucophage', 'Concor', 'Norvasc', 'Centrum'];
    $types = ['Tab', 'Cap', 'Syp', 'Inj'];
    $dosages = ['500mg', '250mg', '100mg', '50mg'];
    
    for ($i = 1; $i <= 30; $i++) {
        $fake_products[] = [
            'id' => $i,
            'name' => $types[array_rand($types)] . ' ' . $medicines[array_rand($medicines)] . ' ' . $dosages[array_rand($dosages)],
            'description' => 'High quality medicine for effective treatment',
            'category' => ['prescription', 'vitamins', 'firstaid'][array_rand(['prescription', 'vitamins', 'firstaid'])],
            'price' => rand(50, 2000),
            'stock_quantity' => rand(10, 200)
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products Management - Medix Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        :root {
            --primary-color: #B91C1C;
            --secondary-color: #991B1B;
            --sidebar-width: 250px;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: #F3F4F6;
        }
        
        :root{--sw:280px}
        .sidebar{position:fixed;top:0;left:0;width:var(--sw);height:100vh;background:linear-gradient(180deg,#B91C1C,#7F1D1D);overflow-y:auto;z-index:1000}
        .sb-brand{padding:1.5rem;border-bottom:1px solid rgba(255,255,255,.1);color:white}
        .mi{display:flex;align-items:center;gap:.75rem;padding:.875rem 1.5rem;color:rgba(255,255,255,.8);text-decoration:none;border-left:3px solid transparent;transition:all .2s;font-weight:500}
        .mi:hover,.mi.active{background:rgba(255,255,255,.15);color:white;border-left-color:white}
        .mi i{width:20px}
        .mdiv{height:1px;background:rgba(255,255,255,.1);margin:.5rem 1.5rem}
        .main-content {
            margin-left: var(--sw);
            padding: 2rem;
        }
        
        .top-bar {
            background: white;
            padding: 1rem 2rem;
            margin: -2rem -2rem 2rem -2rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .table-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        .product-image-preview {
            width: 60px;
            height: 60px;
            background: #F3F4F6;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
        }
        .gallery-item:hover {
            border-color: #B91C1C !important;
            transform: scale(1.05);
            box-shadow: 0 4px 12px rgba(185,28,28,0.2);
        }
        .drag-over {
            border-color: #B91C1C !important;
            background: #fef2f2 !important;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sb-brand"><h4 class="mb-0 fw-bold"><i class="bi bi-heart-pulse-fill me-2"></i>MEDIX</h4><small style="opacity:.6">Admin Portal</small></div>
        <a href="index.php" class="mi"><i class="bi bi-speedometer2"></i>Dashboard</a>
        <a href="products.php" class="mi active"><i class="bi bi-box-seam"></i>Products</a>
        <a href="offers.php" class="mi"><i class="bi bi-tag-fill"></i>Offers</a>
        <a href="orders.php" class="mi"><i class="bi bi-cart-check"></i>Orders</a>
        <a href="customers.php" class="mi"><i class="bi bi-people"></i>Customers</a>
        <a href="categories.php" class="mi"><i class="bi bi-tags"></i>Categories</a>
        <a href="messages.php" class="mi"><i class="bi bi-envelope"></i>Messages</a>
        <a href="reports.php" class="mi"><i class="bi bi-graph-up"></i>Reports</a>
        <a href="settings.php" class="mi"><i class="bi bi-gear"></i>Settings</a>
        <div class="mdiv"></div>
        <a href="database.php" class="mi"><i class="bi bi-database"></i>Database</a>
        <a href="import_medicines.php" class="mi" style="color:#10B981"><i class="bi bi-capsule-pill"></i>Import Medicines</a>
        <div class="mdiv"></div>
        <a href="logout.php" class="mi"><i class="bi bi-box-arrow-right"></i>Logout</a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h4 class="mb-0">Products Management</h4>
                    <small class="text-muted">Manage your product inventory</small>
                </div>
                <div class="d-flex gap-2 align-items-center">
                    <div class="input-group" style="width: 300px;">
                        <span class="input-group-text bg-white border-end-0">
                            <i class="bi bi-search text-muted"></i>
                        </span>
                        <input type="text" id="productSearch" class="form-control border-start-0" 
                               placeholder="Search products..." 
                               oninput="filterProducts(this.value)">
                    </div>
                    <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#addProductModal">
                        <i class="bi bi-plus-circle"></i> Add New Product
                    </button>
                </div>
            </div>
        </div>

        <?php if (isset($success_message)): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle"></i> <?= $success_message ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle"></i> <?= $error_message ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Products Table -->
        <div class="table-card">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <p class="text-muted mb-0">
                    Showing <strong id="productCount"><?= $result ? $result->num_rows : 0 ?></strong> products
                </p>
            </div>
            <div class="table-responsive">
                <table class="table table-hover" id="productsTable">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Image</th>
                            <th>Product Name</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Stock</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if (isset($fake_products) && count($fake_products) > 0) {
                            // Show fake products
                            foreach ($fake_products as $product) {
                        ?>
                        <tr>
                            <td><?= $product['id'] ?></td>
                            <td>
                                <div class="product-image-preview">
                                    <i class="bi bi-capsule-pill text-danger"></i>
                                </div>
                            </td>
                            <td>
                                <strong><?= htmlspecialchars($product['name']) ?></strong><br>
                                <small class="text-muted"><?= htmlspecialchars($product['description']) ?></small>
                            </td>
                            <td><span class="badge bg-info"><?= htmlspecialchars($product['category']) ?></span></td>
                            <td><strong>PKR <?= number_format($product['price'], 2) ?></strong></td>
                            <td>
                                <?php if ($product['stock_quantity'] > 20): ?>
                                    <span class="badge bg-success"><?= $product['stock_quantity'] ?> units</span>
                                <?php elseif ($product['stock_quantity'] > 0): ?>
                                    <span class="badge bg-warning"><?= $product['stock_quantity'] ?> units</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Out of Stock</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($product['stock_quantity'] > 0): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-outline-primary">
                                    <i class="bi bi-pencil"></i>
                                </button>
                                <button class="btn btn-sm btn-outline-danger">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </td>
                        </tr>
                        <?php 
                            }
                        } elseif ($result && $result->num_rows > 0) {
                            // Show real products from database
                            while ($product = $result->fetch_assoc()) {
                        ?>
                        <tr data-name="<?= strtolower(htmlspecialchars($product['name'])) ?>" data-category="<?= strtolower(htmlspecialchars($product['category'])) ?>">
                            <td><?= $product['id'] ?></td>
                            <td>
                                <?php if (!empty($product['image_url'])): ?>
                                    <img src="../<?= htmlspecialchars($product['image_url']) ?>" 
                                         alt="<?= htmlspecialchars($product['name']) ?>" 
                                         class="product-image-preview"
                                         style="width: 60px; height: 60px; object-fit: cover; border-radius: 8px;"
                                         onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';">
                                    <div class="product-image-preview" style="display: none;">
                                        <i class="bi bi-capsule-pill text-danger"></i>
                                    </div>
                                <?php else: ?>
                                    <div class="product-image-preview">
                                        <i class="bi bi-capsule-pill text-danger"></i>
                                    </div>
                                <?php endif; ?>
                            </td>
                            <td>
                                <strong><?= htmlspecialchars($product['name']) ?></strong><br>
                                <small class="text-muted"><?= htmlspecialchars(substr($product['description'], 0, 50)) ?>...</small>
                            </td>
                            <td><span class="badge bg-info"><?= htmlspecialchars($product['category']) ?></span></td>
                            <td><strong>PKR <?= number_format($product['price'], 2) ?></strong></td>
                            <td>
                                <?php if ($product['stock_quantity'] > 20): ?>
                                    <span class="badge bg-success"><?= $product['stock_quantity'] ?> units</span>
                                <?php elseif ($product['stock_quantity'] > 0): ?>
                                    <span class="badge bg-warning"><?= $product['stock_quantity'] ?> units</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Out of Stock</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($product['stock_quantity'] > 0): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#editProductModal<?= $product['id'] ?>">
                                    <i class="bi bi-pencil"></i>
                                </button>
                                <a href="?delete=<?= $product['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure you want to delete this product?')">
                                    <i class="bi bi-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php 
                            }
                        } else {
                        ?>
                        <tr>
                            <td colspan="8" class="text-center py-5">
                                <i class="bi bi-inbox" style="font-size: 3rem; color: #ccc;"></i>
                                <p class="text-muted mt-3">No products found. Add your first product!</p>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Add Product Modal -->
    <div class="modal fade" id="addProductModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title"><i class="bi bi-plus-circle me-2"></i>Add New Product</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" id="addProductForm" enctype="multipart/form-data">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add">
                        
                        <div class="row">
                            <div class="col-md-8">
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Product Name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="name" placeholder="e.g., Paracetamol 500mg" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Description <span class="text-danger">*</span></label>
                                    <textarea class="form-control" name="description" rows="3" placeholder="Enter product description..." required></textarea>
                                    <small class="text-muted">Provide detailed information about the product</small>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Product Image</label>

                                    <!-- Simple Tab Switcher -->
                                    <div class="d-flex gap-2 mb-2 flex-wrap">
                                        <button type="button" class="btn btn-sm btn-danger" onclick="showImgTab('upload',this)">📁 Upload from PC</button>
                                        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="showImgTab('url',this)">🔗 Paste URL</button>
                                        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="showImgTab('gallery',this)">🖼️ Gallery</button>
                                        <a href="gallery.php" target="_blank" class="btn btn-sm btn-outline-primary"><i class="bi bi-images me-1"></i>Manage Gallery</a>
                                    </div>

                                    <!-- Upload from PC - DIRECT FILE INPUT -->
                                    <div id="img-upload">
                                        <input type="file" name="product_image" id="productImageFile" accept="image/*"
                                               class="form-control mb-2"
                                               onchange="previewImage(this)">
                                        <div id="imgPreviewBox" style="display:none;margin-top:.5rem">
                                            <img id="imgPreviewImg" src="" style="max-height:150px;border-radius:8px;border:2px solid #10b981">
                                            <p class="text-success small mt-1"><i class="bi bi-check-circle-fill me-1"></i>Image selected — will upload when you save</p>
                                        </div>
                                        <small class="text-muted">JPG, PNG, GIF, WEBP — Max 5MB</small>
                                    </div>

                                    <!-- Paste URL -->
                                    <div id="img-url" style="display:none">
                                        <input type="url" class="form-control" name="image_url" id="imageUrlInput"
                                               placeholder="https://example.com/image.jpg"
                                               oninput="previewUrl(this.value)">
                                        <div id="urlPreviewBox" style="display:none;margin-top:.5rem">
                                            <img id="urlPreviewImg" src="" style="max-height:150px;border-radius:8px">
                                        </div>
                                        <small class="text-muted">Paste any image URL</small>
                                    </div>

                                    <!-- Gallery -->
                                    <div id="img-gallery" style="display:none;border:1px solid #dee2e6;border-radius:8px;padding:1rem;background:#f8f9fa;max-height:260px;overflow-y:auto">
                                        <p class="text-muted small mb-2"><i class="bi bi-hand-index me-1"></i>Click any image to select. <a href="gallery.php" target="_blank" class="text-danger">Upload more →</a></p>
                                        <div class="row g-2">
                                            <?php
                                            $gdir = $_SERVER['DOCUMENT_ROOT'] . '/ppp/uploads/products/';
                                            $gimages = is_dir($gdir) ? glob($gdir . '*.{jpg,jpeg,png,gif,webp}', GLOB_BRACE) : [];
                                            if (!empty($gimages)):
                                                foreach (array_slice(array_reverse($gimages), 0, 24) as $gf):
                                                    $gurl = 'uploads/products/' . basename($gf);
                                            ?>
                                            <div class="col-3">
                                                <img src="/ppp/<?= htmlspecialchars($gurl) ?>" alt="<?= basename($gf) ?>"
                                                     style="width:100%;height:65px;object-fit:cover;border-radius:8px;cursor:pointer;border:2px solid transparent;transition:all .2s"
                                                     onclick="selectGalleryImg('<?= htmlspecialchars($gurl) ?>',this)"
                                                     onerror="this.parentElement.style.display='none'">
                                            </div>
                                            <?php endforeach; else: ?>
                                            <div class="col-12 text-center py-3 text-muted">
                                                <i class="bi bi-images" style="font-size:2rem;display:block;margin-bottom:.5rem"></i>
                                                No images yet.<br>
                                                <a href="gallery.php" target="_blank" class="btn btn-sm btn-danger mt-2">Upload Images</a>
                                            </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <!-- Hidden URL field for gallery/url selection -->
                                    <input type="hidden" name="image_url" id="finalImageUrl">
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Image Preview</label>
                                    <div id="imagePreview" class="border rounded p-3 text-center" style="min-height: 200px; background: #f8f9fa;">
                                        <i class="bi bi-image text-muted" style="font-size: 3rem;"></i>
                                        <p class="text-muted small mt-2">No image</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Category <span class="text-danger">*</span></label>
                                <select class="form-select" name="category" required>
                                    <option value="">Select Category</option>
                                    <?php foreach ($all_categories as $cat): ?>
                                    <option value="<?= htmlspecialchars($cat) ?>"><?= htmlspecialchars(ucwords(str_replace(['_','-'], ' ', $cat))) ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="col-md-3 mb-3">
                                <label class="form-label fw-bold">Price (PKR) <span class="text-danger">*</span></label>
                                <input type="number" step="0.01" min="0" class="form-control" name="price" placeholder="0.00" required>
                            </div>
                            
                            <div class="col-md-3 mb-3">
                                <label class="form-label fw-bold">Stock <span class="text-danger">*</span></label>
                                <input type="number" min="0" class="form-control" name="stock" placeholder="0" required>
                            </div>
                        </div>
                        
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle me-2"></i>
                            <strong>Tip:</strong> You can find free product images on <a href="https://unsplash.com" target="_blank">Unsplash</a> or <a href="https://pexels.com" target="_blank">Pexels</a>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="bi bi-x-circle me-1"></i>Cancel
                        </button>
                        <button type="submit" class="btn btn-danger">
                            <i class="bi bi-check-circle me-1"></i>Add Product
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Product Modals -->
    <?php 
    if ($result && $result->num_rows > 0) {
        $result->data_seek(0); // Reset pointer
        while ($product = $result->fetch_assoc()) {
    ?>
    <div class="modal fade" id="editProductModal<?= $product['id'] ?>" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title"><i class="bi bi-pencil me-2"></i>Edit Product</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST" enctype="multipart/form-data">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="edit">
                        <input type="hidden" name="id" value="<?= $product['id'] ?>">
                        
                        <div class="row">
                            <div class="col-md-8">
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Product Name <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="name" value="<?= htmlspecialchars($product['name']) ?>" required>
                                </div>
                                
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Description <span class="text-danger">*</span></label>
                                    <textarea class="form-control" name="description" rows="3" required><?= htmlspecialchars($product['description']) ?></textarea>
                                </div>

                                <!-- Image section — same as Add modal -->
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Product Image</label>
                                    <div class="d-flex gap-2 mb-2 flex-wrap">
                                        <button type="button" class="btn btn-sm btn-danger" onclick="showEditImgTab('upload',this)"><i class="bi bi-upload me-1"></i>Upload</button>
                                        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="showEditImgTab('url',this)"><i class="bi bi-link me-1"></i>URL</button>
                                        <button type="button" class="btn btn-sm btn-outline-secondary" onclick="showEditImgTab('gallery',this)"><i class="bi bi-images me-1"></i>Gallery</button>
                                        <a href="gallery.php" target="_blank" class="btn btn-sm btn-outline-primary"><i class="bi bi-plus me-1"></i>Upload to Gallery</a>
                                    </div>

                                    <!-- Upload -->
                                    <div id="edit-img-upload" style="display:block">
                                        <input type="file" class="form-control" name="image_file" accept="image/*"
                                               onchange="editPreviewUpload(this)">
                                        <small class="text-muted">Upload JPG, PNG, GIF (max 5MB). Leave blank to keep current image.</small>
                                    </div>

                                    <!-- URL -->
                                    <div id="edit-img-url" style="display:none">
                                        <input type="url" class="form-control" name="image_url" id="editImageUrlInput"
                                               value="<?= htmlspecialchars($product['image_url'] ?? '') ?>"
                                               placeholder="https://example.com/image.jpg"
                                               oninput="editPreviewUrl(this.value)">
                                        <small class="text-muted">Paste any image URL</small>
                                    </div>

                                    <!-- Gallery -->
                                    <div id="edit-img-gallery" style="display:none;border:1px solid #dee2e6;border-radius:8px;padding:1rem;background:#f8f9fa;max-height:220px;overflow-y:auto">
                                        <p class="text-muted small mb-2"><i class="bi bi-hand-index me-1"></i>Click any image to select.</p>
                                        <div class="row g-2">
                                        <?php
                                        $gdir2 = __DIR__ . '/../uploads/products/';
                                        $gfiles2 = is_dir($gdir2) ? array_filter(scandir($gdir2), fn($f) => preg_match('/\.(jpg|jpeg|png|gif|webp)$/i', $f)) : [];
                                        if (!empty($gfiles2)):
                                            foreach ($gfiles2 as $gf2):
                                                $gurl2 = 'uploads/products/' . $gf2;
                                        ?>
                                        <div class="col-3">
                                            <img src="/ppp/<?= htmlspecialchars($gurl2) ?>" alt="<?= basename($gf2) ?>"
                                                 style="width:100%;height:65px;object-fit:cover;border-radius:8px;cursor:pointer;border:2px solid transparent;transition:all .2s"
                                                 onclick="selectEditGalleryImg('<?= htmlspecialchars($gurl2) ?>',this)"
                                                 onerror="this.parentElement.style.display='none'">
                                        </div>
                                        <?php endforeach; else: ?>
                                        <div class="col-12 text-center text-muted py-3">
                                            <i class="bi bi-images" style="font-size:2rem;display:block;margin-bottom:.5rem"></i>
                                            No images yet. <a href="gallery.php" target="_blank" class="text-danger">Upload Images</a>
                                        </div>
                                        <?php endif; ?>
                                        </div>
                                    </div>

                                    <!-- Hidden field for gallery/url selection -->
                                    <input type="hidden" name="image_url" id="editFinalImageUrl" value="<?= htmlspecialchars($product['image_url'] ?? '') ?>">
                                </div>
                            </div>
                            
                            <div class="col-md-4">
                                <div class="mb-3">
                                    <label class="form-label fw-bold">Current Image</label>
                                    <div class="border rounded p-3 text-center" style="min-height:180px;background:#f8f9fa" id="editImgPreviewBox">
                                        <?php if (!empty($product['image_url'])): ?>
                                            <img id="editImgPreview" src="../<?= htmlspecialchars($product['image_url']) ?>"
                                                 alt="Product"
                                                 style="max-width:100%;max-height:160px;object-fit:contain;border-radius:8px"
                                                 onerror="this.style.display='none'">
                                        <?php else: ?>
                                            <i class="bi bi-image text-muted" style="font-size:3rem"></i>
                                            <p class="text-muted small mt-2">No image</p>
                                        <?php endif; ?>
                                    </div>
                                    <small class="text-muted">Preview updates when you select</small>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label fw-bold">Category <span class="text-danger">*</span></label>
                                <select class="form-select" name="category" required>
                                    <?php foreach ($all_categories as $cat): ?>
                                    <option value="<?= htmlspecialchars($cat) ?>" <?= $product['category'] === $cat ? 'selected' : '' ?>>
                                        <?= htmlspecialchars(ucwords(str_replace(['_','-'], ' ', $cat))) ?>
                                    </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            
                            <div class="col-md-3 mb-3">
                                <label class="form-label fw-bold">Price (PKR) <span class="text-danger">*</span></label>
                                <input type="number" step="0.01" min="0" class="form-control" name="price" value="<?= $product['price'] ?>" required>
                            </div>
                            
                            <div class="col-md-3 mb-3">
                                <label class="form-label fw-bold">Stock <span class="text-danger">*</span></label>
                                <input type="number" min="0" class="form-control" name="stock" value="<?= $product['stock_quantity'] ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="bi bi-x-circle me-1"></i>Cancel
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-check-circle me-1"></i>Update Product
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php 
        }
    }
    ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Live search filter for products table
        function filterProducts(query) {
            const rows = document.querySelectorAll('#productsTable tbody tr');
            const q = query.toLowerCase().trim();
            let visibleCount = 0;

            rows.forEach(row => {
                const name = row.getAttribute('data-name') || '';
                const category = row.getAttribute('data-category') || '';
                const matches = name.includes(q) || category.includes(q);
                row.style.display = matches ? '' : 'none';
                if (matches) visibleCount++;
            });

            // Show/hide no results message
            let noResults = document.getElementById('noResultsRow');
            if (visibleCount === 0 && q !== '') {
                if (!noResults) {
                    noResults = document.createElement('tr');
                    noResults.id = 'noResultsRow';
                    noResults.innerHTML = `<td colspan="8" class="text-center py-4 text-muted">
                        <i class="bi bi-search" style="font-size: 2rem;"></i>
                        <p class="mt-2">No products found for "<strong>${query}</strong>"</p>
                    </td>`;
                    document.querySelector('#productsTable tbody').appendChild(noResults);
                }
                noResults.style.display = '';
            } else if (noResults) {
                noResults.style.display = 'none';
            }

            // Update count
            const countEl = document.getElementById('productCount');
            if (countEl) countEl.textContent = visibleCount;
        }

        // Simple image tab switcher
        function showImgTab(tab, btn) {
            ['upload','url','gallery'].forEach(t => {
                document.getElementById('img-' + t).style.display = t === tab ? 'block' : 'none';
            });
            document.querySelectorAll('[onclick^="showImgTab"]').forEach(b => {
                b.className = 'btn btn-sm btn-outline-secondary';
            });
            btn.className = 'btn btn-sm btn-danger';
        }

        // Preview uploaded file immediately
        function previewImage(input) {
            const file = input.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = e => {
                document.getElementById('imgPreviewImg').src = e.target.result;
                document.getElementById('imgPreviewBox').style.display = 'block';
            };
            reader.readAsDataURL(file);
        }

        // Preview URL
        function previewUrl(url) {
            if (!url) { document.getElementById('urlPreviewBox').style.display = 'none'; return; }
            const img = document.getElementById('urlPreviewImg');
            img.src = url;
            img.onerror = () => document.getElementById('urlPreviewBox').style.display = 'none';
            img.onload = () => document.getElementById('urlPreviewBox').style.display = 'block';
        }

        // Select from gallery
        function selectGalleryImg(url, el) {
            document.getElementById('finalImageUrl').value = url;
            document.querySelectorAll('#img-gallery img').forEach(i => i.style.border = '2px solid transparent');
            el.style.border = '2px solid #B91C1C';
            setTimeout(() => document.getElementById('img-gallery').style.display = 'none', 300);
        }

        // ===== EDIT MODAL IMAGE FUNCTIONS =====
        function showEditImgTab(tab, btn) {
            ['upload','url','gallery'].forEach(t => {
                const el = document.getElementById('edit-img-' + t);
                if (el) el.style.display = t === tab ? 'block' : 'none';
            });
        }

        function editPreviewUpload(input) {
            const file = input.files[0];
            if (!file) return;
            const reader = new FileReader();
            reader.onload = e => {
                const img = document.getElementById('editImgPreview');
                const box = document.getElementById('editImgPreviewBox');
                if (img) { img.src = e.target.result; img.style.display = 'block'; }
                else { box.innerHTML = '<img id="editImgPreview" src="' + e.target.result + '" style="max-width:100%;max-height:160px;object-fit:contain;border-radius:8px">'; }
                // Clear URL field so file takes priority
                document.getElementById('editFinalImageUrl').value = '';
            };
            reader.readAsDataURL(file);
        }

        function editPreviewUrl(url) {
            document.getElementById('editFinalImageUrl').value = url;
            const img = document.getElementById('editImgPreview');
            const box = document.getElementById('editImgPreviewBox');
            if (url) {
                if (img) { img.src = url; img.style.display = 'block'; }
                else { box.innerHTML = '<img id="editImgPreview" src="' + url + '" style="max-width:100%;max-height:160px;object-fit:contain;border-radius:8px" onerror="this.style.display=\'none\'">'; }
            }
        }

        function selectEditGalleryImg(url, el) {
            document.getElementById('editFinalImageUrl').value = url;
            document.querySelectorAll('#edit-img-gallery img').forEach(i => i.style.border = '2px solid transparent');
            el.style.border = '2px solid #B91C1C';
            // Update preview
            const img = document.getElementById('editImgPreview');
            const box = document.getElementById('editImgPreviewBox');
            if (img) { img.src = '/ppp/' + url; img.style.display = 'block'; }
            else { box.innerHTML = '<img id="editImgPreview" src="/ppp/' + url + '" style="max-width:100%;max-height:160px;object-fit:contain;border-radius:8px">'; }
            setTimeout(() => document.getElementById('edit-img-gallery').style.display = 'none', 300);
        }
            const url = e.target.value;
            const preview = document.getElementById('imagePreview');
            
            if (url) {
                preview.innerHTML = `
                    <img src="${url}" 
                         alt="Preview" 
                         style="max-width: 100%; max-height: 180px; object-fit: contain;"
                         onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">
                    <div style="display: none;">
                        <i class="bi bi-exclamation-triangle text-warning" style="font-size: 3rem;"></i>
                        <p class="text-muted small mt-2">Invalid image URL</p>
                    </div>
                `;
            } else {
                preview.innerHTML = `
                    <i class="bi bi-image text-muted" style="font-size: 3rem;"></i>
                    <p class="text-muted small mt-2">No image</p>
                `;
            }
        });
        
        // Auto-dismiss alerts after 5 seconds
        setTimeout(function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);
    </script>
</body>
</html>
