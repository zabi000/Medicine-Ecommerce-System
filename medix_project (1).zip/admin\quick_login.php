﻿<?php
session_start();
$_SESSION['admin_logged_in'] = true;
$_SESSION['admin_username'] = 'admin';
header('Location: index.php');
exit();
?>

