BRAND LOGOS FOLDER
==================

Place pharmaceutical company logos here.

FILE NAMING:
- pfizer.png
- gsk.png
- johnson-johnson.png
- novartis.png
- bayer.png
- abbott.png
- roche.png
- merck.png

WHERE TO GET LOGOS:
1. Google Search: "[Company Name] logo PNG transparent"
2. Official company websites
3. Logo download sites (ensure commercial use allowed)

LOGO SPECS:
- Size: 200x100px (landscape)
- Format: PNG (transparent background preferred)
- Quality: Vector or high-resolution

TIPS:
- Use transparent background PNG files
- Keep logos simple and clean
- Ensure proper licensing for commercial use

AFTER ADDING LOGOS:
Refresh your browser (Ctrl + Shift + R) to see them!
