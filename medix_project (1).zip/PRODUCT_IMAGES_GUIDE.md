# Product Images Setup Guide

## 📁 Folder Structure Created
```
images/
├── products/     (Product images)
├── brands/       (Company logos)
└── README.md
```

## 🖼️ How to Add Product Images

### Step 1: Prepare Your Images
- **Size:** 500x500px (square format recommended)
- **Format:** JPG, PNG, or WebP
- **Quality:** High resolution, clear product photos
- **Background:** White or transparent background preferred

### Step 2: Name Your Images
Product images should be named according to product ID:
- `product-1.jpg` → Paracetamol 500mg
- `product-2.jpg` → Ibuprofen 400mg
- `product-3.jpg` → Vitamin C 1000mg
- `product-4.jpg` → First Aid Kit
- etc.

### Step 3: Upload Images
1. Place images in `images/products/` folder
2. Ensure filenames match the pattern: `product-{id}.jpg`
3. Refresh your browser to see the images

## 🏢 How to Add Brand Logos

### Step 1: Prepare Logos
- **Size:** 200x100px (landscape format)
- **Format:** PNG (with transparent background)
- **Quality:** Vector or high-resolution

### Step 2: Name Your Logos
- `pfizer.png`
- `gsk.png`
- `johnson-johnson.png`
- `novartis.png`
- `bayer.png`
- `abbott.png`
- `roche.png`
- `merck.png`

### Step 3: Upload Logos
1. Place logos in `images/brands/` folder
2. Update the HTML to use actual logo images

## 📦 Current Products in Database

| ID | Product Name | Category |
|----|-------------|----------|
| 1 | Paracetamol 500mg | prescription |
| 2 | Ibuprofen 400mg | prescription |
| 3 | Vitamin C 1000mg | vitamins |
| 4 | First Aid Kit | firstaid |
| 5 | Digital Thermometer | devices |
| 6 | Vitamin D3 2000IU | vitamins |
| 7 | Bandages Pack | firstaid |
| 8 | Blood Pressure Monitor | devices |
| 9 | Aspirin 100mg | prescription |
| 10 | Multivitamin Complex | vitamins |
| 11 | Hand Sanitizer 500ml | personal |
| 12 | Face Masks (50 Pack) | personal |
| 13 | Omega-3 Fish Oil | vitamins |
| 14 | Glucose Meter Kit | devices |
| 15 | Antiseptic Cream | firstaid |
| 16 | Calcium + Vitamin D | vitamins |
| 17 | Pulse Oximeter | devices |
| 18 | Cough Syrup | prescription |
| 19 | Probiotic Capsules | vitamins |
| 20 | Infrared Thermometer | devices |

## 🎨 Where to Get Product Images

### Free Stock Photo Sites:
1. **Unsplash** - https://unsplash.com/s/photos/medicine
2. **Pexels** - https://www.pexels.com/search/pharmacy/
3. **Pixabay** - https://pixabay.com/images/search/medicine/

### Tips for Finding Images:
- Search for: "medicine bottle", "pills", "medical device", "vitamins"
- Look for white background images
- Ensure images are royalty-free for commercial use
- Download high-resolution versions

## 🔄 Automatic Fallback

If an image is not found, the system automatically shows:
- Icon emoji (💊, 💉, 🩹, etc.)
- Colored background
- No broken image icons

## ✨ Features Added

### Product Cards Now Show:
- ✅ Product images (with fallback to icons)
- ✅ Stock status badges (In Stock, Low Stock, Out of Stock)
- ✅ Star ratings with review counts
- ✅ "NEW" badges for recent products
- ✅ Disabled "Add to Cart" for out-of-stock items

### Brand Section Shows:
- ✅ 8 major pharmaceutical company names
- ✅ Professional card layout
- ✅ Hover effects
- ✅ Ready for logo images

## 🚀 Next Steps

1. Download product images from stock photo sites
2. Rename them to match product IDs
3. Place in `images/products/` folder
4. Download brand logos
5. Place in `images/brands/` folder
6. Refresh browser to see changes!

## 💡 Pro Tip

You can also update the database to include image URLs:
```sql
ALTER TABLE products ADD COLUMN image_url VARCHAR(255);
UPDATE products SET image_url = 'product-1.jpg' WHERE id = 1;
```

Then modify the JavaScript to use `product.image_url` instead of `product-${product.id}.jpg`
