# MEDIX — Deployment Guide

## Step 1: Upload Files
Upload all files to your hosting server's `public_html` (or subdirectory).

## Step 2: Create Database
1. Go to your hosting **phpMyAdmin**
2. Create a new database (e.g. `medix_db`)
3. Import `database/schema.sql`
4. Import `database/complete_data.sql` (products & sample data)

## Step 3: Update Database Credentials
Edit `api/config.php`:
```php
define('DB_HOST', 'localhost');       // Usually localhost
define('DB_USER', 'your_db_user');    // Your hosting DB username
define('DB_PASS', 'your_db_pass');    // Your hosting DB password
define('DB_NAME', 'your_db_name');    // Database name you created
```

## Step 4: Set APP_BASE
In `api/config.php`, the `_detectBase()` function auto-detects:
- **localhost** → uses `/ppp`
- **Live server** → uses `''` (root)

If your site is in a subfolder on live (e.g. `yourdomain.com/medix/`), set:
```php
// In _detectBase() function, change the live return to:
return '/medix';
```

## Step 5: Update SMTP Email (Optional)
Edit `api/mailer.php` or set via Admin Panel → Settings → Email:
- Replace Mailtrap credentials with your real SMTP (Gmail, SendGrid, etc.)

## Step 6: Set Folder Permissions
```
uploads/          → 755
uploads/products/ → 755
uploads/messages/ → 755
uploads/payments/ → 755
```

## Step 7: Disable Error Display (Production)
In `api/config.php` add:
```php
ini_set('display_errors', 0);
error_reporting(0);
```

## Step 8: Admin Login
Default admin: `admin@medix.com` / `admin123`
**Change this immediately after deployment!**

## Checklist
- [ ] DB credentials updated
- [ ] Database imported
- [ ] Upload folders writable (755)
- [ ] SMTP configured
- [ ] Error display disabled
- [ ] Admin password changed
- [ ] Test registration + login
- [ ] Test add to cart + checkout
- [ ] Test admin panel
