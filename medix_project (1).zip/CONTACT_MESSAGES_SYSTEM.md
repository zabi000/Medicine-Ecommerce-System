# 📧 Contact Messages System - Complete Guide

## Overview
A complete contact form system where users can send messages and admins can view, manage, and reply to them from the admin dashboard.

---

## 🎯 Features

### For Users:
- ✅ Professional contact form with validation
- ✅ Multiple subject categories
- ✅ Instant confirmation with reference number
- ✅ Email and phone contact options
- ✅ FAQ section for quick answers

### For Admins:
- ✅ Dedicated messages dashboard
- ✅ View all contact messages
- ✅ Filter by status (New, Read, Replied)
- ✅ Update message status
- ✅ Reply via email directly
- ✅ Delete messages
- ✅ Statistics and counts
- ✅ Real-time notifications

---

## 📁 Files Created

### 1. Database
- `database/contact_messages.sql` - Table structure

### 2. API
- `api/submit_contact.php` - Handles form submissions

### 3. Admin
- `admin/messages.php` - Messages dashboard

### 4. Setup
- `setup_contact_messages.php` - One-click setup script

### 5. Updated Files
- `contact.html` - Updated with AJAX submission
- `admin/index.php` - Added Messages link

---

## 🚀 Setup Instructions

### Step 1: Create Database Table
Run the setup script:
```
http://localhost/setup_contact_messages.php
```

This will:
- Create the `contact_messages` table
- Show table structure
- Provide test links

### Step 2: Test Contact Form
1. Go to `contact.html`
2. Fill out the form
3. Submit
4. You'll get a confirmation with reference number

### Step 3: View Messages in Admin
1. Login to admin panel
2. Click "Messages" in sidebar
3. View all submitted messages

---

## 📊 Database Structure

### Table: `contact_messages`

| Field | Type | Description |
|-------|------|-------------|
| id | INT | Auto-increment primary key |
| first_name | VARCHAR(100) | User's first name |
| last_name | VARCHAR(100) | User's last name |
| email | VARCHAR(255) | User's email |
| phone | VARCHAR(20) | User's phone number |
| subject | VARCHAR(100) | Message subject/category |
| message | TEXT | Message content |
| status | ENUM | new, read, replied |
| created_at | TIMESTAMP | When message was sent |
| updated_at | TIMESTAMP | Last update time |

---

## 🎨 Admin Dashboard Features

### Statistics Cards
- **Total Messages**: All messages count
- **New Messages**: Unread messages (green)
- **Read Messages**: Opened messages (blue)
- **Replied Messages**: Responded messages (purple)

### Filter Options
- All Messages
- New Only
- Read Only
- Replied Only

### Message Card Features
- Color-coded by status (left border)
- Full contact information
- Subject badge
- Message content
- Timestamp
- Status dropdown (change status)
- Reply via Email button
- Delete button

### Actions Available
1. **Change Status**: Dropdown to mark as New/Read/Replied
2. **Reply via Email**: Opens email client with pre-filled subject
3. **Delete**: Remove message (with confirmation)

---

## 💻 How It Works

### User Submits Form:
```
1. User fills contact form
2. JavaScript validates fields
3. AJAX sends data to api/submit_contact.php
4. PHP validates and saves to database
5. Returns success with reference number
6. User sees confirmation message
```

### Admin Views Messages:
```
1. Admin logs in
2. Clicks "Messages" in sidebar
3. Sees all messages with stats
4. Can filter by status
5. Can update status
6. Can reply or delete
```

---

## 🔧 Subject Categories

The form includes 6 subject options:
1. **General Inquiry** - General questions
2. **Order Related** - Order issues/questions
3. **Product Information** - Product details
4. **Complaint** - Customer complaints
5. **Feedback** - Customer feedback
6. **Business Partnership** - Partnership inquiries

---

## 📱 Contact Form Fields

### Required Fields:
- First Name *
- Last Name *
- Email Address *
- Phone Number *
- Subject * (dropdown)
- Message *

### Validation:
- All fields required
- Email format validation
- Phone number format
- Minimum message length

---

## 🎯 Status System

### Three Status Types:

1. **New** (Green)
   - Just submitted
   - Not yet viewed
   - Requires attention

2. **Read** (Blue)
   - Admin has viewed
   - Being processed
   - Awaiting response

3. **Replied** (Purple)
   - Admin has responded
   - Issue resolved
   - Can be archived

---

## 📧 Email Integration

### Reply via Email Button:
- Opens default email client
- Pre-fills recipient email
- Includes original subject with "Re:"
- Admin can compose response

Example:
```
To: customer@example.com
Subject: Re: General Inquiry
```

---

## 🔐 Security Features

### Form Validation:
- Server-side validation
- SQL injection prevention (prepared statements)
- XSS protection (htmlspecialchars)
- CSRF protection (session-based)

### Admin Access:
- Login required
- Session-based authentication
- Admin-only access to messages

---

## 📊 Admin Dashboard Layout

```
┌─────────────────────────────────────────┐
│  📧 Contact Messages                    │
├─────────────────────────────────────────┤
│  [Total] [New] [Read] [Replied]        │
├─────────────────────────────────────────┤
│  [All] [New] [Read] [Replied] Filters  │
├─────────────────────────────────────────┤
│  ┌───────────────────────────────────┐ │
│  │ John Doe [New]                    │ │
│  │ john@example.com | +92 300 1234   │ │
│  │ Subject: General Inquiry          │ │
│  │ Message: ...                      │ │
│  │ [Status ▼] [Reply] [Delete]      │ │
│  └───────────────────────────────────┘ │
│  ┌───────────────────────────────────┐ │
│  │ Jane Smith [Read]                 │ │
│  │ ...                               │ │
│  └───────────────────────────────────┘ │
└─────────────────────────────────────────┘
```

---

## 🎨 Visual Design

### Color Coding:
- **New Messages**: Green left border (#10B981)
- **Read Messages**: Blue left border (#3B82F6)
- **Replied Messages**: Purple left border (#8B5CF6)

### Status Badges:
- **New**: Green background
- **Read**: Blue background
- **Replied**: Purple background

---

## 📝 Usage Examples

### User Sends Message:
```javascript
// Form submission
User fills: John Doe, john@example.com, +92 300 1234567
Subject: Product Information
Message: "Do you have Vitamin C in stock?"

// Response
✅ Success!
Reference: MSG-000123
```

### Admin Manages Message:
```
1. View message in dashboard
2. Change status to "Read"
3. Click "Reply via Email"
4. Send response
5. Change status to "Replied"
```

---

## 🔄 Workflow

### Complete Message Lifecycle:
```
User Submits → New (Green)
              ↓
Admin Views → Read (Blue)
              ↓
Admin Replies → Replied (Purple)
              ↓
Optional: Delete or Archive
```

---

## 📈 Statistics Tracking

The dashboard shows:
- Total messages received
- New messages needing attention
- Messages that have been read
- Messages that have been replied to

---

## 🛠️ Customization Options

### Add More Subjects:
Edit `contact.html`:
```html
<option value="custom">Custom Subject</option>
```

### Change Status Options:
Edit `database/contact_messages.sql`:
```sql
status ENUM('new', 'read', 'replied', 'archived')
```

### Email Templates:
Modify reply button in `admin/messages.php`

---

## ✅ Testing Checklist

### User Side:
- ✅ Form displays correctly
- ✅ All fields validate
- ✅ Submission works
- ✅ Confirmation shows
- ✅ Reference number generated

### Admin Side:
- ✅ Messages appear in dashboard
- ✅ Statistics update
- ✅ Filters work
- ✅ Status changes save
- ✅ Reply button works
- ✅ Delete works

---

## 🎉 Result

You now have a complete contact message system where:
- ✅ Users can easily send messages
- ✅ Messages are saved to database
- ✅ Admins can view all messages
- ✅ Messages can be filtered and managed
- ✅ Status tracking is automatic
- ✅ Email replies are integrated
- ✅ Professional dashboard interface

The system is production-ready and fully functional! 🚀
