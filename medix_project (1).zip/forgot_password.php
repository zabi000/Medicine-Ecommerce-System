<?php
session_start();
require_once('api/config.php');

// Ensure reset tokens table
if ($conn) {
    $conn->query("CREATE TABLE IF NOT EXISTS password_resets (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(200) NOT NULL,
        token VARCHAR(64) NOT NULL,
        expires_at DATETIME NOT NULL,
        used TINYINT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

$step    = $_GET['step'] ?? 'request';
$token   = $_GET['token'] ?? '';
$success = $error = '';

// ---- Step 1: Request reset ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['request_reset'])) {
    $email = trim($_POST['email'] ?? '');
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Please enter a valid email address.';
    } elseif (!$conn) {
        $error = 'Database connection failed.';
    } else {
        $chk = $conn->prepare("SELECT id, name, username FROM users WHERE email=?");
        $chk->bind_param("s", $email); $chk->execute();
        $user_row = $chk->get_result()->fetch_assoc();
        if (!$user_row) {
            $success = 'If that email is registered, a reset link has been sent.';
        } else {
            $token_val = bin2hex(random_bytes(32));
            $expires   = date('Y-m-d H:i:s', strtotime('+24 hours')); // 24 hours instead of 1
            $conn->query("DELETE FROM password_resets WHERE email='" . $conn->real_escape_string($email) . "'");
            $ins = $conn->prepare("INSERT INTO password_resets (email, token, expires_at) VALUES (?,?,?)");
            $ins->bind_param("sss", $email, $token_val, $expires);
            $ins->execute();
            $scheme    = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
            $base      = defined('APP_BASE') ? APP_BASE : '/ppp';
            $reset_url = $scheme . '://' . $_SERVER['HTTP_HOST'] . $base . "/forgot_password.php?step=reset&token=$token_val";
            $user_name  = $user_row['name'] ?: $user_row['username'] ?: $email;

            // Try to send via Mailtrap
            require_once('api/mailer.php');
            $sent = sendPasswordResetEmail($email, $user_name, $reset_url, $conn);

            if ($sent) {
                $success = 'Password reset email sent! Check your Mailtrap inbox at mailtrap.io';
            } else {
                // Always show the link as fallback — SMTP may be blocked on localhost
                $success = 'Reset link generated! (Email sending failed — use the link below directly)';
                $reset_link = $reset_url;
            }
        }
    }
}

// ---- Step 2: Reset password ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['do_reset'])) {
    $token_in = trim($_POST['token'] ?? '');
    $new_pass = $_POST['new_password'] ?? '';
    $confirm  = $_POST['confirm_password'] ?? '';

    if (strlen($new_pass) < 6) {
        $error = 'Password must be at least 6 characters.';
        $step  = 'reset';
    } elseif ($new_pass !== $confirm) {
        $error = 'Passwords do not match.';
        $step  = 'reset';
    } else {
        $r = $conn->prepare("SELECT email FROM password_resets WHERE token=? AND used=0 AND expires_at > NOW()");
        $r->bind_param("s", $token_in); $r->execute();
        $row = $r->get_result()->fetch_assoc();
        if (!$row) {
            $error = 'Invalid or expired reset link. Please request a new one.';
            $step  = 'request';
        } else {
            $hash = password_hash($new_pass, PASSWORD_DEFAULT);
            $u = $conn->prepare("UPDATE users SET password=? WHERE email=?");
            $u->bind_param("ss", $hash, $row['email']); $u->execute();
            $conn->query("UPDATE password_resets SET used=1 WHERE token='" . $conn->real_escape_string($token_in) . "'");
            $success = 'Password reset successfully! You can now login with your new password.';
            $step    = 'done';
        }
    }
}

// Validate token for reset step
$valid_token = false;
$token_email = '';
if ($step === 'reset' && $token) {
    // Check without expiry first to give better error message
    $r_any = $conn->prepare("SELECT email, used, expires_at FROM password_resets WHERE token=?");
    $r_any->bind_param("s", $token); $r_any->execute();
    $row_any = $r_any->get_result()->fetch_assoc();

    if (!$row_any) {
        $error = 'This reset link is invalid. Please request a new one.';
        $step  = 'request';
    } elseif ($row_any['used']) {
        $error = 'This reset link has already been used. Please request a new one.';
        $step  = 'request';
    } elseif (strtotime($row_any['expires_at']) < time()) {
        $error = 'This reset link has expired (valid for 24 hours). Please request a new one.';
        $step  = 'request';
    } else {
        $valid_token = true;
        $token_email = $row_any['email'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Forgot Password - MEDIX</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
* { font-family: 'Inter', sans-serif; }
body { background: linear-gradient(135deg, #fef2f2, #fff, #fef2f2); min-height: 100vh; display: flex; flex-direction: column; }
.navbar-brand { font-weight: 800; color: #B91C1C !important; }
.wrapper { flex: 1; display: flex; align-items: center; justify-content: center; padding: 2rem 1rem; }
.card-box { background: white; border-radius: 24px; box-shadow: 0 20px 60px rgba(185,28,28,.1); width: 100%; max-width: 440px; overflow: hidden; }
.card-header-red { background: linear-gradient(135deg, #B91C1C, #7F1D1D); padding: 2rem; text-align: center; color: white; }
.card-body-pad { padding: 2rem; }
.form-control { border: 1.5px solid #e2e8f0; border-radius: 10px; padding: .7rem .875rem; }
.form-control:focus { border-color: #B91C1C; box-shadow: 0 0 0 3px rgba(185,28,28,.1); }
.btn-red { background: linear-gradient(135deg,#B91C1C,#991B1B); border: none; border-radius: 10px; padding: .875rem; font-weight: 700; color: white; width: 100%; }
.btn-red:hover { background: linear-gradient(135deg,#991B1B,#7F1D1D); color: white; }
.reset-link-box { background: #f0fdf4; border: 2px solid #22c55e; border-radius: 12px; padding: 1rem; word-break: break-all; font-size: .8rem; }
</style>
</head>
<body>
<nav class="navbar bg-white shadow-sm px-4">
    <a class="navbar-brand" href="index.php"><i class="bi bi-heart-pulse-fill me-2"></i>MEDIX</a>
    <a href="login.php" class="btn btn-outline-danger btn-sm">Back to Login</a>
</nav>

<div class="wrapper">
<div class="card-box">
    <div class="card-header-red">
        <i class="bi bi-key-fill" style="font-size:2.5rem"></i>
        <h4 class="mt-2 mb-0 fw-bold">
            <?= $step === 'reset' ? 'Set New Password' : ($step === 'done' ? 'Password Reset!' : 'Forgot Password') ?>
        </h4>
        <p class="mb-0" style="opacity:.8;font-size:.875rem">
            <?= $step === 'reset' ? 'Enter your new password below' : ($step === 'done' ? 'Your password has been updated' : 'Enter your email to reset your password') ?>
        </p>
    </div>

    <div class="card-body-pad">
        <?php if ($error): ?>
        <div class="alert alert-danger py-2 mb-3" style="border-radius:10px;border-left:4px solid #ef4444">
            <i class="bi bi-exclamation-triangle me-2"></i><?= htmlspecialchars($error) ?>
        </div>
        <?php endif; ?>

        <?php if ($step === 'done'): ?>
        <!-- Success -->
        <div class="text-center py-3">
            <i class="bi bi-check-circle-fill text-success" style="font-size:4rem"></i>
            <h5 class="mt-3 fw-bold"><?= htmlspecialchars($success) ?></h5>
            <a href="login.php" class="btn btn-red mt-3">
                <i class="bi bi-box-arrow-in-right me-2"></i>Login Now
            </a>
        </div>

        <?php elseif ($step === 'reset' && $valid_token): ?>
        <!-- Reset form -->
        <form method="POST">
            <input type="hidden" name="token" value="<?= htmlspecialchars($token) ?>">
            <p class="text-muted small mb-3">Resetting password for: <strong><?= htmlspecialchars($token_email) ?></strong></p>
            <div class="mb-3">
                <label class="form-label fw-semibold">New Password</label>
                <input type="password" name="new_password" class="form-control" placeholder="Min 6 characters" minlength="6" required id="np">
            </div>
            <div class="mb-4">
                <label class="form-label fw-semibold">Confirm Password</label>
                <input type="password" name="confirm_password" class="form-control" placeholder="Repeat password" required>
            </div>
            <button type="submit" name="do_reset" class="btn btn-red">
                <i class="bi bi-shield-check me-2"></i>Reset Password
            </button>
        </form>

        <?php else: ?>
        <!-- Request form -->
        <?php if ($success): ?>
        <div class="alert alert-success py-2 mb-3" style="border-radius:10px;border-left:4px solid #22c55e">
            <i class="bi bi-check-circle me-2"></i><?= htmlspecialchars($success) ?>
        </div>
        <?php if (isset($reset_link)): ?>
        <div class="reset-link-box mb-3">
            <p class="fw-bold text-success mb-1"><i class="bi bi-link-45deg me-1"></i>Your Reset Link:</p>
            <a href="<?= htmlspecialchars($reset_link) ?>"><?= htmlspecialchars($reset_link) ?></a>
        </div>
        <a href="<?= htmlspecialchars($reset_link) ?>" class="btn btn-red mb-3">
            <i class="bi bi-arrow-right me-2"></i>Click Here to Reset Password
        </a>
        <?php endif; ?>
        <?php endif; ?>

        <form method="POST">
            <div class="mb-4">
                <label class="form-label fw-semibold">Email Address</label>
                <div class="input-group">
                    <span class="input-group-text" style="background:#f8fafc;border-right:none;border-radius:10px 0 0 10px"><i class="bi bi-envelope text-muted"></i></span>
                    <input type="email" name="email" class="form-control" style="border-left:none;border-radius:0 10px 10px 0"
                           placeholder="your@email.com" required value="<?= htmlspecialchars($_POST['email'] ?? '') ?>">
                </div>
            </div>
            <button type="submit" name="request_reset" class="btn btn-red">
                <i class="bi bi-send me-2"></i>Send Reset Link
            </button>
        </form>

        <div class="text-center mt-3">
            <a href="login.php" class="text-muted small text-decoration-none">
                <i class="bi bi-arrow-left me-1"></i>Back to Login
            </a>
        </div>
        <?php endif; ?>
    </div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
