﻿<?php
// Bypass login for testing
session_start();
$_SESSION['admin_logged_in'] = true;

echo "<!DOCTYPE html><html><head><title>Settings Test</title></head><body>";
echo "<h1>Settings Page Test</h1>";
echo "<hr>";

echo "<h2>1. PHP is working: âœ…</h2>";
echo "<p>Current time: " . date('Y-m-d H:i:s') . "</p>";

echo "<hr>";
echo "<h2>2. Session is working: âœ…</h2>";
echo "<p>Admin logged in: " . ($_SESSION['admin_logged_in'] ? 'Yes' : 'No') . "</p>";

echo "<hr>";
echo "<h2>3. Now loading actual settings page...</h2>";
echo "<p><a href='settings.php' style='padding: 10px 20px; background: #B91C1C; color: white; text-decoration: none; border-radius: 5px;'>Click Here to Open Settings</a></p>";

echo "<hr>";
echo "<h2>4. Or view the raw code:</h2>";
echo "<p><a href='settings.php?view=source'>View Source Code</a></p>";

echo "</body></html>";
?>

