<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>Test Message Upload</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style="padding:2rem;background:#f8fafc">
<h3>Test Message with Image Upload</h3>
<div id="result" class="mb-3"></div>
<div class="card p-4" style="max-width:500px">
    <div class="mb-3">
        <label class="form-label fw-bold">Message</label>
        <textarea id="msg" class="form-control" rows="3">Test message with image</textarea>
    </div>
    <div class="mb-3">
        <label class="form-label fw-bold">Attach Image</label>
        <input type="file" id="imgFile" class="form-control" accept="image/*">
    </div>
    <button onclick="sendTest()" class="btn btn-danger">Send Test Message</button>
</div>

<hr>
<h5>Recent Messages in DB:</h5>
<?php
require_once('api/config.php');
if ($conn) {
    // Ensure column exists
    $conn->query("ALTER TABLE contact_messages ADD COLUMN IF NOT EXISTS attachment VARCHAR(255) DEFAULT NULL");
    $r = $conn->query("SELECT id, email, subject, attachment, created_at FROM contact_messages ORDER BY id DESC LIMIT 5");
    echo "<table class='table table-sm' style='max-width:800px'><tr><th>ID</th><th>Email</th><th>Attachment Path</th><th>File Exists?</th><th>Preview</th></tr>";
    while ($row = $r->fetch_assoc()) {
        $att = $row['attachment'];
        $exists = $att ? (file_exists(__DIR__.'/'.$att) ? '✅' : '❌ Missing') : '—';
        $preview = ($att && preg_match('/\.(jpg|jpeg|png|gif|webp)$/i', $att))
            ? "<img src='/ppp/$att' style='max-height:50px;border-radius:4px'>"
            : ($att ? "<a href='/ppp/$att'>View</a>" : '—');
        echo "<tr><td>{$row['id']}</td><td>{$row['email']}</td><td style='font-size:.75rem'>$att</td><td>$exists</td><td>$preview</td></tr>";
    }
    echo "</table>";
}
?>

<script>
function sendTest() {
    const msg = document.getElementById('msg').value;
    const file = document.getElementById('imgFile').files[0];
    const result = document.getElementById('result');

    const fd = new FormData();
    fd.append('firstName', 'Test');
    fd.append('lastName', 'User');
    fd.append('email', 'test@test.com');
    fd.append('phone', '0300-0000000');
    fd.append('subject', 'Test Upload');
    fd.append('message', msg);
    if (file) fd.append('attachment', file);

    result.innerHTML = '<div class="alert alert-info">Sending...</div>';

    fetch('api/submit_contact.php', { method: 'POST', body: fd })
        .then(r => r.json())
        .then(data => {
            result.innerHTML = data.success
                ? `<div class="alert alert-success">✅ ${data.message} | Ref: ${data.reference} | Attachment: ${data.attachment || 'none'}</div>`
                : `<div class="alert alert-danger">❌ ${data.message}</div>`;
            if (data.success) setTimeout(() => location.reload(), 1500);
        })
        .catch(e => result.innerHTML = `<div class="alert alert-danger">Error: ${e.message}</div>`);
}
</script>
</body>
</html>
