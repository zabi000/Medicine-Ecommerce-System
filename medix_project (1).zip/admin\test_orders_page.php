﻿<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once('../api/config.php');

echo "<h1>Orders Page Diagnostic</h1>";

// Check database connection
if (!$conn) {
    die("<p style='color: red;'>âŒ Database connection failed!</p>");
}
echo "<p style='color: green;'>âœ… Database connected</p>";

// Check if orders table exists
$result = $conn->query("SHOW TABLES LIKE 'orders'");
if ($result->num_rows > 0) {
    echo "<p style='color: green;'>âœ… Orders table exists</p>";
} else {
    die("<p style='color: red;'>âŒ Orders table not found!</p>");
}

// Check orders table structure
echo "<h2>Orders Table Columns:</h2>";
$result = $conn->query("DESCRIBE orders");
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>Column</th><th>Type</th></tr>";
$has_customer_name = false;
$has_customer_email = false;
$has_customer_phone = false;

while ($row = $result->fetch_assoc()) {
    echo "<tr><td>{$row['Field']}</td><td>{$row['Type']}</td></tr>";
    if ($row['Field'] == 'customer_name') $has_customer_name = true;
    if ($row['Field'] == 'customer_email') $has_customer_email = true;
    if ($row['Field'] == 'customer_phone') $has_customer_phone = true;
}
echo "</table>";

// Check if new columns exist
echo "<h2>New Columns Status:</h2>";
if ($has_customer_name) {
    echo "<p style='color: green;'>âœ… customer_name column exists</p>";
} else {
    echo "<p style='color: red;'>âŒ customer_name column missing - <a href='../add_customer_info_to_orders.php'>Add it now</a></p>";
}

if ($has_customer_email) {
    echo "<p style='color: green;'>âœ… customer_email column exists</p>";
} else {
    echo "<p style='color: red;'>âŒ customer_email column missing - <a href='../add_customer_info_to_orders.php'>Add it now</a></p>";
}

if ($has_customer_phone) {
    echo "<p style='color: green;'>âœ… customer_phone column exists</p>";
} else {
    echo "<p style='color: red;'>âŒ customer_phone column missing - <a href='../add_customer_info_to_orders.php'>Add it now</a></p>";
}

// Try the query that orders.php uses
echo "<h2>Testing Orders Query:</h2>";
try {
    if ($has_customer_name && $has_customer_email && $has_customer_phone) {
        // New query with customer fields
        $sql = "SELECT o.*, 
            COALESCE(o.customer_name, u.name) as customer_name,
            COALESCE(o.customer_email, u.email) as customer_email,
            COALESCE(o.customer_phone, u.phone) as customer_phone
            FROM orders o 
            LEFT JOIN users u ON o.user_id = u.id 
            ORDER BY o.created_at DESC LIMIT 5";
    } else {
        // Old query without customer fields
        $sql = "SELECT o.*, u.name as username, u.email FROM orders o LEFT JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC LIMIT 5";
    }
    
    $result = $conn->query($sql);
    
    if ($result) {
        echo "<p style='color: green;'>âœ… Query executed successfully</p>";
        echo "<p>Found {$result->num_rows} orders</p>";
        
        if ($result->num_rows > 0) {
            echo "<h3>Sample Orders:</h3>";
            echo "<table border='1' cellpadding='5'>";
            echo "<tr><th>ID</th><th>Customer</th><th>Email</th><th>Total</th><th>Status</th></tr>";
            while ($order = $result->fetch_assoc()) {
                $customer = $has_customer_name ? ($order['customer_name'] ?? 'N/A') : ($order['username'] ?? 'N/A');
                $email = $has_customer_email ? ($order['customer_email'] ?? 'N/A') : ($order['email'] ?? 'N/A');
                echo "<tr>";
                echo "<td>{$order['id']}</td>";
                echo "<td>" . htmlspecialchars($customer) . "</td>";
                echo "<td>" . htmlspecialchars($email) . "</td>";
                echo "<td>PKR " . number_format($order['total_amount'], 2) . "</td>";
                echo "<td>{$order['status']}</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
    } else {
        echo "<p style='color: red;'>âŒ Query failed: " . $conn->error . "</p>";
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>âŒ Error: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<h2>Next Steps:</h2>";
if (!$has_customer_name || !$has_customer_email || !$has_customer_phone) {
    echo "<p><strong>1. Add missing columns:</strong> <a href='../add_customer_info_to_orders.php' style='background: #B91C1C; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Update Database Now</a></p>";
    echo "<p><strong>2. Then try orders page again:</strong> <a href='orders.php'>Open Orders Page</a></p>";
} else {
    echo "<p style='color: green;'>âœ… All columns exist! Orders page should work.</p>";
    echo "<p><a href='orders.php' style='background: #10B981; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Open Orders Page</a></p>";
}
?>

