﻿<?php
session_start();

// Simple authentication check
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Database connection
require_once('../api/config.php');

// Create uploads directory if it doesn't exist
$upload_dir = '../uploads/';
if (!file_exists($upload_dir)) {
    mkdir($upload_dir, 0777, true);
}

// Create subdirectories
$subdirs = ['images', 'documents', 'data', 'temp'];
foreach ($subdirs as $dir) {
    if (!file_exists($upload_dir . $dir)) {
        mkdir($upload_dir . $dir, 0777, true);
    }
}

// Handle file upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $file = $_FILES['file'];
    $file_category = $_POST['category'] ?? 'temp';
    $file_description = $_POST['description'] ?? '';
    
    // Validate file
    if ($file['error'] === UPLOAD_ERR_OK) {
        $file_name = basename($file['name']);
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $file_size = $file['size'];
        
        // Allowed file types
        $allowed_types = [
            'images' => ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'],
            'documents' => ['pdf', 'doc', 'docx', 'txt', 'xlsx', 'xls'],
            'data' => ['csv', 'sql', 'json', 'xml'],
            'temp' => ['zip', 'rar', '7z']
        ];
        
        $all_allowed = array_merge(...array_values($allowed_types));
        
        if (in_array($file_ext, $all_allowed)) {
            // Generate unique filename
            $unique_name = time() . '_' . uniqid() . '.' . $file_ext;
            $target_path = $upload_dir . $file_category . '/' . $unique_name;
            
            if (move_uploaded_file($file['tmp_name'], $target_path)) {
                // Save to database
                $stmt = $conn->prepare("INSERT INTO uploaded_files (original_name, stored_name, file_path, file_type, file_size, category, description, uploaded_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $admin_name = $_SESSION['admin_name'] ?? 'Admin';
                $stmt->bind_param("ssssisss", $file_name, $unique_name, $target_path, $file_ext, $file_size, $file_category, $file_description, $admin_name);
                
                if ($stmt->execute()) {
                    $success_message = "File uploaded successfully!";
                } else {
                    $error_message = "File uploaded but database entry failed.";
                }
                $stmt->close();
            } else {
                $error_message = "Failed to move uploaded file.";
            }
        } else {
            $error_message = "File type not allowed. Allowed types: " . implode(', ', $all_allowed);
        }
    } else {
        $error_message = "Upload error: " . $file['error'];
    }
}

// Handle file deletion
if (isset($_GET['delete'])) {
    $file_id = intval($_GET['delete']);
    $stmt = $conn->prepare("SELECT file_path FROM uploaded_files WHERE id = ?");
    $stmt->bind_param("i", $file_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($row = $result->fetch_assoc()) {
        if (file_exists($row['file_path'])) {
            unlink($row['file_path']);
        }
        
        $delete_stmt = $conn->prepare("DELETE FROM uploaded_files WHERE id = ?");
        $delete_stmt->bind_param("i", $file_id);
        if ($delete_stmt->execute()) {
            $success_message = "File deleted successfully!";
        }
        $delete_stmt->close();
    }
    $stmt->close();
}

// Fetch all uploaded files
$files_result = $conn->query("SELECT * FROM uploaded_files ORDER BY uploaded_at DESC");

// Get statistics
$total_files = $conn->query("SELECT COUNT(*) as count FROM uploaded_files")->fetch_assoc()['count'];
$total_size = $conn->query("SELECT SUM(file_size) as size FROM uploaded_files")->fetch_assoc()['size'] ?? 0;
$images_count = $conn->query("SELECT COUNT(*) as count FROM uploaded_files WHERE category = 'images'")->fetch_assoc()['count'];
$documents_count = $conn->query("SELECT COUNT(*) as count FROM uploaded_files WHERE category = 'documents'")->fetch_assoc()['count'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Manager - Medix Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #B91C1C;
            --secondary-color: #991B1B;
            --sidebar-width: 250px;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: #F3F4F6;
        }
        
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: var(--sidebar-width);
            background: linear-gradient(180deg, var(--primary-color), var(--secondary-color));
            color: white;
            overflow-y: auto;
            z-index: 1000;
            box-shadow: 4px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-header {
            padding: 1.5rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .sidebar-header h4 {
            font-weight: 700;
            font-size: 1.25rem;
        }
        
        .sidebar-menu {
            padding: 1rem 0;
        }
        
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 0.75rem 1.5rem;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            transition: all 0.3s;
            font-weight: 500;
        }
        
        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background: rgba(255, 255, 255, 0.15);
            color: white;
            border-left: 4px solid white;
            padding-left: calc(1.5rem - 4px);
        }
        
        .sidebar-menu a i {
            margin-right: 0.75rem;
            font-size: 1.2rem;
        }
        
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 2rem;
            min-height: 100vh;
        }
        
        .top-bar {
            background: white;
            padding: 1.25rem 2rem;
            margin: -2rem -2rem 1.5rem -2rem;
            box-shadow: 0 2px 6px rgba(0,0,0,0.08);
            border-bottom: 3px solid var(--primary-color);
        }
        
        .top-bar h4 {
            font-weight: 700;
            color: #1e293b;
            font-size: 1.35rem;
        }
        
        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 1.25rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.08);
            margin-bottom: 1.5rem;
            border: 1px solid #e2e8f0;
            transition: all 0.3s;
            position: relative;
            overflow: hidden;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
        }
        
        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 16px rgba(0,0,0,0.12);
        }
        
        .stat-card i {
            opacity: 0.9;
            font-size: 2rem !important;
        }
        
        .stat-card h3 {
            font-weight: 700;
            font-size: 1.5rem;
            color: #1e293b;
            margin-top: 0.5rem;
        }
        
        .upload-zone {
            background: white;
            border: 3px dashed #cbd5e1;
            border-radius: 12px;
            padding: 3rem 2rem;
            text-align: center;
            transition: all 0.3s;
            cursor: pointer;
            margin-bottom: 2rem;
        }
        
        .upload-zone:hover {
            border-color: var(--primary-color);
            background: #fef2f2;
        }
        
        .upload-zone.dragover {
            border-color: var(--primary-color);
            background: #fee2e2;
        }
        
        .upload-zone i {
            font-size: 3rem;
            color: #94a3b8;
            margin-bottom: 1rem;
        }
        
        .file-card {
            background: white;
            border-radius: 10px;
            padding: 1rem;
            margin-bottom: 1rem;
            border: 1px solid #e2e8f0;
            transition: all 0.3s;
        }
        
        .file-card:hover {
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            transform: translateY(-2px);
        }
        
        .file-icon {
            width: 50px;
            height: 50px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
            color: white;
        }
        
        .file-icon.image { background: linear-gradient(135deg, #667eea, #764ba2); }
        .file-icon.document { background: linear-gradient(135deg, #f093fb, #f5576c); }
        .file-icon.data { background: linear-gradient(135deg, #4facfe, #00f2fe); }
        .file-icon.archive { background: linear-gradient(135deg, #43e97b, #38f9d7); }
        
        .btn-danger {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            font-weight: 600;
        }
        
        .btn-primary {
            background: linear-gradient(135deg, #3b82f6, #2563eb);
            border: none;
            font-weight: 600;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0"><i class="bi bi-heart-pulse-fill me-2"></i>MEDIX Admin</h4>
            <small class="text-white-50">Administrator Panel</small>
        </div>
        <div class="sidebar-menu">
            <a href="index.php">
                <i class="bi bi-speedometer2"></i> Dashboard
            </a>
            <a href="products.php">
                <i class="bi bi-box-seam"></i> Products
            </a>
            <a href="orders.php">
                <i class="bi bi-cart-check"></i> Orders
            </a>
            <a href="customers.php">
                <i class="bi bi-people"></i> Customers
            </a>
            <a href="categories.php">
                <i class="bi bi-tags"></i> Categories
            </a>
            <a href="file_manager.php" class="active">
                <i class="bi bi-folder"></i> File Manager
            </a>
            <a href="messages.php">
                <i class="bi bi-envelope"></i> Messages
            </a>
            <a href="import_medicines.php">
                <i class="bi bi-cloud-upload"></i> Import Medicines
            </a>
            <a href="reports.php">
                <i class="bi bi-graph-up"></i> Reports
            </a>
            <a href="settings.php">
                <i class="bi bi-gear"></i> Settings
            </a>
            <hr class="text-white-50">
            <a href="logout.php">
                <i class="bi bi-box-arrow-right"></i> Logout
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h4 class="mb-1"><i class="bi bi-folder me-2"></i>File Manager</h4>
                    <small class="text-muted">Upload and manage all types of files</small>
                </div>
            </div>
        </div>

        <?php if (isset($success_message)): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle me-2"></i><?= $success_message ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle me-2"></i><?= $error_message ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Statistics -->
        <div class="row g-3 mb-4">
            <div class="col-md-3">
                <div class="stat-card text-center">
                    <i class="bi bi-files text-primary"></i>
                    <h3 class="mt-2 mb-0"><?= $total_files ?></h3>
                    <p class="text-muted mb-0">Total Files</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card text-center">
                    <i class="bi bi-image text-success"></i>
                    <h3 class="mt-2 mb-0"><?= $images_count ?></h3>
                    <p class="text-muted mb-0">Images</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card text-center">
                    <i class="bi bi-file-earmark-text text-info"></i>
                    <h3 class="mt-2 mb-0"><?= $documents_count ?></h3>
                    <p class="text-muted mb-0">Documents</p>
                </div>
            </div>
            <div class="col-md-3">
                <div class="stat-card text-center">
                    <i class="bi bi-hdd text-warning"></i>
                    <h3 class="mt-2 mb-0"><?= number_format($total_size / 1024 / 1024, 2) ?> MB</h3>
                    <p class="text-muted mb-0">Total Size</p>
                </div>
            </div>
        </div>

        <!-- Upload Form -->
        <div class="card border-0 shadow-sm mb-4">
            <div class="card-body p-4">
                <h5 class="mb-4"><i class="bi bi-cloud-upload me-2"></i>Upload New File</h5>
                <form method="POST" enctype="multipart/form-data" id="uploadForm">
                    <div class="upload-zone" id="uploadZone">
                        <i class="bi bi-cloud-arrow-up"></i>
                        <h5>Drag & Drop files here</h5>
                        <p class="text-muted mb-3">or click to browse</p>
                        <input type="file" name="file" id="fileInput" class="d-none" required>
                        <button type="button" class="btn btn-primary" onclick="document.getElementById('fileInput').click()">
                            <i class="bi bi-folder2-open me-2"></i>Choose File
                        </button>
                    </div>
                    
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Category</label>
                            <select name="category" class="form-select" required>
                                <option value="images">Images (JPG, PNG, GIF, SVG)</option>
                                <option value="documents">Documents (PDF, DOC, TXT, XLSX)</option>
                                <option value="data">Data Files (CSV, SQL, JSON, XML)</option>
                                <option value="temp">Archives (ZIP, RAR, 7Z)</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Description (Optional)</label>
                            <input type="text" name="description" class="form-control" placeholder="Enter file description">
                        </div>
                    </div>
                    
                    <div class="mt-3">
                        <button type="submit" class="btn btn-danger">
                            <i class="bi bi-upload me-2"></i>Upload File
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Files List -->
        <div class="card border-0 shadow-sm">
            <div class="card-body p-4">
                <h5 class="mb-4"><i class="bi bi-files me-2"></i>Uploaded Files</h5>
                
                <?php if ($files_result && $files_result->num_rows > 0): ?>
                    <?php while ($file = $files_result->fetch_assoc()): ?>
                        <div class="file-card">
                            <div class="row align-items-center">
                                <div class="col-auto">
                                    <?php
                                    $icon_class = 'archive';
                                    $icon = 'file-earmark-zip';
                                    
                                    if ($file['category'] == 'images') {
                                        $icon_class = 'image';
                                        $icon = 'image';
                                    } elseif ($file['category'] == 'documents') {
                                        $icon_class = 'document';
                                        $icon = 'file-earmark-text';
                                    } elseif ($file['category'] == 'data') {
                                        $icon_class = 'data';
                                        $icon = 'database';
                                    }
                                    ?>
                                    <div class="file-icon <?= $icon_class ?>">
                                        <i class="bi bi-<?= $icon ?>"></i>
                                    </div>
                                </div>
                                <div class="col">
                                    <h6 class="mb-1"><?= htmlspecialchars($file['original_name']) ?></h6>
                                    <small class="text-muted">
                                        <?= strtoupper($file['file_type']) ?> â€¢ 
                                        <?= number_format($file['file_size'] / 1024, 2) ?> KB â€¢ 
                                        <?= ucfirst($file['category']) ?> â€¢ 
                                        <?= date('M d, Y h:i A', strtotime($file['uploaded_at'])) ?>
                                    </small>
                                    <?php if ($file['description']): ?>
                                        <p class="mb-0 mt-1 text-muted small"><?= htmlspecialchars($file['description']) ?></p>
                                    <?php endif; ?>
                                </div>
                                <div class="col-auto">
                                    <a href="<?= $file['file_path'] ?>" class="btn btn-sm btn-outline-primary me-2" download>
                                        <i class="bi bi-download"></i> Download
                                    </a>
                                    <a href="?delete=<?= $file['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete this file?')">
                                        <i class="bi bi-trash"></i> Delete
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="bi bi-inbox" style="font-size: 3rem; color: #cbd5e1;"></i>
                        <p class="text-muted mt-3">No files uploaded yet</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Drag and drop functionality
        const uploadZone = document.getElementById('uploadZone');
        const fileInput = document.getElementById('fileInput');
        
        uploadZone.addEventListener('dragover', (e) => {
            e.preventDefault();
            uploadZone.classList.add('dragover');
        });
        
        uploadZone.addEventListener('dragleave', () => {
            uploadZone.classList.remove('dragover');
        });
        
        uploadZone.addEventListener('drop', (e) => {
            e.preventDefault();
            uploadZone.classList.remove('dragover');
            
            const files = e.dataTransfer.files;
            if (files.length > 0) {
                fileInput.files = files;
                updateFileName();
            }
        });
        
        fileInput.addEventListener('change', updateFileName);
        
        function updateFileName() {
            if (fileInput.files.length > 0) {
                const fileName = fileInput.files[0].name;
                uploadZone.querySelector('h5').textContent = 'Selected: ' + fileName;
            }
        }
        
        // Auto-dismiss alerts
        setTimeout(() => {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);
    </script>
</body>
</html>

