﻿<?php
// Shared admin authentication — include at top of every admin page
ini_set('session.gc_maxlifetime', 28800); // 8 hours
session_set_cookie_params(28800);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Not logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

// Session timeout: 8 hours of inactivity
if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity']) > 28800) {
    session_unset();
    session_destroy();
    header('Location: login.php?timeout=1');
    exit();
}

// Refresh activity timestamp
$_SESSION['last_activity'] = time();
?>
