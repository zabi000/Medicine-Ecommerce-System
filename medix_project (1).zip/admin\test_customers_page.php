﻿<?php
/**
 * Test Customers Page
 * This will show you exactly what's happening
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<!DOCTYPE html>";
echo "<html><head>";
echo "<title>Test Customers Page</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "</head><body class='p-5'>";
echo "<div class='container'>";
echo "<h1>ðŸ§ª Testing Customers Page</h1><hr>";

// Test 1: Database Connection
echo "<h3>1. Database Connection</h3>";
require_once('../api/config.php');
if ($conn) {
    echo "<p class='text-success'>âœ… Connected to database: <strong>" . DB_NAME . "</strong></p>";
} else {
    echo "<p class='text-danger'>âŒ Database connection failed!</p>";
    echo "</div></body></html>";
    exit;
}

// Test 2: Check if users table exists
echo "<h3>2. Users Table</h3>";
$result = $conn->query("SHOW TABLES LIKE 'users'");
if ($result && $result->num_rows > 0) {
    echo "<p class='text-success'>âœ… Users table exists</p>";
    
    // Check table structure
    $columns = $conn->query("DESCRIBE users");
    echo "<p><strong>Table Structure:</strong></p>";
    echo "<ul>";
    while ($col = $columns->fetch_assoc()) {
        echo "<li><code>{$col['Field']}</code> - {$col['Type']}</li>";
    }
    echo "</ul>";
} else {
    echo "<p class='text-danger'>âŒ Users table does not exist!</p>";
    echo "<p>Please import the database first: <a href='../IMPORT_COMPLETE_DATABASE.php'>Import Database</a></p>";
}

// Test 3: Count users
echo "<h3>3. Users Count</h3>";
$count_result = $conn->query("SELECT COUNT(*) as count FROM users");
if ($count_result) {
    $count = $count_result->fetch_assoc()['count'];
    echo "<p class='text-success'>âœ… Total users in database: <strong>$count</strong></p>";
    
    if ($count == 0) {
        echo "<p class='text-warning'>âš ï¸ No users found. Please import sample data.</p>";
    }
} else {
    echo "<p class='text-danger'>âŒ Error counting users: " . $conn->error . "</p>";
}

// Test 4: Fetch sample users
echo "<h3>4. Sample Users Data</h3>";
$users_result = $conn->query("SELECT * FROM users LIMIT 5");
if ($users_result && $users_result->num_rows > 0) {
    echo "<table class='table table-bordered'>";
    echo "<thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Created</th></tr></thead>";
    echo "<tbody>";
    while ($user = $users_result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>{$user['id']}</td>";
        echo "<td>{$user['name']}</td>";
        echo "<td>{$user['email']}</td>";
        echo "<td>{$user['phone']}</td>";
        echo "<td>{$user['created_at']}</td>";
        echo "</tr>";
    }
    echo "</tbody></table>";
} else {
    echo "<p class='text-warning'>âš ï¸ No users to display</p>";
}

// Test 5: Test the actual query used in customers.php
echo "<h3>5. Test Customers Query (with Orders)</h3>";
$query = "SELECT u.*, COUNT(o.id) as total_orders, SUM(o.total_amount) as total_spent 
          FROM users u 
          LEFT JOIN orders o ON u.id = o.user_id 
          GROUP BY u.id 
          ORDER BY u.created_at DESC 
          LIMIT 5";
          
echo "<p><strong>Query:</strong></p>";
echo "<pre class='bg-light p-3'>" . htmlspecialchars($query) . "</pre>";

$customers_result = $conn->query($query);
if ($customers_result) {
    echo "<p class='text-success'>âœ… Query executed successfully</p>";
    echo "<p>Rows returned: <strong>{$customers_result->num_rows}</strong></p>";
    
    if ($customers_result->num_rows > 0) {
        echo "<table class='table table-bordered'>";
        echo "<thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Phone</th><th>Orders</th><th>Total Spent</th></tr></thead>";
        echo "<tbody>";
        while ($customer = $customers_result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>{$customer['id']}</td>";
            echo "<td>{$customer['name']}</td>";
            echo "<td>{$customer['email']}</td>";
            echo "<td>{$customer['phone']}</td>";
            echo "<td>{$customer['total_orders']}</td>";
            echo "<td>PKR " . number_format($customer['total_spent'] ?? 0, 2) . "</td>";
            echo "</tr>";
        }
        echo "</tbody></table>";
    }
} else {
    echo "<p class='text-danger'>âŒ Query failed: " . $conn->error . "</p>";
}

// Test 6: Check session
echo "<h3>6. Session Check</h3>";
session_start();
if (isset($_SESSION['admin_logged_in'])) {
    echo "<p class='text-success'>âœ… Admin session is active</p>";
} else {
    echo "<p class='text-warning'>âš ï¸ Admin session not found</p>";
    echo "<p>Setting session for testing...</p>";
    $_SESSION['admin_logged_in'] = true;
    echo "<p class='text-success'>âœ… Session set!</p>";
}

// Test 7: Final verdict
echo "<h3>7. Final Verdict</h3>";
echo "<div class='alert alert-info'>";
echo "<h5>What should happen on customers.php:</h5>";
echo "<ul>";
echo "<li>If you have data: Shows list of customers with their order counts</li>";
echo "<li>If no data: Shows fake sample data (10 customers)</li>";
echo "<li>If not logged in: Redirects to login.php</li>";
echo "</ul>";
echo "</div>";

echo "<div class='d-grid gap-2 mt-4'>";
echo "<a href='customers.php' class='btn btn-primary btn-lg'>ðŸ”— Go to Customers Page</a>";
echo "<a href='../IMPORT_COMPLETE_DATABASE.php' class='btn btn-success btn-lg'>ðŸ“¦ Import Database</a>";
echo "<a href='debug_check.php' class='btn btn-info btn-lg'>ðŸ” Run Full Debug</a>";
echo "</div>";

echo "</div></body></html>";
$conn->close();
?>

