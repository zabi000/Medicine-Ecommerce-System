﻿<?php
session_start();

// Simple authentication check
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Database connection
require_once('../api/config.php');

// Handle Add Product
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $category = $_POST['category'];
    $stock = $_POST['stock'];
    
    $stmt = $conn->prepare("INSERT INTO products (name, description, price, category, stock_quantity) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssdsi", $name, $description, $price, $category, $stock);
    
    if ($stmt->execute()) {
        $success_message = "Product added successfully!";
    } else {
        $error_message = "Error adding product: " . $conn->error;
    }
}

// Handle Delete Product
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        $success_message = "Product deleted successfully!";
    } else {
        $error_message = "Error deleting product: " . $conn->error;
    }
}

// Fetch all products
$result = @$conn->query("SELECT * FROM products ORDER BY id DESC");

// If no database, create fake data
if (!$result || $result->num_rows == 0) {
    $fake_products = [];
    $medicines = ['Panadol', 'Brufen', 'Augmentin', 'Disprin', 'Calpol', 'Flagyl', 'Glucophage', 'Concor', 'Norvasc', 'Centrum'];
    $types = ['Tab', 'Cap', 'Syp', 'Inj'];
    $dosages = ['500mg', '250mg', '100mg', '50mg'];
    
    for ($i = 1; $i <= 30; $i++) {
        $fake_products[] = [
            'id' => $i,
            'name' => $types[array_rand($types)] . ' ' . $medicines[array_rand($medicines)] . ' ' . $dosages[array_rand($dosages)],
            'description' => 'High quality medicine for effective treatment',
            'category' => ['prescription', 'vitamins', 'firstaid'][array_rand(['prescription', 'vitamins', 'firstaid'])],
            'price' => rand(50, 2000),
            'stock_quantity' => rand(10, 200)
        ];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products Management - Medix Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        :root {
            --primary-color: #B91C1C;
            --secondary-color: #991B1B;
            --sidebar-width: 250px;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: #F3F4F6;
        }
        
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: var(--sidebar-width);
            background: linear-gradient(180deg, var(--primary-color), var(--secondary-color));
            color: white;
            overflow-y: auto;
            z-index: 1000;
        }
        
        .sidebar-header {
            padding: 1.5rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .sidebar-menu {
            padding: 1rem 0;
        }
        
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 0.75rem 1.5rem;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .sidebar-menu a:hover,
        .sidebar-menu a.active {
            background: rgba(255, 255, 255, 0.1);
            color: white;
        }
        
        .sidebar-menu a i {
            margin-right: 0.75rem;
            font-size: 1.2rem;
        }
        
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 2rem;
        }
        
        .top-bar {
            background: white;
            padding: 1rem 2rem;
            margin: -2rem -2rem 2rem -2rem;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        
        .table-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        .product-image-preview {
            width: 60px;
            height: 60px;
            background: #F3F4F6;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2rem;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0"><i class="bi bi-heart-pulse-fill me-2"></i>MEDIX Admin</h4>
            <small class="text-white-50">Administrator Panel</small>
        </div>
        <div class="sidebar-menu">
            <a href="index.php">
                <i class="bi bi-speedometer2"></i> Dashboard
            </a>
            <a href="products.php" class="active">
                <i class="bi bi-box-seam"></i> Products
            </a>
            <a href="orders.php">
                <i class="bi bi-cart-check"></i> Orders
            </a>
            <a href="customers.php">
                <i class="bi bi-people"></i> Customers
            </a>
            <a href="categories.php">
                <i class="bi bi-tags"></i> Categories
            </a>
            <a href="reports.php">
                <i class="bi bi-graph-up"></i> Reports
            </a>
            <a href="settings.php">
                <i class="bi bi-gear"></i> Settings
            </a>
            <hr class="text-white-50">
            <a href="logout.php">
                <i class="bi bi-box-arrow-right"></i> Logout
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h4 class="mb-0">Products Management</h4>
                    <small class="text-muted">Manage your product inventory</small>
                </div>
                <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#addProductModal">
                    <i class="bi bi-plus-circle"></i> Add New Product
                </button>
            </div>
        </div>

        <?php if (isset($success_message)): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="bi bi-check-circle"></i> <?= $success_message ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="bi bi-exclamation-triangle"></i> <?= $error_message ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Products Table -->
        <div class="table-card">
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Image</th>
                            <th>Product Name</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Stock</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                        if (isset($fake_products) && count($fake_products) > 0) {
                            // Show fake products
                            foreach ($fake_products as $product) {
                        ?>
                        <tr>
                            <td><?= $product['id'] ?></td>
                            <td>
                                <div class="product-image-preview">
                                    <i class="bi bi-capsule-pill text-danger"></i>
                                </div>
                            </td>
                            <td>
                                <strong><?= htmlspecialchars($product['name']) ?></strong><br>
                                <small class="text-muted"><?= htmlspecialchars($product['description']) ?></small>
                            </td>
                            <td><span class="badge bg-info"><?= htmlspecialchars($product['category']) ?></span></td>
                            <td><strong>PKR <?= number_format($product['price'], 2) ?></strong></td>
                            <td>
                                <?php if ($product['stock_quantity'] > 20): ?>
                                    <span class="badge bg-success"><?= $product['stock_quantity'] ?> units</span>
                                <?php elseif ($product['stock_quantity'] > 0): ?>
                                    <span class="badge bg-warning"><?= $product['stock_quantity'] ?> units</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Out of Stock</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($product['stock_quantity'] > 0): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-outline-primary">
                                    <i class="bi bi-pencil"></i>
                                </button>
                                <button class="btn btn-sm btn-outline-danger">
                                    <i class="bi bi-trash"></i>
                                </button>
                            </td>
                        </tr>
                        <?php 
                            }
                        } elseif ($result && $result->num_rows > 0) {
                            // Show real products from database
                            while ($product = $result->fetch_assoc()) {
                        ?>
                        <tr>
                            <td><?= $product['id'] ?></td>
                            <td>
                                <div class="product-image-preview">
                                    <i class="bi bi-capsule-pill text-danger"></i>
                                </div>
                            </td>
                            <td>
                                <strong><?= htmlspecialchars($product['name']) ?></strong><br>
                                <small class="text-muted"><?= htmlspecialchars(substr($product['description'], 0, 50)) ?>...</small>
                            </td>
                            <td><span class="badge bg-info"><?= htmlspecialchars($product['category']) ?></span></td>
                            <td><strong>PKR <?= number_format($product['price'], 2) ?></strong></td>
                            <td>
                                <?php if ($product['stock_quantity'] > 20): ?>
                                    <span class="badge bg-success"><?= $product['stock_quantity'] ?> units</span>
                                <?php elseif ($product['stock_quantity'] > 0): ?>
                                    <span class="badge bg-warning"><?= $product['stock_quantity'] ?> units</span>
                                <?php else: ?>
                                    <span class="badge bg-danger">Out of Stock</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($product['stock_quantity'] > 0): ?>
                                    <span class="badge bg-success">Active</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary">Inactive</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button class="btn btn-sm btn-outline-primary" data-bs-toggle="modal" data-bs-target="#editProductModal<?= $product['id'] ?>">
                                    <i class="bi bi-pencil"></i>
                                </button>
                                <a href="?delete=<?= $product['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Are you sure you want to delete this product?')">
                                    <i class="bi bi-trash"></i>
                                </a>
                            </td>
                        </tr>
                        <?php 
                            }
                        } else {
                        ?>
                        <tr>
                            <td colspan="8" class="text-center py-5">
                                <i class="bi bi-inbox" style="font-size: 3rem; color: #ccc;"></i>
                                <p class="text-muted mt-3">No products found. Add your first product!</p>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Add Product Modal -->
    <div class="modal fade" id="addProductModal" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Add New Product</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add">
                        <div class="mb-3">
                            <label class="form-label">Product Name</label>
                            <input type="text" class="form-control" name="name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Description</label>
                            <textarea class="form-control" name="description" rows="3" required></textarea>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Category</label>
                            <select class="form-select" name="category" required>
                                <option value="prescription">Prescription</option>
                                <option value="vitamins">Vitamins</option>
                                <option value="firstaid">First Aid</option>
                                <option value="devices">Medical Devices</option>
                                <option value="personal">Personal Care</option>
                                <option value="baby">Baby Care</option>
                            </select>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Price ($)</label>
                                <input type="number" step="0.01" class="form-control" name="price" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Stock Quantity</label>
                                <input type="number" class="form-control" name="stock" required>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger">Add Product</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

