<?php
/**
 * Complete Database Import
 * This will import all customers, products, categories, and orders
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<!DOCTYPE html>";
echo "<html><head>";
echo "<title>Complete Database Import</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "<style>body { padding: 50px; background: #f5f5f5; }</style>";
echo "</head><body>";
echo "<div class='container'>";
echo "<h1 class='mb-4'>📦 Complete Database Import</h1>";

// Database connection
require_once('api/config.php');

if (!$conn) {
    echo "<div class='alert alert-danger'>";
    echo "<h4>❌ Database Connection Failed!</h4>";
    echo "<p>Please check your database configuration in <code>api/config.php</code></p>";
    echo "</div>";
    echo "</div></body></html>";
    exit;
}

echo "<div class='alert alert-success'>";
echo "<h4>✅ Database Connected Successfully!</h4>";
echo "<p>Database: <strong>" . DB_NAME . "</strong></p>";
echo "</div>";

// Read SQL file
$sql_file = 'database/complete_data.sql';

if (!file_exists($sql_file)) {
    echo "<div class='alert alert-danger'>";
    echo "<h4>❌ SQL File Not Found!</h4>";
    echo "<p>Looking for: <code>$sql_file</code></p>";
    echo "</div>";
    echo "</div></body></html>";
    exit;
}

echo "<div class='alert alert-info'>";
echo "<h4>📄 Reading SQL File...</h4>";
echo "<p>File: <code>$sql_file</code></p>";
echo "</div>";

$sql = file_get_contents($sql_file);

// Split into individual queries
$queries = array_filter(array_map('trim', explode(';', $sql)));

echo "<div class='card mb-4'>";
echo "<div class='card-body'>";
echo "<h5>🚀 Executing Queries...</h5>";
echo "<div class='progress mb-3'>";
echo "<div class='progress-bar progress-bar-striped progress-bar-animated' style='width: 0%' id='progress'></div>";
echo "</div>";
echo "<div id='results'>";

$total = count($queries);
$success = 0;
$failed = 0;

foreach ($queries as $index => $query) {
    if (empty($query) || strpos($query, '--') === 0) {
        continue;
    }
    
    $percentage = round((($index + 1) / $total) * 100);
    echo "<script>document.getElementById('progress').style.width = '{$percentage}%';</script>";
    
    if ($conn->query($query)) {
        $success++;
        // Only show important queries
        if (stripos($query, 'INSERT') !== false || stripos($query, 'CREATE TABLE') !== false) {
            $short_query = substr($query, 0, 80) . '...';
            echo "<p class='text-success mb-1'>✓ " . htmlspecialchars($short_query) . "</p>";
        }
    } else {
        $failed++;
        if ($conn->error && strpos($conn->error, 'already exists') === false) {
            echo "<p class='text-danger mb-1'>✗ Error: " . htmlspecialchars($conn->error) . "</p>";
        }
    }
    
    flush();
    ob_flush();
}

echo "</div>";
echo "</div>";
echo "</div>";

// Show summary
echo "<div class='row g-3 mb-4'>";

// Count users
$users_count = $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'];
echo "<div class='col-md-3'>";
echo "<div class='card text-center'>";
echo "<div class='card-body'>";
echo "<h2 class='text-primary'>$users_count</h2>";
echo "<p class='mb-0'>Customers</p>";
echo "</div>";
echo "</div>";
echo "</div>";

// Count products
$products_count = $conn->query("SELECT COUNT(*) as count FROM products")->fetch_assoc()['count'];
echo "<div class='col-md-3'>";
echo "<div class='card text-center'>";
echo "<div class='card-body'>";
echo "<h2 class='text-success'>$products_count</h2>";
echo "<p class='mb-0'>Products</p>";
echo "</div>";
echo "</div>";
echo "</div>";

// Count orders
$orders_count = $conn->query("SELECT COUNT(*) as count FROM orders")->fetch_assoc()['count'];
echo "<div class='col-md-3'>";
echo "<div class='card text-center'>";
echo "<div class='card-body'>";
echo "<h2 class='text-info'>$orders_count</h2>";
echo "<p class='mb-0'>Orders</p>";
echo "</div>";
echo "</div>";
echo "</div>";

// Count categories
$categories_count = $conn->query("SELECT COUNT(*) as count FROM categories")->fetch_assoc()['count'];
echo "<div class='col-md-3'>";
echo "<div class='card text-center'>";
echo "<div class='card-body'>";
echo "<h2 class='text-warning'>$categories_count</h2>";
echo "<p class='mb-0'>Categories</p>";
echo "</div>";
echo "</div>";
echo "</div>";

echo "</div>";

echo "<div class='alert alert-success'>";
echo "<h4>🎉 Import Complete!</h4>";
echo "<p><strong>Success:</strong> $success queries executed</p>";
if ($failed > 0) {
    echo "<p><strong>Skipped:</strong> $failed queries (likely duplicates)</p>";
}
echo "</div>";

echo "<div class='d-grid gap-2'>";
echo "<a href='admin/debug_check.php' class='btn btn-primary btn-lg'>🔍 Test Admin Pages</a>";
echo "<a href='admin/login.php' class='btn btn-danger btn-lg'>🔐 Go to Admin Login</a>";
echo "<a href='index.html' class='btn btn-success btn-lg'>🏠 Go to Homepage</a>";
echo "</div>";

echo "</div>";
echo "</body></html>";

$conn->close();
?>
