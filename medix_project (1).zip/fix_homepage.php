<?php
// Read the file as raw bytes
$file = __DIR__ . '/index.html';
$content = file_get_contents($file);

// Use regex to find and replace ALL broken emoji patterns
// The pattern: ðŸ followed by various chars = broken UTF-8 emoji
// Replace entire category-icon divs, tip-icon divs, etc.

// Strategy: use regex to match the broken patterns regardless of exact bytes
// Pattern matches: ð followed by any chars that look like broken encoding

// Replace category icons section
$content = preg_replace(
    '/<div class="category-icon">[^<]*<\/div>\s*<h3>Prescription<\/h3>/',
    '<div class="category-icon"><i class="bi bi-capsule-pill" style="font-size:2rem;color:#B91C1C"></i></div><h3>Prescription</h3>',
    $content
);
$content = preg_replace(
    '/<div class="category-icon">[^<]*<\/div>\s*<h3>First Aid<\/h3>/',
    '<div class="category-icon"><i class="bi bi-bandaid-fill" style="font-size:2rem;color:#B91C1C"></i></div><h3>First Aid</h3>',
    $content
);
$content = preg_replace(
    '/<div class="category-icon">[^<]*<\/div>\s*<h3>Vitamins<\/h3>/',
    '<div class="category-icon"><i class="bi bi-heart-pulse-fill" style="font-size:2rem;color:#B91C1C"></i></div><h3>Vitamins</h3>',
    $content
);
$content = preg_replace(
    '/<div class="category-icon">[^<]*<\/div>\s*<h3>Medical Devices<\/h3>/',
    '<div class="category-icon"><i class="bi bi-thermometer-half" style="font-size:2rem;color:#B91C1C"></i></div><h3>Medical Devices</h3>',
    $content
);
$content = preg_replace(
    '/<div class="category-icon">[^<]*<\/div>\s*<h3>Personal Care<\/h3>/',
    '<div class="category-icon"><i class="bi bi-droplet-fill" style="font-size:2rem;color:#B91C1C"></i></div><h3>Personal Care</h3>',
    $content
);
$content = preg_replace(
    '/<div class="category-icon">[^<]*<\/div>\s*<h3>Baby Care<\/h3>/',
    '<div class="category-icon"><i class="bi bi-emoji-smile-fill" style="font-size:2rem;color:#B91C1C"></i></div><h3>Baby Care</h3>',
    $content
);

// Replace ad banner broken emoji in h3 and ad-visual
$content = preg_replace(
    '/<h3>[^<]*Free Health Checkup<\/h3>/',
    '<h3><i class="bi bi-hospital-fill me-2"></i>Free Health Checkup</h3>',
    $content
);
$content = preg_replace(
    '/<div class="ad-visual">[^<]*<\/div>/',
    '<div class="ad-visual"><i class="bi bi-stethoscope" style="font-size:5rem;color:#B91C1C;opacity:.3"></i></div>',
    $content
);

// Replace health tips section title
$content = preg_replace(
    '/<h2 class="section-title">[^<]*Health Tips &amp; Articles<\/h2>/',
    '<h2 class="section-title"><i class="bi bi-lightbulb-fill text-warning me-2"></i>Health Tips &amp; Articles</h2>',
    $content
);
$content = preg_replace(
    '/<h2 class="section-title">[^<]*Health Tips & Articles<\/h2>/',
    '<h2 class="section-title"><i class="bi bi-lightbulb-fill text-warning me-2"></i>Health Tips &amp; Articles</h2>',
    $content
);

// Replace health tip icons
$content = preg_replace(
    '/<div class="tip-icon">[^<]*<\/div>\s*<h4>Stay Active Daily<\/h4>/',
    '<div class="tip-icon"><i class="bi bi-person-walking" style="font-size:2rem;color:#B91C1C"></i></div><h4>Stay Active Daily</h4>',
    $content
);
$content = preg_replace(
    '/<div class="tip-icon">[^<]*<\/div>\s*<h4>Balanced Diet<\/h4>/',
    '<div class="tip-icon"><i class="bi bi-egg-fried" style="font-size:2rem;color:#B91C1C"></i></div><h4>Balanced Diet</h4>',
    $content
);
$content = preg_replace(
    '/<div class="tip-icon">[^<]*<\/div>\s*<h4>Quality Sleep<\/h4>/',
    '<div class="tip-icon"><i class="bi bi-moon-stars-fill" style="font-size:2rem;color:#B91C1C"></i></div><h4>Quality Sleep</h4>',
    $content
);
$content = preg_replace(
    '/<div class="tip-icon">[^<]*<\/div>\s*<h4>Stay Hydrated<\/h4>/',
    '<div class="tip-icon"><i class="bi bi-droplet-half" style="font-size:2rem;color:#B91C1C"></i></div><h4>Stay Hydrated</h4>',
    $content
);

// Fix "Read More" broken arrow
$content = preg_replace(
    '/Read More [^\s<"]+/',
    'Read More &rarr;',
    $content
);

// Fix app banner broken emoji
$content = preg_replace(
    '/<span class="ad-label">[^<]*SPECIAL OFFER<\/span>/',
    '<span class="ad-label"><i class="bi bi-gift-fill me-1"></i>SPECIAL OFFER</span>',
    $content
);
$content = preg_replace(
    '/class="btn-app">[^<]*App Store<\/a>/',
    'class="btn-app"><i class="bi bi-apple me-1"></i>App Store</a>',
    $content
);
$content = preg_replace(
    '/class="btn-app">[^<]*Play Store<\/a>/',
    'class="btn-app"><i class="bi bi-google-play me-1"></i>Play Store</a>',
    $content
);

// Fix trust badges broken emoji
$content = preg_replace(
    '/<span style="color: #F59E0B;">[^<]*<\/span>\s*<span>Secure Payment<\/span>/',
    '<i class="bi bi-lock-fill" style="color:#F59E0B;font-size:1.5rem"></i><span>Secure Payment</span>',
    $content
);
$content = preg_replace(
    '/<span style="color: #EF4444;">[^<]*<\/span>\s*<span>Fast Delivery<\/span>/',
    '<i class="bi bi-truck-front-fill" style="color:#EF4444;font-size:1.5rem"></i><span>Fast Delivery</span>',
    $content
);
$content = preg_replace(
    '/<span style="color: #B91C1C;">[^<]*<\/span>\s*<span>Quality Guaranteed<\/span>/',
    '<i class="bi bi-award-fill" style="color:#B91C1C;font-size:1.5rem"></i><span>Quality Guaranteed</span>',
    $content
);
$content = preg_replace(
    '/<span style="color: #10B981;">[^<]*<\/span>\s*<span>FDA Approved<\/span>/',
    '<i class="bi bi-patch-check-fill" style="color:#10B981;font-size:1.5rem"></i><span>FDA Approved</span>',
    $content
);

// Fix broken star ratings in featured products
$content = preg_replace(
    '/<span class="text-warning">[^\w<]*<\/span>/',
    '<span class="text-warning"><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i><i class="bi bi-star-fill"></i></span>',
    $content
);

// Fix Rs. → PKR
$content = str_replace('Rs. ', 'PKR ', $content);

// Fix broken brand images
$brand_fixes = [
    'GSK'              => ['#F36633', 'bi-heart-pulse-fill'],
    'Johnson &amp; Johnson' => ['#CC0000', 'bi-bandaid-fill'],
    'Novartis'         => ['#0460A9', 'bi-shield-fill-check'],
    'Bayer'            => ['#10384F', 'bi-droplet-fill'],
    'Abbott'           => ['#0066CC', 'bi-activity'],
    'Merck'            => ['#009999', 'bi-prescription2'],
];
foreach ($brand_fixes as $name => $info) {
    [$color, $icon] = $info;
    $content = preg_replace(
        '/<img[^>]+alt="' . preg_quote($name, '/') . '"[^>]*>/i',
        '<div style="width:60px;height:60px;background:' . $color . '22;border-radius:12px;display:flex;align-items:center;justify-content:center;margin:0 auto"><i class="bi ' . $icon . '" style="font-size:1.75rem;color:' . $color . '"></i></div>',
        $content
    );
}

// Save
file_put_contents($file, $content);

echo '<!DOCTYPE html><html><head><meta charset="UTF-8">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head><body style="padding:2rem;background:#f8fafc">';
echo '<div class="alert alert-success fs-5"><i class="bi bi-check-circle-fill me-2"></i><strong>Done!</strong> Homepage fixed.</div>';
echo '<a href="index.php" class="btn btn-danger btn-lg">View Homepage</a>&nbsp;';
echo '<small class="text-muted ms-3">Press Ctrl+Shift+R to clear browser cache</small>';
echo '</body></html>';
?>
