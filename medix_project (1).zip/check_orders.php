<?php
require_once('api/config.php');
echo "<h2 style='font-family:Arial;padding:1rem'>Orders Debug</h2>";

if (!$conn) { die("DB failed"); }

// Count orders
$count = $conn->query("SELECT COUNT(*) as c FROM orders")->fetch_assoc()['c'];
echo "<p style='font-family:Arial;padding:.5rem 1rem'>Total orders in database: <strong>$count</strong></p>";

// Show columns
echo "<h3 style='font-family:Arial;padding:.5rem 1rem'>Orders table columns:</h3><ul style='font-family:Arial'>";
$cols = $conn->query("SHOW COLUMNS FROM orders");
while ($c = $cols->fetch_assoc()) echo "<li>{$c['Field']} ({$c['Type']})</li>";
echo "</ul>";

// Show last 5 orders
if ($count > 0) {
    echo "<h3 style='font-family:Arial;padding:.5rem 1rem'>Last 5 orders:</h3>";
    $orders = $conn->query("SELECT * FROM orders ORDER BY id DESC LIMIT 5");
    echo "<table border='1' style='font-family:Arial;margin:1rem;border-collapse:collapse'>";
    echo "<tr><th>ID</th><th>user_id</th><th>total_amount</th><th>status</th><th>created_at</th></tr>";
    while ($o = $orders->fetch_assoc()) {
        echo "<tr><td>{$o['id']}</td><td>{$o['user_id']}</td><td>{$o['total_amount']}</td><td>{$o['status']}</td><td>{$o['created_at']}</td></tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color:red;font-family:Arial;padding:1rem'>No orders found! Place an order first.</p>";
    echo "<a href='test_checkout.php' style='padding:10px 20px;background:#B91C1C;color:white;text-decoration:none;border-radius:8px;font-family:Arial;margin:1rem;display:inline-block'>Place Test Order</a>";
}

// Add payment_method column if missing
$pm = $conn->query("SHOW COLUMNS FROM orders LIKE 'payment_method'");
if ($pm->num_rows == 0) {
    $conn->query("ALTER TABLE orders ADD COLUMN payment_method VARCHAR(50) DEFAULT 'Cash on Delivery'");
    echo "<p style='color:green;font-family:Arial;padding:1rem'>✅ Added payment_method column</p>";
}
?>
