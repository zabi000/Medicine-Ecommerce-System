<?php
header('Content-Type: application/json');
header('Cache-Control: public, max-age=60'); // Cache for 60 seconds

require_once('config.php');

$q = trim($_GET['q'] ?? '');

if (strlen($q) < 1 || !$conn) {
    echo json_encode([]);
    exit;
}

// Sanitize
$q_safe = $conn->real_escape_string($q);
$like = "%$q_safe%";
$prefix = "$q_safe%"; // Prefix match ranks higher

// Fast query: prefix matches first, then contains
$sql = "SELECT id, name, category, price, stock_quantity
        FROM products
        WHERE name LIKE '$like'
           OR description LIKE '$like'
           OR category LIKE '$like'
        ORDER BY
            CASE WHEN name LIKE '$prefix' THEN 0 ELSE 1 END,
            name ASC
        LIMIT 8";

$result = $conn->query($sql);

$suggestions = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $suggestions[] = [
            'id'       => (int)$row['id'],
            'name'     => $row['name'],
            'category' => ucfirst($row['category']),
            'price'    => 'PKR ' . number_format($row['price'], 0),
            'in_stock' => (int)$row['stock_quantity'] > 0
        ];
    }
}

echo json_encode($suggestions);
?>
