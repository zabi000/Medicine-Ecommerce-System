<?php
require_once('api/config.php');

echo "<h2>Product Images Diagnostic</h2>";

if (!$conn) {
    die("<p style='color: red;'>Database connection failed!</p>");
}

// Check if image_url column exists
$columns_query = "SHOW COLUMNS FROM products LIKE 'image_url'";
$columns_result = $conn->query($columns_query);

echo "<h3>1. Checking if image_url column exists...</h3>";
if ($columns_result && $columns_result->num_rows > 0) {
    echo "<p style='color: green;'>✓ image_url column EXISTS in products table</p>";
} else {
    echo "<p style='color: red;'>✗ image_url column DOES NOT EXIST in products table</p>";
    echo "<p>Creating image_url column...</p>";
    
    $alter_query = "ALTER TABLE products ADD COLUMN image_url VARCHAR(500) NULL AFTER description";
    if ($conn->query($alter_query)) {
        echo "<p style='color: green;'>✓ image_url column created successfully!</p>";
    } else {
        echo "<p style='color: red;'>✗ Failed to create column: " . $conn->error . "</p>";
    }
}

// Get sample products
echo "<h3>2. Sample Products with Image URLs:</h3>";
$result = $conn->query("SELECT id, name, category, image_url FROM products LIMIT 10");

if ($result && $result->num_rows > 0) {
    echo "<table border='1' cellpadding='10' style='width: 100%; border-collapse: collapse;'>";
    echo "<tr style='background: #B91C1C; color: white;'>";
    echo "<th>ID</th><th>Name</th><th>Category</th><th>Image URL</th><th>Preview</th>";
    echo "</tr>";
    
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['category']) . "</td>";
        echo "<td style='font-size: 0.8em;'>" . htmlspecialchars($row['image_url'] ?? 'NULL') . "</td>";
        echo "<td>";
        if (!empty($row['image_url'])) {
            echo "<img src='" . htmlspecialchars($row['image_url']) . "' style='width: 50px; height: 50px; object-fit: cover;' onerror='this.src=\"data:image/svg+xml,%3Csvg xmlns=%27http://www.w3.org/2000/svg%27 width=%27100%27 height=%27100%27%3E%3Crect fill=%27%23ddd%27 width=%27100%27 height=%27100%27/%3E%3Ctext x=%2750%25%27 y=%2750%25%27 text-anchor=%27middle%27 dy=%27.3em%27%3ENo Image%3C/text%3E%3C/svg%3E\"'>";
        } else {
            echo "<span style='color: red;'>No Image</span>";
        }
        echo "</td>";
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color: red;'>No products found in database!</p>";
}

// Count products with and without images
echo "<h3>3. Image Statistics:</h3>";
$stats = $conn->query("SELECT 
    COUNT(*) as total,
    SUM(CASE WHEN image_url IS NOT NULL AND image_url != '' THEN 1 ELSE 0 END) as with_images,
    SUM(CASE WHEN image_url IS NULL OR image_url = '' THEN 1 ELSE 0 END) as without_images
    FROM products");

if ($stats) {
    $stat_row = $stats->fetch_assoc();
    echo "<div style='background: white; padding: 20px; border-radius: 8px;'>";
    echo "<p><strong>Total Products:</strong> " . $stat_row['total'] . "</p>";
    echo "<p><strong>With Images:</strong> <span style='color: green;'>" . $stat_row['with_images'] . "</span></p>";
    echo "<p><strong>Without Images:</strong> <span style='color: red;'>" . $stat_row['without_images'] . "</span></p>";
    echo "</div>";
}

echo "<div style='margin: 30px 0; text-align: center;'>";
if ($stat_row['without_images'] > 0) {
    echo "<a href='add_product_images.php' style='background: linear-gradient(135deg, #B91C1C, #991B1B); color: white; padding: 15px 40px; border-radius: 10px; text-decoration: none; font-weight: bold; display: inline-block;'>";
    echo "Add Images to Products";
    echo "</a>";
} else {
    echo "<a href='products.php' style='background: linear-gradient(135deg, #10B981, #059669); color: white; padding: 15px 40px; border-radius: 10px; text-decoration: none; font-weight: bold; display: inline-block;'>";
    echo "View Products Page";
    echo "</a>";
}
echo "</div>";

$conn->close();
?>
