<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Fresh Start - Complete Setup</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { padding: 50px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
        .container { background: white; padding: 40px; border-radius: 15px; box-shadow: 0 10px 40px rgba(0,0,0,0.3); }
        .step { background: #f8f9fa; padding: 20px; margin: 20px 0; border-radius: 10px; border-left: 5px solid #007bff; }
        .success { border-left-color: #28a745; background: #d4edda; }
        .error { border-left-color: #dc3545; background: #f8d7da; }
        .btn-huge { padding: 20px 40px; font-size: 1.5rem; margin: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center mb-4">🚀 Fresh Start - Complete Setup</h1>
        <p class="text-center text-muted">Let's set up everything from scratch!</p>
        <hr>

<?php
// Database credentials
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'medicare_db';

echo "<div class='step'>";
echo "<h3>Step 1: Connecting to MySQL...</h3>";

// Connect without database first
$conn = @new mysqli($host, $user, $pass);

if ($conn->connect_error) {
    echo "<div class='error'>";
    echo "<h4>❌ Cannot Connect to MySQL!</h4>";
    echo "<p><strong>Error:</strong> " . $conn->connect_error . "</p>";
    echo "<p><strong>Solution:</strong></p>";
    echo "<ol>";
    echo "<li>Open XAMPP Control Panel</li>";
    echo "<li>Click 'Start' next to Apache</li>";
    echo "<li>Click 'Start' next to MySQL</li>";
    echo "<li>Wait for green lights</li>";
    echo "<li>Refresh this page</li>";
    echo "</ol>";
    echo "</div>";
    echo "</div></div></body></html>";
    exit;
}

echo "<p class='text-success'>✅ Connected to MySQL Server!</p>";
echo "</div>";

// Step 2: Create/Reset Database
echo "<div class='step'>";
echo "<h3>Step 2: Creating Fresh Database...</h3>";

// Drop old database if exists
$conn->query("DROP DATABASE IF EXISTS $dbname");
echo "<p>🗑️ Removed old database (if existed)</p>";

// Create new database
if ($conn->query("CREATE DATABASE $dbname")) {
    echo "<p class='text-success'>✅ Created new database: <strong>$dbname</strong></p>";
} else {
    echo "<p class='text-danger'>❌ Error creating database: " . $conn->error . "</p>";
}

// Select database
$conn->select_db($dbname);
echo "</div>";

// Step 3: Create Tables
echo "<div class='step'>";
echo "<h3>Step 3: Creating Tables...</h3>";

$tables_created = 0;

// Users table
$sql = "CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20) NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
if ($conn->query($sql)) {
    echo "<p>✅ Created table: <strong>users</strong></p>";
    $tables_created++;
}

// Products table
$sql = "CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    category VARCHAR(50) NOT NULL,
    icon VARCHAR(10) DEFAULT '💊',
    stock INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
if ($conn->query($sql)) {
    echo "<p>✅ Created table: <strong>products</strong></p>";
    $tables_created++;
}

// Categories table
$sql = "CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
if ($conn->query($sql)) {
    echo "<p>✅ Created table: <strong>categories</strong></p>";
    $tables_created++;
}

// Orders table
$sql = "CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    status VARCHAR(50) DEFAULT 'pending',
    shipping_address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
)";
if ($conn->query($sql)) {
    echo "<p>✅ Created table: <strong>orders</strong></p>";
    $tables_created++;
}

// Order items table
$sql = "CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
)";
if ($conn->query($sql)) {
    echo "<p>✅ Created table: <strong>order_items</strong></p>";
    $tables_created++;
}

echo "<p class='text-success'><strong>Total tables created: $tables_created</strong></p>";
echo "</div>";

// Step 4: Insert Sample Data
echo "<div class='step'>";
echo "<h3>Step 4: Adding Sample Data...</h3>";

$data_inserted = 0;

// Insert 10 customers
$customers = [
    ['Ahmed Khan', 'ahmed@email.com', '+92-300-1234567'],
    ['Fatima Ali', 'fatima@email.com', '+92-321-9876543'],
    ['Hassan Raza', 'hassan@email.com', '+92-333-5551234'],
    ['Ayesha Malik', 'ayesha@email.com', '+92-345-7778888'],
    ['Usman Sheikh', 'usman@email.com', '+92-301-4445566'],
    ['Zainab Hussain', 'zainab@email.com', '+92-322-9998877'],
    ['Ali Haider', 'ali@email.com', '+92-334-6667788'],
    ['Sana Tariq', 'sana@email.com', '+92-346-3332211'],
    ['Bilal Ahmed', 'bilal@email.com', '+92-302-1112233'],
    ['Mariam Noor', 'mariam@email.com', '+92-323-5554433']
];

foreach ($customers as $c) {
    $stmt = $conn->prepare("INSERT INTO users (name, email, phone, password) VALUES (?, ?, ?, ?)");
    $password = password_hash('password123', PASSWORD_DEFAULT);
    $stmt->bind_param("ssss", $c[0], $c[1], $c[2], $password);
    if ($stmt->execute()) $data_inserted++;
}
echo "<p>✅ Added <strong>10 customers</strong></p>";

// Insert categories
$categories = [
    ['prescription', 'Doctor prescribed medicines'],
    ['vitamins', 'Health supplements and vitamins'],
    ['firstaid', 'Emergency medical supplies'],
    ['devices', 'Medical devices and equipment'],
    ['personal', 'Personal care products']
];

foreach ($categories as $cat) {
    $stmt = $conn->prepare("INSERT INTO categories (name, description) VALUES (?, ?)");
    $stmt->bind_param("ss", $cat[0], $cat[1]);
    if ($stmt->execute()) $data_inserted++;
}
echo "<p>✅ Added <strong>5 categories</strong></p>";

// Insert 20 products
$products = [
    ['Paracetamol 500mg', 'Pain relief tablets', 5.99, 'prescription', '💊', 500],
    ['Ibuprofen 400mg', 'Anti-inflammatory', 7.99, 'prescription', '💊', 450],
    ['Vitamin C 1000mg', 'Immune support', 12.99, 'vitamins', '💉', 400],
    ['Vitamin D3 2000IU', 'Bone health', 14.99, 'vitamins', '💉', 350],
    ['First Aid Kit', 'Emergency kit', 29.99, 'firstaid', '🩹', 100],
    ['Bandages Pack', 'Sterile bandages', 8.99, 'firstaid', '🩹', 250],
    ['Digital Thermometer', 'Temperature reading', 15.99, 'devices', '🌡️', 180],
    ['Blood Pressure Monitor', 'BP measurement', 45.99, 'devices', '🌡️', 80],
    ['Hand Sanitizer 500ml', 'Antibacterial gel', 4.99, 'personal', '🧴', 600],
    ['Face Masks (50 Pack)', 'Surgical masks', 12.99, 'personal', '😷', 500],
    ['Aspirin 100mg', 'Blood thinner', 6.99, 'prescription', '💊', 400],
    ['Multivitamin Complex', 'Daily nutrition', 19.99, 'vitamins', '💉', 300],
    ['Antiseptic Cream', 'Wound care', 7.99, 'firstaid', '🩹', 300],
    ['Pulse Oximeter', 'Oxygen monitor', 29.99, 'devices', '🩺', 120],
    ['Antibacterial Soap', 'Hand wash', 6.99, 'personal', '🧴', 350],
    ['Omega-3 Fish Oil', 'Heart health', 24.99, 'vitamins', '💉', 250],
    ['Gauze Pads', 'Medical gauze', 6.99, 'firstaid', '🩹', 280],
    ['Infrared Thermometer', 'Non-contact scanner', 34.99, 'devices', '🌡️', 100],
    ['Wet Wipes (80pcs)', 'Cleaning wipes', 5.99, 'personal', '🧴', 400],
    ['Calcium + Vitamin D', 'Bone strength', 16.99, 'vitamins', '💉', 280]
];

foreach ($products as $p) {
    $stmt = $conn->prepare("INSERT INTO products (name, description, price, category, icon, stock) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssdssi", $p[0], $p[1], $p[2], $p[3], $p[4], $p[5]);
    if ($stmt->execute()) $data_inserted++;
}
echo "<p>✅ Added <strong>20 products</strong></p>";

// Insert 5 orders
for ($i = 1; $i <= 5; $i++) {
    $user_id = rand(1, 10);
    $amount = rand(50, 500);
    $statuses = ['pending', 'processing', 'delivered'];
    $status = $statuses[array_rand($statuses)];
    
    $stmt = $conn->prepare("INSERT INTO orders (user_id, total_amount, status, shipping_address) VALUES (?, ?, ?, ?)");
    $address = "Address $i, City, Pakistan";
    $stmt->bind_param("idss", $user_id, $amount, $status, $address);
    if ($stmt->execute()) $data_inserted++;
}
echo "<p>✅ Added <strong>5 orders</strong></p>";

echo "<p class='text-success'><strong>Total records inserted: $data_inserted</strong></p>";
echo "</div>";

// Step 5: Verify
echo "<div class='step success'>";
echo "<h3>Step 5: Verification</h3>";

$users_count = $conn->query("SELECT COUNT(*) as c FROM users")->fetch_assoc()['c'];
$products_count = $conn->query("SELECT COUNT(*) as c FROM products")->fetch_assoc()['c'];
$orders_count = $conn->query("SELECT COUNT(*) as c FROM orders")->fetch_assoc()['c'];
$categories_count = $conn->query("SELECT COUNT(*) as c FROM categories")->fetch_assoc()['c'];

echo "<div class='row text-center'>";
echo "<div class='col-3'><h2>$users_count</h2><p>Customers</p></div>";
echo "<div class='col-3'><h2>$products_count</h2><p>Products</p></div>";
echo "<div class='col-3'><h2>$orders_count</h2><p>Orders</p></div>";
echo "<div class='col-3'><h2>$categories_count</h2><p>Categories</p></div>";
echo "</div>";
echo "</div>";

$conn->close();
?>

        <div class="step success text-center">
            <h2>🎉 Setup Complete!</h2>
            <p>Your database is ready with sample data!</p>
            <hr>
            <a href="admin/customers.php" class="btn btn-primary btn-huge">
                👥 View Customers
            </a>
            <a href="admin/products.php" class="btn btn-success btn-huge">
                📦 View Products
            </a>
            <a href="admin/index.php" class="btn btn-danger btn-huge">
                📊 Admin Dashboard
            </a>
        </div>

        <div class="alert alert-info mt-4">
            <h5>📝 Admin Login Credentials:</h5>
            <p><strong>Email:</strong> admin@email.com (or any customer email)</p>
            <p><strong>Password:</strong> password123</p>
            <p class="mb-0"><small>Note: You may need to set session manually using debug_check.php first</small></p>
        </div>
    </div>
</body>
</html>
