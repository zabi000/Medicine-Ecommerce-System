﻿<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>File Check</title>
    <style>
        body { font-family: monospace; padding: 20px; background: #f0f0f0; }
        .box { background: white; padding: 20px; margin: 10px 0; border-radius: 5px; }
        .error { background: #ffebee; color: #c62828; }
        .success { background: #e8f5e9; color: #2e7d32; }
        .warning { background: #fff3e0; color: #ef6c00; }
        h2 { color: #B91C1C; }
        pre { background: #f5f5f5; padding: 10px; overflow-x: auto; }
    </style>
</head>
<body>
    <h1>ðŸ” File Diagnostic Check</h1>
    
    <div class="box">
        <h2>1. Current File Information</h2>
        <pre>Current File: <?= __FILE__ ?>
Current Script: <?= $_SERVER['PHP_SELF'] ?>
Request URI: <?= $_SERVER['REQUEST_URI'] ?></pre>
    </div>

    <div class="box">
        <h2>2. File Existence Check</h2>
        <?php
        $files = [
            'customers.php' => 'Customers Page',
            'products.php' => 'Products Page',
            'settings.php' => 'Settings Page',
            'orders.php' => 'Orders Page'
        ];
        
        foreach ($files as $file => $name) {
            $path = __DIR__ . '/' . $file;
            if (file_exists($path)) {
                $size = filesize($path);
                $modified = date('Y-m-d H:i:s', filemtime($path));
                echo "<div class='success'>âœ“ $name ($file) - Size: " . number_format($size) . " bytes - Modified: $modified</div>";
            } else {
                echo "<div class='error'>âœ— $name ($file) - FILE NOT FOUND!</div>";
            }
        }
        ?>
    </div>

    <div class="box">
        <h2>3. File Content Check (First 500 chars)</h2>
        <?php
        foreach (['customers.php', 'products.php'] as $file) {
            $path = __DIR__ . '/' . $file;
            if (file_exists($path)) {
                $content = file_get_contents($path, false, null, 0, 500);
                echo "<h3>$file:</h3>";
                echo "<pre>" . htmlspecialchars($content) . "...</pre>";
            }
        }
        ?>
    </div>

    <div class="box">
        <h2>4. Title Check</h2>
        <?php
        foreach (['customers.php', 'products.php', 'settings.php'] as $file) {
            $path = __DIR__ . '/' . $file;
            if (file_exists($path)) {
                $content = file_get_contents($path);
                if (preg_match('/<title>(.*?)<\/title>/i', $content, $matches)) {
                    echo "<div class='success'>$file: <strong>" . htmlspecialchars($matches[1]) . "</strong></div>";
                } else {
                    echo "<div class='warning'>$file: No title found</div>";
                }
            }
        }
        ?>
    </div>

    <div class="box">
        <h2>5. PHP Error Log</h2>
        <?php
        $error_log = ini_get('error_log');
        if ($error_log && file_exists($error_log)) {
            $errors = file_get_contents($error_log);
            $recent = array_slice(explode("\n", $errors), -20);
            echo "<pre>" . htmlspecialchars(implode("\n", $recent)) . "</pre>";
        } else {
            echo "<div class='warning'>Error log not found or not configured</div>";
        }
        ?>
    </div>

    <div class="box">
        <h2>6. Test Links</h2>
        <p><a href="customers.php" style="color: #B91C1C; font-size: 18px; font-weight: bold;">â†’ Click to go to Customers Page</a></p>
        <p><a href="products.php" style="color: #B91C1C; font-size: 18px; font-weight: bold;">â†’ Click to go to Products Page</a></p>
        <p><a href="settings.php" style="color: #B91C1C; font-size: 18px; font-weight: bold;">â†’ Click to go to Settings Page</a></p>
    </div>

    <div class="box">
        <h2>7. Server Information</h2>
        <pre>PHP Version: <?= phpversion() ?>
Server Software: <?= $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown' ?>
Document Root: <?= $_SERVER['DOCUMENT_ROOT'] ?>
Script Filename: <?= $_SERVER['SCRIPT_FILENAME'] ?></pre>
    </div>
</body>
</html>

