﻿<?php
session_start();
require_once('api/config.php');

// Search and Category Logic
$search = "";
$category = "";
$products = [];

if ($conn) {
    // Handle search
    if (isset($_GET['search']) && !empty($_GET['search'])) {
        $search = trim($_GET['search']);
        
        // Split search into individual words for better matching
        $words = array_filter(explode(' ', $search));
        
        if (count($words) > 1) {
            // Multi-word: search each word separately with OR logic
            $conditions = [];
            $params = [];
            $types = '';
            foreach ($words as $word) {
                $word = trim($word);
                if (strlen($word) >= 2) {
                    $conditions[] = "(name LIKE ? OR description LIKE ? OR category LIKE ?)";
                    $like = "%$word%";
                    $params[] = $like;
                    $params[] = $like;
                    $params[] = $like;
                    $types .= 'sss';
                }
            }
            
            if (!empty($conditions)) {
                $sql = "SELECT * FROM products WHERE " . implode(' OR ', $conditions) . " ORDER BY id DESC";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param($types, ...$params);
                $stmt->execute();
                $result = $stmt->get_result();
                $products = $result->fetch_all(MYSQLI_ASSOC);
            }
        } else {
            // Single word search
            $stmt = $conn->prepare("SELECT * FROM products WHERE name LIKE ? OR description LIKE ? OR category LIKE ? ORDER BY id DESC");
            $search_param = "%$search%";
            $stmt->bind_param("sss", $search_param, $search_param, $search_param);
            $stmt->execute();
            $result = $stmt->get_result();
            $products = $result->fetch_all(MYSQLI_ASSOC);
        }
    }
    // Handle category filter
    elseif (isset($_GET['category']) && !empty($_GET['category'])) {
        $category = $_GET['category'];
        $stmt = $conn->prepare("SELECT * FROM products WHERE category = ? ORDER BY id DESC");
        $stmt->bind_param("s", $category);
        $stmt->execute();
        $result = $stmt->get_result();
        $products = $result->fetch_all(MYSQLI_ASSOC);
    }
    // Show all products
    else {
        $result = $conn->query("SELECT * FROM products ORDER BY id DESC");
        if ($result) {
            $products = $result->fetch_all(MYSQLI_ASSOC);
        }
    }
}

// Get cart count
$cart_count = 0;
if (isset($_SESSION['cart'])) {
    $cart_count = array_sum($_SESSION['cart']);
}

// Load active offers into a lookup array [product_id => offer]
$active_offers = [];
if ($conn) {
    $conn->query("CREATE TABLE IF NOT EXISTS offers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        product_id INT NOT NULL,
        discount_percent DECIMAL(5,2) NOT NULL,
        offer_label VARCHAR(100) DEFAULT 'SALE',
        start_date DATE NOT NULL,
        end_date DATE NOT NULL,
        is_active TINYINT(1) DEFAULT 1,
        show_on_homepage TINYINT(1) DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $or = $conn->query("SELECT product_id, discount_percent, offer_label FROM offers WHERE is_active=1 AND CURDATE() BETWEEN start_date AND end_date");
    if ($or) while ($row = $or->fetch_assoc()) {
        $active_offers[$row['product_id']] = $row;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Products - MEDIX</title>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/style.css?v=36.0">
    <style>
        body { 
            background: #F8FAFC; 
            font-family: 'Inter', sans-serif;
        }
        /* Force navigation visibility */
        .navbar {
            background: linear-gradient(135deg, #B91C1C, #991B1B) !important;
        }
        .nav-link {
            color: #FFFFFF !important;
            font-weight: 500 !important;
            opacity: 1 !important;
        }
        .nav-link:hover,
        .nav-link.active {
            color: #FFFFFF !important;
            background: rgba(255, 255, 255, 0.2) !important;
            border-radius: 8px;
        }
        .products-header {
            background: linear-gradient(135deg, #B91C1C 0%, #7F1D1D 60%, #450A0A 100%);
            color: white;
            padding: 3.5rem 0 4rem;
            margin-bottom: 0;
            position: relative;
            overflow: hidden;
        }
        .products-header::before {
            content: '';
            position: absolute;
            top: -50%; right: -10%;
            width: 500px; height: 500px;
            background: radial-gradient(circle, rgba(255,255,255,0.06) 0%, transparent 70%);
            border-radius: 50%;
        }
        .products-header::after {
            content: '';
            position: absolute;
            bottom: -30%; left: -5%;
            width: 350px; height: 350px;
            background: radial-gradient(circle, rgba(255,255,255,0.04) 0%, transparent 70%);
            border-radius: 50%;
        }
        
        /* Professional Search Box */
        .search-box-professional {
            max-width: 750px;
            margin: 0 auto;
            position: relative;
        }
        .search-wrapper {
            position: relative;
            display: flex;
            align-items: center;
            background: white;
            border-radius: 16px;
            padding: 0.5rem 0.5rem 0.5rem 1.5rem;
            box-shadow: 0 8px 32px rgba(0,0,0,0.2);
            border: 3px solid transparent;
            transition: all 0.3s ease;
        }
        .search-wrapper:focus-within {
            border-color: rgba(255,255,255,0.6);
            box-shadow: 0 12px 40px rgba(0,0,0,0.3);
            transform: translateY(-2px);
        }
        .search-icon {
            color: #B91C1C;
            font-size: 1.4rem;
            margin-right: 0.75rem;
            flex-shrink: 0;
        }
        .search-input-pro {
            flex: 1;
            border: none;
            outline: none;
            font-size: 1.05rem;
            padding: 0.75rem 0;
            color: #1e293b;
            background: transparent;
            font-weight: 500;
        }
        .search-input-pro::placeholder {
            color: #94a3b8;
            font-weight: 400;
        }
        .search-clear-btn {
            background: none;
            border: none;
            color: #94a3b8;
            font-size: 1.2rem;
            cursor: pointer;
            padding: 0.5rem;
            display: none;
            transition: color 0.2s;
        }
        .search-clear-btn:hover { color: #ef4444; }
        .search-btn-pro {
            background: linear-gradient(135deg, #B91C1C, #991B1B);
            color: white;
            border: none;
            padding: 0.875rem 2rem;
            border-radius: 12px;
            font-weight: 700;
            font-size: 0.95rem;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            white-space: nowrap;
            letter-spacing: 0.3px;
        }
        .search-btn-pro:hover {
            background: linear-gradient(135deg, #991B1B, #7F1D1D);
            transform: scale(1.03);
            box-shadow: 0 6px 20px rgba(185,28,28,0.4);
        }
        /* Autocomplete Dropdown */
        .search-suggestions {
            position: absolute;
            top: calc(100% + 8px);
            left: 0;
            right: 0;
            background: white;
            border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.2);
            z-index: 1000;
            overflow: hidden;
            display: none;
            border: 1px solid #f1f5f9;
        }
        .suggestion-item {
            padding: 0.875rem 1.5rem;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 0.75rem;
            transition: background 0.2s;
            border-bottom: 1px solid #f8fafc;
        }
        .suggestion-item:last-child { border-bottom: none; }
        .suggestion-item:hover, .suggestion-item.active {
            background: #FEF2F2;
        }
        .suggestion-item i {
            color: #B91C1C;
            font-size: 1rem;
            flex-shrink: 0;
        }
        .suggestion-name {
            font-weight: 600;
            color: #1e293b;
            font-size: 0.9rem;
        }
        .suggestion-category {
            font-size: 0.75rem;
            color: #64748b;
            margin-left: auto;
            background: #f1f5f9;
            padding: 0.2rem 0.6rem;
            border-radius: 20px;
        }
        .suggestion-header {
            padding: 0.5rem 1.5rem;
            font-size: 0.75rem;
            font-weight: 700;
            color: #94a3b8;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            background: #f8fafc;
        }
        /* Quick search tags */
        .quick-tags {
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
            justify-content: center;
            margin-top: 1rem;
        }
        .quick-tag {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 0.4rem 1rem;
            border-radius: 20px;
            font-size: 0.8rem;
            font-weight: 500;
            cursor: pointer;
            border: 1px solid rgba(255,255,255,0.3);
            transition: all 0.2s;
            text-decoration: none;
        }
        .quick-tag:hover {
            background: rgba(255,255,255,0.35);
            color: white;
            transform: translateY(-2px);
        }
        
        /* Category Pills */
        .category-pills {
            background: white;
            padding: 0.875rem 1.5rem;
            border-radius: 14px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
            margin-bottom: 1.5rem;
            display: flex;
            flex-wrap: wrap;
            gap: 0.5rem;
            align-items: center;
        }
        .category-pills a {
            background: #F8FAFC;
            color: #475569;
            padding: 0.45rem 1.1rem;
            border-radius: 20px;
            font-size: 0.82rem;
            font-weight: 600;
            text-decoration: none;
            border: 1.5px solid #E2E8F0;
            transition: all 0.2s ease;
            white-space: nowrap;
        }
        .category-pills a:hover {
            background: #FEF2F2;
            color: #B91C1C;
            border-color: #B91C1C;
            transform: translateY(-1px);
        }
        .category-pills a.active {
            background: linear-gradient(135deg, #B91C1C, #DC2626);
            color: white;
            border-color: transparent;
            box-shadow: 0 4px 12px rgba(185,28,28,0.3);
        }
        
        .product-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
            gap: 1.5rem;
            padding: 2rem 0;
        }
        .product-card {
            background: white;
            border-radius: 20px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
            transition: all 0.3s cubic-bezier(0.4,0,0.2,1);
            border: 1.5px solid #F1F5F9;
            position: relative;
            display: flex;
            flex-direction: column;
        }
        .product-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 20px 40px rgba(185,28,28,0.14);
            border-color: #B91C1C;
        }
        .product-image-container {
            position: relative;
            width: 100%;
            height: 220px;
            background: linear-gradient(145deg, #FFF5F5 0%, #FFF 60%, #F8FAFC 100%);
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
        }
        .product-image-container::after {
            content: '';
            position: absolute;
            bottom: 0; left: 0; right: 0;
            height: 60px;
            background: linear-gradient(to top, rgba(255,255,255,1), transparent);
            pointer-events: none;
        }
        .product-image {
            max-width: 100%;
            max-height: 100%;
            object-fit: contain;
            transition: transform 0.4s cubic-bezier(0.4,0,0.2,1);
            z-index: 1;
        }
        .product-card:hover .product-image {
            transform: scale(1.08);
        }
        /* No-image icon styling */
        .product-image-container .bi-capsule-pill {
            font-size: 5rem;
            color: #FECACA;
            transition: transform 0.4s ease, color 0.3s;
        }
        .product-card:hover .product-image-container .bi-capsule-pill {
            transform: scale(1.1) rotate(-5deg);
            color: #B91C1C;
        }
        .product-category-badge {
            position: absolute;
            top: 12px;
            left: 12px;
            background: rgba(255,255,255,0.95);
            color: #7C3AED;
            padding: 4px 12px;
            border-radius: 20px;
            font-size: 0.7rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            z-index: 3;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            backdrop-filter: blur(4px);
        }
        /* Wishlist / quick action button */
        .product-card::before {
            content: '\F588'; /* Bootstrap Icons heart */
            font-family: 'bootstrap-icons';
            position: absolute;
            top: 12px; right: 12px;
            width: 32px; height: 32px;
            background: rgba(255,255,255,0.9);
            border-radius: 50%;
            display: flex; align-items: center; justify-content: center;
            font-size: 0.9rem;
            color: #94a3b8;
            z-index: 3;
            opacity: 0;
            transition: opacity 0.2s, color 0.2s;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            line-height: 32px;
            text-align: center;
        }
        .product-card:hover::before { opacity: 1; }
        .product-body {
            padding: 1.25rem 1.5rem 1.5rem;
            flex: 1;
            display: flex;
            flex-direction: column;
        }
        .product-name {
            font-size: 0.975rem;
            font-weight: 700;
            color: #0F172A;
            margin-bottom: 0.5rem;
            min-height: 44px;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            line-height: 1.4;
        }
        .product-description {
            color: #94A3B8;
            font-size: 0.8rem;
            margin-bottom: 0.75rem;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
            line-height: 1.5;
            flex: 1;
        }
        .product-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: auto;
            padding-top: 1rem;
            border-top: 1.5px solid #F8FAFC;
        }
        .product-price {
            font-size: 1.35rem;
            font-weight: 800;
            color: #B91C1C;
            letter-spacing: -0.5px;
        }
        .product-price::before { content: ''; }
        .btn-add-cart {
            background: linear-gradient(135deg, #B91C1C, #DC2626);
            color: white;
            border: none;
            padding: 0.6rem 1.1rem;
            border-radius: 10px;
            cursor: pointer;
            transition: all 0.25s ease;
            font-weight: 600;
            font-size: 0.85rem;
            display: flex;
            align-items: center;
            gap: 0.4rem;
            white-space: nowrap;
        }
        .btn-add-cart:hover {
            background: linear-gradient(135deg, #991B1B, #B91C1C);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px rgba(185,28,28,0.4);
        }
        .btn-add-cart:active { transform: translateY(0); }
        .btn-add-cart:disabled {
            background: linear-gradient(135deg, #CBD5E1, #94A3B8);
            cursor: not-allowed;
            transform: none;
            box-shadow: none;
        }
        .no-products {
            text-align: center;
            padding: 5rem 2rem;
            background: white;
            border-radius: 20px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.06);
        }
        .stock-badge {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            padding: 0.2rem 0.65rem;
            border-radius: 20px;
            font-size: 0.75rem;
            font-weight: 600;
            margin-bottom: 0.5rem;
        }
        .in-stock  { background: #DCFCE7; color: #166534; }
        .low-stock { background: #FEF3C7; color: #92400E; }
        .out-stock { background: #FEE2E2; color: #991B1B; }

        /* Results bar */
        .results-bar {
            background: white;
            padding: 0.875rem 1.5rem;
            border-radius: 12px;
            margin-bottom: 1.5rem;
            box-shadow: 0 1px 4px rgba(0,0,0,0.06);
            border-left: 4px solid #B91C1C;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            font-size: 0.9rem;
            color: #475569;
        }
        .results-bar strong { color: #0F172A; }
        .results-count { color: #B91C1C; font-weight: 700; margin-left: auto; }
        
        /* Responsive */
        @media (max-width: 991.98px) {
            /* Navbar: keep logo + toggler on ONE row */
            .navbar > .container {
                flex-wrap: nowrap !important;
                align-items: center !important;
            }
            .navbar-brand { flex-shrink: 0; }
            .navbar-toggler { flex-shrink: 0; margin-left: auto; }

            /* Collapsed menu */
            .navbar-collapse {
                background: linear-gradient(135deg,#991B1B,#7F1D1D);
                border-radius: 10px;
                padding: 0.75rem 1rem;
                margin-top: 0.5rem;
            }
        }

        @media (max-width: 767.98px) {
            /* Top bar: single compact line */
            .top-bar .row { flex-direction: row !important; }
            .top-bar .col-md-6 { flex: 0 0 auto; }
            .top-bar .col-md-6:last-child { display: none; }

            .search-btn-pro {
                padding: 0.6rem 1rem;
                font-size: 0.85rem;
            }
            .search-input-pro { font-size: 0.85rem; }
            .category-pills {
                flex-wrap: nowrap !important;
                overflow-x: auto;
                -webkit-overflow-scrolling: touch;
                scrollbar-width: none;
            }
            .category-pills::-webkit-scrollbar { display: none; }
            .category-pills a {
                flex-shrink: 0;
                padding: 0.35rem 0.8rem;
                font-size: 0.78rem;
            }
            .products-header h1 { font-size: 1.6rem !important; }
            .products-header p { font-size: 0.9rem !important; }
        }

        @media (max-width: 480px) {
            /* Hide top bar entirely on phones */
            .top-bar { display: none !important; }
            .product-grid {
                grid-template-columns: repeat(2, 1fr) !important;
                gap: 0.75rem !important;
            }
            .product-name { font-size: 0.8rem !important; }
            .product-price { font-size: 1rem !important; }
            .btn-add-cart {
                padding: 0.4rem 0.5rem !important;
                font-size: 0.72rem !important;
            }
            .product-image-container { height: 160px !important; }
        }
    </style>
</head>
<body>
    <header>
        <!-- Top Bar -->
        <div class="top-bar">
            <div class="container">
                <div class="d-flex align-items-center justify-content-between py-1">
                    <div>
                        <span class="text-white-50 small me-3">
                            <i class="bi bi-telephone-fill me-1"></i> +92 300 1234567
                        </span>
                        <span class="text-white-50 small d-none d-sm-inline">
                            <i class="bi bi-envelope-fill me-1"></i> info@medix.com
                        </span>
                    </div>
                    <span class="text-white-50 small d-none d-md-inline">
                        <i class="bi bi-truck me-1"></i> Free Delivery on Orders Over Rs. 2000
                    </span>
                </div>
            </div>
        </div>
        
        <nav class="navbar navbar-expand-lg navbar-dark">
            <div class="container">
                <a class="navbar-brand d-flex align-items-center" href="index.html">
                    <div class="logo-icon-wrapper me-2">
                        <i class="bi bi-heart-pulse-fill"></i>
                    </div>
                    <span class="fw-bold" style="letter-spacing: 1px;">MEDIX</span>
                </a>
                
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link" href="index.html">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="products.php">Products</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.html">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.html">Contact</a>
                        </li>

                    </ul>
                    
                    <div class="d-flex align-items-center gap-2 ms-lg-3">
                        <?php if (isset($_SESSION['user_id']) && $_SESSION['user_id'] > 0):
                            $uname = htmlspecialchars(explode(' ', $_SESSION['user_name'] ?? 'User')[0]);
                        ?>
                        <div class="dropdown">
                            <button class="btn btn-outline-light btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                <i class="bi bi-person-check-fill me-1"></i><?= $uname ?>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li><span class="dropdown-item-text text-muted small"><?= htmlspecialchars($_SESSION['user_name'] ?? '') ?></span></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="user/logout.php"><i class="bi bi-box-arrow-right me-2 text-danger"></i>Logout</a></li>
                            </ul>
                        </div>
                        <?php else: ?>
                        <a href="login.php" class="btn btn-outline-light btn-sm">
                            <i class="bi bi-person"></i> Login
                        </a>
                        <?php endif; ?>
                        <a href="cart.php" class="position-relative text-white">
                            <i class="bi bi-cart3 fs-4"></i>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger"><?= $cart_count ?></span>
                        </a>
                    </div>
                </div>
            </div>
        </nav>
    </header>

    <div class="products-header">
        <div class="container">
            <h1 class="text-center mb-2" style="font-size: 2.5rem; font-weight: bold;">
                <i class="bi bi-shop"></i> All Products
            </h1>
            <p class="text-center mb-4" style="font-size: 1.1rem; opacity: 0.9;">
                Browse our complete collection of medicines, supplements, and healthcare products
            </p>
            
            <!-- Professional Search Box -->
            <div class="search-box-professional mb-4">
                <form action="products.php" method="GET" id="searchForm" autocomplete="off">
                    <div class="search-wrapper search-container">
                        <i class="bi bi-search search-icon"></i>
                        <input 
                            type="text" 
                            name="search" 
                            id="searchInput"
                            class="search-input-pro" 
                            placeholder="Search medicines, vitamins, skincare..." 
                            value="<?= htmlspecialchars($search) ?>"
                            autocomplete="off">
                        <button type="button" class="search-clear-btn" id="clearBtn" onclick="clearSearch()">
                            <i class="bi bi-x-circle-fill"></i>
                        </button>
                        <button type="submit" class="search-btn-pro">
                            <i class="bi bi-search"></i> Search
                        </button>
                        <!-- Autocomplete Dropdown -->
                        <div class="s-dropdown" id="suggestions"></div>
                    </div>
                </form>
                
                                <!-- Quick Search Tags -->
                <div class="quick-tags">
                    <a href="products.php?search=panadol" class="quick-tag"><i class="bi bi-capsule-pill me-1"></i>Panadol</a>
                    <a href="products.php?search=antibiotic" class="quick-tag"><i class="bi bi-shield-plus me-1"></i>Antibiotics</a>
                    <a href="products.php?search=pain" class="quick-tag"><i class="bi bi-bandaid me-1"></i>Pain Relief</a>
                    <a href="products.php?search=fever" class="quick-tag"><i class="bi bi-thermometer-half me-1"></i>Fever</a>
                    <a href="products.php?search=vitamin" class="quick-tag"><i class="bi bi-heart-pulse me-1"></i>Vitamins</a>
                    <a href="products.php?search=gel" class="quick-tag"><i class="bi bi-droplet me-1"></i>Gels</a>
                    <a href="products.php?search=allergy" class="quick-tag"><i class="bi bi-flower1 me-1"></i>Allergy</a>
                    <a href="products.php?search=cough" class="quick-tag"><i class="bi bi-lungs me-1"></i>Cough</a>
                </div>
            </div>
            
            <!-- Category Filter Pills - moved to below header -->
        </div>
    </div>

    <div class="container" style="padding-top: 1.5rem;">
        <!-- Category Pills -->
        <div class="category-pills mb-3">
            <a href="products.php" class="<?= empty($search) && empty($category) ? 'active' : '' ?>">
                <i class="bi bi-grid-3x3-gap me-1"></i>All
            </a>
            <a href="products.php?category=vitamins" class="<?= $category === 'vitamins' ? 'active' : '' ?>">
                <i class="bi bi-capsule me-1"></i>Vitamins
            </a>
            <a href="products.php?category=skincare" class="<?= $category === 'skincare' ? 'active' : '' ?>">
                <i class="bi bi-droplet me-1"></i>Skincare
            </a>
            <a href="products.php?category=firstaid" class="<?= $category === 'firstaid' ? 'active' : '' ?>">
                <i class="bi bi-bandaid me-1"></i>First Aid
            </a>
            <a href="products.php?category=devices" class="<?= $category === 'devices' ? 'active' : '' ?>">
                <i class="bi bi-thermometer me-1"></i>Devices
            </a>
            <a href="products.php?category=antibiotics" class="<?= $category === 'antibiotics' ? 'active' : '' ?>">
                <i class="bi bi-capsule-pill me-1"></i>Antibiotics
            </a>
            <a href="products.php?category=painrelief" class="<?= $category === 'painrelief' ? 'active' : '' ?>">
                <i class="bi bi-heart-pulse me-1"></i>Pain Relief
            </a>
        </div>
        <?php if (!empty($search)): ?>
            <div class="results-bar">
                <i class="bi bi-search text-danger"></i>
                Results for: <strong>"<?= htmlspecialchars($search) ?>"</strong>
                <span class="results-count"><?= count($products) ?> found</span>
            </div>
        <?php elseif (!empty($category)): ?>
            <div class="results-bar">
                <i class="bi bi-tag-fill text-danger"></i>
                Category: <strong style="text-transform:capitalize"><?= htmlspecialchars($category) ?></strong>
                <span class="results-count"><?= count($products) ?> products</span>
            </div>
        <?php else: ?>
            <div class="results-bar">
                <i class="bi bi-grid-3x3-gap-fill text-danger"></i>
                <strong>All Products</strong>
                <span class="results-count"><?= count($products) ?> total</span>
            </div>
        <?php endif; ?>
        
        <?php if (count($products) > 0): ?>
            <div class="product-grid">
                <?php foreach($products as $product): ?>
                    <div class="product-card">
                        <div class="product-image-container">
                            <span class="product-category-badge"><?= htmlspecialchars(ucfirst($product['category'])) ?></span>
                            <?php if (!empty($active_offers[$product['id']])): ?>
                            <span style="position:absolute;top:12px;right:12px;background:linear-gradient(135deg,#B91C1C,#DC2626);color:white;padding:4px 10px;border-radius:20px;font-size:.7rem;font-weight:800;z-index:3">
                                -<?= number_format($active_offers[$product['id']]['discount_percent'], 0) ?>%
                            </span>
                            <?php endif; ?>
                            <?php if (!empty($product['image_url'])): ?>
                                <?php
                                // Fix image URL - handle both relative and absolute paths
                                $img_src = $product['image_url'];
                                if (!str_starts_with($img_src, 'http') && !str_starts_with($img_src, '/')) {
                                    $img_src = '/' . ltrim($img_src, '/');
                                    // If it's uploads/products/... prefix with /ppp/
                                    if (str_starts_with($img_src, '/uploads/')) {
                                        $img_src = '/ppp' . $img_src;
                                    }
                                }
                                ?>
                                <img src="<?= htmlspecialchars($img_src) ?>" 
                                     alt="<?= htmlspecialchars($product['name']) ?>" 
                                     class="product-image">
                            <?php else: ?>
                                <i class="bi bi-capsule-pill" style="font-size: 5rem; color: #B91C1C;"></i>
                            <?php endif; ?>
                        </div>
                        <div class="product-body">
                            <h3 class="product-name"><?= htmlspecialchars($product['name']) ?></h3>
                            
                            <?php if (!empty($product['description'])): ?>
                                <p class="product-description"><?= htmlspecialchars($product['description']) ?></p>
                            <?php endif; ?>
                            
                            <?php
                            $stock  = (int)($product['stock_quantity'] ?? 0);
                            $offer  = $active_offers[$product['id']] ?? null;
                            $disp_p = $offer ? round($product['price'] * (1 - $offer['discount_percent'] / 100), 2) : $product['price'];
                            ?>

                            <?php if ($stock > 10): ?>
                                <span class="stock-badge in-stock"><i class="bi bi-check-circle-fill"></i> In Stock</span>
                            <?php elseif ($stock > 0): ?>
                                <span class="stock-badge low-stock"><i class="bi bi-exclamation-triangle-fill"></i> Only <?= $stock ?> left!</span>
                            <?php else: ?>
                                <span class="stock-badge out-stock"><i class="bi bi-x-circle-fill"></i> Out of Stock</span>
                            <?php endif; ?>
                            
                            <div class="product-footer">
                                <div>
                                    <?php if ($offer): ?>
                                        <div class="text-muted text-decoration-line-through" style="font-size:.8rem">PKR <?= number_format($product['price'], 0) ?></div>
                                    <?php endif; ?>
                                    <span class="product-price">PKR <?= number_format($disp_p, 0) ?></span>
                                </div>
                                <?php if ($stock > 0): ?>
                                    <form action="cart.php" method="POST" style="margin: 0;">
                                        <input type="hidden" name="product_id" value="<?= $product['id'] ?>">
                                        <?php if (!isset($_SESSION['user_id']) || !$_SESSION['user_id']): ?>
                                        <button type="button" class="btn-add-cart" onclick="window.location.href='login.php?redirect=products.php'">
                                            <i class="bi bi-person-lock"></i> Login to Buy
                                        </button>
                                        <?php else: ?>
                                        <button type="submit" class="btn-add-cart">
                                            <i class="bi bi-cart-plus-fill"></i> Add
                                        </button>
                                        <?php endif; ?>
                                    </form>
                                <?php else: ?>
                                    <button class="btn-add-cart" disabled>
                                        <i class="bi bi-x-circle"></i> Unavailable
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="no-products">
                <i class="bi bi-search" style="font-size: 4rem; color: #ccc;"></i>
                <h3 class="mt-3">No products found</h3>
                <?php if (!empty($search)): ?>
                    <p class="text-muted">No results for "<strong><?= htmlspecialchars($search) ?></strong>"</p>
                    <p class="text-muted small">Try searching with simpler terms like:</p>
                    <div class="d-flex flex-wrap gap-2 justify-content-center mt-2 mb-3">
                        <?php
                        // Show suggestion chips from the search words
                        $words = array_filter(explode(' ', $search));
                        foreach ($words as $word):
                            if (strlen(trim($word)) >= 2):
                        ?>
                        <a href="products.php?search=<?= urlencode(trim($word)) ?>" 
                           class="btn btn-sm btn-outline-danger">
                            <i class="bi bi-search"></i> <?= htmlspecialchars(trim($word)) ?>
                        </a>
                        <?php 
                            endif;
                        endforeach; 
                        ?>
                    </div>
                    <a href="products.php" class="btn btn-danger mt-2">
                        <i class="bi bi-grid-3x3-gap me-1"></i>View All Products
                    </a>
                <?php else: ?>
                    <p class="text-muted">No products available at the moment.</p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3 class="text-white mb-3">MEDIX</h3>
                    <p class="text-white-50">Your trusted online pharmacy</p>
                </div>
                <div class="footer-section">
                    <h4 class="text-white mb-3">Quick Links</h4>
                    <ul>
                        <li><a href="products.php">Products</a></li>
                        <li><a href="about.html">About Us</a></li>
                        <li><a href="contact.html">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4 class="text-white mb-3">Contact</h4>
                    <p class="text-white-50"><i class="bi bi-envelope-fill me-2"></i>info@medix.com</p>
                    <p class="text-white-50"><i class="bi bi-telephone-fill me-2"></i>+92 300 1234567</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p class="text-white-50 mb-0">&copy; 2026 MEDIX. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <!-- Bootstrap JS Bundle -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/search.js"></script>
    <script>
        // Initialize smart search on products page
        new MedixSearch('searchInput', 'suggestions', {
            apiPath: 'api/search_suggestions.php',
            redirectPath: 'products.php'
        });

        const searchInput = document.getElementById('searchInput');
        const clearBtn = document.getElementById('clearBtn');

        // Clear button visibility
        searchInput?.addEventListener('input', function() {
            if (clearBtn) clearBtn.style.display = this.value ? 'block' : 'none';
        });

        function clearSearch() {
            searchInput.value = '';
            if (clearBtn) clearBtn.style.display = 'none';
            searchInput.focus();
        }

        // Init clear button
        if (clearBtn && searchInput?.value) clearBtn.style.display = 'block';
    </script>
</body>
</html>

