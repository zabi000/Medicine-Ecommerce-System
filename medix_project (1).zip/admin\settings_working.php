﻿<?php
session_start();
if (!isset($_SESSION["admin_logged_in"])) { header("Location: login.php"); exit(); }

$settings_file = "data/settings.json";
$default_settings = [
    "store_name" => "MEDIX Pharmacy",
    "email" => "info@medix.com.pk",
    "phone" => "+92-300-1234567",
    "currency" => "PKR",
    "address" => "123 Main Street, Karachi, Pakistan",
    "free_shipping" => 5000,
    "shipping_cost" => 250,
    "express_shipping" => 500,
    "delivery_time" => "2-3 business days",
    "opening_time" => "09:00",
    "closing_time" => "21:00"
];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $settings = [
        "store_name" => $_POST["store_name"] ?? "",
        "email" => $_POST["email"] ?? "",
        "phone" => $_POST["phone"] ?? "",
        "currency" => $_POST["currency"] ?? "PKR",
        "address" => $_POST["address"] ?? "",
        "free_shipping" => $_POST["free_shipping"] ?? 5000,
        "shipping_cost" => $_POST["shipping_cost"] ?? 250,
        "express_shipping" => $_POST["express_shipping"] ?? 500,
        "delivery_time" => $_POST["delivery_time"] ?? "",
        "opening_time" => $_POST["opening_time"] ?? "09:00",
        "closing_time" => $_POST["closing_time"] ?? "21:00"
    ];
    file_put_contents($settings_file, json_encode($settings, JSON_PRETTY_PRINT));
    $success_message = "Settings saved successfully!";
}

if (file_exists($settings_file)) {
    $settings = json_decode(file_get_contents($settings_file), true);
} else {
    $settings = $default_settings;
}
?>

