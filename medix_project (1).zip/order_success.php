<?php
session_start();
require_once('api/config.php');

$orderNumber   = intval($_GET['order'] ?? 0);
$paymentMethod = $_GET['payment'] ?? '';

if (!$orderNumber) {
    header('Location: products.php');
    exit;
}

$paymentNames = [
    'cod'       => 'Cash on Delivery',
    'jazzcash'  => 'JazzCash',
    'easypaisa' => 'Easypaisa',
    'bank'      => 'Bank Transfer'
];
$paymentDisplay = $paymentNames[$paymentMethod] ?? 'Unknown';
$is_digital = in_array($paymentMethod, ['jazzcash', 'easypaisa', 'bank']);

// Read real status + existing proof from database
$real_status   = 'pending';
$payment_proof = null;
if ($conn) {
    // Add column if missing
    $conn->query("ALTER TABLE orders ADD COLUMN IF NOT EXISTS payment_proof VARCHAR(255) DEFAULT NULL");
    $conn->query("ALTER TABLE orders ADD COLUMN IF NOT EXISTS payment_proof_at TIMESTAMP NULL DEFAULT NULL");

    $sr = $conn->query("SELECT status, payment_proof FROM orders WHERE id = $orderNumber");
    if ($sr && $row = $sr->fetch_assoc()) {
        $real_status   = $row['status'];
        $payment_proof = $row['payment_proof'];
    }
}

$statusLabels = [
    'pending'    => ['label' => 'Pending Payment Verification', 'color' => '#F59E0B'],
    'processing' => ['label' => 'Confirmed',  'color' => '#10B981'],
    'delivered'  => ['label' => 'Delivered',  'color' => '#3B82F6'],
    'cancelled'  => ['label' => 'Cancelled',  'color' => '#EF4444'],
];
$statusInfo = $statusLabels[$real_status] ?? ['label' => ucfirst($real_status), 'color' => '#6B7280'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Successful - MEDIX</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="css/style.css?v=22.0">
    <style>
        .success-container {
            max-width: 700px;
            margin: 3rem auto;
            padding: 2rem;
            text-align: center;
        }
        .success-card {
            background: white;
            padding: 3rem 2rem;
            border-radius: 15px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        .success-icon {
            width: 80px;
            height: 80px;
            background: #10B981;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 1.5rem;
        }
        .success-icon i {
            font-size: 3rem;
            color: white;
        }
        .success-title {
            color: #10B981;
            font-size: 2rem;
            margin-bottom: 1rem;
        }
        .order-details {
            background: #F9FAFB;
            padding: 1.5rem;
            border-radius: 10px;
            margin: 2rem 0;
            text-align: left;
        }
        .order-details p {
            margin: 0.75rem 0;
            font-size: 1.1rem;
        }
        .order-details strong {
            color: #B91C1C;
        }
        .payment-instructions {
            background: #FEF2F2;
            border-left: 4px solid #B91C1C;
            padding: 1.5rem;
            margin: 2rem 0;
            text-align: left;
        }
        .payment-instructions h4 {
            color: #B91C1C;
            margin-bottom: 1rem;
        }
        .payment-instructions p {
            margin: 0.5rem 0;
            line-height: 1.6;
        }
        .action-buttons {
            display: flex;
            gap: 1rem;
            justify-content: center;
            margin-top: 2rem;
        }
        .btn-primary, .btn-secondary {
            padding: 0.75rem 2rem;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 600;
            transition: all 0.3s;
        }
        .btn-primary {
            background: #B91C1C;
            color: white;
        }
        .btn-primary:hover {
            background: #991B1B;
        }
        .btn-secondary {
            background: white;
            color: #B91C1C;
            border: 2px solid #B91C1C;
        }
        .btn-secondary:hover {
            background: #FEF2F2;
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="container">
                <div class="logo">
                    <h1><a href="index.html" style="text-decoration: none; color: inherit; display: flex; align-items: center; gap: 0.5rem;">
                        <div class="logo-icon-wrapper-simple">
                            <i class="bi bi-heart-pulse-fill"></i>
                        </div>
                        <span style="letter-spacing: 1px;">MEDIX</span>
                    </a></h1>
                </div>
                <ul class="nav-links">
                    <li><a href="index.html">Home</a></li>
                    <li><a href="products.php">Products</a></li>
                    <li><a href="about.html">About</a></li>
                    <li><a href="contact.html">Contact</a></li>
                </ul>
                <div class="nav-actions">
                    <a href="login.php" class="btn-login">Login</a>
                    <a href="cart.php" class="cart-icon">🛒 <span id="cart-count">0</span></a>
                </div>
            </div>
        </nav>
    </header>

    <div class="success-container">
        <div class="success-card">
            <div class="success-icon">
                <i class="bi bi-check-lg"></i>
            </div>
            <h1 class="success-title">Order Placed Successfully!</h1>
            <p style="color: #666; font-size: 1.1rem;">Thank you for your order. We'll process it shortly.</p>
            
            <div class="order-details">
                <p><strong>Order Number:</strong> <?php echo htmlspecialchars($orderNumber); ?></p>
                <p><strong>Payment Method:</strong> <?php echo htmlspecialchars($paymentDisplay); ?></p>
                <p><strong>Status:</strong> <span style="color: <?= $statusInfo['color'] ?>; font-weight:700"><?= $statusInfo['label'] ?></span></p>
                <?php if ($real_status === 'processing'): ?>
                <p style="color:#10B981;font-size:.95rem"><i class="bi bi-check-circle-fill me-1"></i>Your order has been confirmed and is being prepared!</p>
                <?php endif; ?>
            </div>

            <?php if ($paymentMethod === 'jazzcash'): ?>
            <div class="payment-instructions">
                <h4><i class="bi bi-info-circle"></i> JazzCash Payment Instructions</h4>
                <p><strong>Account Title:</strong> MEDIX Pharmacy</p>
                <p><strong>JazzCash Number:</strong> 0300-1234567</p>
                <p style="margin-top: 1rem;">Please send the payment amount to the above number and share the payment screenshot via WhatsApp at <strong>0300-1234567</strong>. Your order will be processed once payment is confirmed.</p>
            </div>
            <?php elseif ($paymentMethod === 'easypaisa'): ?>
            <div class="payment-instructions">
                <h4><i class="bi bi-info-circle"></i> Easypaisa Payment Instructions</h4>
                <p><strong>Account Title:</strong> MEDIX Pharmacy</p>
                <p><strong>Easypaisa Number:</strong> 0321-7654321</p>
                <p style="margin-top: 1rem;">Please send the payment amount to the above number and share the payment screenshot via WhatsApp at <strong>0321-7654321</strong>. Your order will be processed once payment is confirmed.</p>
            </div>
            <?php elseif ($paymentMethod === 'bank'): ?>
            <div class="payment-instructions">
                <h4><i class="bi bi-info-circle"></i> Bank Transfer Instructions</h4>
                <p><strong>Bank Name:</strong> HBL (Habib Bank Limited)</p>
                <p><strong>Account Title:</strong> MEDIX Pharmacy</p>
                <p><strong>Account Number:</strong> 12345678901234</p>
                <p><strong>IBAN:</strong> PK36HABB0012345678901234</p>
                <p style="margin-top: 1rem;">After completing the bank transfer, please send the receipt to <strong>info@medix.com</strong> with your order number. Your order will be processed once payment is confirmed.</p>
            </div>
            <?php elseif ($paymentMethod === 'cod'): ?>
            <div class="payment-instructions">
                <h4><i class="bi bi-info-circle"></i> Cash on Delivery</h4>
                <p>Your order will be delivered to your address. Please keep the exact amount ready for payment upon delivery.</p>
                <p style="margin-top: 1rem;">Our delivery team will contact you shortly to confirm your order and delivery time.</p>
            </div>
            <?php endif; ?>

            <?php if ($is_digital): ?>
            <!-- ===== PAYMENT PROOF UPLOAD ===== -->
            <div id="uploadSection" style="background: <?= $payment_proof ? '#f0fdf4' : '#fffbeb' ?>; border: 2px solid <?= $payment_proof ? '#22c55e' : '#f59e0b' ?>; border-radius: 14px; padding: 1.5rem; margin: 1.5rem 0; text-align:left">
                <?php if ($payment_proof): ?>
                    <h4 style="color:#166534"><i class="bi bi-check-circle-fill me-2"></i>Payment Screenshot Received</h4>
                    <p style="color:#166534; font-size:.9rem">Your payment screenshot has been uploaded. We will verify it and confirm your order shortly.</p>
                    <div class="text-center mt-2">
                        <img src="/ppp/<?= htmlspecialchars($payment_proof) ?>" alt="Payment Proof" style="max-width:100%;max-height:300px;border-radius:10px;border:2px solid #22c55e">
                    </div>
                <?php else: ?>
                    <h4 style="color:#92400e"><i class="bi bi-exclamation-triangle-fill me-2"></i>Action Required — Upload Payment Screenshot</h4>
                    <p style="color:#78350f; font-size:.9rem"><strong>Your order is on hold.</strong> Please upload your payment screenshot to confirm your order. You cannot continue until this is done.</p>
                    <div id="uploadResult" style="display:none;margin-bottom:1rem"></div>
                    <div style="border:2px dashed #f59e0b;border-radius:10px;padding:1.5rem;text-align:center;background:white;cursor:pointer" id="dropZone" onclick="document.getElementById('proofFile').click()">
                        <i class="bi bi-cloud-upload-fill" style="font-size:2.5rem;color:#f59e0b"></i>
                        <p class="mt-2 mb-1 fw-semibold" style="color:#92400e">Click to upload payment screenshot</p>
                        <p class="small text-muted mb-0">JPG, PNG, GIF — Max 5MB</p>
                        <input type="file" id="proofFile" accept="image/*" style="display:none" onchange="uploadProof(this)">
                    </div>
                    <button onclick="document.getElementById('proofFile').click()" class="btn btn-warning w-100 mt-3 fw-bold" style="border-radius:10px;border:none;background:linear-gradient(135deg,#f59e0b,#d97706)">
                        <i class="bi bi-camera-fill me-2"></i>Select & Upload Screenshot
                    </button>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <div class="action-buttons">
                <?php if ($is_digital && !$payment_proof): ?>
                <!-- Digital payment: must upload screenshot first -->
                <button onclick="alert('Please upload your payment screenshot first before continuing.')"
                        class="btn-secondary" style="cursor:not-allowed;opacity:.6">
                    Continue Shopping
                </button>
                <button onclick="alert('Please upload your payment screenshot first before going home.')"
                        class="btn-secondary" style="cursor:not-allowed;opacity:.6">
                    Go to Home
                </button>
                <?php else: ?>
                <a href="products.php" class="btn-primary">Continue Shopping</a>
                <a href="index.php" class="btn-secondary">Go to Home</a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3 class="text-white mb-3">MEDIX</h3>
                    <p class="text-white-50">Your trusted online pharmacy</p>
                </div>
                <div class="footer-section">
                    <h4 class="text-white mb-3">Quick Links</h4>
                    <ul>
                        <li><a href="products.php">Products</a></li>
                        <li><a href="about.html">About Us</a></li>
                        <li><a href="contact.html">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4 class="text-white mb-3">Contact</h4>
                    <p class="text-white-50"><i class="bi bi-envelope-fill me-2"></i>info@medix.com</p>
                    <p class="text-white-50"><i class="bi bi-telephone-fill me-2"></i>+92 300 1234567</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p class="text-white-50 mb-0">&copy; 2026 MEDIX. All rights reserved.</p>
            </div>
        </div>
    </footer>

    <script src="js/main.js"></script>
    <script>
    function uploadProof(input) {
        const file = input.files[0];
        if (!file) return;

        const result = document.getElementById('uploadResult');
        result.style.display = 'block';
        result.innerHTML = '<div style="background:#eff6ff;border:1px solid #93c5fd;border-radius:8px;padding:.75rem;color:#1e40af"><i class="bi bi-hourglass-split me-2"></i>Uploading screenshot...</div>';

        const fd = new FormData();
        fd.append('payment_proof', file);
        fd.append('order_id', <?= $orderNumber ?>);

        fetch('api/upload_payment_proof.php', { method: 'POST', body: fd })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    result.innerHTML = '<div style="background:#f0fdf4;border:1px solid #86efac;border-radius:8px;padding:.75rem;color:#166534"><i class="bi bi-check-circle-fill me-2"></i><strong>Screenshot uploaded!</strong> We\'ll verify your payment and confirm the order shortly.</div>';
                    // Show the image preview
                    const uploadSection = document.getElementById('uploadSection');
                    uploadSection.style.border = '2px solid #22c55e';
                    uploadSection.style.background = '#f0fdf4';
                    setTimeout(() => location.reload(), 2000);
                } else {
                    result.innerHTML = '<div style="background:#fef2f2;border:1px solid #fca5a5;border-radius:8px;padding:.75rem;color:#991b1b"><i class="bi bi-exclamation-triangle me-2"></i>' + data.message + '</div>';
                }
            })
            .catch(() => {
                result.innerHTML = '<div style="background:#fef2f2;border:1px solid #fca5a5;border-radius:8px;padding:.75rem;color:#991b1b"><i class="bi bi-exclamation-triangle me-2"></i>Upload failed. Please try again.</div>';
            });
    }

    // Drag and drop
    const dz = document.getElementById('dropZone');
    if (dz) {
        dz.addEventListener('dragover', e => { e.preventDefault(); dz.style.background='#fffbeb'; });
        dz.addEventListener('dragleave', () => dz.style.background='white');
        dz.addEventListener('drop', e => {
            e.preventDefault();
            dz.style.background = 'white';
            const dt = e.dataTransfer;
            if (dt.files.length) {
                document.getElementById('proofFile').files = dt.files;
                uploadProof(document.getElementById('proofFile'));
            }
        });
    }
    </script>
</body>
</html>
