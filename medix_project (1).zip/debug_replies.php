<?php
session_start();
require_once('api/config.php');

echo "<style>body{font-family:sans-serif;padding:2rem;background:#f8fafc} table{border-collapse:collapse;width:100%} td,th{border:1px solid #ddd;padding:8px;font-size:13px}</style>";
echo "<h3>Message & Reply Debug</h3>";

if (!$conn) { echo "DB failed"; exit; }

// Show logged-in user
echo "<h4>Logged-in User:</h4>";
if (isset($_SESSION['user_id'])) {
    echo "<p>User ID: {$_SESSION['user_id']} | Email: {$_SESSION['user_email']} | Name: {$_SESSION['user_name']}</p>";
} else {
    echo "<p style='color:red'>Not logged in</p>";
}

// Show all messages
echo "<h4>All Contact Messages:</h4>";
$r = $conn->query("SELECT id, first_name, last_name, email, subject, status, created_at FROM contact_messages ORDER BY id DESC LIMIT 10");
echo "<table><tr><th>ID</th><th>Name</th><th>Email</th><th>Subject</th><th>Status</th><th>Date</th></tr>";
while ($row = $r->fetch_assoc()) {
    echo "<tr><td>{$row['id']}</td><td>{$row['first_name']} {$row['last_name']}</td><td>{$row['email']}</td><td>{$row['subject']}</td><td>{$row['status']}</td><td>{$row['created_at']}</td></tr>";
}
echo "</table>";

// Show all replies
echo "<h4>All Replies:</h4>";
$r2 = $conn->query("SELECT mr.*, cm.email as msg_email FROM message_replies mr JOIN contact_messages cm ON mr.message_id=cm.id ORDER BY mr.id DESC LIMIT 10");
echo "<table><tr><th>Reply ID</th><th>Message ID</th><th>Message Email</th><th>Reply Subject</th><th>Sent At</th></tr>";
while ($row = $r2->fetch_assoc()) {
    echo "<tr><td>{$row['id']}</td><td>{$row['message_id']}</td><td>{$row['msg_email']}</td><td>{$row['reply_subject']}</td><td>{$row['sent_at']}</td></tr>";
}
echo "</table>";

// Check if user's email matches any messages
if (isset($_SESSION['user_email'])) {
    $em = $conn->real_escape_string($_SESSION['user_email']);
    $r3 = $conn->query("SELECT cm.id, cm.subject, COUNT(mr.id) as reply_count FROM contact_messages cm LEFT JOIN message_replies mr ON cm.id=mr.message_id WHERE cm.email='$em' GROUP BY cm.id");
    echo "<h4>Messages for logged-in user ({$_SESSION['user_email']}):</h4>";
    if ($r3 && $r3->num_rows > 0) {
        echo "<table><tr><th>Message ID</th><th>Subject</th><th>Replies</th></tr>";
        while ($row = $r3->fetch_assoc()) {
            echo "<tr><td>{$row['id']}</td><td>{$row['subject']}</td><td>{$row['reply_count']}</td></tr>";
        }
        echo "</table>";
    } else {
        echo "<p style='color:red'>No messages found for this email. The contact form may have used a different email address.</p>";
    }
}
?>
