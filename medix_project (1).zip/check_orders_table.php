<?php
require_once('api/config.php');

echo "<h2>Orders Table Structure:</h2>";
$result = $conn->query("DESCRIBE orders");
echo "<table border='1' cellpadding='5'>";
echo "<tr><th>Field</th><th>Type</th></tr>";
while ($row = $result->fetch_assoc()) {
    echo "<tr><td>{$row['Field']}</td><td>{$row['Type']}</td></tr>";
}
echo "</table>";

echo "<h2>Recent Order Data:</h2>";
$orders = $conn->query("SELECT * FROM orders ORDER BY created_at DESC LIMIT 1");
if ($orders && $orders->num_rows > 0) {
    $order = $orders->fetch_assoc();
    echo "<pre>";
    print_r($order);
    echo "</pre>";
}
?>
