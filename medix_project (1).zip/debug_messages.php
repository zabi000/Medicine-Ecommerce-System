<?php
require_once('api/config.php');
echo "<!DOCTYPE html><html><head><meta charset='UTF-8'>
<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css' rel='stylesheet'>
</head><body style='padding:2rem;background:#f8fafc'>";

echo "<h3>Message System Debug</h3>";

if (!$conn) { echo "<div class='alert alert-danger'>DB connection FAILED</div>"; exit; }

// 1. Check column
$cols = [];
$cr = $conn->query("SHOW COLUMNS FROM contact_messages");
if ($cr) while ($c = $cr->fetch_assoc()) $cols[] = $c['Field'];
echo "<div class='alert alert-info'>Columns: " . implode(', ', $cols) . "</div>";

if (!in_array('attachment', $cols)) {
    $conn->query("ALTER TABLE contact_messages ADD COLUMN attachment VARCHAR(255) DEFAULT NULL");
    echo "<div class='alert alert-warning'>attachment column was MISSING — just added it. Please send a new test message.</div>";
} else {
    echo "<div class='alert alert-success'>✅ attachment column exists</div>";
}

// 2. PHP upload settings
echo "<h5>PHP Upload Settings:</h5>";
echo "<ul>";
echo "<li>file_uploads: " . (ini_get('file_uploads') ? '✅ ON' : '❌ OFF') . "</li>";
echo "<li>upload_max_filesize: " . ini_get('upload_max_filesize') . "</li>";
echo "<li>post_max_size: " . ini_get('post_max_size') . "</li>";
echo "</ul>";

// 3. uploads/messages folder
$dir = __DIR__ . '/uploads/messages/';
echo "<h5>uploads/messages/ folder:</h5>";
if (!is_dir($dir)) {
    mkdir($dir, 0755, true);
    echo "<div class='alert alert-warning'>Folder was missing — created it now.</div>";
} else {
    echo "<div class='alert alert-success'>✅ Folder exists</div>";
    $files = array_filter(scandir($dir), fn($f) => !in_array($f, ['.','..']));
    if (empty($files)) {
        echo "<p class='text-muted'>Folder is empty (no files uploaded yet)</p>";
    } else {
        echo "<table class='table table-sm'><tr><th>File</th><th>Size</th><th>Preview</th></tr>";
        foreach ($files as $f) {
            $size = round(filesize($dir.$f)/1024, 1) . ' KB';
            $url = '/ppp/uploads/messages/' . $f;
            $preview = preg_match('/\.(jpg|jpeg|png|gif|webp)$/i', $f)
                ? "<img src='$url' style='max-height:60px;border-radius:4px'>"
                : "<a href='$url' target='_blank'>View</a>";
            echo "<tr><td>$f</td><td>$size</td><td>$preview</td></tr>";
        }
        echo "</table>";
    }
}

// 4. Recent messages
echo "<h5>Recent Messages (last 5):</h5>";
$r = $conn->query("SELECT id, email, subject, attachment, created_at FROM contact_messages ORDER BY id DESC LIMIT 5");
echo "<table class='table table-sm'><tr><th>ID</th><th>Email</th><th>Subject</th><th>Attachment</th><th>File OK?</th></tr>";
while ($row = $r->fetch_assoc()) {
    $att = $row['attachment'];
    if ($att) {
        $path = __DIR__ . '/' . $att;
        $ok = file_exists($path) ? "<span class='text-success'>✅ File exists</span>" : "<span class='text-danger'>❌ File missing at: $path</span>";
        $link = "<a href='/ppp/$att' target='_blank'>View</a>";
    } else {
        $ok = "<span class='text-muted'>No attachment</span>";
        $link = '—';
    }
    echo "<tr><td>{$row['id']}</td><td>{$row['email']}</td><td>{$row['subject']}</td><td>$att $link</td><td>$ok</td></tr>";
}
echo "</table>";

echo "<hr><p><a href='admin/messages.php' class='btn btn-danger'>Go to Admin Messages</a></p>";
echo "</body></html>";
?>
