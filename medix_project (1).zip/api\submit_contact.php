<?php
session_start();
header('Content-Type: application/json');
require_once('config.php');

// Ensure file uploads are enabled
if (!ini_get('file_uploads')) {
    ini_set('file_uploads', 1);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

if (!$conn) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed.']);
    exit;
}

// Auto-create / upgrade table
$conn->query("CREATE TABLE IF NOT EXISTS contact_messages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    first_name VARCHAR(100) DEFAULT '',
    last_name VARCHAR(100) DEFAULT '',
    email VARCHAR(200) NOT NULL,
    phone VARCHAR(30) DEFAULT '',
    subject VARCHAR(200) DEFAULT 'General',
    message TEXT NOT NULL,
    attachment VARCHAR(255) DEFAULT NULL,
    status ENUM('new','read','replied') DEFAULT 'new',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Add attachment column if missing
$conn->query("ALTER TABLE contact_messages ADD COLUMN IF NOT EXISTS attachment VARCHAR(255) DEFAULT NULL");

// Get form data
$firstName = trim($_POST['firstName'] ?? $_POST['first_name'] ?? '');
$lastName  = trim($_POST['lastName']  ?? $_POST['last_name']  ?? '');
$phone     = trim($_POST['phone']     ?? '');
$subject   = trim($_POST['subject']   ?? 'General');
$message   = trim($_POST['message']   ?? '');

// Use session email if logged in
$email = trim($_POST['email'] ?? '');
if (isset($_SESSION['user_email']) && !empty($_SESSION['user_email'])) {
    $email = $_SESSION['user_email'];
    if (!$firstName && isset($_SESSION['user_name'])) {
        $parts = explode(' ', $_SESSION['user_name'], 2);
        $firstName = $parts[0];
        $lastName  = $parts[1] ?? '';
    }
}

if (!$firstName || !$email || !$message) {
    echo json_encode(['success' => false, 'message' => 'Name, email and message are required.']);
    exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Invalid email address.']);
    exit;
}

// Handle file upload
$attachment = null;
if (isset($_FILES['attachment']) && $_FILES['attachment']['error'] === UPLOAD_ERR_OK) {
    $file = $_FILES['attachment'];

    // Check by extension (finfo may not be available on all XAMPP setups)
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $allowed_ext = ['jpg','jpeg','png','gif','webp','pdf'];

    if (!in_array($ext, $allowed_ext)) {
        echo json_encode(['success' => false, 'message' => 'Only images (JPG, PNG, GIF) and PDF allowed.']);
        exit;
    }
    if ($file['size'] > 5 * 1024 * 1024) {
        echo json_encode(['success' => false, 'message' => 'File too large. Max 5MB.']);
        exit;
    }

    $filename = 'msg_' . time() . '_' . bin2hex(random_bytes(4)) . '.' . $ext;
    $dir      = __DIR__ . '/../uploads/messages/';
    if (!is_dir($dir)) mkdir($dir, 0755, true);

    if (move_uploaded_file($file['tmp_name'], $dir . $filename)) {
        $attachment = 'uploads/messages/' . $filename;
    } else {
        // Log the error but don't fail the whole message
        error_log("Failed to move uploaded file to: " . $dir . $filename);
    }
}

$stmt = $conn->prepare("INSERT INTO contact_messages (first_name, last_name, email, phone, subject, message, attachment, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'new')");
$stmt->bind_param("sssssss", $firstName, $lastName, $email, $phone, $subject, $message, $attachment);

if ($stmt->execute()) {
    $messageId = $conn->insert_id;
    $ref = 'MSG-' . str_pad($messageId, 6, '0', STR_PAD_LEFT);
    // Notify admin via email (silently — don't fail if email fails)
    @include_once('mailer.php');
    if (function_exists('sendContactNotificationToAdmin')) {
        @sendContactNotificationToAdmin(trim("$firstName $lastName"), $email, $subject, $message, $conn);
    }
    echo json_encode([
        'success'    => true,
        'message'    => 'Message sent! We\'ll reply soon.',
        'reference'  => $ref,
        'attachment' => $attachment
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Failed to save: ' . $conn->error]);
}
$stmt->close();
?>
