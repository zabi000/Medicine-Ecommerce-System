<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Simple Test</title>
    <style>
        body { font-family: Arial; padding: 50px; background: #f5f5f5; }
        .box { background: white; padding: 20px; margin: 10px 0; border-radius: 5px; }
        .success { border-left: 5px solid green; }
        .error { border-left: 5px solid red; }
        .warning { border-left: 5px solid orange; }
    </style>
</head>
<body>
    <h1>🔍 Simple Test</h1>
    
    <?php
    // Test 1
    echo "<div class='box success'>";
    echo "<h3>✓ PHP is Working</h3>";
    echo "<p>PHP Version: " . phpversion() . "</p>";
    echo "</div>";
    
    // Test 2
    echo "<div class='box'>";
    echo "<h3>Testing Database Connection...</h3>";
    
    $host = 'localhost';
    $user = 'root';
    $pass = '';
    $db = 'medicare_db';
    
    $conn = @new mysqli($host, $user, $pass, $db);
    
    if ($conn->connect_error) {
        echo "<div class='error'>";
        echo "<p>❌ Connection Failed!</p>";
        echo "<p>Error: " . $conn->connect_error . "</p>";
        echo "<p><strong>Solutions:</strong></p>";
        echo "<ul>";
        echo "<li>Make sure XAMPP/WAMP is running</li>";
        echo "<li>Make sure MySQL service is started</li>";
        echo "<li>Create database 'medicare_db' in phpMyAdmin</li>";
        echo "</ul>";
        echo "</div>";
    } else {
        echo "<div class='success'>";
        echo "<p>✓ Connected to MySQL!</p>";
        echo "<p>Database: <strong>$db</strong></p>";
        echo "</div>";
        
        // Check tables
        echo "<h3>Checking Tables...</h3>";
        $tables = ['users', 'products', 'orders', 'categories'];
        
        foreach ($tables as $table) {
            $result = $conn->query("SHOW TABLES LIKE '$table'");
            if ($result && $result->num_rows > 0) {
                $count = $conn->query("SELECT COUNT(*) as c FROM $table")->fetch_assoc()['c'];
                echo "<div class='box success'>";
                echo "<p>✓ Table '<strong>$table</strong>' exists ($count records)</p>";
                echo "</div>";
            } else {
                echo "<div class='box error'>";
                echo "<p>❌ Table '<strong>$table</strong>' NOT FOUND</p>";
                echo "</div>";
            }
        }
        
        $conn->close();
    }
    echo "</div>";
    ?>
    
    <div class="box warning">
        <h3>📋 What to Do Next:</h3>
        <ol>
            <li><strong>If database connected but tables missing:</strong><br>
                <a href="IMPORT_COMPLETE_DATABASE.php" style="display:inline-block;margin:10px 0;padding:10px 20px;background:#28a745;color:white;text-decoration:none;border-radius:5px;">
                    📦 Click Here to Import Database
                </a>
            </li>
            <li><strong>If database connection failed:</strong><br>
                - Start XAMPP/WAMP<br>
                - Go to phpMyAdmin<br>
                - Create database: <code>medicare_db</code>
            </li>
            <li><strong>After importing:</strong><br>
                <a href="admin/customers.php" style="display:inline-block;margin:10px 0;padding:10px 20px;background:#007bff;color:white;text-decoration:none;border-radius:5px;">
                    👥 Go to Customers Page
                </a>
            </li>
        </ol>
    </div>
</body>
</html>
