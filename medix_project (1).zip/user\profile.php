<?php
session_start();
require_once('../api/config.php');

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php?redirect=user/profile.php');
    exit;
}

$uid = (int)$_SESSION['user_id'];
$success = $error = '';

// Handle profile update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $name  = trim($_POST['name'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    if (!$name) { $error = 'Name is required.'; }
    else {
        $cols = [];
        $cr = $conn->query("SHOW COLUMNS FROM users");
        if ($cr) while ($c = $cr->fetch_assoc()) $cols[] = $c['Field'];
        $nc = in_array('name', $cols) ? 'name' : (in_array('username', $cols) ? 'username' : null);
        if ($nc) {
            $stmt = $conn->prepare("UPDATE users SET $nc=?, phone=? WHERE id=?");
            $stmt->bind_param("ssi", $name, $phone, $uid);
            $stmt->execute();
            $_SESSION['user_name'] = $name;
            $success = 'Profile updated successfully!';
        }
    }
}

// Handle password change
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $cur  = $_POST['current_password'] ?? '';
    $new  = $_POST['new_password'] ?? '';
    $conf = $_POST['confirm_password'] ?? '';
    if (strlen($new) < 6) { $error = 'New password must be at least 6 characters.'; }
    elseif ($new !== $conf) { $error = 'Passwords do not match.'; }
    else {
        $stmt = $conn->prepare("SELECT password FROM users WHERE id=?");
        $stmt->bind_param("i", $uid); $stmt->execute();
        $row = $stmt->get_result()->fetch_assoc();
        if ($row && password_verify($cur, $row['password'])) {
            $hash = password_hash($new, PASSWORD_DEFAULT);
            $u = $conn->prepare("UPDATE users SET password=? WHERE id=?");
            $u->bind_param("si", $hash, $uid); $u->execute();
            $success = 'Password changed successfully!';
        } else { $error = 'Current password is incorrect.'; }
    }
}

// Fetch user
$stmt = $conn->prepare("SELECT * FROM users WHERE id=?");
$stmt->bind_param("i", $uid); $stmt->execute();
$user = $stmt->get_result()->fetch_assoc() ?? [];
$display_name = $user['name'] ?? $user['username'] ?? $user['email'] ?? 'User';
$initials = strtoupper(implode('', array_map(fn($w) => $w[0], array_slice(explode(' ', $display_name), 0, 2))));

// Fetch orders
$orders_result = $conn->query("SELECT * FROM orders WHERE user_id=$uid ORDER BY created_at DESC LIMIT 20");
$order_list = $orders_result ? $orders_result->fetch_all(MYSQLI_ASSOC) : [];
$total_spent = array_sum(array_column($order_list, 'total_amount'));
$delivered_count = count(array_filter($order_list, fn($o) => $o['status'] === 'delivered'));

// Fetch messages sent by this user (matched by email)
$user_email = $user['email'] ?? '';
$messages_list = [];
$unread_replies = 0;
if ($user_email && $conn) {
    $conn->query("CREATE TABLE IF NOT EXISTS contact_messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        first_name VARCHAR(100) DEFAULT '',
        last_name VARCHAR(100) DEFAULT '',
        email VARCHAR(200) NOT NULL,
        phone VARCHAR(30) DEFAULT '',
        subject VARCHAR(200) DEFAULT 'General',
        message TEXT NOT NULL,
        status ENUM('new','read','replied') DEFAULT 'new',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $conn->query("CREATE TABLE IF NOT EXISTS message_replies (
        id INT AUTO_INCREMENT PRIMARY KEY,
        message_id INT NOT NULL,
        reply_subject VARCHAR(255) NOT NULL,
        reply_message TEXT NOT NULL,
        recipient_email VARCHAR(255) NOT NULL,
        recipient_name VARCHAR(255) NOT NULL,
        sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $em = $conn->real_escape_string($user_email);
    $mr = $conn->query("SELECT * FROM contact_messages WHERE email='$em' ORDER BY created_at DESC");
    if ($mr) $messages_list = $mr->fetch_all(MYSQLI_ASSOC);

    // Count unread replies
    foreach ($messages_list as $msg) {
        $rr = $conn->query("SELECT COUNT(*) c FROM message_replies WHERE message_id={$msg['id']}");
        if ($rr && $rr->fetch_assoc()['c'] > 0 && $msg['status'] !== 'replied') $unread_replies++;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>My Profile - MEDIX</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<style>
* { font-family: 'Plus Jakarta Sans', sans-serif; }
body { background: #f1f5f9; min-height: 100vh; }

/* Navbar */
.top-nav {
    background: linear-gradient(135deg, #B91C1C, #7F1D1D);
    padding: .875rem 0;
    position: sticky; top: 0; z-index: 100;
    box-shadow: 0 2px 12px rgba(0,0,0,.2);
}
.top-nav a { color: rgba(255,255,255,.85); text-decoration: none; font-size: .875rem; font-weight: 500; transition: color .2s; }
.top-nav a:hover { color: white; }
.top-nav .brand { font-size: 1.25rem; font-weight: 800; color: white; letter-spacing: .5px; }

/* Hero banner */
.profile-hero {
    background: linear-gradient(135deg, #B91C1C 0%, #7F1D1D 60%, #450A0A 100%);
    padding: 3rem 0 5rem;
    position: relative;
    overflow: hidden;
}
.profile-hero::before {
    content: '';
    position: absolute; top: -50%; right: -10%;
    width: 500px; height: 500px;
    background: radial-gradient(circle, rgba(255,255,255,.06) 0%, transparent 70%);
    border-radius: 50%;
}
.avatar-circle {
    width: 90px; height: 90px;
    background: rgba(255,255,255,.2);
    border: 3px solid rgba(255,255,255,.5);
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    font-size: 2rem; font-weight: 800; color: white;
    margin: 0 auto 1rem;
    backdrop-filter: blur(4px);
}

/* Stats cards floating over hero */
.stats-row {
    margin-top: -3rem;
    position: relative; z-index: 10;
}
.stat-card {
    background: white;
    border-radius: 16px;
    padding: 1.25rem 1.5rem;
    box-shadow: 0 4px 20px rgba(0,0,0,.1);
    text-align: center;
    border-top: 3px solid #B91C1C;
    transition: transform .2s;
}
.stat-card:hover { transform: translateY(-3px); }
.stat-card .num { font-size: 1.75rem; font-weight: 800; color: #B91C1C; }
.stat-card .lbl { font-size: .8rem; color: #64748b; font-weight: 500; }

/* Cards */
.pcard {
    background: white;
    border-radius: 20px;
    box-shadow: 0 1px 4px rgba(0,0,0,.06);
    border: 1px solid #f1f5f9;
    overflow: hidden;
}
.pcard-header {
    padding: 1.25rem 1.5rem;
    border-bottom: 1px solid #f1f5f9;
    display: flex; align-items: center; gap: .75rem;
}
.pcard-header .icon {
    width: 36px; height: 36px;
    background: #fef2f2;
    border-radius: 10px;
    display: flex; align-items: center; justify-content: center;
    color: #B91C1C; font-size: 1rem;
}
.pcard-body { padding: 1.5rem; }

/* Form */
.form-label { font-size: .8rem; font-weight: 700; color: #374151; text-transform: uppercase; letter-spacing: .5px; }
.form-control {
    border: 1.5px solid #e2e8f0;
    border-radius: 10px;
    padding: .65rem .875rem;
    font-size: .9rem;
    transition: border-color .2s, box-shadow .2s;
}
.form-control:focus { border-color: #B91C1C; box-shadow: 0 0 0 3px rgba(185,28,28,.1); }
.form-control:disabled { background: #f8fafc; }

/* Buttons */
.btn-red {
    background: linear-gradient(135deg, #B91C1C, #DC2626);
    color: white; border: none;
    border-radius: 10px; padding: .65rem 1.5rem;
    font-weight: 700; font-size: .875rem;
    transition: all .2s;
}
.btn-red:hover { background: linear-gradient(135deg,#991B1B,#B91C1C); transform: translateY(-1px); box-shadow: 0 6px 18px rgba(185,28,28,.35); color: white; }
.btn-outline-red {
    background: white; color: #B91C1C;
    border: 1.5px solid #B91C1C;
    border-radius: 10px; padding: .65rem 1.5rem;
    font-weight: 700; font-size: .875rem;
    transition: all .2s;
}
.btn-outline-red:hover { background: #B91C1C; color: white; }

/* Order table */
.order-row { transition: background .15s; }
.order-row:hover { background: #fafafa; }
.status-pill {
    padding: .25rem .75rem; border-radius: 20px;
    font-size: .72rem; font-weight: 700; display: inline-block;
}
.sp-pending    { background: #FEF3C7; color: #92400E; }
.sp-processing { background: #D1FAE5; color: #065F46; }
.sp-delivered  { background: #DBEAFE; color: #1E40AF; }
.sp-cancelled  { background: #FEE2E2; color: #991B1B; }

/* Tab nav */
.tab-nav { display: flex; gap: .5rem; margin-bottom: 1.5rem; }
.tab-btn {
    padding: .5rem 1.25rem; border-radius: 20px;
    font-size: .85rem; font-weight: 600;
    border: 1.5px solid #e2e8f0; background: white; color: #64748b;
    cursor: pointer; transition: all .2s;
}
.tab-btn.active { background: #B91C1C; color: white; border-color: #B91C1C; }
.tab-pane { display: none; }
.tab-pane.active { display: block; }
</style>
</head>
<body>

<!-- Navbar -->
<nav class="top-nav">
    <div class="container d-flex justify-content-between align-items-center">
        <a href="../index.php" class="brand"><i class="bi bi-heart-pulse-fill me-2"></i>MEDIX</a>
        <div class="d-flex align-items-center gap-3">
            <a href="../products.php"><i class="bi bi-shop me-1"></i>Products</a>
            <a href="../cart.php"><i class="bi bi-cart3 me-1"></i>Cart</a>
            <div class="dropdown">
                <button class="btn btn-sm btn-outline-light dropdown-toggle" data-bs-toggle="dropdown" style="border-radius:20px;font-weight:600">
                    <i class="bi bi-person-circle me-1"></i><?= htmlspecialchars(explode(' ', $display_name)[0]) ?>
                </button>
                <ul class="dropdown-menu dropdown-menu-end shadow-lg" style="border-radius:14px;border:none;min-width:200px">
                    <li class="px-3 py-2">
                        <div class="fw-bold" style="font-size:.9rem"><?= htmlspecialchars($display_name) ?></div>
                        <div class="text-muted" style="font-size:.75rem"><?= htmlspecialchars($user['email'] ?? '') ?></div>
                    </li>
                    <li><hr class="dropdown-divider my-1"></li>
                    <li><a class="dropdown-item py-2" href="profile.php"><i class="bi bi-person me-2 text-danger"></i>My Profile</a></li>
                    <li><a class="dropdown-item py-2 text-danger" href="logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
                </ul>
            </div>
        </div>
    </div>
</nav>

<!-- Hero -->
<div class="profile-hero text-center text-white">
    <div class="avatar-circle"><?= $initials ?></div>
    <h2 class="fw-bold mb-1"><?= htmlspecialchars($display_name) ?></h2>
    <p style="opacity:.75;font-size:.9rem;margin:0"><?= htmlspecialchars($user['email'] ?? '') ?></p>
    <?php if (!empty($user['phone'])): ?>
    <p style="opacity:.6;font-size:.8rem;margin:.25rem 0 0"><i class="bi bi-telephone me-1"></i><?= htmlspecialchars($user['phone']) ?></p>
    <?php endif; ?>
</div>

<!-- Stats floating cards -->
<div class="container stats-row">
    <div class="row g-3">
        <div class="col-6 col-md-3">
            <div class="stat-card">
                <div class="num"><?= count($order_list) ?></div>
                <div class="lbl">Total Orders</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="stat-card">
                <div class="num"><?= $delivered_count ?></div>
                <div class="lbl">Delivered</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="stat-card">
                <div class="num" style="font-size:1.25rem">PKR <?= number_format($total_spent, 0) ?></div>
                <div class="lbl">Total Spent</div>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="stat-card">
                <div class="num"><?= count(array_filter($order_list, fn($o) => $o['status'] === 'pending')) ?></div>
                <div class="lbl">Pending Orders</div>
            </div>
        </div>
    </div>
</div>

<!-- Main Content -->
<div class="container py-4">
    <?php if ($success): ?>
    <div class="alert alert-success alert-dismissible fade show mb-4" style="border-radius:12px;border-left:4px solid #22c55e">
        <i class="bi bi-check-circle-fill me-2"></i><?= htmlspecialchars($success) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>
    <?php if ($error): ?>
    <div class="alert alert-danger alert-dismissible fade show mb-4" style="border-radius:12px;border-left:4px solid #ef4444">
        <i class="bi bi-exclamation-triangle-fill me-2"></i><?= htmlspecialchars($error) ?>
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
    <?php endif; ?>

    <!-- Tab Navigation -->
    <div class="tab-nav">
        <button class="tab-btn active" onclick="switchTab('orders', this)"><i class="bi bi-bag-check me-1"></i>My Orders</button>
        <button class="tab-btn" onclick="switchTab('messages', this)">
            <i class="bi bi-chat-dots me-1"></i>Messages
            <?php if ($unread_replies > 0): ?><span style="background:#B91C1C;color:white;border-radius:10px;padding:1px 7px;font-size:.7rem;margin-left:4px"><?= $unread_replies ?></span><?php endif; ?>
        </button>
        <button class="tab-btn" onclick="switchTab('profile', this)"><i class="bi bi-person me-1"></i>Edit Profile</button>
        <button class="tab-btn" onclick="switchTab('security', this)"><i class="bi bi-shield-lock me-1"></i>Security</button>
    </div>

    <!-- Orders Tab -->
    <div id="tab-orders" class="tab-pane active">
        <div class="pcard">
            <div class="pcard-header">
                <div class="icon"><i class="bi bi-bag-check-fill"></i></div>
                <div>
                    <div class="fw-bold">Order History</div>
                    <div class="text-muted" style="font-size:.8rem"><?= count($order_list) ?> orders placed</div>
                </div>
            </div>
            <?php if (empty($order_list)): ?>
            <div class="pcard-body text-center py-5">
                <i class="bi bi-bag-x" style="font-size:4rem;color:#e2e8f0;display:block;margin-bottom:1rem"></i>
                <h5 class="text-muted">No orders yet</h5>
                <p class="text-muted small">Start shopping to see your orders here</p>
                <a href="../products.php" class="btn-red px-4 py-2 text-decoration-none d-inline-block mt-2">
                    <i class="bi bi-shop me-2"></i>Browse Products
                </a>
            </div>
            <?php else: ?>
            <div class="table-responsive">
            <table class="table mb-0">
            <thead style="background:#f8fafc">
                <tr>
                    <th style="padding:.875rem 1.5rem;font-size:.72rem;color:#64748b;text-transform:uppercase;font-weight:700">Order</th>
                    <th style="font-size:.72rem;color:#64748b;text-transform:uppercase;font-weight:700">Amount</th>
                    <th style="font-size:.72rem;color:#64748b;text-transform:uppercase;font-weight:700">Payment</th>
                    <th style="font-size:.72rem;color:#64748b;text-transform:uppercase;font-weight:700">Status</th>
                    <th style="font-size:.72rem;color:#64748b;text-transform:uppercase;font-weight:700">Date</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($order_list as $o):
                $st = $o['status'];
                $sc = ['pending'=>'sp-pending','processing'=>'sp-processing','delivered'=>'sp-delivered','cancelled'=>'sp-cancelled'][$st] ?? 'sp-pending';
                $sl = ['pending'=>'Pending','processing'=>'Confirmed','delivered'=>'Delivered','cancelled'=>'Cancelled'][$st] ?? ucfirst($st);
            ?>
            <tr class="order-row">
                <td style="padding:.875rem 1.5rem">
                    <div class="fw-bold text-danger">#<?= str_pad($o['id'],4,'0',STR_PAD_LEFT) ?></div>
                </td>
                <td class="fw-bold">PKR <?= number_format($o['total_amount'], 0) ?></td>
                <td class="text-muted" style="font-size:.85rem"><?= htmlspecialchars($o['payment_method'] ?? 'COD') ?></td>
                <td><span class="status-pill <?= $sc ?>"><?= $sl ?></span></td>
                <td class="text-muted" style="font-size:.85rem"><?= date('M d, Y', strtotime($o['created_at'])) ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
            </table>
            </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Messages Tab -->
    <div id="tab-messages" class="tab-pane">
        <!-- Send new message form -->
        <div class="pcard mb-4">
            <div class="pcard-header">
                <div class="icon"><i class="bi bi-pencil-fill"></i></div>
                <div>
                    <div class="fw-bold">Send a Message</div>
                    <div class="text-muted" style="font-size:.8rem">Ask us anything — we reply within 24 hours</div>
                </div>
            </div>
            <div class="pcard-body">
                <div id="msgResult" style="display:none" class="mb-3"></div>
                <?php
                $name_parts = explode(' ', $display_name, 2);
                $first = $name_parts[0];
                $last  = $name_parts[1] ?? '';
                ?>
                <input type="hidden" id="senderFirst" value="<?= htmlspecialchars($first) ?>">
                <input type="hidden" id="senderLast"  value="<?= htmlspecialchars($last) ?>">
                <input type="hidden" id="senderEmail" value="<?= htmlspecialchars($user_email) ?>">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Subject</label>
                        <select id="msgSubject" class="form-control">
                            <option value="General Inquiry">General Inquiry</option>
                            <option value="Order Issue">Order Issue</option>
                            <option value="Product Question">Product Question</option>
                            <option value="Payment Issue">Payment Issue</option>
                            <option value="Complaint">Complaint</option>
                            <option value="Other">Other</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Phone (optional)</label>
                        <input type="text" id="msgPhone" class="form-control" value="<?= htmlspecialchars($user['phone'] ?? '') ?>" placeholder="+92-300-1234567">
                    </div>
                    <div class="col-12">
                        <label class="form-label">Your Message</label>
                        <textarea id="msgBody" class="form-control" rows="3" placeholder="Type your message here..." required></textarea>
                    </div>
                    <div class="col-12">
                        <label class="form-label">Attach Screenshot / Image (optional)</label>
                        <div id="dropZone" onclick="document.getElementById('msgFile').click()"
                             style="border:2px dashed #e2e8f0;border-radius:10px;padding:1rem;text-align:center;cursor:pointer;background:#fafafa;transition:all .2s"
                             onmouseenter="this.style.borderColor='#B91C1C';this.style.background='#fef2f2'"
                             onmouseleave="this.style.borderColor='#e2e8f0';this.style.background='#fafafa'">
                            <i class="bi bi-cloud-upload" style="font-size:1.5rem;color:#94a3b8"></i>
                            <p class="mb-0 mt-1 small text-muted">Click to attach image or PDF (max 5MB)</p>
                            <input type="file" id="msgFile" accept="image/*,.pdf" style="display:none" onchange="previewFile(this)">
                        </div>
                        <div id="filePreview" style="display:none;margin-top:.75rem"></div>
                    </div>
                </div>
                <div class="mt-3 d-flex gap-2 align-items-center">
                    <button onclick="sendMessage()" class="btn-red px-4" id="sendMsgBtn">
                        <i class="bi bi-send-fill me-2"></i>Send Message
                    </button>
                    <span id="uploadProgress" style="display:none;font-size:.8rem;color:#64748b">
                        <span class="spinner-border spinner-border-sm me-1"></span>Uploading...
                    </span>
                </div>
            </div>
        </div>
        <!-- Conversation history -->
        <div class="pcard">
            <div class="pcard-header">
                <div class="icon"><i class="bi bi-chat-dots-fill"></i></div>
                <div>
                    <div class="fw-bold">Conversation History</div>
                    <div class="text-muted" style="font-size:.8rem"><?= count($messages_list) ?> message<?= count($messages_list) != 1 ? 's' : '' ?></div>
                </div>
            </div>
            <div class="pcard-body" style="padding:0">
                <?php if (empty($messages_list)): ?>
                <div class="text-center py-5 text-muted">
                    <i class="bi bi-chat-square-dots" style="font-size:3.5rem;color:#e2e8f0;display:block;margin-bottom:1rem"></i>
                    <h6>No messages yet</h6>
                    <p class="small">Use the form above to send your first message</p>
                </div>
                <?php else: ?>
                <div style="max-height:600px;overflow-y:auto">
                <?php foreach ($messages_list as $msg):
                    // Get replies for this message
                    $mid = $msg['id'];
                    $replies_r = $conn->query("SELECT * FROM message_replies WHERE message_id=$mid ORDER BY sent_at ASC");
                    $replies = $replies_r ? $replies_r->fetch_all(MYSQLI_ASSOC) : [];
                    $has_reply = count($replies) > 0;
                ?>
                <div style="border-bottom:1px solid #f1f5f9;padding:1.5rem">
                    <!-- Thread header -->
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <div>
                            <span class="fw-bold" style="font-size:.9rem"><?= htmlspecialchars(ucfirst($msg['subject'] ?? 'General')) ?></span>
                            <span style="background:<?= $has_reply ? '#D1FAE5' : '#FEF3C7' ?>;color:<?= $has_reply ? '#065F46' : '#92400E' ?>;padding:2px 10px;border-radius:20px;font-size:.7rem;font-weight:700;margin-left:.5rem">
                                <?= $has_reply ? 'Replied' : 'Pending' ?>
                            </span>
                        </div>
                        <span class="text-muted" style="font-size:.75rem"><?= date('M d, Y', strtotime($msg['created_at'])) ?></span>
                    </div>

                    <!-- User's original message (right side) -->
                    <div class="d-flex justify-content-end mb-3">
                        <div style="max-width:80%">
                            <div style="background:linear-gradient(135deg,#B91C1C,#DC2626);color:white;border-radius:16px 16px 4px 16px;padding:1rem 1.25rem;font-size:.875rem;line-height:1.6">
                                <?= nl2br(htmlspecialchars($msg['message'])) ?>
                                <?php if (!empty($msg['attachment'])): ?>
                                <div class="mt-2">
                                    <?php $att = $msg['attachment']; $is_img = preg_match('/\.(jpg|jpeg|png|gif|webp)$/i', $att); ?>
                                    <?php if ($is_img): ?>
                                    <img src="/ppp/<?= htmlspecialchars($att) ?>" alt="Attachment"
                                         style="max-width:220px;max-height:180px;border-radius:8px;border:2px solid rgba(255,255,255,.3);cursor:pointer;display:block;margin-top:.5rem"
                                         onclick="window.open('/ppp/<?= htmlspecialchars($att) ?>','_blank')">
                                    <small style="opacity:.75;font-size:.7rem"><i class="bi bi-zoom-in me-1"></i>Click to enlarge</small>
                                    <?php else: ?>
                                    <a href="/ppp/<?= htmlspecialchars($att) ?>" target="_blank"
                                       style="color:rgba(255,255,255,.9);font-size:.8rem;display:inline-flex;align-items:center;gap:.4rem;background:rgba(255,255,255,.15);padding:.3rem .75rem;border-radius:20px;text-decoration:none;margin-top:.5rem">
                                        <i class="bi bi-file-earmark-pdf"></i> View Attachment
                                    </a>
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>
                            </div>
                            <div class="text-end mt-1" style="font-size:.72rem;color:#94a3b8">
                                <i class="bi bi-person-fill me-1"></i>You &nbsp;·&nbsp; <?= date('h:i A', strtotime($msg['created_at'])) ?>
                            </div>
                        </div>
                    </div>

                    <!-- Admin replies (left side) -->
                    <?php if ($has_reply): ?>
                    <?php foreach ($replies as $reply): ?>
                    <div class="d-flex justify-content-start mb-3">
                        <div style="max-width:80%">
                            <div style="display:flex;align-items:center;gap:.5rem;margin-bottom:.4rem">
                                <div style="width:28px;height:28px;background:linear-gradient(135deg,#B91C1C,#7F1D1D);border-radius:50%;display:flex;align-items:center;justify-content:center;color:white;font-size:.7rem;font-weight:700">M</div>
                                <span style="font-size:.75rem;font-weight:700;color:#374151">MEDIX Support</span>
                            </div>
                            <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:4px 16px 16px 16px;padding:1rem 1.25rem;font-size:.875rem;line-height:1.6;color:#374151">
                                <?= nl2br(htmlspecialchars($reply['reply_message'])) ?>
                            </div>
                            <div class="mt-1" style="font-size:.72rem;color:#94a3b8">
                                <i class="bi bi-shield-check me-1"></i>Admin &nbsp;·&nbsp; <?= date('M d, h:i A', strtotime($reply['sent_at'])) ?>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                    <?php else: ?>
                    <div style="text-align:center;padding:.75rem;background:#fffbeb;border-radius:10px;font-size:.8rem;color:#92400e">
                        <i class="bi bi-clock me-1"></i>Waiting for admin reply...
                    </div>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Profile Tab -->
    <div id="tab-profile" class="tab-pane">
        <div class="pcard">
            <div class="pcard-header">
                <div class="icon"><i class="bi bi-person-fill"></i></div>
                <div>
                    <div class="fw-bold">Personal Information</div>
                    <div class="text-muted" style="font-size:.8rem">Update your name and phone number</div>
                </div>
            </div>
            <div class="pcard-body">
                <form method="POST">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">Full Name</label>
                            <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($display_name) ?>" required>
                        </div>
                        <div class="col-md-6">
                            <label class="form-label">Phone Number</label>
                            <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($user['phone'] ?? '') ?>" placeholder="+92-300-1234567">
                        </div>
                        <div class="col-12">
                            <label class="form-label">Email Address</label>
                            <input type="email" class="form-control" value="<?= htmlspecialchars($user['email'] ?? '') ?>" disabled>
                            <small class="text-muted">Email address cannot be changed</small>
                        </div>
                    </div>
                    <div class="mt-4">
                        <button type="submit" name="update_profile" class="btn-red px-4">
                            <i class="bi bi-save me-2"></i>Save Changes
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Security Tab -->
    <div id="tab-security" class="tab-pane">
        <div class="pcard">
            <div class="pcard-header">
                <div class="icon"><i class="bi bi-shield-lock-fill"></i></div>
                <div>
                    <div class="fw-bold">Change Password</div>
                    <div class="text-muted" style="font-size:.8rem">Keep your account secure</div>
                </div>
            </div>
            <div class="pcard-body">
                <form method="POST">
                    <div class="row g-3" style="max-width:480px">
                        <div class="col-12">
                            <label class="form-label">Current Password</label>
                            <input type="password" name="current_password" class="form-control" required>
                        </div>
                        <div class="col-12">
                            <label class="form-label">New Password</label>
                            <input type="password" name="new_password" class="form-control" minlength="6" required>
                            <small class="text-muted">Minimum 6 characters</small>
                        </div>
                        <div class="col-12">
                            <label class="form-label">Confirm New Password</label>
                            <input type="password" name="confirm_password" class="form-control" required>
                        </div>
                    </div>
                    <div class="mt-4 d-flex gap-2">
                        <button type="submit" name="change_password" class="btn-red px-4">
                            <i class="bi bi-key me-2"></i>Update Password
                        </button>
                        <a href="logout.php" class="btn-outline-red px-4 text-decoration-none">
                            <i class="bi bi-box-arrow-right me-2"></i>Logout
                        </a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function switchTab(name, btn) {
    document.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.getElementById('tab-' + name).classList.add('active');
    btn.classList.add('active');
}

function previewFile(input) {
    const file = input.files[0];
    const preview = document.getElementById('filePreview');
    const dz = document.getElementById('dropZone');
    if (!file) { preview.style.display='none'; return; }

    const isImg = file.type.startsWith('image/');
    preview.style.display = 'block';
    if (isImg) {
        const reader = new FileReader();
        reader.onload = e => {
            preview.innerHTML = `<div style="position:relative;display:inline-block">
                <img src="${e.target.result}" style="max-height:120px;max-width:200px;border-radius:8px;border:2px solid #e2e8f0">
                <button onclick="clearFile()" style="position:absolute;top:-8px;right:-8px;background:#ef4444;color:white;border:none;border-radius:50%;width:22px;height:22px;font-size:.7rem;cursor:pointer;display:flex;align-items:center;justify-content:center">✕</button>
                <div style="font-size:.75rem;color:#64748b;margin-top:.25rem">${file.name}</div>
            </div>`;
        };
        reader.readAsDataURL(file);
    } else {
        preview.innerHTML = `<div style="display:inline-flex;align-items:center;gap:.5rem;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:.5rem .875rem;font-size:.8rem">
            <i class="bi bi-file-earmark-pdf text-danger"></i>${file.name}
            <button onclick="clearFile()" style="background:none;border:none;color:#ef4444;cursor:pointer;font-size:.8rem">✕</button>
        </div>`;
    }
    dz.innerHTML = `<i class="bi bi-check-circle-fill" style="color:#22c55e;font-size:1.25rem"></i><p class="mb-0 mt-1 small" style="color:#166534">File selected: ${file.name}</p>`;
}

function clearFile() {
    const fi = document.getElementById('msgFile');
    if (fi) fi.value = '';
    document.getElementById('filePreview').style.display = 'none';
    const dz = document.getElementById('dropZone');
    if (dz) {
        dz.innerHTML = '<i class="bi bi-cloud-upload" style="font-size:1.5rem;color:#94a3b8"></i><p class="mb-0 mt-1 small text-muted">Click to attach image or PDF (max 5MB)</p>';
        dz.style.borderColor = '#e2e8f0';
        dz.style.background  = '#fafafa';
    }
}

function sendMessage() {
    const subject = document.getElementById('msgSubject').value;
    const phone   = document.getElementById('msgPhone').value;
    const body    = document.getElementById('msgBody').value.trim();
    const result  = document.getElementById('msgResult');
    const btn     = document.getElementById('sendMsgBtn');
    const fileInput = document.getElementById('msgFile');

    if (!body) {
        result.style.display = 'block';
        result.innerHTML = '<div style="background:#fef2f2;border-left:3px solid #ef4444;border-radius:8px;padding:.75rem 1rem;color:#991b1b"><i class="bi bi-exclamation-triangle me-2"></i>Please write a message.</div>';
        return;
    }

    btn.disabled = true;
    btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Sending...';
    result.style.display = 'none';

    const fd = new FormData();
    fd.append('firstName', document.getElementById('senderFirst').value);
    fd.append('lastName',  document.getElementById('senderLast').value);
    fd.append('email',     document.getElementById('senderEmail').value);
    fd.append('phone',     phone);
    fd.append('subject',   subject);
    fd.append('message',   body);
    if (fileInput && fileInput.files[0]) fd.append('attachment', fileInput.files[0]);

    fetch('../api/submit_contact.php', { method: 'POST', body: fd })
        .then(r => {
            if (!r.ok) throw new Error('HTTP ' + r.status);
            return r.json();
        })
        .then(data => {
            result.style.display = 'block';
            if (data.success) {
                result.innerHTML = '<div style="background:#f0fdf4;border-left:3px solid #22c55e;border-radius:8px;padding:.75rem 1rem;color:#166534"><i class="bi bi-check-circle-fill me-2"></i>' + data.message + ' Ref: <strong>' + data.reference + '</strong></div>';
                document.getElementById('msgBody').value = '';
                clearFile();
                setTimeout(() => location.reload(), 1800);
            } else {
                result.innerHTML = '<div style="background:#fef2f2;border-left:3px solid #ef4444;border-radius:8px;padding:.75rem 1rem;color:#991b1b"><i class="bi bi-exclamation-triangle me-2"></i>' + data.message + '</div>';
                btn.disabled = false;
                btn.innerHTML = '<i class="bi bi-send-fill me-2"></i>Send Message';
            }
        })
        .catch(() => {
            result.innerHTML = '<div style="background:#fef2f2;border-left:3px solid #ef4444;border-radius:8px;padding:.75rem 1rem;color:#991b1b"><i class="bi bi-exclamation-triangle me-2"></i>Connection error. Please try again.</div>';
            btn.disabled = false;
            btn.innerHTML = '<i class="bi bi-send-fill me-2"></i>Send Message';
        });
}
setTimeout(function(){
    document.querySelectorAll('.alert').forEach(function(a){ bootstrap.Alert.getOrCreateInstance(a)?.close(); });
}, 4000);

// Auto-open correct tab if there was a form submission
<?php if ($success || $error): ?>
<?php if (isset($_POST['change_password'])): ?>
switchTab('security', document.querySelectorAll('.tab-btn')[3]);
<?php elseif (isset($_POST['update_profile'])): ?>
switchTab('profile', document.querySelectorAll('.tab-btn')[2]);
<?php endif; ?>
<?php elseif (isset($_GET['tab'])): ?>
const tabMap = {orders:0, messages:1, profile:2, security:3};
const t = '<?= htmlspecialchars($_GET['tab'] ?? '') ?>';
if (tabMap[t] !== undefined) switchTab(t, document.querySelectorAll('.tab-btn')[tabMap[t]]);
<?php endif; ?>
</script>
</body>
</html>
