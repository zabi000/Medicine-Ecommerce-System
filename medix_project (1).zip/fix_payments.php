<?php
require_once('api/config.php');
if (!$conn) die("DB failed");

$conn->query("CREATE TABLE IF NOT EXISTS site_settings (`key` VARCHAR(100) PRIMARY KEY, `value` TEXT) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Enable all payment methods
$payments = ['pay_cod'=>'1','pay_jazzcash'=>'1','pay_easypaisa'=>'1','pay_bank'=>'1'];
foreach ($payments as $k => $v) {
    $conn->query("INSERT INTO site_settings (`key`,`value`) VALUES ('$k','$v') ON DUPLICATE KEY UPDATE `value`='$v'");
}

// Verify
$r = $conn->query("SELECT `key`,`value` FROM site_settings WHERE `key` LIKE 'pay_%'");
echo "<style>body{font-family:sans-serif;padding:2rem;background:#f8fafc}</style>";
echo "<h3 style='color:green'>✅ All payment methods enabled!</h3>";
echo "<table border=1 cellpadding=8 style='border-collapse:collapse'>";
echo "<tr><th>Setting</th><th>Value</th></tr>";
while ($row = $r->fetch_assoc()) {
    $status = $row['value'] === '1' ? '✅ Enabled' : '❌ Disabled';
    echo "<tr><td>{$row['key']}</td><td>$status</td></tr>";
}
echo "</table>";
echo "<br><a href='checkout.php' style='background:#B91C1C;color:white;padding:.5rem 1.5rem;border-radius:8px;text-decoration:none'>Go to Checkout</a>";
echo "&nbsp;<a href='admin/settings.php' style='background:#374151;color:white;padding:.5rem 1.5rem;border-radius:8px;text-decoration:none'>Admin Settings</a>";
?>
