<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) { header('Location: login.php'); exit(); }

$upload_dir = $_SERVER['DOCUMENT_ROOT'] . '/ppp/uploads/products/';
if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

$success = '';
$error   = '';

// Handle upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['images'])) {
    $files   = $_FILES['images'];
    $allowed = ['image/jpeg','image/jpg','image/png','image/gif','image/webp'];
    $uploaded = 0;
    $errors   = [];

    // Support multiple files
    $count = is_array($files['name']) ? count($files['name']) : 1;
    for ($i = 0; $i < $count; $i++) {
        $name = is_array($files['name']) ? $files['name'][$i] : $files['name'];
        $tmp  = is_array($files['tmp_name']) ? $files['tmp_name'][$i] : $files['tmp_name'];
        $type = is_array($files['type']) ? $files['type'][$i] : $files['type'];
        $size = is_array($files['size']) ? $files['size'][$i] : $files['size'];
        $err  = is_array($files['error']) ? $files['error'][$i] : $files['error'];

        if ($err !== UPLOAD_ERR_OK) continue;
        if (!in_array($type, $allowed)) { $errors[] = "$name: not an image"; continue; }
        if ($size > 5 * 1024 * 1024) { $errors[] = "$name: too large (max 5MB)"; continue; }

        $ext      = strtolower(pathinfo($name, PATHINFO_EXTENSION));
        $newname  = 'img_' . time() . '_' . $i . '_' . rand(100,999) . '.' . $ext;
        if (move_uploaded_file($tmp, $upload_dir . $newname)) {
            $uploaded++;
        } else {
            $errors[] = "$name: upload failed";
        }
    }

    if ($uploaded > 0) $success = "✅ $uploaded image(s) uploaded successfully!";
    if (!empty($errors)) $error = implode('<br>', $errors);
}

// Handle delete
if (isset($_GET['delete'])) {
    $file = basename($_GET['delete']);
    $path = $upload_dir . $file;
    if (file_exists($path) && is_file($path)) {
        unlink($path);
        $success = "Image deleted.";
    }
    header('Location: gallery.php');
    exit();
}

// Get all images
$images = [];
if (is_dir($upload_dir)) {
    foreach (glob($upload_dir . '*.{jpg,jpeg,png,gif,webp}', GLOB_BRACE) as $f) {
        $images[] = [
            'file' => basename($f),
            'url'  => 'uploads/products/' . basename($f),
            'size' => filesize($f),
            'time' => filemtime($f),
        ];
    }
    usort($images, fn($a,$b) => $b['time'] - $a['time']); // newest first
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Image Gallery - MEDIX Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{--sw:280px;--red:#B91C1C}
*{box-sizing:border-box}
body{font-family:'Inter',sans-serif;background:#F3F4F6;margin:0}
.sidebar{position:fixed;top:0;left:0;width:var(--sw);height:100vh;background:linear-gradient(180deg,#B91C1C,#7F1D1D);overflow-y:auto;z-index:1000}
.sb-brand{padding:1.5rem;border-bottom:1px solid rgba(255,255,255,.1);color:white}
.mi{display:flex;align-items:center;gap:.75rem;padding:.875rem 1.5rem;color:rgba(255,255,255,.8);text-decoration:none;border-left:3px solid transparent;transition:all .2s;font-weight:500}
.mi:hover,.mi.active{background:rgba(255,255,255,.15);color:white;border-left-color:white}
.mi i{width:20px}
.mdiv{height:1px;background:rgba(255,255,255,.1);margin:.5rem 1.5rem}
.main{margin-left:var(--sw);padding:2rem;min-height:100vh}
.topbar{background:white;border-bottom:3px solid var(--red);padding:1.25rem 2rem;margin:-2rem -2rem 2rem;display:flex;justify-content:space-between;align-items:center;box-shadow:0 2px 6px rgba(0,0,0,.08)}
.card{background:white;border-radius:16px;padding:1.5rem;box-shadow:0 1px 3px rgba(0,0,0,.08)}

/* Drop Zone */
.drop-zone{border:3px dashed #e2e8f0;border-radius:16px;padding:3rem 2rem;text-align:center;cursor:pointer;transition:all .3s;background:#fafafa}
.drop-zone:hover,.drop-zone.drag-over{border-color:var(--red);background:#fef2f2}
.drop-zone i{font-size:3rem;color:var(--red);display:block;margin-bottom:1rem}

/* Gallery Grid */
.gallery-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:1rem}
.img-card{background:white;border-radius:12px;overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.1);transition:all .2s;position:relative}
.img-card:hover{transform:translateY(-3px);box-shadow:0 8px 20px rgba(0,0,0,.15)}
.img-card img{width:100%;height:150px;object-fit:cover;display:block}
.img-card .img-info{padding:.75rem}
.img-card .img-name{font-size:.75rem;font-weight:600;color:#1e293b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.img-card .img-size{font-size:.65rem;color:#94a3b8}
.img-card .img-actions{display:flex;gap:.5rem;margin-top:.5rem}
.img-card .img-actions button,.img-card .img-actions a{flex:1;padding:.3rem;border-radius:6px;font-size:.72rem;font-weight:600;border:none;cursor:pointer;transition:all .2s;text-align:center;text-decoration:none}
.btn-copy{background:#dbeafe;color:#2563eb}
.btn-copy:hover{background:#2563eb;color:white}
.btn-del{background:#fee2e2;color:#B91C1C}
.btn-del:hover{background:#B91C1C;color:white}
.btn-use{background:#d1fae5;color:#059669}
.btn-use:hover{background:#059669;color:white}
.copied{background:#059669!important;color:white!important}
.img-overlay{position:absolute;top:.5rem;right:.5rem;display:flex;gap:.25rem}
.img-overlay .badge{font-size:.65rem;padding:.25rem .5rem}
</style>
</head>
<body>
<div class="sidebar">
    <div class="sb-brand"><h4 class="mb-0 fw-bold"><i class="bi bi-heart-pulse-fill me-2"></i>MEDIX</h4><small style="opacity:.6">Admin Portal</small></div>
    <a href="index.php" class="mi"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="products.php" class="mi"><i class="bi bi-box-seam"></i>Products</a>
    <a href="offers.php" class="mi"><i class="bi bi-tag-fill"></i>Offers</a>
    <a href="orders.php" class="mi"><i class="bi bi-cart-check"></i>Orders</a>
    <a href="customers.php" class="mi"><i class="bi bi-people"></i>Customers</a>
    <a href="categories.php" class="mi"><i class="bi bi-tags"></i>Categories</a>
    <a href="messages.php" class="mi"><i class="bi bi-envelope"></i>Messages</a>
    <a href="reports.php" class="mi"><i class="bi bi-graph-up"></i>Reports</a>
    <a href="settings.php" class="mi"><i class="bi bi-gear"></i>Settings</a>
    <div class="mdiv"></div>
    <a href="gallery.php" class="mi active"><i class="bi bi-images"></i>Image Gallery</a>
    <a href="database.php" class="mi"><i class="bi bi-database"></i>Database</a>
    <a href="import_medicines.php" class="mi" style="color:#10B981"><i class="bi bi-capsule-pill"></i>Import Medicines</a>
    <div class="mdiv"></div>
    <a href="logout.php" class="mi"><i class="bi bi-box-arrow-right"></i>Logout</a>
</div>

<div class="main">
    <div class="topbar">
        <div>
            <h4 class="mb-0 fw-bold"><i class="bi bi-images me-2 text-danger"></i>Image Gallery</h4>
            <small class="text-muted"><?= count($images) ?> images uploaded</small>
        </div>
        <div class="d-flex gap-2">
            <input type="text" id="searchImg" class="form-control form-control-sm" placeholder="Search images..." style="width:200px" oninput="filterImages(this.value)">
        </div>
    </div>

    <?php if ($success): ?>
    <div class="alert alert-success alert-dismissible fade show"><i class="bi bi-check-circle me-2"></i><?= $success ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endif; ?>
    <?php if ($error): ?>
    <div class="alert alert-warning alert-dismissible fade show"><i class="bi bi-exclamation-triangle me-2"></i><?= $error ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endif; ?>

    <!-- Upload Zone -->
    <div class="card mb-4">
        <h6 class="fw-bold mb-3"><i class="bi bi-cloud-upload me-2 text-danger"></i>Upload Images</h6>
        <form method="POST" enctype="multipart/form-data" id="uploadForm">
            <div class="drop-zone" id="dropZone" onclick="document.getElementById('fileInput').click()"
                 ondragover="event.preventDefault();this.classList.add('drag-over')"
                 ondragleave="this.classList.remove('drag-over')"
                 ondrop="handleDrop(event)">
                <i class="bi bi-cloud-upload-fill"></i>
                <h5 class="fw-bold mb-1">Click to browse or drag & drop</h5>
                <p class="text-muted mb-2">JPG, PNG, GIF, WEBP — Max 5MB each</p>
                <p class="text-muted small mb-0">You can select multiple images at once</p>
                <div id="uploadProgress" style="display:none" class="mt-3">
                    <div class="progress" style="height:8px">
                        <div class="progress-bar progress-bar-striped progress-bar-animated bg-danger" style="width:100%"></div>
                    </div>
                    <small class="text-muted mt-1 d-block">Uploading...</small>
                </div>
            </div>
            <input type="file" id="fileInput" name="images[]" accept="image/*" multiple style="display:none" onchange="submitUpload()">
        </form>
    </div>

    <!-- Gallery Grid -->
    <div class="card">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h6 class="fw-bold mb-0"><i class="bi bi-grid me-2 text-danger"></i>All Images <span class="badge bg-danger ms-1"><?= count($images) ?></span></h6>
            <small class="text-muted">Click "Copy URL" to use in products</small>
        </div>

        <?php if (empty($images)): ?>
        <div class="text-center py-5 text-muted">
            <i class="bi bi-images" style="font-size:4rem;display:block;margin-bottom:1rem"></i>
            <h5>No images yet</h5>
            <p>Upload images above to get started</p>
        </div>
        <?php else: ?>
        <div class="gallery-grid" id="galleryGrid">
            <?php foreach ($images as $img): ?>
            <div class="img-card" data-name="<?= strtolower($img['file']) ?>">
                <div class="img-overlay">
                    <span class="badge bg-dark"><?= strtoupper(pathinfo($img['file'], PATHINFO_EXTENSION)) ?></span>
                </div>
                <img src="/ppp/<?= htmlspecialchars($img['url']) ?>"
                     alt="<?= htmlspecialchars($img['file']) ?>"
                     loading="lazy"
                     onerror="this.src='https://placehold.co/180x150/f1f5f9/94a3b8?text=Image'">
                <div class="img-info">
                    <div class="img-name" title="<?= htmlspecialchars($img['file']) ?>"><?= htmlspecialchars($img['file']) ?></div>
                    <div class="img-size"><?= round($img['size']/1024, 1) ?> KB &bull; <?= date('M d, Y', $img['time']) ?></div>
                    <div class="img-actions">
                        <button class="btn-copy" onclick="copyUrl('<?= htmlspecialchars($img['url']) ?>', this)" title="Copy URL">
                            <i class="bi bi-clipboard me-1"></i>Copy URL
                        </button>
                        <a href="?delete=<?= urlencode($img['file']) ?>" class="btn-del"
                           onclick="return confirm('Delete this image?')" title="Delete">
                            <i class="bi bi-trash"></i>
                        </a>
                    </div>
                    <button class="btn-use w-100 mt-1" onclick="useInProduct('<?= htmlspecialchars($img['url']) ?>')" style="background:#f3e8ff;color:#9333ea;border:none;border-radius:6px;padding:.3rem;font-size:.72rem;font-weight:600;cursor:pointer;transition:all .2s">
                        <i class="bi bi-box-seam me-1"></i>Use in Product
                    </button>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Preview Modal -->
<div class="modal fade" id="previewModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="previewTitle">Image Preview</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body text-center">
                <img id="previewImg" src="" style="max-width:100%;border-radius:8px">
                <div class="mt-3">
                    <code id="previewUrl" class="d-block p-2 bg-light rounded small"></code>
                    <button class="btn btn-danger btn-sm mt-2" onclick="copyUrl(document.getElementById('previewUrl').textContent, this)">
                        <i class="bi bi-clipboard me-1"></i>Copy URL
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function submitUpload() {
    document.getElementById('uploadProgress').style.display = 'block';
    document.getElementById('uploadForm').submit();
}

function handleDrop(e) {
    e.preventDefault();
    document.getElementById('dropZone').classList.remove('drag-over');
    const dt = new DataTransfer();
    Array.from(e.dataTransfer.files).forEach(f => dt.items.add(f));
    document.getElementById('fileInput').files = dt.files;
    submitUpload();
}

function copyUrl(url, btn) {
    navigator.clipboard.writeText(url).then(() => {
        const orig = btn.innerHTML;
        btn.innerHTML = '<i class="bi bi-check me-1"></i>Copied!';
        btn.classList.add('copied');
        setTimeout(() => { btn.innerHTML = orig; btn.classList.remove('copied'); }, 2000);
    }).catch(() => {
        // Fallback
        const ta = document.createElement('textarea');
        ta.value = url;
        document.body.appendChild(ta);
        ta.select();
        document.execCommand('copy');
        document.body.removeChild(ta);
        btn.innerHTML = '<i class="bi bi-check me-1"></i>Copied!';
        setTimeout(() => btn.innerHTML = '<i class="bi bi-clipboard me-1"></i>Copy URL', 2000);
    });
}

function useInProduct(url) {
    // Open products page with the URL pre-filled
    window.open('products.php?prefill_image=' + encodeURIComponent(url), '_blank');
}

function filterImages(q) {
    q = q.toLowerCase();
    document.querySelectorAll('.img-card').forEach(card => {
        card.style.display = card.dataset.name.includes(q) ? '' : 'none';
    });
}

// Auto-dismiss alerts
setTimeout(() => {
    document.querySelectorAll('.alert').forEach(a => bootstrap.Alert.getOrCreateInstance(a)?.close());
}, 4000);
</script>
</body>
</html>
