// Enhanced image handling for products
function handleProductImage(img, product) {
    // Try database image first
    if (product.image_url) {
        img.src = product.image_url;
        img.onerror = function() {
            // If database image fails, try local image
            this.onerror = function() {
                // If local image fails, show icon placeholder
                this.style.display = 'none';
                this.parentElement.innerHTML = `<div class='product-img-placeholder'>${product.icon || '💊'}</div>`;
            };
            this.src = `images/products/product-${product.id}.jpg`;
        };
    } else {
        // No database image, try local image
        img.src = `images/products/product-${product.id}.jpg`;
        img.onerror = function() {
            // If local image fails, show icon placeholder
            this.style.display = 'none';
            this.parentElement.innerHTML = `<div class='product-img-placeholder'>${product.icon || '💊'}</div>`;
        };
    }
}

// Add CSS for placeholder
const style = document.createElement('style');
style.textContent = `
.product-img-placeholder {
    width: 100%;
    height: 250px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 5rem;
    background: linear-gradient(135deg, #F9FAFB, #E5E7EB);
    border-radius: 8px;
    color: #B91C1C;
}
`;
document.head.appendChild(style);