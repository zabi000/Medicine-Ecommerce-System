<?php
require_once('api/config.php');
echo "<h3>Offers Debug</h3>";
if (!$conn) { echo "DB FAILED"; exit; }

echo "<b>Today's date:</b> " . date('Y-m-d') . "<br><br>";

// Check if table exists
$t = $conn->query("SHOW TABLES LIKE 'offers'");
if (!$t || $t->num_rows == 0) {
    echo "<p style='color:red'>offers table does NOT exist!</p>";
    // Create it
    $conn->query("CREATE TABLE IF NOT EXISTS offers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        product_id INT NOT NULL,
        discount_percent DECIMAL(5,2) NOT NULL,
        offer_label VARCHAR(100) DEFAULT 'SALE',
        start_date DATE NOT NULL,
        end_date DATE NOT NULL,
        is_active TINYINT(1) DEFAULT 1,
        show_on_homepage TINYINT(1) DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    echo "<p style='color:green'>Created offers table. Go add an offer in admin.</p>";
} else {
    echo "<p style='color:green'>offers table exists</p>";
}

// Show all offers
$all = $conn->query("SELECT o.*, p.name AS pname FROM offers o LEFT JOIN products p ON o.product_id=p.id");
if ($all && $all->num_rows > 0) {
    echo "<h4>All offers in DB:</h4><table border=1 cellpadding=6>";
    echo "<tr><th>ID</th><th>Product</th><th>Disc%</th><th>Label</th><th>Start</th><th>End</th><th>Active</th><th>Homepage</th><th>Live?</th></tr>";
    while ($r = $all->fetch_assoc()) {
        $live = ($r['is_active'] && date('Y-m-d') >= $r['start_date'] && date('Y-m-d') <= $r['end_date']) ? '✅ LIVE' : '❌';
        echo "<tr>
            <td>{$r['id']}</td>
            <td>{$r['pname']}</td>
            <td>{$r['discount_percent']}%</td>
            <td>{$r['offer_label']}</td>
            <td>{$r['start_date']}</td>
            <td>{$r['end_date']}</td>
            <td>{$r['is_active']}</td>
            <td>{$r['show_on_homepage']}</td>
            <td>$live</td>
        </tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color:orange'>No offers in database yet. <a href='admin/offers.php'>Create one here</a></p>";
}

// Test the API query
echo "<h4>API Query Result:</h4>";
$q = $conn->query("
    SELECT o.id, o.discount_percent, o.offer_label,
           p.id AS product_id, p.name, p.price AS original_price
    FROM offers o
    JOIN products p ON o.product_id = p.id
    WHERE o.is_active = 1
      AND CURDATE() BETWEEN o.start_date AND o.end_date
      AND o.show_on_homepage = 1
      AND p.stock_quantity > 0
    ORDER BY o.discount_percent DESC
    LIMIT 8
");
if ($q && $q->num_rows > 0) {
    echo "<p style='color:green'>API returns {$q->num_rows} offer(s)!</p>";
    echo "<p><strong>Homepage will show the Special Offers section.</strong></p>";
    echo "<p>Visit: <a href='index.php'>index.php</a></p>";
} else {
    echo "<p style='color:red'>API returns 0 offers. Possible reasons:</p><ul>";
    echo "<li>Offer is not active (is_active = 0)</li>";
    echo "<li>Today's date is outside start_date – end_date range</li>";
    echo "<li>show_on_homepage = 0</li>";
    echo "<li>Product is out of stock</li></ul>";
}
?>
