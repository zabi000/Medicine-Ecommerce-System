-- Complete Database Setup with Sample Data
-- Import this file to get a fully working system

-- Create database
CREATE DATABASE IF NOT EXISTS medicare_db;
USE medicare_db;

-- Drop existing tables to avoid conflicts
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS users;

-- Users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20) NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Products table
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    category VARCHAR(50) NOT NULL,
    icon VARCHAR(10) DEFAULT '💊',
    stock INT DEFAULT 0,
    stock_quantity INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Orders table
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    status VARCHAR(50) DEFAULT 'pending',
    shipping_address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Order items table
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Categories table
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================
-- INSERT SAMPLE CUSTOMERS
-- ============================================
INSERT INTO users (name, email, phone, password, created_at) VALUES
('Ahmed Khan', 'ahmed.khan@email.com', '+92-300-1234567', '$2y$10$abcdefghijklmnopqrstuv', '2024-01-15 10:30:00'),
('Fatima Ali', 'fatima.ali@email.com', '+92-321-9876543', '$2y$10$abcdefghijklmnopqrstuv', '2024-02-20 14:20:00'),
('Hassan Raza', 'hassan.raza@email.com', '+92-333-5551234', '$2y$10$abcdefghijklmnopqrstuv', '2023-12-10 09:15:00'),
('Ayesha Malik', 'ayesha.malik@email.com', '+92-345-7778888', '$2y$10$abcdefghijklmnopqrstuv', '2024-03-05 16:45:00'),
('Usman Sheikh', 'usman.sheikh@email.com', '+92-301-4445566', '$2y$10$abcdefghijklmnopqrstuv', '2023-11-22 11:00:00'),
('Zainab Hussain', 'zainab.hussain@email.com', '+92-322-9998877', '$2y$10$abcdefghijklmnopqrstuv', '2024-04-12 13:30:00'),
('Ali Haider', 'ali.haider@email.com', '+92-334-6667788', '$2y$10$abcdefghijklmnopqrstuv', '2024-01-28 08:20:00'),
('Sana Tariq', 'sana.tariq@email.com', '+92-346-3332211', '$2y$10$abcdefghijklmnopqrstuv', '2024-05-01 15:10:00'),
('Bilal Ahmed', 'bilal.ahmed@email.com', '+92-302-1112233', '$2y$10$abcdefghijklmnopqrstuv', '2024-02-14 12:40:00'),
('Mariam Noor', 'mariam.noor@email.com', '+92-323-5554433', '$2y$10$abcdefghijklmnopqrstuv', '2024-05-10 10:00:00'),
('Kamran Iqbal', 'kamran.iqbal@email.com', '+92-315-2223344', '$2y$10$abcdefghijklmnopqrstuv', '2024-03-18 09:30:00'),
('Hina Farooq', 'hina.farooq@email.com', '+92-336-8889900', '$2y$10$abcdefghijklmnopqrstuv', '2024-04-22 14:15:00'),
('Imran Siddiqui', 'imran.siddiqui@email.com', '+92-347-1112222', '$2y$10$abcdefghijklmnopqrstuv', '2024-01-05 11:20:00'),
('Rabia Aziz', 'rabia.aziz@email.com', '+92-303-4445555', '$2y$10$abcdefghijklmnopqrstuv', '2024-02-28 16:00:00'),
('Faisal Mahmood', 'faisal.mahmood@email.com', '+92-324-7778899', '$2y$10$abcdefghijklmnopqrstuv', '2023-12-20 10:45:00');

-- ============================================
-- INSERT CATEGORIES
-- ============================================
INSERT INTO categories (name, description) VALUES
('prescription', 'Doctor prescribed medicines and antibiotics'),
('vitamins', 'Health supplements, vitamins and minerals'),
('firstaid', 'Emergency medical supplies and first aid kits'),
('devices', 'Medical devices and monitoring equipment'),
('personal', 'Personal care and hygiene products'),
('baby', 'Baby care products and infant medicines'),
('skincare', 'Skin care products and dermatology items'),
('herbal', 'Herbal and natural remedies'),
('surgical', 'Surgical supplies and elderly care'),
('winter', 'Winter essentials and cold remedies');

-- ============================================
-- INSERT PRODUCTS (50+ items)
-- ============================================
INSERT INTO products (name, description, price, category, icon, stock, stock_quantity) VALUES
-- Prescription Medicines
('Paracetamol 500mg', 'Pain relief and fever reducer tablets', 5.99, 'prescription', '💊', 500, 500),
('Ibuprofen 400mg', 'Anti-inflammatory pain reliever', 7.99, 'prescription', '💊', 450, 450),
('Aspirin 100mg', 'Blood thinner and pain relief', 6.99, 'prescription', '💊', 400, 400),
('Amoxicillin 500mg', 'Antibiotic for bacterial infections', 12.99, 'prescription', '💊', 300, 300),
('Azithromycin 250mg', 'Antibiotic for respiratory infections', 15.99, 'prescription', '💊', 250, 250),
('Omeprazole 20mg', 'Acid reflux and heartburn relief', 9.99, 'prescription', '💊', 350, 350),
('Metformin 500mg', 'Diabetes management medication', 11.99, 'prescription', '💊', 280, 280),
('Atorvastatin 10mg', 'Cholesterol lowering medication', 18.99, 'prescription', '💊', 200, 200),
('Losartan 50mg', 'Blood pressure control medication', 14.99, 'prescription', '💊', 220, 220),
('Cough Syrup 100ml', 'Relief from dry and wet cough', 8.99, 'prescription', '💊', 180, 180),

-- Vitamins & Supplements
('Vitamin C 1000mg', 'Immune system support tablets', 12.99, 'vitamins', '💉', 400, 400),
('Vitamin D3 2000IU', 'Bone health and immunity booster', 14.99, 'vitamins', '💉', 350, 350),
('Multivitamin Complex', 'Complete daily nutrition supplement', 19.99, 'vitamins', '💉', 300, 300),
('Omega-3 Fish Oil', 'Heart and brain health capsules', 24.99, 'vitamins', '💉', 250, 250),
('Calcium + Vitamin D', 'Bone strength supplement', 16.99, 'vitamins', '💉', 280, 280),
('Zinc 50mg', 'Immune support and wound healing', 10.99, 'vitamins', '💉', 320, 320),
('Iron Supplement', 'Anemia prevention and energy boost', 13.99, 'vitamins', '💉', 200, 200),
('Probiotic Capsules', 'Digestive health support', 22.99, 'vitamins', '💉', 180, 180),
('B-Complex Vitamins', 'Energy and metabolism support', 15.99, 'vitamins', '💉', 260, 260),
('Magnesium 400mg', 'Muscle and nerve function support', 11.99, 'vitamins', '💉', 240, 240),

-- First Aid & Emergency
('First Aid Kit Complete', 'Comprehensive emergency medical kit', 29.99, 'firstaid', '🩹', 100, 100),
('Bandages Pack (50pcs)', 'Assorted sterile bandages', 8.99, 'firstaid', '🩹', 250, 250),
('Antiseptic Cream 50g', 'Wound care and infection prevention', 7.99, 'firstaid', '🩹', 300, 300),
('Gauze Pads Sterile', 'Medical grade gauze pads pack', 6.99, 'firstaid', '🩹', 280, 280),
('Medical Tape', 'Hypoallergenic adhesive tape', 4.99, 'firstaid', '🩹', 350, 350),
('Hydrogen Peroxide', 'Wound cleaning and disinfection', 5.99, 'firstaid', '🩹', 200, 200),
('Cotton Balls (200pcs)', 'Sterile cotton balls pack', 3.99, 'firstaid', '🩹', 400, 400),
('Elastic Bandage', 'Compression and support bandage', 9.99, 'firstaid', '🩹', 150, 150),

-- Medical Devices
('Digital Thermometer', 'Fast and accurate temperature reading', 15.99, 'devices', '🌡️', 180, 180),
('Blood Pressure Monitor', 'Digital BP measurement device', 45.99, 'devices', '🌡️', 80, 80),
('Pulse Oximeter', 'Oxygen saturation monitor', 29.99, 'devices', '🩺', 120, 120),
('Glucose Meter Kit', 'Blood sugar monitoring system', 39.99, 'devices', '🩺', 90, 90),
('Infrared Thermometer', 'Non-contact temperature scanner', 34.99, 'devices', '🌡️', 100, 100),
('Nebulizer Machine', 'Respiratory therapy device', 89.99, 'devices', '🩺', 45, 45),
('Digital Weight Scale', 'Accurate body weight measurement', 25.99, 'devices', '🩺', 110, 110),

-- Personal Care
('Hand Sanitizer 500ml', 'Antibacterial hand gel 70% alcohol', 4.99, 'personal', '🧴', 600, 600),
('Face Masks (50 Pack)', 'Disposable 3-ply surgical masks', 12.99, 'personal', '😷', 500, 500),
('Antibacterial Soap', 'Germ protection hand wash', 6.99, 'personal', '🧴', 350, 350),
('Wet Wipes (80pcs)', 'Antibacterial cleaning wipes', 5.99, 'personal', '🧴', 400, 400),
('Tissue Box (200 sheets)', 'Soft facial tissues', 3.99, 'personal', '🧴', 450, 450),

-- Skin Care
('Moisturizing Cream', 'Hydrating skin care cream', 18.99, 'skincare', '🧴', 200, 200),
('Sunscreen SPF 50', 'UV protection lotion', 22.99, 'skincare', '🧴', 180, 180),
('Acne Treatment Gel', 'Pimple and acne control', 16.99, 'skincare', '🧴', 150, 150),
('Anti-Aging Serum', 'Wrinkle reduction formula', 34.99, 'skincare', '🧴', 100, 100),
('Face Wash Cleanser', 'Deep cleansing face wash', 12.99, 'skincare', '🧴', 220, 220),

-- Baby Care
('Baby Diapers (40pcs)', 'Soft and absorbent diapers', 24.99, 'baby', '👶', 200, 200),
('Baby Wipes (80pcs)', 'Gentle cleaning wipes', 8.99, 'baby', '👶', 300, 300),
('Baby Lotion 200ml', 'Moisturizing baby lotion', 11.99, 'baby', '👶', 180, 180),
('Gripe Water', 'Colic and gas relief for infants', 7.99, 'baby', '👶', 150, 150),

-- Winter Essentials
('Cough Drops (30pcs)', 'Throat soothing lozenges', 4.99, 'winter', '❄️', 350, 350),
('Nasal Spray', 'Congestion relief spray', 9.99, 'winter', '❄️', 200, 200),
('Vapor Rub', 'Chest congestion relief', 8.99, 'winter', '❄️', 180, 180);

-- ============================================
-- INSERT SAMPLE ORDERS
-- ============================================
INSERT INTO orders (user_id, total_amount, status, shipping_address, created_at) VALUES
(1, 45.97, 'delivered', '123 Main Street, Karachi, Pakistan', '2024-01-20 10:30:00'),
(1, 89.95, 'delivered', '123 Main Street, Karachi, Pakistan', '2024-02-15 14:20:00'),
(2, 156.89, 'processing', '456 Park Avenue, Lahore, Pakistan', '2024-05-08 09:15:00'),
(3, 234.50, 'delivered', '789 Garden Road, Islamabad, Pakistan', '2024-03-10 16:45:00'),
(3, 78.99, 'delivered', '789 Garden Road, Islamabad, Pakistan', '2024-04-22 11:00:00'),
(4, 45.98, 'pending', '321 Mall Road, Rawalpindi, Pakistan', '2024-05-12 13:30:00'),
(5, 567.80, 'delivered', '654 University Road, Peshawar, Pakistan', '2024-02-28 08:20:00'),
(5, 123.45, 'delivered', '654 University Road, Peshawar, Pakistan', '2024-03-15 15:10:00'),
(6, 89.97, 'cancelled', '987 Clifton Block, Karachi, Pakistan', '2024-04-18 12:40:00'),
(7, 234.89, 'delivered', '147 Model Town, Lahore, Pakistan', '2024-02-05 10:00:00'),
(7, 156.78, 'processing', '147 Model Town, Lahore, Pakistan', '2024-05-10 09:30:00'),
(9, 98.95, 'delivered', '258 Satellite Town, Rawalpindi, Pakistan', '2024-03-20 14:15:00'),
(11, 345.67, 'delivered', '369 Gulberg, Lahore, Pakistan', '2024-04-05 11:20:00'),
(13, 189.99, 'delivered', '741 F-7, Islamabad, Pakistan', '2024-01-25 16:00:00'),
(14, 267.88, 'processing', '852 DHA Phase 5, Karachi, Pakistan', '2024-05-11 10:45:00');

-- ============================================
-- INSERT ORDER ITEMS
-- ============================================
INSERT INTO order_items (order_id, product_id, quantity, price) VALUES
-- Order 1
(1, 1, 2, 5.99),
(1, 11, 1, 12.99),
(1, 23, 1, 29.99),
-- Order 2
(2, 5, 1, 15.99),
(2, 12, 2, 14.99),
(2, 30, 1, 45.99),
-- Order 3
(3, 8, 1, 18.99),
(3, 14, 2, 24.99),
(3, 31, 1, 29.99),
(3, 36, 3, 4.99),
-- Order 4
(4, 2, 3, 7.99),
(4, 13, 2, 19.99),
(4, 28, 1, 15.99),
(4, 40, 2, 12.99),
-- Order 5
(5, 10, 1, 8.99),
(5, 20, 1, 11.99),
(5, 35, 2, 25.99);

-- ============================================
-- CREATE ADMIN USER (for login)
-- ============================================
-- Password: admin123
INSERT INTO users (name, email, phone, password, created_at) VALUES
('Admin User', 'admin@medix.com', '+92-300-0000000', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', NOW());

-- ============================================
-- SUMMARY
-- ============================================
SELECT 'Database setup complete!' as Status;
SELECT COUNT(*) as Total_Users FROM users;
SELECT COUNT(*) as Total_Products FROM products;
SELECT COUNT(*) as Total_Orders FROM orders;
SELECT COUNT(*) as Total_Categories FROM categories;
