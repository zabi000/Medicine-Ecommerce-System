ADVERTISEMENT BANNERS FOLDER
============================

Place your advertisement banner images here.

FILE NAMING:
- ad-banner-1.jpg  (Vitamins Sale)
- ad-banner-2.jpg  (Free Delivery)
- ad-banner-3.jpg  (New Arrivals)

CREATE ADS USING:
1. Canva (Free): https://www.canva.com/
   - Search: "Pharmacy Banner" or "Medical Ad"
   - Customize with your offers
   
2. Freepik: https://www.freepik.com/free-photos-vectors/pharmacy-banner
   - Download free templates
   
3. Bing Image Creator: https://www.bing.com/images/create
   - AI-generated banners

BANNER SPECS:
- Size: 1200x400px (landscape)
- Format: JPG or PNG
- Theme: Blue/Medical colors
- Text: Clear and readable

SUGGESTED AD CONTENT:
- "50% OFF on Vitamins"
- "Free Delivery on Orders $50+"
- "New Arrivals - Check Now"
- "24/7 Customer Support"
- "100% Genuine Products"

AFTER ADDING BANNERS:
The carousel will automatically display your ads!
Refresh browser (Ctrl + Shift + R) to see changes.
