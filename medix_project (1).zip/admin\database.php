﻿<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) { header('Location: login.php'); exit(); }
require_once('../api/config.php');

$action = $_GET['action'] ?? 'overview';
$table  = $_GET['table'] ?? '';
$msg    = '';

// Run custom SQL query
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['sql'])) {
    $sql = trim($_POST['sql']);
    $query_result = null;
    $query_error  = null;
    $query_affected = 0;
    if ($conn) {
        $res = $conn->query($sql);
        if ($res === true) {
            $query_affected = $conn->affected_rows;
            $msg = "âœ… Query executed. Rows affected: $query_affected";
        } elseif ($res) {
            $query_result = $res;
            $msg = "âœ… Query returned " . $res->num_rows . " rows";
        } else {
            $query_error = $conn->error;
        }
    }
}

// Get all tables
$tables = [];
if ($conn) {
    $res = $conn->query("SHOW TABLES");
    while ($r = $res->fetch_array()) $tables[] = $r[0];
}

// Get table data
$table_data = null;
$table_cols = [];
$table_count = 0;
$page = max(1, intval($_GET['page'] ?? 1));
$per_page = 20;
$offset = ($page - 1) * $per_page;

if ($table && $conn && in_array($table, $tables)) {
    $table_count = $conn->query("SELECT COUNT(*) as c FROM `$table`")->fetch_assoc()['c'];
    $table_data  = $conn->query("SELECT * FROM `$table` LIMIT $per_page OFFSET $offset");
    $col_res = $conn->query("SHOW COLUMNS FROM `$table`");
    while ($c = $col_res->fetch_assoc()) $table_cols[] = $c;
}

// Get DB stats
$db_stats = [];
if ($conn) {
    foreach ($tables as $t) {
        $s = $conn->query("SELECT COUNT(*) as cnt FROM `$t`")->fetch_assoc();
        $db_stats[$t] = $s['cnt'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Database Manager - MEDIX</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
*{font-family:'Inter',sans-serif}
:root{--primary:#B91C1C;--sw:280px}
body{background:#f1f5f9;margin:0}
.sidebar{position:fixed;top:0;left:0;width:var(--sw);height:100vh;background:linear-gradient(160deg,#B91C1C,#7F1D1D);overflow-y:auto;z-index:1000}
.sb-brand{padding:1.5rem;border-bottom:1px solid rgba(255,255,255,.1);color:white}
.mi{display:flex;align-items:center;gap:.75rem;padding:.875rem 1.5rem;color:rgba(255,255,255,.8);text-decoration:none;border-left:3px solid transparent;transition:all .2s;font-size:.9rem}
.mi:hover,.mi.active{background:rgba(255,255,255,.12);color:white;border-left-color:white}
.mi i{width:20px}
.mdiv{height:1px;background:rgba(255,255,255,.1);margin:.5rem 1.5rem}
.main{margin-left:var(--sw);padding:0}
.topbar{background:white;padding:1.25rem 2rem;display:flex;justify-content:space-between;align-items:center;box-shadow:0 1px 3px rgba(0,0,0,.08);position:sticky;top:0;z-index:100}
.content{padding:2rem}
.db-card{background:white;border-radius:16px;box-shadow:0 1px 3px rgba(0,0,0,.08);overflow:hidden;margin-bottom:1.5rem}
.db-card-header{padding:1rem 1.5rem;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;justify-content:space-between;background:#fafafa}
.db-card-header h6{margin:0;font-weight:700;font-size:.95rem}
.table-list{list-style:none;padding:0;margin:0}
.table-list li a{display:flex;align-items:center;justify-content:space-between;padding:.75rem 1.5rem;color:#374151;text-decoration:none;border-bottom:1px solid #f8fafc;transition:all .2s;font-size:.875rem}
.table-list li a:hover{background:#fef2f2;color:#B91C1C}
.table-list li a.active{background:#fef2f2;color:#B91C1C;font-weight:600;border-left:3px solid #B91C1C}
.row-count{background:#f1f5f9;color:#64748b;padding:.2rem .6rem;border-radius:20px;font-size:.72rem;font-weight:600}
.data-table{width:100%;font-size:.8rem}
.data-table th{background:#f8fafc;padding:.625rem .875rem;font-weight:700;color:#64748b;text-transform:uppercase;font-size:.7rem;letter-spacing:.3px;border-bottom:2px solid #e2e8f0;white-space:nowrap}
.data-table td{padding:.625rem .875rem;border-bottom:1px solid #f8fafc;color:#374151;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.data-table tr:hover td{background:#fef2f2}
.sql-editor{font-family:'Courier New',monospace;font-size:.875rem;background:#1e293b;color:#e2e8f0;border:none;border-radius:10px;padding:1rem;resize:vertical;min-height:120px}
.sql-editor:focus{outline:none;box-shadow:0 0 0 3px rgba(185,28,28,.3)}
.stat-mini{background:#f8fafc;border-radius:10px;padding:.875rem 1rem;border:1px solid #e2e8f0;text-align:center}
.stat-mini .n{font-size:1.5rem;font-weight:800;color:#1e293b}
.stat-mini .l{font-size:.72rem;color:#64748b;margin-top:.2rem}
.badge-table{background:#fee2e2;color:#B91C1C;padding:.25rem .6rem;border-radius:6px;font-size:.72rem;font-weight:700}
.null-val{color:#94a3b8;font-style:italic}
.col-type{font-size:.65rem;color:#94a3b8;font-weight:400}
</style>
</head>
<body>
<div class="sidebar">
    <div class="sb-brand"><h4 class="mb-0 fw-bold"><i class="bi bi-heart-pulse-fill me-2"></i>MEDIX</h4><small style="opacity:.6">Admin Portal</small></div>
    <a href="index.php" class="mi"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="products.php" class="mi"><i class="bi bi-box-seam"></i>Products</a>
    <a href="offers.php" class="mi"><i class="bi bi-tag-fill"></i>Offers</a>
    <a href="orders.php" class="mi"><i class="bi bi-cart-check"></i>Orders</a>
    <a href="customers.php" class="mi"><i class="bi bi-people"></i>Customers</a>
    <a href="categories.php" class="mi"><i class="bi bi-tags"></i>Categories</a>
    <a href="messages.php" class="mi"><i class="bi bi-envelope"></i>Messages</a>
    <a href="reports.php" class="mi"><i class="bi bi-graph-up"></i>Reports</a>
    <a href="settings.php" class="mi"><i class="bi bi-gear"></i>Settings</a>
    <div class="mdiv"></div>
    <a href="database.php" class="mi active" style="color:#10B981;border-left-color:#10B981"><i class="bi bi-database"></i>Database Manager</a>
    <a href="import_medicines.php" class="mi" style="color:#10B981"><i class="bi bi-capsule-pill"></i>Import Medicines</a>
    <div class="mdiv"></div>
    <a href="logout.php" class="mi"><i class="bi bi-box-arrow-right"></i>Logout</a>
</div>

<div class="main">
    <div class="topbar">
        <div>
            <h4 class="mb-0 fw-bold"><i class="bi bi-database me-2 text-danger"></i>Database Manager</h4>
            <small class="text-muted">medicare_db â€” <?= count($tables) ?> tables</small>
        </div>
        <div class="d-flex gap-2">
            <a href="http://localhost/phpmyadmin" target="_blank" class="btn btn-sm btn-outline-primary">
                <i class="bi bi-box-arrow-up-right me-1"></i>phpMyAdmin
            </a>
            <a href="database.php?action=query" class="btn btn-sm btn-danger">
                <i class="bi bi-terminal me-1"></i>SQL Query
            </a>
        </div>
    </div>

    <div class="content">
        <?php if ($msg): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <?= $msg ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <?php if (isset($query_error)): ?>
        <div class="alert alert-danger">
            <i class="bi bi-exclamation-triangle me-2"></i><strong>SQL Error:</strong> <?= htmlspecialchars($query_error) ?>
        </div>
        <?php endif; ?>

        <div class="row g-3">
            <!-- Left: Table List -->
            <div class="col-lg-3">
                <div class="db-card">
                    <div class="db-card-header">
                        <h6><i class="bi bi-table me-2 text-danger"></i>Tables</h6>
                        <span class="badge-table"><?= count($tables) ?></span>
                    </div>
                    <ul class="table-list">
                        <?php foreach ($tables as $t): ?>
                        <li>
                            <a href="database.php?table=<?= urlencode($t) ?>" class="<?= $table === $t ? 'active' : '' ?>">
                                <span><i class="bi bi-grid-3x3 me-2" style="font-size:.8rem"></i><?= htmlspecialchars($t) ?></span>
                                <span class="row-count"><?= number_format($db_stats[$t] ?? 0) ?></span>
                            </a>
                        </li>
                        <?php endforeach; ?>
                    </ul>
                </div>

                <!-- DB Stats -->
                <div class="db-card">
                    <div class="db-card-header"><h6><i class="bi bi-bar-chart me-2 text-primary"></i>Quick Stats</h6></div>
                    <div class="p-3">
                        <div class="row g-2">
                            <?php
                            $key_tables = ['products' => 'Products', 'orders' => 'Orders', 'users' => 'Customers'];
                            foreach ($key_tables as $kt => $label):
                                $cnt = $db_stats[$kt] ?? 0;
                            ?>
                            <div class="col-12">
                                <div class="stat-mini">
                                    <div class="n"><?= number_format($cnt) ?></div>
                                    <div class="l"><?= $label ?></div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right: Table Data / Query -->
            <div class="col-lg-9">
                <?php if ($table && $table_data): ?>
                <!-- Table View -->
                <div class="db-card">
                    <div class="db-card-header">
                        <h6><i class="bi bi-table me-2 text-danger"></i><?= htmlspecialchars($table) ?>
                            <span class="text-muted fw-normal ms-2" style="font-size:.8rem"><?= number_format($table_count) ?> rows</span>
                        </h6>
                        <div class="d-flex gap-2">
                            <a href="database.php?action=query&sql=SELECT+*+FROM+`<?= urlencode($table) ?>`+LIMIT+100" class="btn btn-sm btn-outline-secondary">
                                <i class="bi bi-code-slash me-1"></i>Query
                            </a>
                        </div>
                    </div>

                    <!-- Column Info -->
                    <div class="p-3 border-bottom" style="background:#f8fafc">
                        <div class="d-flex gap-2 flex-wrap">
                            <?php foreach ($table_cols as $col): ?>
                            <span style="background:white;border:1px solid #e2e8f0;border-radius:6px;padding:.25rem .6rem;font-size:.72rem;">
                                <strong><?= $col['Field'] ?></strong>
                                <span class="col-type ms-1"><?= $col['Type'] ?></span>
                                <?php if ($col['Key'] === 'PRI'): ?><i class="bi bi-key-fill text-warning ms-1" style="font-size:.65rem"></i><?php endif; ?>
                            </span>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div class="table-responsive" style="max-height:500px;overflow-y:auto">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <?php foreach ($table_cols as $col): ?>
                                    <th><?= htmlspecialchars($col['Field']) ?></th>
                                    <?php endforeach; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = $table_data->fetch_assoc()): ?>
                                <tr>
                                    <?php foreach ($row as $val): ?>
                                    <td title="<?= htmlspecialchars($val ?? '') ?>">
                                        <?php if ($val === null): ?>
                                            <span class="null-val">NULL</span>
                                        <?php else: ?>
                                            <?= htmlspecialchars(mb_substr($val, 0, 60)) ?><?= mb_strlen($val) > 60 ? '...' : '' ?>
                                        <?php endif; ?>
                                    </td>
                                    <?php endforeach; ?>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>

                    <!-- Pagination -->
                    <?php if ($table_count > $per_page): ?>
                    <div class="p-3 border-top d-flex justify-content-between align-items-center">
                        <small class="text-muted">Showing <?= $offset + 1 ?>â€“<?= min($offset + $per_page, $table_count) ?> of <?= number_format($table_count) ?></small>
                        <div class="d-flex gap-1">
                            <?php for ($p = 1; $p <= ceil($table_count / $per_page); $p++): ?>
                            <a href="?table=<?= urlencode($table) ?>&page=<?= $p ?>"
                               class="btn btn-sm <?= $p === $page ? 'btn-danger' : 'btn-outline-secondary' ?>"
                               style="min-width:32px"><?= $p ?></a>
                            <?php endfor; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <?php elseif (isset($_POST['sql']) && isset($query_result)): ?>
                <!-- Query Results -->
                <div class="db-card">
                    <div class="db-card-header"><h6><i class="bi bi-terminal me-2 text-success"></i>Query Results</h6></div>
                    <div class="table-responsive" style="max-height:400px;overflow-y:auto">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <?php
                                    $first = true;
                                    $cols_q = [];
                                    while ($row = $query_result->fetch_assoc()):
                                        if ($first) { foreach (array_keys($row) as $k) { $cols_q[] = $k; echo "<th>".htmlspecialchars($k)."</th>"; } echo "</tr></thead><tbody>"; $first = false; }
                                    ?>
                                    <tr><?php foreach ($row as $v): ?><td><?= htmlspecialchars($v ?? 'NULL') ?></td><?php endforeach; ?></tr>
                                    <?php endwhile; ?>
                                </tbody>
                        </table>
                    </div>
                </div>

                <?php else: ?>
                <!-- Overview -->
                <div class="db-card">
                    <div class="db-card-header"><h6><i class="bi bi-database me-2 text-primary"></i>Database Overview</h6></div>
                    <div class="p-4">
                        <div class="row g-3 mb-4">
                            <?php foreach ($db_stats as $t => $cnt): ?>
                            <div class="col-md-3 col-6">
                                <a href="database.php?table=<?= urlencode($t) ?>" style="text-decoration:none">
                                    <div class="stat-mini" style="cursor:pointer;transition:all .2s" onmouseover="this.style.borderColor='#B91C1C'" onmouseout="this.style.borderColor='#e2e8f0'">
                                        <div class="n"><?= number_format($cnt) ?></div>
                                        <div class="l"><?= htmlspecialchars($t) ?></div>
                                    </div>
                                </a>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <div class="alert alert-info mb-0">
                            <i class="bi bi-info-circle me-2"></i>
                            Click any table on the left to browse its data, or use the <strong>SQL Query</strong> button to run custom queries.
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- SQL Query Box -->
                <div class="db-card">
                    <div class="db-card-header">
                        <h6><i class="bi bi-terminal me-2 text-success"></i>SQL Query</h6>
                        <div class="d-flex gap-1">
                            <button class="btn btn-sm btn-outline-secondary" onclick="setSQL('SELECT * FROM products LIMIT 10')">Products</button>
                            <button class="btn btn-sm btn-outline-secondary" onclick="setSQL('SELECT * FROM orders ORDER BY created_at DESC LIMIT 10')">Orders</button>
                            <button class="btn btn-sm btn-outline-secondary" onclick="setSQL('SELECT * FROM users LIMIT 10')">Users</button>
                            <button class="btn btn-sm btn-outline-secondary" onclick="setSQL('SHOW TABLES')">Tables</button>
                        </div>
                    </div>
                    <div class="p-3">
                        <form method="POST">
                            <textarea name="sql" id="sqlInput" class="sql-editor w-100 mb-2"
                                placeholder="-- Write your SQL query here&#10;SELECT * FROM products LIMIT 10;"><?= htmlspecialchars($_POST['sql'] ?? '') ?></textarea>
                            <div class="d-flex justify-content-between align-items-center">
                                <small class="text-muted"><i class="bi bi-exclamation-triangle me-1 text-warning"></i>Be careful with DELETE/DROP queries</small>
                                <button type="submit" class="btn btn-danger px-4">
                                    <i class="bi bi-play-fill me-1"></i>Run Query
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function setSQL(sql) {
    document.getElementById('sqlInput').value = sql;
    document.getElementById('sqlInput').focus();
}
// Keyboard shortcut: Ctrl+Enter to run query
document.getElementById('sqlInput')?.addEventListener('keydown', function(e) {
    if (e.ctrlKey && e.key === 'Enter') {
        this.closest('form').submit();
    }
});
</script>
</body>
</html>

