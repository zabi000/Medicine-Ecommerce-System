﻿<?php
session_start();
require_once('../api/config.php');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php'); exit;
}

// Auto-create tables
if ($conn) {
    $conn->query("CREATE TABLE IF NOT EXISTS contact_messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        first_name VARCHAR(100) DEFAULT '',
        last_name VARCHAR(100) DEFAULT '',
        email VARCHAR(200) NOT NULL,
        phone VARCHAR(30) DEFAULT '',
        subject VARCHAR(200) DEFAULT 'General',
        message TEXT NOT NULL,
        status ENUM('new','read','replied') DEFAULT 'new',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $conn->query("CREATE TABLE IF NOT EXISTS message_replies (
        id INT AUTO_INCREMENT PRIMARY KEY,
        message_id INT NOT NULL,
        reply_subject VARCHAR(255) NOT NULL,
        reply_message TEXT NOT NULL,
        recipient_email VARCHAR(255) NOT NULL,
        recipient_name VARCHAR(255) NOT NULL,
        sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Ensure columns exist
    $cols = [];
    $cr = $conn->query("SHOW COLUMNS FROM contact_messages");
    if ($cr) while ($c = $cr->fetch_assoc()) $cols[] = $c['Field'];
    if (!in_array('first_name', $cols)) $conn->query("ALTER TABLE contact_messages ADD COLUMN first_name VARCHAR(100) DEFAULT '' AFTER id");
    if (!in_array('last_name',  $cols)) $conn->query("ALTER TABLE contact_messages ADD COLUMN last_name VARCHAR(100) DEFAULT '' AFTER first_name");
    if (!in_array('phone',      $cols)) $conn->query("ALTER TABLE contact_messages ADD COLUMN phone VARCHAR(30) DEFAULT ''");
    if (!in_array('subject',    $cols)) $conn->query("ALTER TABLE contact_messages ADD COLUMN subject VARCHAR(200) DEFAULT 'General'");
    if (!in_array('status',     $cols)) $conn->query("ALTER TABLE contact_messages ADD COLUMN status ENUM('new','read','replied') DEFAULT 'new'");
    if (!in_array('attachment', $cols)) $conn->query("ALTER TABLE contact_messages ADD COLUMN attachment VARCHAR(255) DEFAULT NULL");
}

// ---- Handle Reply ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_reply'])) {
    $mid     = (int)$_POST['message_id'];
    $subj    = trim($_POST['reply_subject'] ?? '');
    $body    = trim($_POST['reply_message'] ?? '');
    $email   = trim($_POST['recipient_email'] ?? '');
    $name    = trim($_POST['recipient_name'] ?? '');

    if (!$mid || !$subj || !$body) {
        $_SESSION['flash'] = ['type'=>'danger','msg'=>'Subject and reply message are required.'];
        header('Location: messages.php'); exit;
    }

    $stmt = $conn->prepare("INSERT INTO message_replies (message_id,reply_subject,reply_message,recipient_email,recipient_name) VALUES (?,?,?,?,?)");
    $stmt->bind_param("issss", $mid, $subj, $body, $email, $name);

    if ($stmt->execute()) {
        $u = $conn->prepare("UPDATE contact_messages SET status='replied' WHERE id=?");
        $u->bind_param("i", $mid); $u->execute(); $u->close();
        // Send email notification to customer
        require_once('../api/mailer.php');
        sendMessageReplyEmail($email, $name, $subj, $body, $conn);
        $_SESSION['flash'] = ['type'=>'success','msg'=>'Reply saved and email sent to customer!'];
    } else {
        $_SESSION['flash'] = ['type'=>'danger','msg'=>'Failed to save reply: ' . $conn->error];
    }
    $stmt->close();
    header('Location: messages.php'); exit;
}

// ---- Handle Status Update ----
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $mid = (int)$_POST['message_id'];
    $st  = $_POST['status'];
    if (in_array($st, ['new','read','replied'])) {
        $s = $conn->prepare("UPDATE contact_messages SET status=? WHERE id=?");
        $s->bind_param("si", $st, $mid); $s->execute(); $s->close();
    }
    header('Location: messages.php?updated=1'); exit;
}

// ---- Handle Delete ----
if (isset($_GET['delete'])) {
    $mid = (int)$_GET['delete'];
    $conn->query("DELETE FROM message_replies WHERE message_id=$mid");
    $conn->query("DELETE FROM contact_messages WHERE id=$mid");
    $_SESSION['flash'] = ['type'=>'success','msg'=>'Message deleted.'];
    header('Location: messages.php'); exit;
}

// ---- Flash message ----
$flash = $_SESSION['flash'] ?? null;
unset($_SESSION['flash']);

// ---- Fetch data ----
$filter   = $_GET['filter'] ?? 'all';
$where    = $filter !== 'all' ? "WHERE status='" . $conn->real_escape_string($filter) . "'" : '';
$messages = $conn->query("SELECT * FROM contact_messages $where ORDER BY created_at DESC")->fetch_all(MYSQLI_ASSOC);

$total    = $conn->query("SELECT COUNT(*) c FROM contact_messages")->fetch_assoc()['c'] ?? 0;
$newCnt   = $conn->query("SELECT COUNT(*) c FROM contact_messages WHERE status='new'")->fetch_assoc()['c'] ?? 0;
$readCnt  = $conn->query("SELECT COUNT(*) c FROM contact_messages WHERE status='read'")->fetch_assoc()['c'] ?? 0;
$replyCnt = $conn->query("SELECT COUNT(*) c FROM contact_messages WHERE status='replied'")->fetch_assoc()['c'] ?? 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Messages - MEDIX Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{--sw:280px;--red:#B91C1C;--red2:#7F1D1D}
body{font-family:'Inter',sans-serif;background:#f8fafc}
.sidebar{position:fixed;top:0;left:0;width:var(--sw);height:100vh;background:linear-gradient(180deg,var(--red),var(--red2));overflow-y:auto;z-index:1000}
.sb-brand{padding:1.5rem;border-bottom:1px solid rgba(255,255,255,.1);color:white}
.mi{display:flex;align-items:center;gap:.75rem;padding:.875rem 1.5rem;color:rgba(255,255,255,.8);text-decoration:none;border-left:3px solid transparent;transition:all .2s;font-weight:500}
.mi:hover,.mi.active{background:rgba(255,255,255,.15);color:white;border-left-color:white}
.mi i{width:20px}
.mdiv{height:1px;background:rgba(255,255,255,.1);margin:.5rem 1.5rem}
.main{margin-left:var(--sw);padding:2rem}
.topbar{background:white;border-bottom:1px solid #e2e8f0;padding:1rem 2rem;margin:-2rem -2rem 2rem;box-shadow:0 1px 3px rgba(0,0,0,.06)}
.msg-card{background:white;border-radius:16px;padding:1.5rem;margin-bottom:1rem;box-shadow:0 1px 4px rgba(0,0,0,.06);border:1.5px solid #f1f5f9;transition:box-shadow .2s}
.msg-card:hover{box-shadow:0 4px 16px rgba(0,0,0,.1)}
.msg-card.new    {border-left:4px solid #10B981}
.msg-card.read   {border-left:4px solid #3B82F6}
.msg-card.replied{border-left:4px solid #8B5CF6}
.sbadge-new    {background:#D1FAE5;color:#065F46;padding:.25rem .75rem;border-radius:20px;font-size:.75rem;font-weight:700}
.sbadge-read   {background:#DBEAFE;color:#1E40AF;padding:.25rem .75rem;border-radius:20px;font-size:.75rem;font-weight:700}
.sbadge-replied{background:#EDE9FE;color:#5B21B6;padding:.25rem .75rem;border-radius:20px;font-size:.75rem;font-weight:700}
.sc{background:white;border-radius:12px;padding:1.25rem;box-shadow:0 1px 4px rgba(0,0,0,.06);border:1px solid #f1f5f9}
.filter-pill{display:inline-block;padding:.4rem 1.1rem;border-radius:20px;text-decoration:none;font-size:.85rem;font-weight:600;border:1.5px solid #E2E8F0;color:#475569;background:white;transition:all .2s;margin-right:.5rem;margin-bottom:.5rem}
.filter-pill:hover,.filter-pill.active{background:#B91C1C;color:white;border-color:#B91C1C}
</style>
</head>
<body>
<div class="sidebar">
    <div class="sb-brand"><h4 class="mb-0 fw-bold"><i class="bi bi-heart-pulse-fill me-2"></i>MEDIX</h4><small style="opacity:.6">Admin Portal</small></div>
    <a href="index.php"      class="mi"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="products.php"   class="mi"><i class="bi bi-box-seam"></i>Products</a>
    <a href="offers.php"     class="mi"><i class="bi bi-tag-fill"></i>Offers</a>
    <a href="orders.php"     class="mi"><i class="bi bi-cart-check"></i>Orders</a>
    <a href="customers.php"  class="mi"><i class="bi bi-people"></i>Customers</a>
    <a href="categories.php" class="mi"><i class="bi bi-tags"></i>Categories</a>
    <a href="messages.php"   class="mi active"><i class="bi bi-envelope"></i>Messages</a>
    <a href="reports.php"    class="mi"><i class="bi bi-graph-up"></i>Reports</a>
    <a href="settings.php"   class="mi"><i class="bi bi-gear"></i>Settings</a>
    <div class="mdiv"></div>
    <a href="database.php"   class="mi"><i class="bi bi-database"></i>Database</a>
    <a href="import_medicines.php" class="mi" style="color:#10B981"><i class="bi bi-capsule-pill"></i>Import Medicines</a>
    <div class="mdiv"></div>
    <a href="logout.php" class="mi"><i class="bi bi-box-arrow-right"></i>Logout</a>
</div>

<div class="main">
<div class="topbar d-flex justify-content-between align-items-center">
    <div>
        <h4 class="mb-0 fw-bold"><i class="bi bi-envelope-fill me-2 text-danger"></i>Contact Messages</h4>
        <small class="text-muted">Messages from customers via the contact form</small>
    </div>
    <span class="badge bg-danger fs-6"><?= $newCnt ?> New</span>
</div>

<?php if ($flash): ?>
<div class="alert alert-<?= $flash['type'] ?> alert-dismissible fade show">
    <i class="bi bi-<?= $flash['type']==='success'?'check-circle':'exclamation-triangle' ?> me-2"></i><?= htmlspecialchars($flash['msg']) ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>
<?php if (isset($_GET['updated'])): ?>
<div class="alert alert-success alert-dismissible fade show"><i class="bi bi-check-circle me-2"></i>Status updated.<button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
<?php endif; ?>

<!-- Stats -->
<div class="row g-3 mb-4">
    <div class="col-6 col-md-3"><div class="sc text-center"><i class="bi bi-envelope text-primary" style="font-size:1.75rem"></i><h3 class="mt-1 mb-0 fw-bold"><?= $total ?></h3><p class="text-muted small mb-0">Total</p></div></div>
    <div class="col-6 col-md-3"><div class="sc text-center"><i class="bi bi-envelope-exclamation text-success" style="font-size:1.75rem"></i><h3 class="mt-1 mb-0 fw-bold text-success"><?= $newCnt ?></h3><p class="text-muted small mb-0">New</p></div></div>
    <div class="col-6 col-md-3"><div class="sc text-center"><i class="bi bi-envelope-open text-info" style="font-size:1.75rem"></i><h3 class="mt-1 mb-0 fw-bold text-info"><?= $readCnt ?></h3><p class="text-muted small mb-0">Read</p></div></div>
    <div class="col-6 col-md-3"><div class="sc text-center"><i class="bi bi-reply-fill text-purple" style="font-size:1.75rem;color:#8B5CF6"></i><h3 class="mt-1 mb-0 fw-bold" style="color:#8B5CF6"><?= $replyCnt ?></h3><p class="text-muted small mb-0">Replied</p></div></div>
</div>

<!-- Filters -->
<div class="mb-4">
    <a href="?filter=all"     class="filter-pill <?= $filter==='all'?'active':'' ?>">All (<?= $total ?>)</a>
    <a href="?filter=new"     class="filter-pill <?= $filter==='new'?'active':'' ?>">New (<?= $newCnt ?>)</a>
    <a href="?filter=read"    class="filter-pill <?= $filter==='read'?'active':'' ?>">Read (<?= $readCnt ?>)</a>
    <a href="?filter=replied" class="filter-pill <?= $filter==='replied'?'active':'' ?>">Replied (<?= $replyCnt ?>)</a>
</div>

<!-- Messages -->
<?php if (empty($messages)): ?>
<div class="text-center py-5 bg-white rounded-4">
    <i class="bi bi-inbox" style="font-size:4rem;color:#cbd5e1"></i>
    <h5 class="mt-3 text-muted">No messages<?= $filter!=='all'?" with status \"$filter\"":'' ?></h5>
    <p class="text-muted small">Messages from the contact form will appear here.</p>
</div>
<?php else: ?>
<?php foreach ($messages as $msg):
    $name = trim(($msg['first_name']??'') . ' ' . ($msg['last_name']??'')) ?: ($msg['name'] ?? 'Unknown');
    $st   = $msg['status'] ?? 'new';
?>
<div class="msg-card <?= $st ?>">
    <div class="row g-3">
        <div class="col-md-8">
            <div class="d-flex align-items-center gap-2 mb-1">
                <div class="fw-bold"><?= htmlspecialchars($name) ?></div>
                <span class="sbadge-<?= $st ?>"><?= ucfirst($st) ?></span>
            </div>
            <div class="small text-muted mb-1">
                <i class="bi bi-envelope me-1"></i><?= htmlspecialchars($msg['email']) ?>
                <?php if (!empty($msg['phone'])): ?> &nbsp;|&nbsp; <i class="bi bi-telephone me-1"></i><?= htmlspecialchars($msg['phone']) ?><?php endif; ?>
            </div>
            <div class="small text-muted mb-2">
                <i class="bi bi-clock me-1"></i><?= date('M d, Y h:i A', strtotime($msg['created_at'])) ?>
                &nbsp;&nbsp;<span class="badge bg-secondary"><?= htmlspecialchars(ucfirst($msg['subject'] ?? 'General')) ?></span>
            </div>
            <div class="p-3 rounded-3 mb-3" style="background:#f8fafc;border-left:3px solid #e2e8f0">
                <?= nl2br(htmlspecialchars($msg['message'])) ?>
                <?php if (!empty($msg['attachment'])): ?>
                <div class="mt-2 pt-2 border-top">
                    <?php
                    $att = $msg['attachment'];
                    $is_img = preg_match('/\.(jpg|jpeg|png|gif|webp)$/i', $att);
                    // Use absolute URL path — works from any subfolder
                    $img_url = '/ppp/' . ltrim($att, '/');
                    ?>
                    <?php if ($is_img): ?>
                    <p class="small text-muted mb-1"><i class="bi bi-image me-1"></i><strong>Attached Screenshot:</strong></p>
                    <a href="<?= htmlspecialchars($img_url) ?>" target="_blank">
                        <img src="<?= htmlspecialchars($img_url) ?>"
                             alt="Attachment"
                             style="max-width:300px;max-height:250px;border-radius:10px;border:2px solid #e2e8f0;display:block;cursor:pointer"
                             title="Click to open full size">
                    </a>
                    <small class="text-muted"><i class="bi bi-zoom-in me-1"></i>Click image to open full size</small>
                    <?php else: ?>
                    <a href="<?= htmlspecialchars($img_url) ?>" target="_blank" class="btn btn-sm btn-outline-secondary">
                        <i class="bi bi-file-earmark me-1"></i>View Attachment
                    </a>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>

            <?php
            // Show existing replies
            $replies = $conn->query("SELECT * FROM message_replies WHERE message_id={$msg['id']} ORDER BY sent_at ASC");
            if ($replies && $replies->num_rows > 0):
            ?>
            <div class="p-3 rounded-3" style="background:#f0fdf4;border-left:3px solid #10B981">
                <div class="fw-semibold text-success mb-2"><i class="bi bi-reply-fill me-1"></i>Your Replies</div>
                <?php while ($r = $replies->fetch_assoc()): ?>
                <div class="p-2 mb-2 bg-white rounded-2">
                    <div class="small text-muted"><?= date('M d, Y h:i A', strtotime($r['sent_at'])) ?></div>
                    <div class="small fw-semibold">Subject: <?= htmlspecialchars($r['reply_subject']) ?></div>
                    <div class="small mt-1"><?= nl2br(htmlspecialchars($r['reply_message'])) ?></div>
                </div>
                <?php endwhile; ?>
            </div>
            <?php endif; ?>
        </div>

        <div class="col-md-4">
            <!-- Status Dropdown -->
            <form method="POST" class="mb-2">
                <input type="hidden" name="message_id" value="<?= $msg['id'] ?>">
                <input type="hidden" name="update_status" value="1">
                <select name="status" class="form-select form-select-sm mb-1" onchange="this.form.submit()">
                    <option value="new"     <?= $st==='new'?'selected':'' ?>>New</option>
                    <option value="read"    <?= $st==='read'?'selected':'' ?>>Read</option>
                    <option value="replied" <?= $st==='replied'?'selected':'' ?>>Replied</option>
                </select>
            </form>

            <!-- Reply Button -->
            <button class="btn btn-danger btn-sm w-100 mb-2"
                    data-bs-toggle="modal"
                    data-bs-target="#replyModal<?= $msg['id'] ?>">
                <i class="bi bi-reply-fill me-1"></i>Reply to Customer
            </button>

            <!-- Delete -->
            <a href="?delete=<?= $msg['id'] ?>"
               class="btn btn-outline-danger btn-sm w-100"
               onclick="return confirm('Delete this message and all its replies?')">
                <i class="bi bi-trash me-1"></i>Delete
            </a>
        </div>
    </div>
</div>

<!-- Reply Modal -->
<div class="modal fade" id="replyModal<?= $msg['id'] ?>" tabindex="-1">
<div class="modal-dialog modal-lg"><div class="modal-content">
<div class="modal-header bg-danger text-white">
    <h5 class="modal-title"><i class="bi bi-reply-fill me-2"></i>Reply to <?= htmlspecialchars($name) ?></h5>
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
</div>
<form method="POST" action="messages.php">
<div class="modal-body">
    <input type="hidden" name="send_reply" value="1">
    <input type="hidden" name="message_id" value="<?= $msg['id'] ?>">
    <input type="hidden" name="recipient_email" value="<?= htmlspecialchars($msg['email']) ?>">
    <input type="hidden" name="recipient_name" value="<?= htmlspecialchars($name) ?>">

    <!-- Original message summary -->
    <div class="p-3 rounded-3 mb-3" style="background:#f8fafc;border-left:3px solid #B91C1C;font-size:.875rem">
        <strong>From:</strong> <?= htmlspecialchars($name) ?> &lt;<?= htmlspecialchars($msg['email']) ?>&gt;<br>
        <strong>Subject:</strong> <?= htmlspecialchars(ucfirst($msg['subject'] ?? 'General')) ?><br>
        <strong>Message:</strong> <?= nl2br(htmlspecialchars($msg['message'])) ?>
    </div>

    <div class="mb-3">
        <label class="form-label fw-semibold">Reply Subject <span class="text-danger">*</span></label>
        <input type="text" name="reply_subject" class="form-control" value="Re: <?= htmlspecialchars(ucfirst($msg['subject'] ?? 'General')) ?>" required>
    </div>
    <div class="mb-3">
        <label class="form-label fw-semibold">Your Reply <span class="text-danger">*</span></label>
        <textarea name="reply_message" class="form-control" rows="7" placeholder="Write your reply here..." required></textarea>
        <small class="text-muted"><i class="bi bi-info-circle me-1"></i>Reply will be saved to database. Message status will be set to "Replied".</small>
    </div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
    <button type="submit" class="btn btn-danger px-4"><i class="bi bi-send-fill me-1"></i>Send Reply</button>
</div>
</form>
</div></div></div>
<?php endforeach; ?>
<?php endif; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
setTimeout(function(){
    document.querySelectorAll('.alert').forEach(function(a){
        bootstrap.Alert.getOrCreateInstance(a)?.close();
    });
}, 4000);
</script>
</body>
</html>
