﻿<?php
/**
 * AUTOMATIC DATABASE IMPORTER
 * Just open this file in browser: http://localhost/ppp/admin/auto_import_database.php
 * It will automatically import the database for you!
 */

set_time_limit(300); // 5 minutes timeout

// Database configuration
$host = 'localhost';
$user = 'root';
$pass = '';
$dbname = 'medicare_db';

// Path to SQL file
$sqlFile = '../database/import_this.sql';

echo '<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auto Database Import - MEDIX</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #B91C1C, #991B1B);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 20px;
            padding: 3rem;
            max-width: 700px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        h1 {
            color: #B91C1C;
            text-align: center;
            margin-bottom: 2rem;
        }
        .step {
            background: #F9FAFB;
            padding: 1rem;
            margin: 1rem 0;
            border-radius: 8px;
            border-left: 4px solid #B91C1C;
        }
        .success {
            background: #D1FAE5;
            border-left-color: #10B981;
            color: #065F46;
        }
        .error {
            background: #FEE2E2;
            border-left-color: #EF4444;
            color: #991B1B;
        }
        .info {
            background: #DBEAFE;
            border-left-color: #3B82F6;
            color: #1E40AF;
        }
        .btn {
            display: inline-block;
            background: #B91C1C;
            color: white;
            padding: 1rem 2rem;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
            margin: 0.5rem;
            transition: all 0.3s;
        }
        .btn:hover {
            background: #991B1B;
            transform: translateY(-2px);
        }
        .btn-green {
            background: #10B981;
        }
        .btn-green:hover {
            background: #059669;
        }
        .buttons {
            text-align: center;
            margin-top: 2rem;
        }
        code {
            background: #E5E7EB;
            padding: 0.2rem 0.5rem;
            border-radius: 4px;
            font-family: "Courier New", monospace;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>ðŸš€ Auto Database Import</h1>';

// Step 1: Check if SQL file exists
echo '<div class="step info">
        <strong>Step 1:</strong> Checking SQL file...
      </div>';

if (!file_exists($sqlFile)) {
    echo '<div class="step error">
            <strong>âŒ Error:</strong> SQL file not found at: ' . $sqlFile . '
          </div>';
    echo '<div class="buttons">
            <a href="index.php" class="btn">Back to Dashboard</a>
          </div>
        </div>
    </body>
    </html>';
    exit;
}

echo '<div class="step success">
        <strong>âœ… Success:</strong> SQL file found!
      </div>';

// Step 2: Connect to MySQL
echo '<div class="step info">
        <strong>Step 2:</strong> Connecting to MySQL...
      </div>';

$conn = new mysqli($host, $user, $pass);

if ($conn->connect_error) {
    echo '<div class="step error">
            <strong>âŒ Error:</strong> Could not connect to MySQL: ' . $conn->connect_error . '
            <br><br>
            <strong>Solution:</strong> Make sure MySQL is running in XAMPP Control Panel (should be green)
          </div>';
    echo '<div class="buttons">
            <a href="index.php" class="btn">Back to Dashboard</a>
          </div>
        </div>
    </body>
    </html>';
    exit;
}

echo '<div class="step success">
        <strong>âœ… Success:</strong> Connected to MySQL!
      </div>';

// Step 3: Read SQL file
echo '<div class="step info">
        <strong>Step 3:</strong> Reading SQL file...
      </div>';

$sql = file_get_contents($sqlFile);

if ($sql === false) {
    echo '<div class="step error">
            <strong>âŒ Error:</strong> Could not read SQL file
          </div>';
    echo '<div class="buttons">
            <a href="index.php" class="btn">Back to Dashboard</a>
          </div>
        </div>
    </body>
    </html>';
    exit;
}

echo '<div class="step success">
        <strong>âœ… Success:</strong> SQL file loaded! (' . number_format(strlen($sql)) . ' characters)
      </div>';

// Step 4: Execute SQL
echo '<div class="step info">
        <strong>Step 4:</strong> Importing database... (this may take 10-30 seconds)
      </div>';

// Execute multi-query
if ($conn->multi_query($sql)) {
    // Wait for all queries to complete
    do {
        if ($result = $conn->store_result()) {
            $result->free();
        }
    } while ($conn->more_results() && $conn->next_result());
    
    echo '<div class="step success">
            <strong>âœ… SUCCESS!</strong> Database imported successfully!
          </div>';
    
    // Step 5: Verify data
    echo '<div class="step info">
            <strong>Step 5:</strong> Verifying imported data...
          </div>';
    
    $conn->select_db($dbname);
    
    // Count products
    $result = $conn->query("SELECT COUNT(*) as count FROM products");
    $productCount = $result ? $result->fetch_assoc()['count'] : 0;
    
    // Count customers
    $result = $conn->query("SELECT COUNT(*) as count FROM users");
    $customerCount = $result ? $result->fetch_assoc()['count'] : 0;
    
    // Count orders
    $result = $conn->query("SELECT COUNT(*) as count FROM orders");
    $orderCount = $result ? $result->fetch_assoc()['count'] : 0;
    
    // Count categories
    $result = $conn->query("SELECT COUNT(*) as count FROM categories");
    $categoryCount = $result ? $result->fetch_assoc()['count'] : 0;
    
    echo '<div class="step success">
            <strong>âœ… Database Verified!</strong><br><br>
            ðŸ“¦ Products: <strong>' . $productCount . '</strong><br>
            ðŸ‘¥ Customers: <strong>' . $customerCount . '</strong><br>
            ðŸ›’ Orders: <strong>' . $orderCount . '</strong><br>
            ðŸ·ï¸ Categories: <strong>' . $categoryCount . '</strong>
          </div>';
    
    echo '<div class="step success" style="text-align: center; font-size: 1.2rem;">
            <strong>ðŸŽ‰ ALL DONE!</strong><br><br>
            Your database is now fully imported with real data!<br>
            You can now use all admin features with real products.
          </div>';
    
    echo '<div class="buttons">
            <a href="index.php" class="btn btn-green">Go to Dashboard</a>
            <a href="products.php" class="btn">View Products</a>
          </div>';
    
} else {
    echo '<div class="step error">
            <strong>âŒ Error:</strong> ' . $conn->error . '
          </div>';
    echo '<div class="buttons">
            <a href="index.php" class="btn">Back to Dashboard</a>
          </div>';
}

$conn->close();

echo '    </div>
    </body>
    </html>';
?>

