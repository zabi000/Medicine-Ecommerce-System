// Cart functionality
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// Update cart count
function updateCartCount() {
    const cartCount = document.getElementById('cart-count');
    if (cartCount) {
        cartCount.textContent = cart.length;
    }
}

// Add to cart
function addToCart(productId, productName, productPrice) {
    const product = {
        id: productId,
        name: productName,
        price: productPrice,
        quantity: 1
    };
    
    const existingProduct = cart.find(item => item.id === productId);
    
    if (existingProduct) {
        existingProduct.quantity++;
    } else {
        cart.push(product);
    }
    
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    showNotification('Product added to cart!');
}

// Show notification
function showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background-color: var(--success-color);
        color: white;
        padding: 1rem 2rem;
        border-radius: 8px;
        box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        z-index: 10000;
        animation: slideIn 0.3s ease-out;
    `;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease-out';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Load featured products on homepage
function loadFeaturedProducts() {
    const productsContainer = document.getElementById('products-container');
    if (!productsContainer) return;
    
    fetch('api/get_products.php?limit=8')
        .then(response => response.json())
        .then(products => {
            productsContainer.innerHTML = products.map(product => {
                const imageUrl = `images/products/product-${product.id}.jpg`;
                const stockClass = product.stock > 50 ? 'in-stock' : product.stock > 0 ? 'low-stock' : 'out-of-stock';
                const stockText = product.stock > 50 ? 'In Stock' : product.stock > 0 ? 'Low Stock' : 'Out of Stock';
                
                return `
                <div class="product-card">
                    <div class="product-image-wrapper">
                        <img src="${imageUrl}" alt="${product.name}" onerror="this.style.display='none'; this.parentElement.innerHTML='<div class=\\'product-img-placeholder\\'>${product.icon || '💊'}</div>'">
                        ${product.id <= 4 ? '<span class="product-badge new">NEW</span>' : ''}
                    </div>
                    <div class="product-info">
                        <span class="stock-status ${stockClass}">${stockText}</span>
                        <h3>${product.name}</h3>
                        <div class="product-rating">
                            <span class="stars">★★★★★</span>
                            <span class="rating-count">(${Math.floor(Math.random() * 500) + 50})</span>
                        </div>
                        <p>${product.description}</p>
                        <div class="product-price">$${parseFloat(product.price).toFixed(2)}</div>
                        <button class="btn-add-cart" onclick="addToCart(${product.id}, '${product.name}', ${product.price})" ${product.stock === 0 ? 'disabled' : ''}>
                            ${product.stock === 0 ? 'Out of Stock' : 'Add to Cart'}
                        </button>
                    </div>
                </div>
            `}).join('');
        })
        .catch(error => console.error('Error loading products:', error));
}

// Load all products
function loadProducts(category = '') {
    const productsContainer = document.getElementById('products-container');
    if (!productsContainer) return;
    
    let url = 'api/get_products.php';
    if (category) {
        url += `?category=${category}`;
    }
    
    fetch(url)
        .then(response => response.json())
        .then(products => {
            if (products.length === 0) {
                productsContainer.innerHTML = '<p style="text-align: center; grid-column: 1/-1; color: var(--text-light);">No products found.</p>';
                return;
            }
            
            productsContainer.innerHTML = products.map(product => {
                const imageUrl = `images/products/product-${product.id}.jpg`;
                const stockClass = product.stock > 50 ? 'in-stock' : product.stock > 0 ? 'low-stock' : 'out-of-stock';
                const stockText = product.stock > 50 ? 'In Stock' : product.stock > 0 ? 'Low Stock' : 'Out of Stock';
                
                return `
                <div class="product-card">
                    <div class="product-image-wrapper">
                        <img src="${imageUrl}" alt="${product.name}" onerror="this.style.display='none'; this.parentElement.innerHTML='<div class=\\'product-img-placeholder\\'>${product.icon || '💊'}</div>'">
                        ${product.id <= 4 ? '<span class="product-badge new">NEW</span>' : ''}
                    </div>
                    <div class="product-info">
                        <span class="stock-status ${stockClass}">${stockText}</span>
                        <h3>${product.name}</h3>
                        <div class="product-rating">
                            <span class="stars">★★★★★</span>
                            <span class="rating-count">(${Math.floor(Math.random() * 500) + 50})</span>
                        </div>
                        <p>${product.description}</p>
                        <div class="product-price">$${parseFloat(product.price).toFixed(2)}</div>
                        <button class="btn-add-cart" onclick="addToCart(${product.id}, '${product.name}', ${product.price})" ${product.stock === 0 ? 'disabled' : ''}>
                            ${product.stock === 0 ? 'Out of Stock' : 'Add to Cart'}
                        </button>
                    </div>
                </div>
            `}).join('');
        })
        .catch(error => console.error('Error loading products:', error));
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    updateCartCount();
    
    // Load products based on page
    if (document.getElementById('products-container')) {
        const urlParams = new URLSearchParams(window.location.search);
        const category = urlParams.get('category');
        
        if (window.location.pathname.includes('index.html') || window.location.pathname === '/') {
            loadFeaturedProducts();
        } else {
            loadProducts(category);
        }
    }
});

// Add CSS animations
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);


// Scroll to top button
const scrollTopBtn = document.getElementById('scrollTop');

if (scrollTopBtn) {
    window.addEventListener('scroll', function() {
        if (window.pageYOffset > 300) {
            scrollTopBtn.classList.add('visible');
        } else {
            scrollTopBtn.classList.remove('visible');
        }
        
        // Add scrolled class to header
        const header = document.querySelector('header');
        if (window.pageYOffset > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
    
    scrollTopBtn.addEventListener('click', function() {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
}

// Animate elements on scroll
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver(function(entries) {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Observe elements with animation
document.addEventListener('DOMContentLoaded', function() {
    const animatedElements = document.querySelectorAll('.category-card, .product-card, .stat-item');
    
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(30px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
});

// Enhanced add to cart with animation
function addToCartEnhanced(productId, productName, productPrice, buttonElement) {
    addToCart(productId, productName, productPrice);
    
    // Button animation
    if (buttonElement) {
        const originalText = buttonElement.textContent;
        buttonElement.textContent = '✓ Added!';
        buttonElement.style.background = 'linear-gradient(135deg, var(--success-color), #00e5a0)';
        
        setTimeout(() => {
            buttonElement.textContent = originalText;
            buttonElement.style.background = '';
        }, 2000);
    }
}

// Loading state for products
function showLoading() {
    const container = document.getElementById('products-container');
    if (container) {
        container.innerHTML = '<div class="loading-container"><div class="loading"></div><p>Loading products...</p></div>';
    }
}

// Update loadFeaturedProducts to show loading
const originalLoadFeatured = loadFeaturedProducts;
loadFeaturedProducts = function() {
    showLoading();
    originalLoadFeatured();
};

// Update loadProducts to show loading
const originalLoadProducts = loadProducts;
loadProducts = function(category) {
    showLoading();
    originalLoadProducts(category);
};
