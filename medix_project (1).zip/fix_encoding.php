<?php
// COMPREHENSIVE FIX for index.html
// Run at: http://localhost/ppp/fix_encoding.php

$file = __DIR__ . '/index.html';
$content = file_get_contents($file);

// ===== 1. Fix broken emoji by byte patterns =====
$byte_fixes = [
    // Category icons
    "\xc3\xb0\xc5\xb8\xe2\x80\x99\xc5\xa0"     => '<i class="bi bi-capsule-pill" style="font-size:2rem;color:#B91C1C"></i>',
    "\xc3\xb0\xc5\xb8\xc2\xa9\xc2\xb9"          => '<i class="bi bi-bandaid-fill" style="font-size:2rem;color:#B91C1C"></i>',
    "\xc3\xb0\xc5\xb8\xe2\x80\x99\xe2\x80\xb0"  => '<i class="bi bi-heart-pulse-fill" style="font-size:2rem;color:#B91C1C"></i>',
    "\xc3\xb0\xc5\xb8\xc5\x92\xc2\xa1\xc3\xaf\xc2\xb8" => '<i class="bi bi-thermometer-half" style="font-size:2rem;color:#B91C1C"></i>',
    "\xc3\xb0\xc5\xb8\xc2\xa7\xc2\xb4"          => '<i class="bi bi-droplet-fill" style="font-size:2rem;color:#B91C1C"></i>',
    "\xc3\xb0\xc5\xb8\xe2\x80\x99\xc2\xb6"      => '<i class="bi bi-emoji-smile-fill" style="font-size:2rem;color:#B91C1C"></i>',
    // Ad banner
    "\xc3\xb0\xc5\xb8\xc2\xa5"                  => '<i class="bi bi-hospital-fill" style="font-size:2rem;color:#B91C1C"></i>',
    "\xc3\xb0\xc5\xb8\xc2\xa9\xc2\xba"          => '<i class="bi bi-stethoscope" style="font-size:4rem;color:#B91C1C"></i>',
    // Health tips title
    "\xc3\xb0\xc5\xb8\xe2\x80\x99\xc2\xa1"      => '<i class="bi bi-lightbulb-fill text-warning"></i>',
    // Health tip icons
    "\xc3\xb0\xc5\xb8\xc6\x92"                  => '<i class="bi bi-person-walking" style="font-size:2rem;color:#B91C1C"></i>',
    "\xc3\xb0\xc5\xb8\xc2\xa5\xe2\x80\x94"      => '<i class="bi bi-egg-fried" style="font-size:2rem;color:#B91C1C"></i>',
    "\xc3\xb0\xc5\xb8\xe2\x80\x99\xc2\xa4"      => '<i class="bi bi-moon-stars-fill" style="font-size:2rem;color:#B91C1C"></i>',
    "\xc3\xb0\xc5\xb8\xe2\x80\x99\xc2\xa7"      => '<i class="bi bi-droplet-half" style="font-size:2rem;color:#B91C1C"></i>',
    // App banner
    "\xc3\xb0\xc5\xb8\xc5\xbd"                  => '<i class="bi bi-gift-fill"></i>',
    "\xc3\xb0\xc5\xb8\xe2\x80\x9c\xc2\xb1"      => '<i class="bi bi-phone-fill"></i>',
    "\xc3\xb0\xc5\xb8\xc2\xa4\xe2\x80\x93"      => '<i class="bi bi-robot"></i>',
    // Trust badges
    "\xc3\xb0\xc5\xb8\xe2\x80\x9c\xe2\x80\x99"  => '<i class="bi bi-lock-fill"></i>',
    "\xc3\xb0\xc5\xb8\xc5\xa1\xc5\xa1"          => '<i class="bi bi-truck-front-fill"></i>',
    "\xc3\xb0\xc5\xb8\xe2\x80\x99\xc2\xaf"      => '<i class="bi bi-award-fill"></i>',
    // Broken checkmark
    "\xc3\xa2\xe2\x80\x9a\xc2\xac"              => '<i class="bi bi-check-circle-fill text-success"></i>',
    // Broken arrow
    "\xc3\xa2\xe2\x80\xa0\xe2\x80\x98"          => '&rarr;',
    "\xc3\xa2\xe2\x80\x9e\xe2\x80\x98"          => '&rarr;',
    // Broken Urdu
    "\xc3\x98\xc2\xa7\xc3\x98\xc2\xb1\xc3\x98\xc2\xaf\xc3\x99\xcb\x86" => 'اردو',
];

foreach ($byte_fixes as $broken => $fixed) {
    $content = str_replace($broken, $fixed, $content);
}

// ===== 2. Fix broken star ratings =====
// Replace any remaining â˜… sequences
$content = preg_replace('/\xc3\xa2\xcb\x9c[\x80-\xbf]/', '<i class="bi bi-star-fill text-warning" style="font-size:.8rem"></i>', $content);

// ===== 3. Fix Rs. → PKR =====
$content = str_replace('Rs. ', 'PKR ', $content);

// ===== 4. Fix broken brand images — replace with icon cards =====
$brands = [
    'GSK'              => ['#F36633', 'bi-heart-pulse-fill'],
    'Johnson &amp; Johnson' => ['#CC0000', 'bi-bandaid-fill'],
    'Novartis'         => ['#0460A9', 'bi-shield-fill-check'],
    'Bayer'            => ['#10384F', 'bi-droplet-fill'],
    'Abbott'           => ['#0066CC', 'bi-activity'],
    'Merck'            => ['#009999', 'bi-prescription2'],
];

foreach ($brands as $name => $info) {
    [$color, $icon] = $info;
    $display = html_entity_decode($name);
    // Replace broken img tag with icon
    $content = preg_replace(
        '/<img[^>]+alt="' . preg_quote($name, '/') . '"[^>]*>/i',
        '<div style="width:60px;height:60px;background:' . $color . '22;border-radius:12px;display:flex;align-items:center;justify-content:center;margin:0 auto"><i class="bi ' . $icon . '" style="font-size:1.75rem;color:' . $color . '"></i></div>',
        $content
    );
}

// ===== 5. Save =====
file_put_contents($file, $content);

echo '<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Fix Complete</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head><body style="font-family:sans-serif;padding:2rem;background:#f8fafc">';
echo '<div class="alert alert-success"><i class="bi bi-check-circle-fill me-2"></i><strong>Fix Complete!</strong> All broken characters have been replaced.</div>';
echo '<p>Now visit: <a href="index.php" class="btn btn-danger btn-sm">Homepage</a></p>';
echo '<p class="text-muted small">Press <kbd>Ctrl+Shift+R</kbd> on the homepage to clear browser cache.</p>';
echo '</body></html>';
?>
