<?php
session_start();

// Simple authentication check
if (!isset($_SESSION['user_logged_in'])) {
    header('Location: ../login.html');
    exit();
}

$user_name = $_SESSION['user_name'] ?? 'User';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Dashboard - Medix</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .dashboard-sidebar {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        
        .dashboard-menu a {
            display: flex;
            align-items: center;
            padding: 0.75rem 1rem;
            color: #6B7280;
            text-decoration: none;
            border-radius: 8px;
            margin-bottom: 0.5rem;
            transition: all 0.3s;
        }
        
        .dashboard-menu a:hover,
        .dashboard-menu a.active {
            background: #B91C1C;
            color: white;
        }
        
        .dashboard-menu a i {
            margin-right: 0.75rem;
            font-size: 1.2rem;
        }
        
        .dashboard-card {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-bottom: 1.5rem;
        }
        
        .order-item {
            border: 2px solid #E5E7EB;
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            transition: all 0.3s;
        }
        
        .order-item:hover {
            border-color: #B91C1C;
            box-shadow: 0 4px 12px rgba(185, 28, 28, 0.1);
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header>
        <nav class="navbar navbar-expand-lg navbar-dark" style="background: linear-gradient(135deg, #B91C1C, #991B1B);">
            <div class="container">
                <a class="navbar-brand" href="../index.html">
                    <i class="bi bi-heart-pulse-fill me-2"></i>
                    <span class="fw-bold">MEDIX</span>
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="../index.html">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="../products.php">Products</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" href="dashboard.php">My Account</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php">Logout</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <div class="container my-5">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3">
                <div class="dashboard-sidebar">
                    <div class="text-center mb-4">
                        <div class="bg-danger bg-opacity-10 rounded-circle d-inline-flex align-items-center justify-content-center" style="width: 80px; height: 80px;">
                            <i class="bi bi-person-circle text-danger" style="font-size: 3rem;"></i>
                        </div>
                        <h5 class="mt-2 mb-0"><?= htmlspecialchars($user_name) ?></h5>
                        <small class="text-muted">Customer</small>
                    </div>
                    <div class="dashboard-menu">
                        <a href="dashboard.php" class="active">
                            <i class="bi bi-speedometer2"></i> Dashboard
                        </a>
                        <a href="orders.php">
                            <i class="bi bi-bag-check"></i> My Orders
                        </a>
                        <a href="profile.php">
                            <i class="bi bi-person"></i> Profile
                        </a>
                        <a href="addresses.php">
                            <i class="bi bi-geo-alt"></i> Addresses
                        </a>
                        <a href="wishlist.php">
                            <i class="bi bi-heart"></i> Wishlist
                        </a>
                        <a href="logout.php">
                            <i class="bi bi-box-arrow-right"></i> Logout
                        </a>
                    </div>
                </div>
            </div>

            <!-- Main Content -->
            <div class="col-md-9">
                <!-- Welcome Card -->
                <div class="dashboard-card">
                    <h4>Welcome back, <?= htmlspecialchars($user_name) ?>! 👋</h4>
                    <p class="text-muted mb-0">Here's what's happening with your account today.</p>
                </div>

                <!-- Stats -->
                <div class="row g-3 mb-4">
                    <div class="col-md-4">
                        <div class="dashboard-card text-center">
                            <i class="bi bi-bag-check text-success" style="font-size: 2.5rem;"></i>
                            <h3 class="mt-2 mb-0">12</h3>
                            <p class="text-muted mb-0">Total Orders</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="dashboard-card text-center">
                            <i class="bi bi-clock-history text-warning" style="font-size: 2.5rem;"></i>
                            <h3 class="mt-2 mb-0">3</h3>
                            <p class="text-muted mb-0">Pending Orders</p>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="dashboard-card text-center">
                            <i class="bi bi-heart text-danger" style="font-size: 2.5rem;"></i>
                            <h3 class="mt-2 mb-0">8</h3>
                            <p class="text-muted mb-0">Wishlist Items</p>
                        </div>
                    </div>
                </div>

                <!-- Recent Orders -->
                <div class="dashboard-card">
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5 class="mb-0">Recent Orders</h5>
                        <a href="orders.php" class="btn btn-sm btn-danger">View All</a>
                    </div>

                    <div class="order-item">
                        <div class="row align-items-center">
                            <div class="col-md-2">
                                <i class="bi bi-capsule-pill text-danger" style="font-size: 3rem;"></i>
                            </div>
                            <div class="col-md-6">
                                <h6 class="mb-1">Paracetamol 500mg</h6>
                                <small class="text-muted">Order #ORD-1234 • Jan 15, 2024</small>
                            </div>
                            <div class="col-md-2">
                                <span class="badge bg-success">Delivered</span>
                            </div>
                            <div class="col-md-2 text-end">
                                <h6 class="mb-0">$5.99</h6>
                                <button class="btn btn-sm btn-outline-danger mt-2">Track</button>
                            </div>
                        </div>
                    </div>

                    <div class="order-item">
                        <div class="row align-items-center">
                            <div class="col-md-2">
                                <i class="bi bi-heart-pulse text-danger" style="font-size: 3rem;"></i>
                            </div>
                            <div class="col-md-6">
                                <h6 class="mb-1">Vitamin D3 1000 IU</h6>
                                <small class="text-muted">Order #ORD-1235 • Jan 14, 2024</small>
                            </div>
                            <div class="col-md-2">
                                <span class="badge bg-warning">Processing</span>
                            </div>
                            <div class="col-md-2 text-end">
                                <h6 class="mb-0">$14.99</h6>
                                <button class="btn btn-sm btn-outline-danger mt-2">Track</button>
                            </div>
                        </div>
                    </div>

                    <div class="order-item">
                        <div class="row align-items-center">
                            <div class="col-md-2">
                                <i class="bi bi-bandaid-fill text-danger" style="font-size: 3rem;"></i>
                            </div>
                            <div class="col-md-6">
                                <h6 class="mb-1">First Aid Kit</h6>
                                <small class="text-muted">Order #ORD-1236 • Jan 13, 2024</small>
                            </div>
                            <div class="col-md-2">
                                <span class="badge bg-info">Shipped</span>
                            </div>
                            <div class="col-md-2 text-end">
                                <h6 class="mb-0">$24.99</h6>
                                <button class="btn btn-sm btn-outline-danger mt-2">Track</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="dashboard-card">
                    <h5 class="mb-3">Quick Actions</h5>
                    <div class="row g-3">
                        <div class="col-md-3">
                            <a href="../products.php" class="btn btn-outline-danger w-100">
                                <i class="bi bi-shop"></i><br>Shop Now
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="orders.php" class="btn btn-outline-danger w-100">
                                <i class="bi bi-bag-check"></i><br>Track Order
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="wishlist.php" class="btn btn-outline-danger w-100">
                                <i class="bi bi-heart"></i><br>Wishlist
                            </a>
                        </div>
                        <div class="col-md-3">
                            <a href="../contact.html" class="btn btn-outline-danger w-100">
                                <i class="bi bi-headset"></i><br>Support
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
