// Load cart items
function loadCart() {
    const cartContent = document.getElementById('cart-content');
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    
    if (cart.length === 0) {
        cartContent.innerHTML = '<p style="text-align: center; padding: 3rem;">Your cart is empty.</p>';
        return;
    }
    
    let total = 0;
    
    const cartHTML = `
        <div class="cart-items">
            ${cart.map((item, index) => {
                const itemTotal = item.price * item.quantity;
                total += itemTotal;
                return `
                    <div class="cart-item">
                        <div>
                            <h3>${item.name}</h3>
                            <p>Price: $${parseFloat(item.price).toFixed(2)}</p>
                        </div>
                        <div style="display: flex; align-items: center; gap: 1rem;">
                            <button onclick="updateQuantity(${index}, -1)" style="padding: 0.5rem 1rem; cursor: pointer;">-</button>
                            <span>${item.quantity}</span>
                            <button onclick="updateQuantity(${index}, 1)" style="padding: 0.5rem 1rem; cursor: pointer;">+</button>
                            <span style="font-weight: 700; margin-left: 1rem;">$${itemTotal.toFixed(2)}</span>
                            <button onclick="removeItem(${index})" style="padding: 0.5rem 1rem; background-color: var(--danger-color); color: white; border: none; border-radius: 5px; cursor: pointer;">Remove</button>
                        </div>
                    </div>
                `;
            }).join('')}
        </div>
        <div class="cart-summary">
            <h3>Order Summary</h3>
            <div class="cart-total">Total: $${total.toFixed(2)}</div>
            <button class="btn-submit" onclick="checkout()">Proceed to Checkout</button>
        </div>
    `;
    
    cartContent.innerHTML = cartHTML;
}

function updateQuantity(index, change) {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart[index].quantity += change;
    
    if (cart[index].quantity <= 0) {
        cart.splice(index, 1);
    }
    
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    loadCart();
}

function removeItem(index) {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart.splice(index, 1);
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
    loadCart();
}

function checkout() {
    window.location.href = 'checkout.php';
}

document.addEventListener('DOMContentLoaded', loadCart);
