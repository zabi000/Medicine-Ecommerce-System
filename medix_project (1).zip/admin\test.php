﻿<?php
// Test page to check if everything is working
echo "<h1>MEDIX Admin Test Page</h1>";
echo "<hr>";

// Check PHP version
echo "<h2>âœ“ PHP Version: " . phpversion() . "</h2>";

// Check if session works
session_start();
echo "<h2>âœ“ Sessions Working</h2>";

// Check database connection
require_once('../api/config.php');

if ($conn) {
    echo "<h2>âœ“ Database Connected</h2>";
    
    // Check if tables exist
    $tables = ['users', 'products', 'orders', 'categories'];
    echo "<h3>Tables Status:</h3>";
    echo "<ul>";
    foreach ($tables as $table) {
        $result = @$conn->query("SELECT COUNT(*) as count FROM $table");
        if ($result) {
            $count = $result->fetch_assoc()['count'];
            echo "<li><strong>$table:</strong> $count records âœ“</li>";
        } else {
            echo "<li><strong>$table:</strong> NOT FOUND âœ—</li>";
        }
    }
    echo "</ul>";
} else {
    echo "<h2>âœ— Database NOT Connected</h2>";
    echo "<p>Error: " . mysqli_connect_error() . "</p>";
}

echo "<hr>";
echo "<h3>Next Steps:</h3>";
echo "<ol>";
echo "<li>If database is NOT connected, check XAMPP MySQL is running</li>";
echo "<li>If tables NOT FOUND, import database: <code>database/import_this.sql</code></li>";
echo "<li>If everything is OK, <a href='login.php'>Go to Admin Login</a></li>";
echo "</ol>";

echo "<hr>";
echo "<h3>Quick Links:</h3>";
echo "<a href='login.php' style='padding: 10px 20px; background: #B91C1C; color: white; text-decoration: none; border-radius: 5px; display: inline-block; margin: 5px;'>Admin Login</a>";
echo "<a href='http://localhost/phpmyadmin' target='_blank' style='padding: 10px 20px; background: #6B7280; color: white; text-decoration: none; border-radius: 5px; display: inline-block; margin: 5px;'>phpMyAdmin</a>";
?>

