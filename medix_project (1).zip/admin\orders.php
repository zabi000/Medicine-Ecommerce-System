﻿<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) { header('Location: login.php'); exit(); }
require_once('../api/config.php');

if (!$conn) { die('<div style="padding:2rem;color:red;font-family:sans-serif"><h3>Database connection failed.</h3></div>'); }

$col_check = $conn->query("SHOW COLUMNS FROM orders LIKE 'customer_name'");
$has_cust  = ($col_check && $col_check->num_rows > 0);

$success_msg = '';
$error_msg   = '';

// Confirm Payment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_payment'])) {
    $oid = intval($_POST['order_id']);
    $stmt = $conn->prepare("UPDATE orders SET status='processing' WHERE id=?");
    $stmt->bind_param("i", $oid);
    if ($stmt->execute()) {
        // Auto-add customer to users table
        if ($has_cust) {
            $oq = $conn->query("SELECT customer_name,customer_email,customer_phone FROM orders WHERE id=$oid");
            if ($oq && $row = $oq->fetch_assoc()) {
                $cn = $row['customer_name'];
                $ce = $row['customer_email'];
                $cp = $row['customer_phone'];
                if ($ce) {
                    $chk = $conn->prepare("SELECT id FROM users WHERE email=?");
                    $chk->bind_param("s", $ce);
                    $chk->execute();
                    if ($chk->get_result()->num_rows === 0) {
                        $pw = password_hash('guest_' . bin2hex(random_bytes(4)), PASSWORD_DEFAULT);
                        $ucols = [];
                        $ucr = $conn->query("SHOW COLUMNS FROM users");
                        while ($uc = $ucr->fetch_assoc()) $ucols[] = $uc['Field'];
                        $nc = in_array('name', $ucols) ? 'name' : (in_array('username', $ucols) ? 'username' : null);
                        if ($nc) {
                            $ins = $conn->prepare("INSERT IGNORE INTO users ($nc,email,phone,password) VALUES (?,?,?,?)");
                            $ins->bind_param("ssss", $cn, $ce, $cp, $pw);
                            $ins->execute();
                        }
                    }
                }
            }
        }
        $success_msg = "Payment confirmed! Order #$oid is now processing.";
    } else {
        $error_msg = "Failed to confirm payment.";
    }
    $stmt->close();
}

// Update Status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $oid    = intval($_POST['order_id']);
    $status = $_POST['status'] ?? '';
    $valid  = ['pending','processing','delivered','cancelled'];
    if (in_array($status, $valid)) {
        $stmt = $conn->prepare("UPDATE orders SET status=? WHERE id=?");
        $stmt->bind_param("si", $status, $oid);
        $stmt->execute() ? $success_msg = "Order #$oid updated to $status." : $error_msg = "Update failed.";
        $stmt->close();
    }
}

// Stats
$total_orders = $conn->query("SELECT COUNT(*) c FROM orders")->fetch_assoc()['c'] ?? 0;
$pending      = $conn->query("SELECT COUNT(*) c FROM orders WHERE status='pending'")->fetch_assoc()['c'] ?? 0;
$processing   = $conn->query("SELECT COUNT(*) c FROM orders WHERE status='processing'")->fetch_assoc()['c'] ?? 0;
$delivered    = $conn->query("SELECT COUNT(*) c FROM orders WHERE status='delivered'")->fetch_assoc()['c'] ?? 0;

// Fetch orders - always use customer_name from orders table first (what they typed at checkout)
if ($has_cust) {
    $sql = "SELECT o.*,
        CASE WHEN o.customer_name IS NOT NULL AND o.customer_name != '' THEN o.customer_name
             ELSE COALESCE(u.name, u.username, 'Guest') END AS cname,
        CASE WHEN o.customer_email IS NOT NULL AND o.customer_email != '' THEN o.customer_email
             ELSE COALESCE(u.email, '') END AS cemail,
        CASE WHEN o.customer_phone IS NOT NULL AND o.customer_phone != '' THEN o.customer_phone
             ELSE COALESCE(u.phone, '') END AS cphone
        FROM orders o LEFT JOIN users u ON o.user_id=u.id
        ORDER BY o.created_at DESC";
} else {
    $sql = "SELECT o.*, COALESCE(u.name, u.username, 'Guest') AS cname, COALESCE(u.email,'') AS cemail, COALESCE(u.phone,'') AS cphone FROM orders o LEFT JOIN users u ON o.user_id=u.id ORDER BY o.created_at DESC";
}
$orders = $conn->query($sql);
if (!$orders) { $error_msg = "Query error: " . $conn->error; $orders = null; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Orders - MEDIX Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{--sw:280px;--red:#B91C1C}
*{box-sizing:border-box}
body{font-family:'Inter',sans-serif;background:#F3F4F6;margin:0}
.sidebar{position:fixed;top:0;left:0;width:var(--sw);height:100vh;background:linear-gradient(180deg,#B91C1C,#7F1D1D);overflow-y:auto;z-index:1000}
.sb-brand{padding:1.5rem;border-bottom:1px solid rgba(255,255,255,.1);color:white}
.mi{display:flex;align-items:center;gap:.75rem;padding:.875rem 1.5rem;color:rgba(255,255,255,.8);text-decoration:none;border-left:3px solid transparent;transition:all .2s;font-weight:500}
.mi:hover,.mi.active{background:rgba(255,255,255,.15);color:white;border-left-color:white}
.mi i{width:20px}
.mdiv{height:1px;background:rgba(255,255,255,.1);margin:.5rem 1.5rem}
.main{margin-left:var(--sw);padding:2rem;min-height:100vh}
.topbar{background:white;border-bottom:3px solid var(--red);padding:1.25rem 2rem;margin:-2rem -2rem 2rem;display:flex;justify-content:space-between;align-items:center;box-shadow:0 2px 6px rgba(0,0,0,.08)}
.sc{background:white;border-radius:16px;padding:1.5rem;box-shadow:0 1px 3px rgba(0,0,0,.08);text-align:center;border-top:3px solid var(--red)}
.sc i{font-size:2.5rem}
.sc h3{font-weight:700;font-size:1.75rem;margin:.5rem 0 0}
.tc{background:white;border-radius:16px;padding:1.5rem;box-shadow:0 1px 3px rgba(0,0,0,.08)}
.table thead th{font-size:.72rem;font-weight:700;color:#64748b;text-transform:uppercase;border-bottom:2px solid #e2e8f0;padding:.75rem;background:#f8fafc}
.table tbody td{padding:.75rem;vertical-align:middle;font-size:.875rem;border-bottom:1px solid #f1f5f9}
.table tbody tr:hover{background:#f8fafc}
.av{width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,#B91C1C,#991B1B);color:white;display:flex;align-items:center;justify-content:center;font-weight:700;font-size:.85rem;flex-shrink:0}
</style>
</head>
<body>
<div class="sidebar">
    <div class="sb-brand"><h4 class="mb-0 fw-bold"><i class="bi bi-heart-pulse-fill me-2"></i>MEDIX</h4><small style="opacity:.6">Admin Portal</small></div>
    <a href="index.php" class="mi"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="products.php" class="mi"><i class="bi bi-box-seam"></i>Products</a>
    <a href="offers.php" class="mi"><i class="bi bi-tag-fill"></i>Offers</a>
    <a href="orders.php" class="mi active"><i class="bi bi-cart-check"></i>Orders</a>
    <a href="customers.php" class="mi"><i class="bi bi-people"></i>Customers</a>
    <a href="categories.php" class="mi"><i class="bi bi-tags"></i>Categories</a>
    <a href="messages.php" class="mi"><i class="bi bi-envelope"></i>Messages</a>
    <a href="reports.php" class="mi"><i class="bi bi-graph-up"></i>Reports</a>
    <a href="settings.php" class="mi"><i class="bi bi-gear"></i>Settings</a>
    <div class="mdiv"></div>
    <a href="database.php" class="mi"><i class="bi bi-database"></i>Database</a>
    <a href="import_medicines.php" class="mi" style="color:#10B981"><i class="bi bi-capsule-pill"></i>Import Medicines</a>
    <div class="mdiv"></div>
    <a href="logout.php" class="mi"><i class="bi bi-box-arrow-right"></i>Logout</a>
</div>
<div class="main">
    <div class="topbar">
        <div><h4 class="mb-0 fw-bold"><i class="bi bi-cart-check me-2 text-danger"></i>Orders Management</h4><small class="text-muted">View and manage all customer orders</small></div>
    </div>

    <?php if ($success_msg): ?>
    <div class="alert alert-success alert-dismissible fade show"><i class="bi bi-check-circle me-2"></i><?= htmlspecialchars($success_msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endif; ?>
    <?php if ($error_msg): ?>
    <div class="alert alert-danger alert-dismissible fade show"><i class="bi bi-exclamation-triangle me-2"></i><?= htmlspecialchars($error_msg) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
    <?php endif; ?>

    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3"><div class="sc"><i class="bi bi-cart-check text-primary"></i><h3><?= $total_orders ?></h3><p class="text-muted small mb-0">Total Orders</p></div></div>
        <div class="col-6 col-md-3"><div class="sc"><i class="bi bi-clock-history text-warning"></i><h3><?= $pending ?></h3><p class="text-muted small mb-0">Pending</p></div></div>
        <div class="col-6 col-md-3"><div class="sc"><i class="bi bi-truck text-info"></i><h3><?= $processing ?></h3><p class="text-muted small mb-0">Processing</p></div></div>
        <div class="col-6 col-md-3"><div class="sc"><i class="bi bi-check-circle text-success"></i><h3><?= $delivered ?></h3><p class="text-muted small mb-0">Delivered</p></div></div>
    </div>

    <div class="tc">
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h6 class="mb-0 fw-bold">All Orders <span class="badge bg-danger ms-2"><?= $orders ? $orders->num_rows : 0 ?></span></h6>
            <div class="d-flex gap-2">
                <input type="text" class="form-control form-control-sm" id="srch" placeholder="Search..." style="width:200px">
                <select class="form-select form-select-sm" id="stFilter" style="width:140px">
                    <option value="">All Status</option>
                    <option value="pending">Pending</option>
                    <option value="processing">Processing</option>
                    <option value="delivered">Delivered</option>
                    <option value="cancelled">Cancelled</option>
                </select>
            </div>
        </div>
        <div class="table-responsive">
        <table class="table table-hover" id="ordTbl">
        <thead><tr>
            <th>Order ID</th><th>Customer</th><th>Contact</th>
            <th>Amount</th><th>Payment</th><th>Status</th><th>Date</th><th class="text-center">Actions</th>
        </tr></thead>
        <tbody>
        <?php if ($orders && $orders->num_rows > 0):
            while ($o = $orders->fetch_assoc()):
                $sid  = str_pad($o['id'], 4, '0', STR_PAD_LEFT);
                $init = strtoupper(substr($o['cname'] ?: 'G', 0, 1));
                $pm   = $o['payment_method'] ?? 'Cash on Delivery';
                $st   = $o['status'] ?? 'pending';
                $badge = ['pending'=>'warning','processing'=>'success','delivered'=>'primary','cancelled'=>'danger'][$st] ?? 'secondary';
                $label = ['pending'=>'Pending','processing'=>'Confirmed','delivered'=>'Delivered','cancelled'=>'Cancelled'][$st] ?? ucfirst($st);
        ?>
        <tr data-search="<?= strtolower(htmlspecialchars($o['cname'].' '.$o['cemail'].' '.$sid)) ?>" data-status="<?= $st ?>">
            <td><strong class="text-danger">#ORD-<?= $sid ?></strong></td>
            <td>
                <div class="d-flex align-items-center gap-2">
                    <div class="av"><?= $init ?></div>
                    <strong><?= htmlspecialchars($o['cname']) ?></strong>
                </div>
            </td>
            <td>
                <div class="small"><?= htmlspecialchars($o['cemail']) ?></div>
                <div class="small text-muted"><?= htmlspecialchars($o['cphone']) ?></div>
            </td>
            <td><strong>PKR <?= number_format($o['total_amount'], 2) ?></strong></td>
            <td>
                <small class="text-muted"><?= htmlspecialchars($pm) ?></small>
                <?php if (!empty($o['payment_proof'])): ?>
                <br><span class="badge bg-success mt-1" style="font-size:.65rem"><i class="bi bi-image-fill me-1"></i>Screenshot</span>
                <?php elseif ($st === 'pending' && stripos($pm, 'cash') === false): ?>
                <br><span class="badge bg-warning text-dark mt-1" style="font-size:.65rem"><i class="bi bi-clock me-1"></i>Awaiting proof</span>
                <?php endif; ?>
            </td>
            <td><span class="badge bg-<?= $badge ?>"><?= $label ?></span></td>
            <td><small class="text-muted"><?= date('M d, Y', strtotime($o['created_at'])) ?></small></td>
            <td class="text-center">
                <div class="d-flex gap-1 justify-content-center">
                    <button class="btn btn-sm btn-outline-primary" onclick="viewOrderItems(<?= $o['id'] ?>, '#ORD-<?= $sid ?>')">
                        <i class="bi bi-eye me-1"></i>View
                    </button>
                    <button class="btn btn-sm btn-outline-secondary"
                            data-bs-toggle="modal" data-bs-target="#stModal"
                            data-id="<?= $o['id'] ?>" data-status="<?= $st ?>">
                        <i class="bi bi-pencil"></i>
                    </button>
                </div>
            </td>
        </tr>
        <?php endwhile; else: ?>
        <tr><td colspan="8" class="text-center py-5 text-muted">
            <i class="bi bi-inbox" style="font-size:3rem;display:block;margin-bottom:.75rem"></i>
            No orders found. Place an order from the store first.
        </td></tr>
        <?php endif; ?>
        </tbody>
        </table>
        </div>
    </div>
</div>

<!-- Order Items Modal -->
<div class="modal fade" id="itemsModal" tabindex="-1">
<div class="modal-dialog modal-lg">
<div class="modal-content">
<div class="modal-header" style="background:linear-gradient(135deg,#1e293b,#334155)">
    <h5 class="modal-title text-white"><i class="bi bi-bag-check me-2"></i>Order Details</h5>
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
</div>
<div class="modal-body p-0">
    <!-- Order Info Header -->
    <div id="orderInfoHeader" style="background:#f8fafc;padding:1rem 1.5rem;border-bottom:1px solid #e2e8f0"></div>
    <!-- Items Table -->
    <div id="orderItemsBody" style="padding:1.5rem">
        <div class="text-center py-4"><div class="spinner-border text-danger" role="status"></div><p class="mt-2 text-muted">Loading order items...</p></div>
    </div>
</div>
<div class="modal-footer" id="orderModalFooter">
    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
</div>
</div>
</div>
</div>

<!-- Update Status Modal -->
<div class="modal fade" id="stModal" tabindex="-1">
<div class="modal-dialog"><div class="modal-content">
<div class="modal-header bg-danger text-white">
    <h5 class="modal-title"><i class="bi bi-pencil me-2"></i>Update Order Status</h5>
    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
</div>
<form method="POST">
<div class="modal-body">
    <input type="hidden" name="order_id" id="modalOid">
    <p class="text-muted small mb-3">Order: <strong id="modalOrderLabel"></strong></p>
    <label class="form-label fw-semibold">Change Status To</label>
    <div class="d-grid gap-2" id="statusButtons">
        <button type="button" class="status-opt btn btn-outline-warning text-start" data-val="pending">
            <i class="bi bi-clock-history me-2"></i><strong>Pending</strong> — Awaiting payment verification
        </button>
        <button type="button" class="status-opt btn btn-outline-success text-start" data-val="processing">
            <i class="bi bi-check-circle me-2"></i><strong>Confirmed</strong> — Payment verified, preparing order
        </button>
        <button type="button" class="status-opt btn btn-outline-primary text-start" data-val="delivered">
            <i class="bi bi-truck me-2"></i><strong>Delivered</strong> — Order delivered to customer
        </button>
        <button type="button" class="status-opt btn btn-outline-danger text-start" data-val="cancelled">
            <i class="bi bi-x-circle me-2"></i><strong>Cancelled</strong> — Order cancelled
        </button>
    </div>
    <input type="hidden" name="status" id="modalSt">
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
    <button type="submit" name="update_status" id="stSaveBtn" class="btn btn-danger px-4" disabled>
        <i class="bi bi-save me-1"></i>Save Status
    </button>
</div>
</form>
</div></div></div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.getElementById('stModal').addEventListener('show.bs.modal', function(e) {
    var btn = e.relatedTarget;
    var oid    = btn.dataset.id;
    var status = btn.dataset.status;
    document.getElementById('modalOid').value = oid;
    document.getElementById('modalOrderLabel').textContent = '#ORD-' + String(oid).padStart(4,'0');
    document.getElementById('modalSt').value = '';
    document.getElementById('stSaveBtn').disabled = true;

    // Highlight current status
    document.querySelectorAll('.status-opt').forEach(function(b) {
        b.classList.remove('active');
        if (b.dataset.val === status) {
            b.classList.add('active');
            b.innerHTML = b.innerHTML.replace('', ' ✓ Current');
        }
    });
});

document.querySelectorAll('.status-opt').forEach(function(btn) {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.status-opt').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        document.getElementById('modalSt').value = this.dataset.val;
        document.getElementById('stSaveBtn').disabled = false;
    });
});

// View Order Items
function viewOrderItems(orderId, orderLabel) {
    const modal = new bootstrap.Modal(document.getElementById('itemsModal'));
    document.querySelector('#itemsModal .modal-title').innerHTML = '<i class="bi bi-bag-check me-2"></i>Order ' + orderLabel;
    document.getElementById('orderItemsBody').innerHTML = '<div class="text-center py-4"><div class="spinner-border text-danger" role="status"></div><p class="mt-2 text-muted">Loading...</p></div>';
    document.getElementById('orderInfoHeader').innerHTML = '';
    document.getElementById('orderModalFooter').innerHTML = '<button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>';
    modal.show();

    fetch('get_order_items.php?id=' + orderId)
        .then(r => r.json())
        .then(data => {
            if (data.error) {
                document.getElementById('orderItemsBody').innerHTML = '<div class="alert alert-danger m-3">' + data.error + '</div>';
                return;
            }

            // Order info header
            document.getElementById('orderInfoHeader').innerHTML = `
                <div class="row g-3">
                    <div class="col-md-4">
                        <div class="small text-muted">Customer</div>
                        <div class="fw-bold">${data.order.cname}</div>
                        <div class="small text-muted">${data.order.cemail}</div>
                        <div class="small text-muted">${data.order.cphone}</div>
                    </div>
                    <div class="col-md-4">
                        <div class="small text-muted">Delivery Address</div>
                        <div class="fw-semibold small">${data.order.address || '—'}</div>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <div class="small text-muted">Payment Method</div>
                        <div class="fw-bold">${data.order.payment_method || 'Cash on Delivery'}</div>
                        <div class="small text-muted">Ordered: ${data.order.created_at}</div>
                    </div>
                </div>
                ${data.order.payment_proof ? `
                <div class="mt-3 p-3 rounded-3" style="background:#f0fdf4;border:1.5px solid #22c55e">
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="fw-semibold text-success"><i class="bi bi-image-fill me-2"></i>Payment Screenshot Uploaded</span>
                        <span class="small text-muted">${data.order.payment_proof_at || ''}</span>
                    </div>
                    <img src="/ppp/${data.order.payment_proof}" alt="Payment Proof"
                         style="max-width:100%;max-height:280px;border-radius:10px;border:2px solid #22c55e;cursor:pointer"
                         onclick="window.open('/ppp/${data.order.payment_proof}','_blank')">
                    <p class="small text-muted mt-1 mb-0"><i class="bi bi-zoom-in me-1"></i>Click image to open full size</p>
                </div>` : (data.order.status === 'pending' && data.order.payment_method !== 'Cash on Delivery' ? `
                <div class="mt-3 p-3 rounded-3" style="background:#fffbeb;border:1.5px solid #f59e0b">
                    <span class="fw-semibold" style="color:#92400e"><i class="bi bi-clock-history me-2"></i>Awaiting payment screenshot from customer</span>
                </div>` : '')}
                `;

            // Items table
            if (data.items.length === 0) {
                document.getElementById('orderItemsBody').innerHTML = '<div class="alert alert-info m-0">No items found for this order.</div>';
            } else {
                let html = `
                    <h6 class="fw-bold mb-3"><i class="bi bi-capsule-pill me-2 text-danger"></i>Ordered Medicines (${data.items.length} items)</h6>
                    <div class="table-responsive">
                    <table class="table table-hover">
                    <thead style="background:#f8fafc">
                        <tr>
                            <th style="font-size:.72rem;color:#64748b;text-transform:uppercase">Medicine</th>
                            <th style="font-size:.72rem;color:#64748b;text-transform:uppercase">Category</th>
                            <th style="font-size:.72rem;color:#64748b;text-transform:uppercase">Qty</th>
                            <th style="font-size:.72rem;color:#64748b;text-transform:uppercase">Unit Price</th>
                            <th style="font-size:.72rem;color:#64748b;text-transform:uppercase">Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>`;

                let total = 0;
                data.items.forEach(item => {
                    const subtotal = item.quantity * item.price;
                    total += subtotal;
                    html += `<tr>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                ${item.image_url ? `<img src="/ppp/${item.image_url}" style="width:40px;height:40px;object-fit:cover;border-radius:8px" onerror="this.style.display='none'">` : '<div style="width:40px;height:40px;background:#fee2e2;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:1.2rem">💊</div>'}
                                <div>
                                    <div class="fw-semibold small">${item.name}</div>
                                </div>
                            </div>
                        </td>
                        <td><span class="badge bg-light text-dark">${item.category || '—'}</span></td>
                        <td><strong>${item.quantity}</strong></td>
                        <td>PKR ${parseFloat(item.price).toLocaleString()}</td>
                        <td class="fw-bold text-danger">PKR ${subtotal.toLocaleString()}</td>
                    </tr>`;
                });

                html += `</tbody>
                    <tfoot style="background:#f8fafc">
                        <tr>
                            <td colspan="4" class="text-end fw-bold">Subtotal:</td>
                            <td class="fw-bold">PKR ${total.toLocaleString()}</td>
                        </tr>
                        <tr>
                            <td colspan="4" class="text-end fw-bold">Shipping:</td>
                            <td class="fw-bold">PKR 250</td>
                        </tr>
                        <tr style="background:#fee2e2">
                            <td colspan="4" class="text-end fw-bold text-danger">Total:</td>
                            <td class="fw-bold text-danger">PKR ${data.order.total_amount}</td>
                        </tr>
                    </tfoot>
                    </table></div>`;

                document.getElementById('orderItemsBody').innerHTML = html;
            }

            // Add confirm button if pending, or update status for others
            if (data.order.status === 'pending') {
                const hasProof = data.order.payment_proof ? true : false;
                document.getElementById('orderModalFooter').innerHTML = `
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-outline-secondary"
                            onclick="bootstrap.Modal.getInstance(document.getElementById('itemsModal')).hide();
                                     setTimeout(()=>{ let b=document.createElement('button'); b.dataset.id='${orderId}'; b.dataset.status='${data.order.status}'; b.dataset.bsToggle='modal'; b.dataset.bsTarget='#stModal'; document.body.appendChild(b); b.click(); document.body.removeChild(b); },400)">
                        <i class="bi bi-pencil me-1"></i>Change Status
                    </button>
                    <form method="POST" class="d-inline">
                        <input type="hidden" name="order_id" value="${orderId}">
                        <button type="submit" name="confirm_payment" class="btn ${hasProof ? 'btn-success' : 'btn-warning'} px-4">
                            <i class="bi bi-${hasProof ? 'check-circle-fill' : 'clock-history'} me-2"></i>
                            ${hasProof ? 'Verify & Confirm Payment' : 'Confirm Without Screenshot'}
                        </button>
                    </form>`;
            } else {
                document.getElementById('orderModalFooter').innerHTML = `
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-danger"
                            onclick="bootstrap.Modal.getInstance(document.getElementById('itemsModal')).hide();
                                     setTimeout(()=>{ let b=document.createElement('button'); b.dataset.id='${orderId}'; b.dataset.status='${data.order.status}'; b.dataset.bsToggle='modal'; b.dataset.bsTarget='#stModal'; document.body.appendChild(b); b.click(); document.body.removeChild(b); },400)">
                        <i class="bi bi-pencil me-1"></i>Update Status
                    </button>`;
            }
        })
        .catch(err => {
            document.getElementById('orderItemsBody').innerHTML = '<div class="alert alert-danger m-3">Failed to load order items. Please try again.</div>';
        });
}
function applyFilters() {
    var q  = document.getElementById('srch').value.toLowerCase();
    var st = document.getElementById('stFilter').value;
    var rows = document.querySelectorAll('#ordTbl tbody tr[data-search]');
    rows.forEach(function(r) {
        var ok = (!q || r.dataset.search.includes(q)) && (!st || r.dataset.status === st);
        r.style.display = ok ? '' : 'none';
    });
}
document.getElementById('srch').addEventListener('input', applyFilters);
document.getElementById('stFilter').addEventListener('change', applyFilters);
setTimeout(function(){document.querySelectorAll('.alert').forEach(function(a){bootstrap.Alert.getOrCreateInstance(a)?.close();});}, 4000);
</script>
</body>
</html>

