# Import Kaggle Pakistan Medicines Dataset 🇵🇰

## Quick Start Guide

### Step 1: Download the Dataset from Kaggle

1. **Visit the Kaggle Dataset Page**:
   - Go to: https://www.kaggle.com/datasets/muhammadabdullah222/pakistan-medicines-dataset

2. **Login to Kaggle** (if not already logged in):
   - You need a free Kaggle account
   - Sign up at: https://www.kaggle.com/account/login

3. **Download the Dataset**:
   - Click the "Download" button (top right)
   - The file will download as a ZIP file
   - Extract the ZIP file to get the CSV file

### Step 2: Place the CSV File

1. **Locate the CSV file** you just extracted
   - It might be named: `pakistan_medicines.csv` or similar

2. **Copy it to your project**:
   - Place it in: `admin/data/pakistan_medicines.csv`
   - The `admin/data/` folder has been created for you

3. **Rename if needed**:
   - If the CSV has a different name, either:
     - Rename it to `pakistan_medicines.csv`, OR
     - Update the filename in `import_kaggle_medicines.php` (line 17)

### Step 3: Run the Import Script

1. **Start your local server** (XAMPP/WAMP)
   - Make sure Apache and MySQL are running

2. **Open your browser** and visit:
   ```
   http://localhost/your-project-folder/import_kaggle_medicines.php
   ```

3. **Watch the import progress**:
   - The script will show real-time progress
   - Green = Successfully imported
   - Yellow = Skipped (duplicate)
   - Red = Error

4. **Wait for completion**:
   - Depending on dataset size, this may take 1-5 minutes
   - Don't close the browser window

5. **View imported products**:
   - Click "View Products in Admin Panel" button
   - Or go to: `admin/products.php`

## What the Import Script Does

### Automatic Column Detection
The script automatically detects these columns from your CSV:
- **Medicine Name** → Product name
- **Formula/Generic Name** → Added to description
- **Company/Manufacturer** → Added to description
- **Price** → Product price (cleaned and validated)
- **Pack Size** → Added to description
- **Category** → Product category

### Smart Features

1. **Price Handling**:
   - Removes currency symbols (Rs, PKR, etc.)
   - Converts to numeric value
   - If price is missing or invalid, generates random price (50-2000 PKR)

2. **Category Detection**:
   - Automatically categorizes based on product name:
     - Contains "vitamin" → vitamins
     - Contains "cream/ointment" → skincare
     - Contains "bandage/gauze" → firstaid
     - Default → prescription

3. **Duplicate Prevention**:
   - Checks if product name already exists
   - Skips duplicates to avoid errors

4. **Description Building**:
   - Combines formula, company, and pack size
   - Creates informative product descriptions

5. **Stock Generation**:
   - Assigns random stock (20-200 units) to each product

## Troubleshooting

### Problem: "CSV File Not Found"
**Solution**: 
- Make sure the CSV file is in `admin/data/` folder
- Check the filename matches (default: `pakistan_medicines.csv`)
- Check file path in script (line 17)

### Problem: "Database Connection Failed"
**Solution**:
- Check XAMPP/WAMP is running
- Verify database credentials in `api/config.php`
- Make sure `medicare_db` database exists

### Problem: "All rows skipped as duplicates"
**Solution**:
- Products already imported
- To re-import, clear products table first:
  ```sql
  TRUNCATE TABLE products;
  ```

### Problem: "Import is very slow"
**Solution**:
- Normal for large datasets (1000+ products)
- Don't close browser window
- Wait for completion message

### Problem: "Some products have no price"
**Solution**:
- Script automatically generates random prices (50-2000 PKR)
- You can edit prices later in admin panel

## Expected Dataset Format

The script works with CSV files containing these columns (any order):

| Column Name | Alternative Names | Required |
|-------------|------------------|----------|
| Medicine Name | Name, Product Name, Drug Name | ✅ Yes |
| Formula | Generic Name, Composition | ❌ No |
| Company | Manufacturer, Brand | ❌ No |
| Price | MRP, Retail Price | ❌ No |
| Pack Size | Packaging, Pack | ❌ No |
| Category | Type, Class | ❌ No |

**Note**: Only "Medicine Name" is required. Other fields are optional.

## After Import

### 1. Verify Products
- Go to `admin/products.php`
- Check imported products
- Verify prices and categories

### 2. Add Images (Optional)
- Edit products in admin panel
- Add image URLs from Unsplash/Pexels
- See: `PRODUCTS_MANAGEMENT_FIXED.md` for image guide

### 3. Adjust Prices (Optional)
- Review auto-generated prices
- Edit any products that need price corrections
- Use bulk edit if available

### 4. Categorize Better (Optional)
- Review auto-assigned categories
- Manually adjust if needed
- Add more specific categories

## Import Statistics

After import completes, you'll see:
- **Total Rows Processed**: Number of rows in CSV
- **Successfully Imported**: New products added
- **Skipped**: Duplicates or invalid rows
- **Errors**: Failed imports (with error messages)

## Re-running the Import

If you need to import again:

1. **Clear existing products** (optional):
   ```sql
   TRUNCATE TABLE products;
   ```

2. **Run import script again**:
   - Visit: `import_kaggle_medicines.php`
   - Script will skip duplicates automatically

## Advanced: Customize Import

To customize the import behavior, edit `import_kaggle_medicines.php`:

### Change CSV file path (line 17):
```php
$csv_file = 'admin/data/your_custom_filename.csv';
```

### Change batch size (line 18):
```php
$batch_size = 100; // Import 100 at a time
```

### Customize price range (line 95):
```php
$price = rand(100, 5000); // Custom price range
```

### Customize stock range (line 135):
```php
$stock = rand(50, 500); // Custom stock range
```

## Dataset Information

**Source**: Kaggle - Pakistan Medicines Dataset
**Author**: Muhammad Abdullah
**Link**: https://www.kaggle.com/datasets/muhammadabdullah222/pakistan-medicines-dataset

This dataset contains information about medicines available in Pakistan, including:
- Medicine names
- Generic formulas
- Manufacturing companies
- Prices
- Pack sizes

Perfect for building a realistic medical e-commerce platform!

## Support

If you encounter any issues:
1. Check the error messages in the import log
2. Verify your CSV file format
3. Check database connection
4. Review the troubleshooting section above

## Next Steps

After successful import:
1. ✅ View products in admin panel
2. ✅ Add product images
3. ✅ Test product display on frontend
4. ✅ Test add to cart functionality
5. ✅ Configure categories
6. ✅ Set up payment system

---

**Status**: Ready to import! 🚀

Follow the steps above to import real Pakistan medicines data into your system.
