<?php
/**
 * File Manager Setup Script
 * Run this file once to set up the file manager system
 */

require_once('api/config.php');

echo "<!DOCTYPE html>
<html lang='en'>
<head>
    <meta charset='UTF-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1.0'>
    <title>File Manager Setup</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css' rel='stylesheet'>
    <style>
        body { background: #f8f9fa; padding: 50px 0; }
        .setup-container { max-width: 800px; margin: 0 auto; }
        .step { background: white; padding: 20px; margin-bottom: 20px; border-radius: 10px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .success { color: #28a745; }
        .error { color: #dc3545; }
    </style>
</head>
<body>
    <div class='setup-container'>
        <h2 class='text-center mb-4'>File Manager Setup</h2>";

// Step 1: Create database table
echo "<div class='step'>
        <h5>Step 1: Creating Database Table</h5>";

$sql = "CREATE TABLE IF NOT EXISTS `uploaded_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `original_name` varchar(255) NOT NULL,
  `stored_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_type` varchar(50) NOT NULL,
  `file_size` bigint(20) NOT NULL,
  `category` enum('images','documents','data','temp') NOT NULL DEFAULT 'temp',
  `description` text DEFAULT NULL,
  `uploaded_by` varchar(100) DEFAULT 'Admin',
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `category` (`category`),
  KEY `uploaded_at` (`uploaded_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($conn->query($sql)) {
    echo "<p class='success'>✓ Database table 'uploaded_files' created successfully!</p>";
} else {
    echo "<p class='error'>✗ Error creating table: " . $conn->error . "</p>";
}
echo "</div>";

// Step 2: Create upload directories
echo "<div class='step'>
        <h5>Step 2: Creating Upload Directories</h5>";

$upload_dir = 'uploads/';
$subdirs = ['images', 'documents', 'data', 'temp'];

// Create main uploads directory
if (!file_exists($upload_dir)) {
    if (mkdir($upload_dir, 0777, true)) {
        echo "<p class='success'>✓ Created main uploads directory</p>";
    } else {
        echo "<p class='error'>✗ Failed to create uploads directory</p>";
    }
} else {
    echo "<p class='success'>✓ Main uploads directory already exists</p>";
}

// Create subdirectories
foreach ($subdirs as $dir) {
    $path = $upload_dir . $dir;
    if (!file_exists($path)) {
        if (mkdir($path, 0777, true)) {
            echo "<p class='success'>✓ Created directory: $dir/</p>";
        } else {
            echo "<p class='error'>✗ Failed to create directory: $dir/</p>";
        }
    } else {
        echo "<p class='success'>✓ Directory already exists: $dir/</p>";
    }
}

// Create .htaccess for security
$htaccess_content = "# Prevent directory listing\nOptions -Indexes\n\n# Allow specific file types\n<FilesMatch \"\\.(jpg|jpeg|png|gif|pdf|doc|docx|txt|csv|sql|json|xml|zip|rar|7z)$\">\n    Order Allow,Deny\n    Allow from all\n</FilesMatch>";

file_put_contents($upload_dir . '.htaccess', $htaccess_content);
echo "<p class='success'>✓ Created .htaccess for security</p>";

echo "</div>";

// Step 3: Test file permissions
echo "<div class='step'>
        <h5>Step 3: Testing File Permissions</h5>";

if (is_writable($upload_dir)) {
    echo "<p class='success'>✓ Upload directory is writable</p>";
} else {
    echo "<p class='error'>✗ Upload directory is not writable. Please set permissions to 777</p>";
}

echo "</div>";

// Step 4: Summary
echo "<div class='step'>
        <h5>Setup Complete!</h5>
        <p>The File Manager system is now ready to use.</p>
        <ul>
            <li>Access the File Manager: <a href='admin/file_manager.php' target='_blank'>admin/file_manager.php</a></li>
            <li>Supported file types:
                <ul>
                    <li><strong>Images:</strong> JPG, JPEG, PNG, GIF, WEBP, SVG</li>
                    <li><strong>Documents:</strong> PDF, DOC, DOCX, TXT, XLSX, XLS</li>
                    <li><strong>Data Files:</strong> CSV, SQL, JSON, XML</li>
                    <li><strong>Archives:</strong> ZIP, RAR, 7Z</li>
                </ul>
            </li>
        </ul>
        <div class='mt-4'>
            <a href='admin/file_manager.php' class='btn btn-danger'>Go to File Manager</a>
            <a href='admin/index.php' class='btn btn-secondary'>Go to Dashboard</a>
        </div>
      </div>";

echo "</div>
</body>
</html>";

$conn->close();
?>
