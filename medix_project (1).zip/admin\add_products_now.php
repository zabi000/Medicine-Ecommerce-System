﻿<?php
require_once '../api/config.php';

$conn = getDBConnection();

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Insert 20 Sample Products
$products = [
    ['Paracetamol 500mg', 'Pain relief and fever reducer - effective for headaches and body aches', 5.99, 'prescription', 'ðŸ’Š', 100],
    ['Ibuprofen 400mg', 'Anti-inflammatory pain reliever - reduces inflammation and pain', 7.99, 'prescription', 'ðŸ’Š', 150],
    ['Aspirin 100mg', 'Blood thinner and pain relief - for heart health and pain management', 6.99, 'prescription', 'ðŸ’Š', 200],
    ['Cough Syrup', 'Relief from dry and wet cough - soothing throat irritation', 8.99, 'prescription', 'ðŸ’Š', 120],
    ['Vitamin C 1000mg', 'Immune system support - boosts immunity and antioxidant protection', 12.99, 'vitamins', 'ðŸ’‰', 200],
    ['Vitamin D3 2000IU', 'Bone health and immunity - supports calcium absorption', 14.99, 'vitamins', 'ðŸ’‰', 180],
    ['Multivitamin Complex', 'Complete daily nutrition - all essential vitamins and minerals', 19.99, 'vitamins', 'ðŸ’‰', 150],
    ['Omega-3 Fish Oil', 'Heart and brain health - supports cardiovascular function', 24.99, 'vitamins', 'ðŸ’‰', 100],
    ['Calcium + Vitamin D', 'Bone strength supplement - prevents osteoporosis', 16.99, 'vitamins', 'ðŸ’‰', 140],
    ['Probiotic Capsules', 'Digestive health support - improves gut bacteria balance', 22.99, 'vitamins', 'ðŸ’‰', 110],
    ['First Aid Kit', 'Complete emergency medical kit - includes bandages, antiseptic, gauze', 29.99, 'firstaid', 'ðŸ©¹', 50],
    ['Bandages Pack', 'Assorted sterile bandages - various sizes for different wounds', 8.99, 'firstaid', 'ðŸ©¹', 120],
    ['Antiseptic Cream', 'Wound care and infection prevention - prevents bacterial infection', 7.99, 'firstaid', 'ðŸ©¹', 180],
    ['Digital Thermometer', 'Fast and accurate temperature reading - quick results in 10 seconds', 15.99, 'devices', 'ðŸŒ¡ï¸', 75],
    ['Blood Pressure Monitor', 'Digital BP measurement device - automatic and easy to use', 45.99, 'devices', 'ðŸŒ¡ï¸', 40],
    ['Infrared Thermometer', 'Non-contact temperature scanner - safe and hygienic measurement', 34.99, 'devices', 'ðŸŒ¡ï¸', 55],
    ['Glucose Meter Kit', 'Blood sugar monitoring system - includes lancets and test strips', 39.99, 'devices', 'ðŸ©º', 60],
    ['Pulse Oximeter', 'Oxygen saturation monitor - tracks SpO2 and heart rate', 29.99, 'devices', 'ðŸ©º', 80],
    ['Hand Sanitizer 500ml', 'Antibacterial hand gel - kills 99.9% of germs', 4.99, 'personal', 'ðŸ§´', 300],
    ['Face Masks (50 Pack)', 'Disposable surgical masks - 3-ply protection', 12.99, 'personal', 'ðŸ˜·', 250]
];

$sql = "INSERT INTO products (name, description, price, category, icon, stock) VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Prepare failed: " . $conn->error);
}

$count = 0;
foreach ($products as $product) {
    $stmt->bind_param("ssdssi", $product[0], $product[1], $product[2], $product[3], $product[4], $product[5]);
    if ($stmt->execute()) {
        $count++;
    } else {
        echo "Error inserting " . $product[0] . ": " . $stmt->error . "<br>";
    }
}

$stmt->close();
$conn->close();

echo "<h2 style='color: green; text-align: center; margin-top: 50px;'>âœ“ Success!</h2>";
echo "<p style='text-align: center; font-size: 18px;'><strong>$count products added to database</strong></p>";
echo "<p style='text-align: center; margin-top: 30px;'><a href='../products.php' style='padding: 10px 20px; background: #B91C1C; color: white; text-decoration: none; border-radius: 5px;'>View Products</a></p>";
?>

