﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MEDIX Admin Setup</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #B91C1C, #991B1B);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Inter', sans-serif;
        }
        .setup-card {
            background: white;
            border-radius: 20px;
            padding: 3rem;
            max-width: 600px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        .status-box {
            padding: 1rem;
            border-radius: 10px;
            margin: 1rem 0;
        }
        .status-success {
            background: #D1FAE5;
            border: 2px solid #10B981;
            color: #065F46;
        }
        .status-error {
            background: #FEE2E2;
            border: 2px solid #EF4444;
            color: #991B1B;
        }
        .status-warning {
            background: #FEF3C7;
            border: 2px solid #F59E0B;
            color: #92400E;
        }
    </style>
</head>
<body>
    <div class="setup-card">
        <h1 class="text-center mb-4" style="color: #B91C1C;">
            <i class="bi bi-heart-pulse-fill"></i> MEDIX Admin Setup
        </h1>

        <?php
        // Check database connection
        require_once('../api/config.php');
        
        $db_connected = false;
        $tables_exist = false;
        $has_data = false;
        
        if ($conn) {
            $db_connected = true;
            echo '<div class="status-box status-success">';
            echo '<i class="bi bi-check-circle-fill"></i> <strong>Database Connected</strong>';
            echo '</div>';
            
            // Check if tables exist
            $result = @$conn->query("SHOW TABLES LIKE 'products'");
            if ($result && $result->num_rows > 0) {
                $tables_exist = true;
                echo '<div class="status-box status-success">';
                echo '<i class="bi bi-check-circle-fill"></i> <strong>Tables Exist</strong>';
                echo '</div>';
                
                // Check if has data
                $count = @$conn->query("SELECT COUNT(*) as count FROM products")->fetch_assoc()['count'];
                if ($count > 0) {
                    $has_data = true;
                    echo '<div class="status-box status-success">';
                    echo '<i class="bi bi-check-circle-fill"></i> <strong>Data Found: ' . $count . ' products</strong>';
                    echo '</div>';
                } else {
                    echo '<div class="status-box status-warning">';
                    echo '<i class="bi bi-exclamation-triangle-fill"></i> <strong>No Data Found</strong>';
                    echo '<p class="mb-0 mt-2">Import database to add sample data</p>';
                    echo '</div>';
                }
            } else {
                echo '<div class="status-box status-error">';
                echo '<i class="bi bi-x-circle-fill"></i> <strong>Tables Not Found</strong>';
                echo '<p class="mb-0 mt-2">You need to import the database</p>';
                echo '</div>';
            }
        } else {
            echo '<div class="status-box status-error">';
            echo '<i class="bi bi-x-circle-fill"></i> <strong>Database Not Connected</strong>';
            echo '<p class="mb-0 mt-2">Make sure XAMPP MySQL is running</p>';
            echo '</div>';
        }
        ?>

        <hr class="my-4">

        <h5 class="mb-3">What to do next:</h5>

        <?php if (!$db_connected): ?>
            <div class="alert alert-danger">
                <strong>Step 1:</strong> Start MySQL in XAMPP Control Panel<br>
                <strong>Step 2:</strong> Refresh this page
            </div>
        <?php elseif (!$tables_exist || !$has_data): ?>
            <div class="alert alert-warning">
                <strong>Step 1:</strong> Open phpMyAdmin<br>
                <strong>Step 2:</strong> Click "Import" tab<br>
                <strong>Step 3:</strong> Choose file: <code>database/import_this.sql</code><br>
                <strong>Step 4:</strong> Click "Go" button<br>
                <strong>Step 5:</strong> Come back and refresh this page
            </div>
            <div class="d-grid gap-2">
                <a href="http://localhost/phpmyadmin" target="_blank" class="btn btn-primary btn-lg">
                    <i class="bi bi-database"></i> Open phpMyAdmin
                </a>
            </div>
        <?php else: ?>
            <div class="alert alert-success">
                <i class="bi bi-check-circle-fill"></i> <strong>Everything is ready!</strong><br>
                You can now login to the admin panel.
            </div>
            <div class="d-grid gap-2">
                <a href="login.php" class="btn btn-danger btn-lg">
                    <i class="bi bi-box-arrow-in-right"></i> Go to Admin Login
                </a>
            </div>
            <div class="text-center mt-3">
                <small class="text-muted">
                    Username: <strong>admin</strong> | Password: <strong>admin123</strong>
                </small>
            </div>
        <?php endif; ?>

        <hr class="my-4">

        <div class="text-center">
            <a href="test.php" class="btn btn-sm btn-outline-secondary">
                <i class="bi bi-gear"></i> Run Diagnostic Test
            </a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

