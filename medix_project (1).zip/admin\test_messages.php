﻿<?php
session_start();
require_once('../api/config.php');

echo "<!DOCTYPE html>
<html>
<head>
    <title>Test Messages - Debug</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css' rel='stylesheet'>
</head>
<body>
    <div class='container mt-5'>
        <h1>Messages System Debug</h1>";

// Check database connection
echo "<h3>1. Database Connection</h3>";
if ($conn) {
    echo "<div class='alert alert-success'>âœ… Database connected</div>";
} else {
    echo "<div class='alert alert-danger'>âŒ Database connection failed</div>";
    echo "</div></body></html>";
    exit;
}

// Check if table exists
echo "<h3>2. Check Table Exists</h3>";
$result = $conn->query("SHOW TABLES LIKE 'contact_messages'");
if ($result && $result->num_rows > 0) {
    echo "<div class='alert alert-success'>âœ… Table 'contact_messages' exists</div>";
    
    // Show table structure
    echo "<h4>Table Structure:</h4>";
    $structure = $conn->query("DESCRIBE contact_messages");
    echo "<table class='table table-sm'>";
    echo "<tr><th>Field</th><th>Type</th></tr>";
    while ($row = $structure->fetch_assoc()) {
        echo "<tr><td>{$row['Field']}</td><td>{$row['Type']}</td></tr>";
    }
    echo "</table>";
    
    // Count messages
    echo "<h3>3. Message Count</h3>";
    $count = $conn->query("SELECT COUNT(*) as count FROM contact_messages")->fetch_assoc()['count'];
    echo "<div class='alert alert-info'>Total messages: $count</div>";
    
    // Show messages
    if ($count > 0) {
        echo "<h3>4. Recent Messages</h3>";
        $messages = $conn->query("SELECT * FROM contact_messages ORDER BY created_at DESC LIMIT 5");
        echo "<table class='table'>";
        echo "<tr><th>ID</th><th>Name</th><th>Email</th><th>Subject</th><th>Status</th><th>Date</th></tr>";
        while ($msg = $messages->fetch_assoc()) {
            echo "<tr>";
            echo "<td>{$msg['id']}</td>";
            echo "<td>{$msg['first_name']} {$msg['last_name']}</td>";
            echo "<td>{$msg['email']}</td>";
            echo "<td>{$msg['subject']}</td>";
            echo "<td><span class='badge bg-primary'>{$msg['status']}</span></td>";
            echo "<td>{$msg['created_at']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    } else {
        echo "<div class='alert alert-warning'>No messages yet. Try submitting the contact form.</div>";
    }
    
} else {
    echo "<div class='alert alert-danger'>âŒ Table 'contact_messages' does NOT exist</div>";
    echo "<p>Please run the setup script:</p>";
    echo "<a href='../setup_contact_messages.php' class='btn btn-primary'>Run Setup</a>";
}

// Check admin session
echo "<h3>5. Admin Session</h3>";
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    echo "<div class='alert alert-success'>âœ… Admin is logged in</div>";
} else {
    echo "<div class='alert alert-warning'>âš ï¸ Admin not logged in</div>";
}

echo "<hr>";
echo "<a href='messages.php' class='btn btn-danger'>Go to Messages Page</a> ";
echo "<a href='../contact.html' class='btn btn-primary'>Test Contact Form</a>";

echo "</div></body></html>";
?>

