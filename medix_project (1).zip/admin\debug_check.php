﻿<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Debug Check</h1>";
echo "<hr>";

// Check 1: PHP Version
echo "<h3>1. PHP Version</h3>";
echo "PHP Version: " . phpversion() . "<br>";
echo "Status: " . (version_compare(phpversion(), '7.0.0', '>=') ? '<span style="color:green">âœ“ OK</span>' : '<span style="color:red">âœ— Too Old</span>') . "<br><br>";

// Check 2: Database Connection
echo "<h3>2. Database Connection</h3>";
require_once('../api/config.php');
if ($conn) {
    echo "Status: <span style='color:green'>âœ“ Connected</span><br>";
    echo "Database: " . DB_NAME . "<br><br>";
} else {
    echo "Status: <span style='color:red'>âœ— Failed</span><br>";
    echo "Error: Connection failed<br><br>";
}

// Check 3: Tables Exist
echo "<h3>3. Database Tables</h3>";
if ($conn) {
    $tables = ['users', 'products', 'orders', 'order_items', 'categories'];
    foreach ($tables as $table) {
        $result = $conn->query("SHOW TABLES LIKE '$table'");
        if ($result && $result->num_rows > 0) {
            $count = $conn->query("SELECT COUNT(*) as count FROM $table")->fetch_assoc()['count'];
            echo "$table: <span style='color:green'>âœ“ Exists</span> ($count records)<br>";
        } else {
            echo "$table: <span style='color:red'>âœ— Missing</span><br>";
        }
    }
} else {
    echo "<span style='color:red'>Cannot check - no database connection</span><br>";
}
echo "<br>";

// Check 4: Session
echo "<h3>4. Session Status</h3>";
session_start();
echo "Session ID: " . session_id() . "<br>";
echo "Admin Logged In: " . (isset($_SESSION['admin_logged_in']) ? '<span style="color:green">âœ“ Yes</span>' : '<span style="color:orange">âš  No</span>') . "<br><br>";

// Check 5: File Permissions
echo "<h3>5. File Permissions</h3>";
$files = [
    'index.php',
    'categories.php',
    'customers.php',
    'reports.php',
    'products.php',
    'orders.php'
];
foreach ($files as $file) {
    if (file_exists($file)) {
        echo "$file: <span style='color:green'>âœ“ Exists</span><br>";
    } else {
        echo "$file: <span style='color:red'>âœ— Missing</span><br>";
    }
}
echo "<br>";

// Check 6: Test Login
echo "<h3>6. Quick Login Test</h3>";
echo "<form method='POST' action='login.php'>";
echo "Username: <input type='text' name='username' value='admin'><br>";
echo "Password: <input type='password' name='password' value='admin123'><br>";
echo "<button type='submit'>Test Login</button>";
echo "</form>";
echo "<br>";

// Check 7: Direct Access Links
echo "<h3>7. Direct Access (Bypass Login for Testing)</h3>";
$_SESSION['admin_logged_in'] = true;
echo "<p style='color:green'>âœ“ Session set for testing</p>";
echo "<a href='index.php' style='display:inline-block; padding:10px; background:#B91C1C; color:white; text-decoration:none; margin:5px;'>Dashboard</a>";
echo "<a href='categories.php' style='display:inline-block; padding:10px; background:#B91C1C; color:white; text-decoration:none; margin:5px;'>Categories</a>";
echo "<a href='customers.php' style='display:inline-block; padding:10px; background:#B91C1C; color:white; text-decoration:none; margin:5px;'>Customers</a>";
echo "<a href='reports.php' style='display:inline-block; padding:10px; background:#B91C1C; color:white; text-decoration:none; margin:5px;'>Reports</a>";
echo "<br><br>";

echo "<hr>";
echo "<p><strong>If you see errors above, that's the problem. Otherwise, click the links to test each page.</strong></p>";
?>

