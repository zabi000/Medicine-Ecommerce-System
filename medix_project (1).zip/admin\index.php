﻿<?php
session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

require_once('../api/config.php');

// Get real statistics from database
$total_products = $conn ? ($conn->query("SELECT COUNT(*) as count FROM products")->fetch_assoc()['count'] ?? 0) : 0;
$total_orders = $conn ? ($conn->query("SELECT COUNT(*) as count FROM orders")->fetch_assoc()['count'] ?? 0) : 0;
$total_customers = $conn ? ($conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'] ?? 0) : 0;
$total_revenue = $conn ? ($conn->query("SELECT COALESCE(SUM(total_amount), 0) as total FROM orders")->fetch_assoc()['total'] ?? 0) : 0;

// Recent orders - check if customer_name column exists in orders table
$has_cname = false;
if ($conn) {
    $chk = $conn->query("SHOW COLUMNS FROM orders LIKE 'customer_name'");
    $has_cname = $chk && $chk->num_rows > 0;
}

$recent_orders = $conn ? $conn->query(
    $has_cname
        ? "SELECT o.*, CASE WHEN o.customer_name IS NOT NULL AND o.customer_name != '' THEN o.customer_name ELSE COALESCE(u.name, u.username, 'Guest') END as display_name FROM orders o LEFT JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC LIMIT 5"
        : "SELECT o.*, COALESCE(u.name, u.username, 'Guest') as display_name FROM orders o LEFT JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC LIMIT 5"
) : false;

// Low stock products
$low_stock = $conn ? $conn->query("SELECT * FROM products WHERE stock_quantity < 20 ORDER BY stock_quantity ASC LIMIT 5") : false;

// Today's stats
$today_orders = $conn ? ($conn->query("SELECT COUNT(*) as count FROM orders WHERE DATE(created_at) = CURDATE()")->fetch_assoc()['count'] ?? 0) : 0;
$today_revenue = $conn ? ($conn->query("SELECT COALESCE(SUM(total_amount), 0) as total FROM orders WHERE DATE(created_at) = CURDATE()")->fetch_assoc()['total'] ?? 0) : 0;

// Unread messages count
$unread_messages = 0;
$new_messages = false;
if ($conn) {
    $msg_check = $conn->query("SHOW TABLES LIKE 'contact_messages'");
    if ($msg_check && $msg_check->num_rows > 0) {
        $unread_messages = $conn->query("SELECT COUNT(*) as count FROM contact_messages WHERE status = 'new'")->fetch_assoc()['count'] ?? 0;
        $new_messages = $conn->query("SELECT * FROM contact_messages WHERE status = 'new' ORDER BY created_at DESC LIMIT 3");
    }
}

// Total notifications = today's orders + unread messages
$total_notifications = $today_orders + $unread_messages;

// Low stock count for bell
$low_stock_count = $conn ? ($conn->query("SELECT COUNT(*) as c FROM products WHERE stock_quantity <= 10")->fetch_assoc()['c'] ?? 0) : 0;
$total_notifications += ($low_stock_count > 0 ? 1 : 0); // Add 1 if any low stock
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - MEDIX</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        :root {
            --primary: #B91C1C;
            --primary-dark: #991B1B;
            --sidebar-width: 280px;
            --topbar-height: 70px;
        }
        
        body {
            font-family: 'Inter', sans-serif;
            background: #f8fafc;
            color: #1e293b;
        }
        
        /* Sidebar */
        .sidebar {
            position: fixed;
            left: 0;
            top: 0;
            width: var(--sidebar-width);
            height: 100vh;
            background: linear-gradient(180deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            overflow-y: auto;
            z-index: 1000;
            box-shadow: 4px 0 10px rgba(0,0,0,0.1);
        }
        
        .sidebar-brand {
            padding: 1.5rem;
            border-bottom: 1px solid rgba(255,255,255,0.1);
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        
        .sidebar-brand i {
            font-size: 2rem;
        }
        
        .sidebar-brand h4 {
            margin: 0;
            font-weight: 700;
            font-size: 1.5rem;
        }
        
        .sidebar-menu {
            padding: 1rem 0;
        }
        
        .menu-item {
            display: flex;
            align-items: center;
            padding: 0.875rem 1.5rem;
            color: rgba(255,255,255,0.85);
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        
        .menu-item:hover {
            background: rgba(255,255,255,0.1);
            color: white;
            border-left-color: white;
        }
        
        .menu-item.active {
            background: rgba(255,255,255,0.15);
            color: white;
            border-left-color: white;
            font-weight: 600;
        }
        
        .menu-item i {
            width: 24px;
            margin-right: 0.875rem;
            font-size: 1.25rem;
        }
        
        .menu-divider {
            height: 1px;
            background: rgba(255,255,255,0.1);
            margin: 0.5rem 1.5rem;
        }
        
        .menu-special {
            background: rgba(16, 185, 129, 0.2);
            color: #10B981;
            margin: 0.5rem 1rem;
            border-radius: 8px;
            border-left: none !important;
        }
        
        .menu-special:hover {
            background: rgba(16, 185, 129, 0.3);
            color: #10B981;
        }
        
        /* Main Content */
        .main-content {
            margin-left: var(--sidebar-width);
            min-height: 100vh;
        }
        
        /* Top Bar */
        .topbar {
            height: var(--topbar-height);
            background: white;
            border-bottom: 1px solid #e2e8f0;
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 2rem;
            position: sticky;
            top: 0;
            z-index: 999;
        }
        
        .topbar-left h5 {
            margin: 0;
            font-weight: 600;
            color: #1e293b;
        }
        
        .topbar-left small {
            color: #64748b;
        }
        
        .topbar-right {
            display: flex;
            align-items: center;
            gap: 1rem;
        }
        
        .topbar-btn {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            border: none;
            background: #f1f5f9;
            color: #475569;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s;
            position: relative;
        }
        
        .topbar-btn:hover {
            background: #e2e8f0;
            color: var(--primary);
        }
        
        .topbar-btn .badge {
            position: absolute;
            top: -5px;
            right: -5px;
            width: 18px;
            height: 18px;
            border-radius: 50%;
            background: #ef4444;
            color: white;
            font-size: 0.65rem;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .admin-avatar {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            background: linear-gradient(135deg, var(--primary), var(--secondary));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .admin-avatar:hover {
            transform: scale(1.05);
        }
        
        .dropdown-menu {
            border: none;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            border-radius: 8px;
            margin-top: 0.5rem;
        }
        
        .dropdown-item {
            padding: 0.75rem 1rem;
            transition: all 0.3s;
        }
        
        .dropdown-item:hover {
            background: #f8fafc;
            color: var(--primary);
        }
        
        .dropdown-header {
            padding: 0.75rem 1rem;
            font-size: 0.875rem;
            font-weight: 600;
        }
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            cursor: pointer;
        }
        
        /* Content Area */
        .content-area {
            padding: 2rem;
        }
        
        /* Stats Cards */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 1.25rem;
            margin-bottom: 1.5rem;
        }
        
        .stat-card {
            background: white;
            border-radius: 16px;
            padding: 1.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.08);
            transition: all 0.3s;
            border: 1px solid #f1f5f9;
            position: relative;
            overflow: hidden;
        }
        
        .stat-card::after {
            content: '';
            position: absolute;
            top: 0; left: 0; right: 0;
            height: 3px;
            background: linear-gradient(90deg, var(--primary), var(--primary-dark));
        }
        
        .stat-card:hover {
            transform: translateY(-4px);
            box-shadow: 0 12px 24px rgba(0,0,0,0.1);
        }
        
        .stat-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 1rem;
        }
        
        .stat-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.5rem;
        }
        
        .stat-icon.blue { background: #dbeafe; color: #3b82f6; }
        .stat-icon.green { background: #d1fae5; color: #10b981; }
        .stat-icon.purple { background: #e9d5ff; color: #a855f7; }
        .stat-icon.orange { background: #fed7aa; color: #f97316; }
        
        .stat-value {
            font-size: 2rem;
            font-weight: 700;
            color: #1e293b;
            margin-bottom: 0.25rem;
        }
        
        .stat-label {
            color: #64748b;
            font-size: 0.875rem;
            font-weight: 500;
        }
        
        .stat-change {
            display: inline-flex;
            align-items: center;
            gap: 0.25rem;
            padding: 0.25rem 0.5rem;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 600;
            margin-top: 0.5rem;
        }
        
        .stat-change.up {
            background: #d1fae5;
            color: #059669;
        }
        
        .stat-change.down {
            background: #fee2e2;
            color: #dc2626;
        }
        
        /* Content Cards */
        .content-card {
            background: white;
            border-radius: 16px;
            padding: 1.5rem;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
            border: 1px solid #f1f5f9;
            margin-bottom: 1.5rem;
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 1.5rem;
        }
        
        .card-title {
            font-size: 1.125rem;
            font-weight: 600;
            color: #1e293b;
            margin: 0;
        }
        
        .card-action {
            color: var(--primary);
            text-decoration: none;
            font-size: 0.875rem;
            font-weight: 500;
        }
        
        .card-action:hover {
            text-decoration: underline;
        }
        
        /* Table */
        .custom-table {
            width: 100%;
        }
        
        .custom-table th {
            font-size: 0.75rem;
            font-weight: 600;
            color: #64748b;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            padding: 0.75rem 0;
            border-bottom: 1px solid #f1f5f9;
        }
        
        .custom-table td {
            padding: 1rem 0;
            border-bottom: 1px solid #f1f5f9;
            color: #475569;
        }
        
        .custom-table tr:last-child td {
            border-bottom: none;
        }
        
        .badge-status {
            padding: 0.375rem 0.75rem;
            border-radius: 6px;
            font-size: 0.75rem;
            font-weight: 600;
        }
        
        .badge-success { background: #d1fae5; color: #059669; }
        .badge-warning { background: #fef3c7; color: #d97706; }
        .badge-danger { background: #fee2e2; color: #dc2626; }
        .badge-info { background: #dbeafe; color: #2563eb; }
        
        .empty-state {
            text-align: center;
            padding: 3rem 1rem;
            color: #94a3b8;
        }
        
        .empty-state i {
            font-size: 3rem;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-brand">
            <i class="bi bi-heart-pulse-fill"></i>
            <div>
                <h4>MEDIX</h4>
                <small style="opacity: 0.7;">Admin Portal</small>
            </div>
        </div>
        
        <div class="sidebar-menu">
            <a href="index.php" class="menu-item active">
                <i class="bi bi-speedometer2"></i>
                <span>Dashboard</span>
            </a>
            <a href="products.php" class="menu-item">
                <i class="bi bi-box-seam"></i>
                <span>Products</span>
            </a>
            <a href="offers.php" class="menu-item">
                <i class="bi bi-tag-fill"></i>
                <span>Offers</span>
            </a>
            <a href="orders.php" class="menu-item">
                <i class="bi bi-cart-check"></i>
                <span>Orders</span>
            </a>
            <a href="customers.php" class="menu-item">
                <i class="bi bi-people"></i>
                <span>Customers</span>
            </a>
            <a href="categories.php" class="menu-item">
                <i class="bi bi-tags"></i>
                <span>Categories</span>
            </a>
            <a href="messages.php" class="menu-item">
                <i class="bi bi-envelope"></i>
                <span>Messages</span>
            </a>
            <a href="reports.php" class="menu-item">
                <i class="bi bi-graph-up"></i>
                <span>Reports</span>
            </a>
            <a href="settings.php" class="menu-item">
                <i class="bi bi-gear"></i>
                <span>Settings</span>
            </a>
            
            <div class="menu-divider"></div>
            
            <a href="database.php" class="menu-item">
                <i class="bi bi-database"></i>
                <span>Database</span>
            </a>
            <a href="import_medicines.php" class="menu-item menu-special">
                <i class="bi bi-capsule-pill"></i>
                <span>Import Medicines</span>
            </a>
            
            <div class="menu-divider"></div>
            
            <a href="logout.php" class="menu-item">
                <i class="bi bi-box-arrow-right"></i>
                <span>Logout</span>
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <!-- Top Bar -->
        <div class="topbar">
            <div class="topbar-left">
                <h5>Dashboard Overview</h5>
                <small><?= date('l, F j, Y') ?> &nbsp;|&nbsp; Today: <strong><?= $today_orders ?> orders</strong> &nbsp;|&nbsp; Revenue: <strong>PKR <?= number_format($today_revenue, 0) ?></strong></small>
            </div>
            <div class="topbar-right">
                <!-- Notification Dropdown -->
                <div class="dropdown">
                    <button class="topbar-btn" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="bi bi-bell"></i>
                        <?php if ($total_notifications > 0): ?>
                            <span class="badge"><?= $total_notifications ?></span>
                        <?php endif; ?>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end" style="min-width: 320px; max-height: 450px; overflow-y: auto;">
                        <li class="dropdown-header d-flex justify-content-between align-items-center px-3 py-2" style="background:#f8fafc;">
                            <strong><i class="bi bi-bell-fill me-2 text-danger"></i>Notifications</strong>
                            <?php if ($total_notifications > 0): ?>
                                <span class="badge bg-danger"><?= $total_notifications ?> new</span>
                            <?php endif; ?>
                        </li>
                        <li><hr class="dropdown-divider m-0"></li>

                        <?php if ($unread_messages > 0 && $new_messages && $new_messages->num_rows > 0): ?>
                        <li class="px-3 py-1" style="background:#fef2f2;">
                            <small class="text-danger fw-bold text-uppercase" style="font-size:.7rem;">
                                <i class="bi bi-envelope-fill me-1"></i>New Messages (<?= $unread_messages ?>)
                            </small>
                        </li>
                        <?php while ($msg = $new_messages->fetch_assoc()): ?>
                        <li>
                            <a class="dropdown-item py-2" href="messages.php">
                                <div class="d-flex align-items-start gap-2">
                                    <div style="width:36px;height:36px;border-radius:50%;background:#fee2e2;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                                        <i class="bi bi-person-fill text-danger"></i>
                                    </div>
                                    <div style="min-width:0;flex:1;">
                                        <div class="fw-semibold" style="font-size:.85rem;"><?= htmlspecialchars(($msg['first_name'] ?? '') . ' ' . ($msg['last_name'] ?? '')) ?></div>
                                        <div class="text-muted" style="font-size:.75rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:200px;"><?= htmlspecialchars(substr($msg['message'] ?? '', 0, 50)) ?>...</div>
                                        <div class="text-muted" style="font-size:.7rem;"><?= date('M d, h:i A', strtotime($msg['created_at'])) ?></div>
                                    </div>
                                    <span class="badge bg-danger" style="font-size:.65rem;flex-shrink:0;">New</span>
                                </div>
                            </a>
                        </li>
                        <?php endwhile; ?>
                        <li><a class="dropdown-item text-center text-danger py-2" href="messages.php"><small><strong>View all messages  &rarr;</strong></small></a></li>
                        <li><hr class="dropdown-divider m-0"></li>
                        <?php endif; ?>

                        <?php if ($today_orders > 0): ?>
                        <li class="px-3 py-1" style="background:#f0fdf4;">
                            <small class="text-success fw-bold text-uppercase" style="font-size:.7rem;">
                                <i class="bi bi-cart-check-fill me-1"></i>Today's Orders (<?= $today_orders ?>)
                            </small>
                        </li>
                        <?php endif; ?>
                        <?php
                        // Get recent orders for notifications
                        $notif_orders = $conn->query(
                            $has_cname
                                ? "SELECT o.*, CASE WHEN o.customer_name IS NOT NULL AND o.customer_name != '' THEN o.customer_name ELSE COALESCE(u.name, u.username, 'Guest') END as display_name FROM orders o LEFT JOIN users u ON o.user_id = u.id WHERE DATE(o.created_at) = CURDATE() ORDER BY o.created_at DESC LIMIT 5"
                                : "SELECT o.*, COALESCE(u.name, u.username, 'Guest') as display_name FROM orders o LEFT JOIN users u ON o.user_id = u.id WHERE DATE(o.created_at) = CURDATE() ORDER BY o.created_at DESC LIMIT 5"
                        );
                        if ($notif_orders && $notif_orders->num_rows > 0):
                            while ($order = $notif_orders->fetch_assoc()):
                        ?>
                        <li>
                            <a class="dropdown-item" href="orders.php">
                                <div class="d-flex align-items-start">
                                    <i class="bi bi-cart-check text-success me-2 mt-1"></i>
                                    <div>
                                        <strong>New Order #<?= $order['id'] ?></strong>
                                        <br>
                                        <small class="text-muted"><?= htmlspecialchars($order['display_name'] ?? 'Guest') ?> - PKR <?= number_format($order['total_amount'], 2) ?></small>
                                        <br>
                                        <small class="text-muted"><?= date('h:i A', strtotime($order['created_at'])) ?></small>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <?php 
                            endwhile;
                        else:
                        ?>
                        <li>
                            <div class="dropdown-item text-center text-muted py-3">
                                <i class="bi bi-inbox" style="font-size: 2rem;"></i>
                                <p class="mb-0 mt-2">No new notifications</p>
                            </div>
                        </li>
                        <?php endif; ?>
                        <?php if ($low_stock_count > 0): ?>
                        <li><hr class="dropdown-divider m-0"></li>
                        <li class="px-3 py-1" style="background:#fef3c7;">
                            <small class="text-warning fw-bold text-uppercase" style="font-size:.7rem;">
                                <i class="bi bi-exclamation-triangle-fill me-1"></i>Stock Alerts (<?= $low_stock_count ?>)
                            </small>
                        </li>
                        <li>
                            <a class="dropdown-item py-2" href="products.php">
                                <div class="d-flex align-items-center gap-2">
                                    <div style="width:36px;height:36px;border-radius:50%;background:#fef3c7;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:1rem">âš ï¸</div>
                                    <div>
                                        <div class="fw-semibold" style="font-size:.85rem"><?= $low_stock_count ?> product<?= $low_stock_count > 1 ? 's' : '' ?> running low</div>
                                        <div class="text-muted" style="font-size:.75rem">Click to manage inventory</div>
                                    </div>
                                </div>
                            </a>
                        </li>
                        <?php endif; ?>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-center text-primary" href="orders.php"><strong>View All Orders</strong></a></li>
                    </ul>
                </div>
                
                <!-- Admin Profile Dropdown -->
                <div class="dropdown">
                    <button class="admin-avatar" type="button" data-bs-toggle="dropdown" aria-expanded="false" style="border: none; background: none; cursor: pointer;">
                        <i class="bi bi-person"></i>
                    </button>
                    <ul class="dropdown-menu dropdown-menu-end">
                        <li><a class="dropdown-item" href="settings.php"><i class="bi bi-gear me-2"></i>Settings</a></li>
                        <li><a class="dropdown-item" href="messages.php"><i class="bi bi-envelope me-2"></i>Messages</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Content Area -->
        <div class="content-area">

            <?php
            // Check for critical stock alerts
            $critical_stock = $conn ? $conn->query("SELECT name, stock_quantity, category FROM products WHERE stock_quantity <= 10 ORDER BY stock_quantity ASC LIMIT 8") : false;
            $out_of_stock   = $conn ? ($conn->query("SELECT COUNT(*) as c FROM products WHERE stock_quantity = 0")->fetch_assoc()['c'] ?? 0) : 0;
            $low_count      = $conn ? ($conn->query("SELECT COUNT(*) as c FROM products WHERE stock_quantity > 0 AND stock_quantity <= 10")->fetch_assoc()['c'] ?? 0) : 0;
            ?>

            <?php if ($out_of_stock > 0 || $low_count > 0): ?>
            <div style="background:linear-gradient(135deg,#7f1d1d,#B91C1C);border-radius:14px;padding:1.25rem 1.5rem;margin-bottom:1.5rem;box-shadow:0 4px 20px rgba(185,28,28,.3)">
                <div style="display:flex;align-items:flex-start;justify-content:space-between;flex-wrap:wrap;gap:1rem">
                    <div style="display:flex;align-items:flex-start;gap:1rem;flex:1">
                        <div style="width:44px;height:44px;background:rgba(255,255,255,.15);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.4rem;flex-shrink:0"><i class="bi bi-exclamation-triangle-fill" style="color:white;font-size:1.3rem"></i></div>
                        <div>
                            <div style="color:white;font-weight:700;font-size:1rem;margin-bottom:.4rem">
                                Stock Alert!
                                <?php if ($out_of_stock > 0): ?>
                                    <span style="background:rgba(0,0,0,.25);padding:.2rem .6rem;border-radius:6px;font-size:.75rem;margin-left:.5rem"><?= $out_of_stock ?> out of stock</span>
                                <?php endif; ?>
                                <?php if ($low_count > 0): ?>
                                    <span style="background:rgba(255,200,0,.25);padding:.2rem .6rem;border-radius:6px;font-size:.75rem;margin-left:.25rem"><?= $low_count ?> running low</span>
                                <?php endif; ?>
                            </div>
                            <?php if ($critical_stock && $critical_stock->num_rows > 0): ?>
                            <div style="display:flex;flex-wrap:wrap;gap:.5rem;margin-top:.5rem">
                                <?php while ($p = $critical_stock->fetch_assoc()):
                                    $s = (int)$p['stock_quantity'];
                                    $bg = $s === 0 ? 'rgba(0,0,0,.3)' : 'rgba(255,200,0,.2)';
                                    $icon = $s === 0 ? '<i class="bi bi-x-circle-fill"></i>' : '<i class="bi bi-lightning-charge-fill"></i>';
                                ?>
                                <span style="background:<?= $bg ?>;color:white;padding:.3rem .75rem;border-radius:20px;font-size:.75rem;font-weight:600;display:flex;align-items:center;gap:.3rem">
                                    <?= $icon ?> <?= htmlspecialchars(mb_substr($p['name'], 0, 25)) ?><?= mb_strlen($p['name']) > 25 ? '...' : '' ?>
                                    <span style="background:rgba(255,255,255,.2);padding:.1rem .4rem;border-radius:10px;font-size:.7rem"><?= $s === 0 ? 'OUT' : $s . ' left' ?></span>
                                </span>
                                <?php endwhile; ?>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <a href="products.php" style="background:white;color:#B91C1C;padding:.625rem 1.25rem;border-radius:10px;text-decoration:none;font-weight:700;font-size:.875rem;white-space:nowrap;flex-shrink:0;align-self:flex-start">
                        <i class="bi bi-box-seam me-1"></i>Manage Stock
                    </a>
                </div>
            </div>
            <?php endif; ?>
            <!-- Stats Grid -->
            <div class="stats-grid">
                <div class="stat-card">
                    <div class="stat-header">
                        <div>
                            <div class="stat-value">PKR <?= number_format($total_revenue, 0) ?></div>
                            <div class="stat-label">Total Revenue</div>
                            <div class="stat-change up">
                                <i class="bi bi-arrow-up"></i> All time
                            </div>
                        </div>
                        <div class="stat-icon orange">
                            <i class="bi bi-currency-dollar"></i>
                        </div>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-header">
                        <div>
                            <div class="stat-value"><?= $total_orders ?></div>
                            <div class="stat-label">Total Orders</div>
                            <div class="stat-change up">
                                <i class="bi bi-arrow-up"></i> <?= $today_orders ?> today
                            </div>
                        </div>
                        <div class="stat-icon blue">
                            <i class="bi bi-cart-check"></i>
                        </div>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-header">
                        <div>
                            <div class="stat-value"><?= $total_products ?></div>
                            <div class="stat-label">Total Products</div>
                            <div class="stat-change up">
                                <i class="bi bi-arrow-up"></i> Active
                            </div>
                        </div>
                        <div class="stat-icon purple">
                            <i class="bi bi-box-seam"></i>
                        </div>
                    </div>
                </div>

                <div class="stat-card">
                    <div class="stat-header">
                        <div>
                            <div class="stat-value"><?= $total_customers ?></div>
                            <div class="stat-label">Total Customers</div>
                            <div class="stat-change up">
                                <i class="bi bi-arrow-up"></i> Growing
                            </div>
                        </div>
                        <div class="stat-icon green">
                            <i class="bi bi-people"></i>
                        </div>
                    </div>
                </div>

                <div class="stat-card" style="cursor:pointer;" onclick="window.location='messages.php'">
                    <div class="stat-header">
                        <div>
                            <div class="stat-value"><?= $unread_messages ?></div>
                            <div class="stat-label">Unread Messages</div>
                            <div class="stat-change <?= $unread_messages > 0 ? 'down' : 'up' ?>">
                                <?php if ($unread_messages > 0): ?>
                                    <i class="bi bi-envelope-fill"></i> <?= $unread_messages ?> new
                                <?php else: ?>
                                    <i class="bi bi-check-circle"></i> All read
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="stat-icon" style="background:#fee2e2;color:#B91C1C;">
                            <i class="bi bi-envelope<?= $unread_messages > 0 ? '-fill' : '' ?>"></i>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Two Column Layout -->
            <div class="row">
                <div class="col-lg-8">
                    <!-- Recent Orders -->
                    <div class="content-card">
                        <div class="card-header">
                            <h6 class="card-title">Recent Orders</h6>
                            <a href="orders.php" class="card-action">View All  &rarr;</a>
                        </div>
                        <?php if ($recent_orders && $recent_orders->num_rows > 0): ?>
                            <table class="custom-table">
                                <thead>
                                    <tr>
                                        <th>Order ID</th>
                                        <th>Customer</th>
                                        <th>Amount</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php while ($order = $recent_orders->fetch_assoc()): ?>
                                    <tr>
                                        <td><strong>#<?= $order['id'] ?></strong></td>
                        <td><?= htmlspecialchars($order['display_name'] ?? $order['customer_name'] ?? 'Guest') ?></td>
                                        <td><strong>PKR <?= number_format($order['total_amount'], 2) ?></strong></td>
                                        <td>
                                            <?php
                                            $status_class = 'info';
                                            if ($order['status'] == 'delivered') $status_class = 'success';
                                            elseif ($order['status'] == 'cancelled') $status_class = 'danger';
                                            elseif ($order['status'] == 'processing') $status_class = 'warning';
                                            ?>
                                            <span class="badge-status badge-<?= $status_class ?>">
                                                <?= ucfirst($order['status']) ?>
                                            </span>
                                        </td>
                                        <td><?= date('M d, Y', strtotime($order['created_at'])) ?></td>
                                    </tr>
                                    <?php endwhile; ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <div class="empty-state">
                                <i class="bi bi-cart-x"></i>
                                <p>No orders yet</p>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="col-lg-4">
                    <!-- Inventory Status -->
                    <div class="content-card">
                        <div class="card-header">
                            <h6 class="card-title"><i class="bi bi-boxes me-2 text-danger"></i>Inventory Status</h6>
                            <a href="products.php" class="card-action">Manage  &rarr;</a>
                        </div>

                        <?php if ($low_stock && $low_stock->num_rows > 0): ?>
                            <div style="padding:.5rem 0">
                            <?php while ($product = $low_stock->fetch_assoc()):
                                $stock = $product['stock_quantity'];
                                $pct = min(100, ($stock / 20) * 100);
                                $bar_color = $stock <= 5 ? '#ef4444' : ($stock <= 10 ? '#f97316' : '#eab308');
                            ?>
                            <div style="padding:.875rem 0;border-bottom:1px solid #f8fafc">
                                <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:.4rem">
                                    <div style="font-weight:600;font-size:.82rem;color:#1e293b;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">
                                        <?= htmlspecialchars($product['name']) ?>
                                    </div>
                                    <span style="background:<?= $stock <= 5 ? '#fee2e2' : '#fef3c7' ?>;color:<?= $stock <= 5 ? '#991b1b' : '#92400e' ?>;padding:.2rem .5rem;border-radius:6px;font-size:.7rem;font-weight:700;flex-shrink:0;margin-left:.5rem">
                                        <?= $stock ?> left
                                    </span>
                                </div>
                                <div style="background:#f1f5f9;border-radius:4px;height:6px;overflow:hidden">
                                    <div style="width:<?= $pct ?>%;height:100%;background:<?= $bar_color ?>;border-radius:4px;transition:width .3s"></div>
                                </div>
                                <div style="font-size:.7rem;color:#94a3b8;margin-top:.3rem"><?= ucfirst($product['category']) ?></div>
                            </div>
                            <?php endwhile; ?>
                            </div>
                            <div style="padding:.75rem 0 0;text-align:center">
                                <a href="products.php" style="font-size:.8rem;color:#B91C1C;font-weight:600;text-decoration:none">
                                    <i class="bi bi-arrow-right me-1"></i>Restock Products
                                </a>
                            </div>
                        <?php else: ?>
                            <div style="text-align:center;padding:2rem 1rem">
                                <div style="width:56px;height:56px;background:#d1fae5;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 1rem;font-size:1.5rem;color:#059669">
                                    <i class="bi bi-check-lg"></i>
                                </div>
                                <div style="font-weight:600;color:#1e293b;font-size:.9rem">All Stocked Up!</div>
                                <div style="font-size:.8rem;color:#64748b;margin-top:.25rem">No low stock products</div>
                            </div>
                        <?php endif; ?>
                    </div>

                    <!-- Recent Messages -->
                    <?php
                    $dash_messages = null;
                    if ($conn) {
                        $mt = $conn->query("SHOW TABLES LIKE 'contact_messages'");
                        if ($mt && $mt->num_rows > 0) {
                            $dash_messages = $conn->query("SELECT * FROM contact_messages ORDER BY created_at DESC LIMIT 3");
                        }
                    }
                    if ($dash_messages && $dash_messages->num_rows > 0):
                    ?>
                    <div class="content-card mt-3">
                        <div class="card-header">
                            <h6 class="card-title">
                                <i class="bi bi-envelope me-2 text-danger"></i>Recent Messages
                                <?php if ($unread_messages > 0): ?>
                                    <span class="badge bg-danger ms-1"><?= $unread_messages ?> new</span>
                                <?php endif; ?>
                            </h6>
                            <a href="messages.php" class="card-action">View All  &rarr;</a>
                        </div>
                        <?php while ($msg = $dash_messages->fetch_assoc()): ?>
                        <div style="padding:.75rem 0;border-bottom:1px solid #f1f5f9;">
                            <div style="display:flex;align-items:center;gap:.75rem;">
                                <div style="width:36px;height:36px;border-radius:50%;background:<?= $msg['status'] === 'new' ? '#fee2e2' : '#f1f5f9' ?>;display:flex;align-items:center;justify-content:center;flex-shrink:0;">
                                    <i class="bi bi-person-fill" style="color:<?= $msg['status'] === 'new' ? '#B91C1C' : '#64748b' ?>"></i>
                                </div>
                                <div style="flex:1;min-width:0;">
                                    <div style="font-weight:600;font-size:.85rem;color:#1e293b;">
                                        <?= htmlspecialchars(($msg['first_name'] ?? '') . ' ' . ($msg['last_name'] ?? '')) ?>
                                        <?php if ($msg['status'] === 'new'): ?>
                                            <span class="badge bg-danger ms-1" style="font-size:.65rem;">New</span>
                                        <?php endif; ?>
                                    </div>
                                    <div style="font-size:.75rem;color:#64748b;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                                        <?= htmlspecialchars(substr($msg['message'] ?? '', 0, 45)) ?>...
                                    </div>
                                    <div style="font-size:.7rem;color:#94a3b8;"><?= date('M d, h:i A', strtotime($msg['created_at'])) ?></div>
                                </div>
                            </div>
                        </div>
                        <?php endwhile; ?>
                        <div style="text-align:center;padding-top:.75rem;">
                            <a href="messages.php" style="color:#B91C1C;font-size:.8rem;font-weight:600;text-decoration:none;">View All Messages  &rarr;</a>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

