﻿<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
session_start();
require_once('api/config.php');

// ===== REQUIRE LOGIN TO CHECKOUT =====
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php?redirect=checkout.php');
    exit;
}

// ===== PRE-FILL USER DATA FROM DB =====
$logged_user = [];
if ($conn && isset($_SESSION['user_id'])) {
    $uid = (int)$_SESSION['user_id'];
    $ur = $conn->query("SELECT name, username, email, phone FROM users WHERE id=$uid");
    if ($ur) $logged_user = $ur->fetch_assoc() ?? [];
}
$prefill_name  = $logged_user['name'] ?? $logged_user['username'] ?? $_SESSION['user_name'] ?? '';
$prefill_email = $logged_user['email'] ?? $_SESSION['user_email'] ?? '';
$prefill_phone = $logged_user['phone'] ?? '';

// Auto-create site_settings table if missing, then load settings
if ($conn) {
    $conn->query("CREATE TABLE IF NOT EXISTS site_settings (
        `key` VARCHAR(100) PRIMARY KEY,
        `value` TEXT
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function getSet($conn, $key, $default = '') {
    if (!$conn) return $default;
    $r = @$conn->query("SELECT value FROM site_settings WHERE `key`='" . $conn->real_escape_string($key) . "'");
    if ($r && $row = $r->fetch_assoc()) return $row['value'];
    return $default;
}

// Check if settings have ever been saved (table has rows)
$settings_exist = false;
if ($conn) {
    $sr = $conn->query("SELECT COUNT(*) c FROM site_settings WHERE `key` LIKE 'pay_%'");
    if ($sr && $sr->fetch_assoc()['c'] > 0) $settings_exist = true;
}

// If no payment settings saved yet, default ALL to enabled
$pay_cod       = $settings_exist ? getSet($conn, 'pay_cod', '0') === '1'       : true;
$pay_jazzcash  = $settings_exist ? getSet($conn, 'pay_jazzcash', '0') === '1'  : true;
$pay_easypaisa = $settings_exist ? getSet($conn, 'pay_easypaisa', '0') === '1' : true;
$pay_bank      = $settings_exist ? getSet($conn, 'pay_bank', '0') === '1'      : true;

// Safety: if ALL are disabled, force-enable COD so checkout never breaks
if (!$pay_cod && !$pay_jazzcash && !$pay_easypaisa && !$pay_bank) {
    $pay_cod = true;
}
$jc_number        = getSet($conn, 'jazzcash_number', '0300-1234567');
$ep_number        = getSet($conn, 'easypaisa_number', '0321-9876543');
$bk_name          = getSet($conn, 'bank_name', 'HBL');
$bk_account       = getSet($conn, 'bank_account', '0123-4567890-01');
$bk_iban          = getSet($conn, 'bank_iban', 'PK36HABB0000000123456789');
$store_name       = getSet($conn, 'store_name', 'MEDIX Pharmacy');

// Check if cart is empty
if (empty($_SESSION['cart'])) {
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Checkout - MEDIX</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    </head>
    <body style="background:#f8f9fa;display:flex;align-items:center;justify-content:center;min-height:100vh">
        <div style="text-align:center;background:white;padding:3rem;border-radius:16px;box-shadow:0 4px 20px rgba(0,0,0,.1);max-width:400px">
            <i class="bi bi-cart-x" style="font-size:4rem;color:#B91C1C"></i>
            <h3 class="mt-3 fw-bold">Your cart is empty</h3>
            <p class="text-muted">Add some products before checking out.</p>
            <a href="products.php" class="btn btn-danger px-4 mt-2">
                <i class="bi bi-shop me-2"></i>Browse Products
            </a>
            <br><br>
            <a href="test_checkout.php" class="btn btn-outline-secondary btn-sm">
                Test Checkout (add test item)
            </a>
        </div>
    </body>
    </html>
    <?php
    exit;
}

// ===== BUILD CART ITEMS FIRST (before any POST processing) =====
$cart_items = [];
$total = 0;
if (!empty($_SESSION['cart']) && $conn) {
    $ids = implode(',', array_map('intval', array_keys($_SESSION['cart'])));
    $result = $conn->query("SELECT * FROM products WHERE id IN ($ids)");
    if ($result) {
        while ($product = $result->fetch_assoc()) {
            $quantity = (int)$_SESSION['cart'][$product['id']];
            $subtotal = $product['price'] * $quantity;
            $total += $subtotal;
            $cart_items[] = [
                'id'             => $product['id'],
                'name'           => $product['name'],
                'price'          => $product['price'],
                'quantity'       => $quantity,
                'subtotal'       => $subtotal,
                'stock_quantity' => (int)($product['stock_quantity'] ?? 0),
                'icon'           => $product['icon'] ?? '💊'
            ];
        }
    }
}
$shipping    = 250;
$grand_total = $total + $shipping;

$checkout_error = null;

// Process order
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {

    // ===== STOCK VALIDATION FIRST =====
    $stock_errors = [];
    if ($conn && !empty($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $pid => $qty) {
            $s = $conn->query("SELECT name, stock_quantity FROM products WHERE id = " . intval($pid));
            if ($s && $row = $s->fetch_assoc()) {
                $available = (int)$row['stock_quantity'];
                if ($available <= 0) {
                    $stock_errors[] = "❌ <strong>" . htmlspecialchars($row['name']) . "</strong> is out of stock and was removed from your cart.";
                    unset($_SESSION['cart'][$pid]);
                } elseif ($qty > $available) {
                    $stock_errors[] = "⚠️ <strong>" . htmlspecialchars($row['name']) . "</strong>: You ordered <strong>$qty</strong> but only <strong>$available</strong> available. Adjusted to $available.";
                    $_SESSION['cart'][$pid] = $available;
                }
            }
        }
    }

    if (!empty($stock_errors)) {
        $checkout_error = implode('<br>', $stock_errors);
        // Fall through — don't place order, show error
    } else {
        // ===== PLACE ORDER =====
        $name           = $_POST['name'];
        $email          = $_POST['email'];
        $phone          = $_POST['phone'];
        $address        = $_POST['address'];
        $city           = $_POST['city'];
        $payment_method = $_POST['payment_method'];
    
    // Create order in database
    if ($conn) {
        // Check if new customer columns exist
        $columns_check = $conn->query("SHOW COLUMNS FROM orders LIKE 'customer_name'");
        $has_customer_columns = ($columns_check && $columns_check->num_rows > 0);
        
        if ($has_customer_columns) {
            $user_id = (int)($_SESSION['user_id'] ?? 1);
            $status = 'pending';
            $full_address = "$address, $city";

            // Add payment_method column if missing
            $pm_check = $conn->query("SHOW COLUMNS FROM orders LIKE 'payment_method'");
            if (!$pm_check || $pm_check->num_rows == 0) {
                $conn->query("ALTER TABLE orders ADD COLUMN payment_method VARCHAR(50) DEFAULT 'Cash on Delivery'");
            }

            $stmt = $conn->prepare("INSERT INTO orders (user_id, customer_name, customer_email, customer_phone, total_amount, status, shipping_address, payment_method, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())");
            // i=user_id, s=name, s=email, s=phone, d=total, s=status, s=address, s=payment
            $types = "isssdss";
            $types .= "s";
            $stmt->bind_param($types, $user_id, $name, $email, $phone, $grand_total, $status, $full_address, $payment_method);
        } else {
            // Insert order without customer columns (fallback)
            $stmt = $conn->prepare("INSERT INTO orders (user_id, total_amount, status, shipping_address, created_at) VALUES (?, ?, ?, ?, NOW())");
            $user_id = 1;
            $status = 'pending';
            $full_address = "$address, $city";
            $stmt->bind_param("idss", $user_id, $grand_total, $status, $full_address);
        }
        
        if ($stmt->execute()) {
            $order_id = $conn->insert_id;
            
            // Log for debugging
            error_log("Order created successfully. Order ID: $order_id");
            
            // Insert order items
            $stmt = $conn->prepare("INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
            foreach ($cart_items as $item) {
                $stmt->bind_param("iiid", $order_id, $item['id'], $item['quantity'], $item['price']);
                if (!$stmt->execute()) {
                    error_log("Failed to insert order item: " . $stmt->error);
                }
            }
            error_log("Order items inserted successfully");

            // Reduce stock for each ordered product
            $stock_stmt = $conn->prepare("UPDATE products SET stock_quantity = GREATEST(0, stock_quantity - ?) WHERE id = ?");
            foreach ($cart_items as $item) {
                $stock_stmt->bind_param("ii", $item['quantity'], $item['id']);
                $stock_stmt->execute();
            }

            // Auto-add customer to users table if not already there
            if (!empty($email)) {
                $chk = $conn->prepare("SELECT id FROM users WHERE email=?");
                $chk->bind_param("s", $email);
                $chk->execute();
                if ($chk->get_result()->num_rows === 0) {
                    $pw = password_hash('guest_' . bin2hex(random_bytes(4)), PASSWORD_DEFAULT);
                    // Insert with both name and username to avoid UNIQUE constraint issues
                    $conn->query("INSERT IGNORE INTO users (name, username, email, phone, password) VALUES (
                        '" . $conn->real_escape_string($name) . "',
                        '" . $conn->real_escape_string($email) . "',
                        '" . $conn->real_escape_string($email) . "',
                        '" . $conn->real_escape_string($phone) . "',
                        '" . $conn->real_escape_string($pw) . "'
                    )");
                }
                $chk->close();
            }
            
            // (customer already added above)

            // Include notification system
            require_once('api/send_notifications.php');
            require_once('api/mailer.php');
            
            // Check payment method
            $is_digital = stripos($payment_method, 'jazzcash') !== false
                       || stripos($payment_method, 'easypaisa') !== false
                       || stripos($payment_method, 'bank') !== false;

            if (!$is_digital) {
                // CASH ON DELIVERY - Auto confirm
                $conn->query("UPDATE orders SET status = 'processing' WHERE id = $order_id");
                // Send order confirmation to customer
                sendOrderConfirmation($email, $name, $order_id, $cart_items, $grand_total, $full_address, $payment_method, $conn);
                // Notify admin
                sendAdminOrderAlert($order_id, $name, $email, $grand_total, $payment_method, $conn);
            } else {
                // DIGITAL PAYMENT - Status stays 'pending' until admin approves
                sendAdminOrderAlert($order_id, $name, $email, $grand_total, $payment_method, $conn);
            }
            
            // Clear cart and redirect
            $_SESSION['cart'] = [];
            
            // Map payment method to URL parameter
            $payment_code = 'cod';
            if (stripos($payment_method, 'jazzcash') !== false) {
                $payment_code = 'jazzcash';
            } elseif (stripos($payment_method, 'easypaisa') !== false) {
                $payment_code = 'easypaisa';
            } elseif (stripos($payment_method, 'bank') !== false) {
                $payment_code = 'bank';
            }
            
            error_log("Redirecting to order_success.php with order=$order_id and payment=$payment_code");
            header('Location: order_success.php?order=' . $order_id . '&payment=' . $payment_code);
            exit;
        } else {
            error_log("Failed to create order: " . $stmt->error);
            $error_message = "Failed to create order. Please try again.";
        }
    } else {
        error_log("Database connection failed");
        $error_message = "Database connection error. Please try again.";
    }
    } // end else (stock validation passed)
}
// grand_total already calculated above
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - Medix</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        :root { --primary-color: #B91C1C; }
        body { background: #f8f9fa; }
        .navbar { background: linear-gradient(135deg, var(--primary-color), #991B1B); padding: 1rem 0; }
        .navbar a { color: white !important; text-decoration: none; }
        .checkout-container { padding: 3rem 0; }
        .checkout-card { background: white; border-radius: 12px; padding: 2rem; margin-bottom: 2rem; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .order-summary { background: white; border-radius: 12px; padding: 2rem; box-shadow: 0 2px 8px rgba(0,0,0,0.1); position: sticky; top: 20px; }
        .payment-option { border: 2px solid #e0e0e0; border-radius: 8px; padding: 1rem; margin-bottom: 1rem; cursor: pointer; transition: all 0.3s; }
        .payment-option:hover { border-color: var(--primary-color); }
        .payment-option input[type="radio"] { margin-right: 10px; }
        .payment-option.selected { border-color: var(--primary-color); background: #fff5f5; }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center w-100">
                <a href="index.php" class="navbar-brand">
                    <i class="bi bi-heart-pulse-fill me-2"></i>
                    <span class="fw-bold">MEDIX</span>
                </a>
                <h5 class="mb-0 text-white">Secure Checkout</h5>
                <div class="d-flex align-items-center gap-2">
                    <?php if (!empty($prefill_name)): ?>
                    <span class="text-white-50 small"><i class="bi bi-person-check-fill me-1"></i><?= htmlspecialchars(explode(' ', $prefill_name)[0]) ?></span>
                    <?php endif; ?>
                    <a href="cart.php" class="btn btn-outline-light btn-sm">
                        <i class="bi bi-arrow-left"></i> Back to Cart
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="checkout-container container">
        <?php if ($checkout_error): ?>
            <div class="alert alert-warning alert-dismissible fade show" style="border-radius:12px;border-left:4px solid #f97316">
                <h6 class="fw-bold mb-2"><i class="bi bi-exclamation-triangle-fill me-2"></i>Stock Issue — Order Not Placed</h6>
                <?= $checkout_error ?>
                <hr class="my-2">
                <small>Your cart has been updated with available quantities. Please review and try again.</small>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="bi bi-exclamation-triangle"></i> <?= $error_message ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>
        
        <div class="row">
            <div class="col-lg-7">
                <form method="POST" id="checkoutForm">
                    <!-- Customer Information -->
                    <div class="checkout-card">
                        <h4 class="mb-4"><i class="bi bi-person-fill"></i> Customer Information</h4>
                        <div class="row">
                            <div class="col-md-12 mb-3">
                                <label class="form-label">Full Name *</label>
                                <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($prefill_name) ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Email Address *</label>
                                <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($prefill_email) ?>" required>
                                <small class="text-muted">Order confirmation will be sent here</small>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Phone Number *</label>
                                <input type="tel" name="phone" class="form-control" value="<?= htmlspecialchars($prefill_phone) ?>" placeholder="+92 300 1234567" required>
                            </div>
                        </div>
                    </div>

                    <!-- Shipping Address -->
                    <div class="checkout-card">
                        <h4 class="mb-4"><i class="bi bi-geo-alt-fill"></i> Shipping Address</h4>
                        <div class="row">
                            <div class="col-md-12 mb-3">
                                <label class="form-label">Street Address *</label>
                                <input type="text" name="address" class="form-control" placeholder="House #, Street, Area" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">City *</label>
                                <select name="city" class="form-select" required>
                                    <option value="">Select City</option>
                                    <option value="Karachi">Karachi</option>
                                    <option value="Lahore">Lahore</option>
                                    <option value="Islamabad">Islamabad</option>
                                    <option value="Rawalpindi">Rawalpindi</option>
                                    <option value="Faisalabad">Faisalabad</option>
                                    <option value="Multan">Multan</option>
                                    <option value="Peshawar">Peshawar</option>
                                    <option value="Quetta">Quetta</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label">Postal Code</label>
                                <input type="text" name="postal_code" class="form-control" placeholder="Optional">
                            </div>
                        </div>
                    </div>

                    <!-- Payment Method -->
                    <div class="checkout-card">
                        <h4 class="mb-4"><i class="bi bi-credit-card-fill"></i> Payment Method</h4>

                        <?php if ($pay_cod): ?>
                        <label class="payment-option" onclick="showPaymentDetails('cod')">
                            <input type="radio" name="payment_method" value="Cash on Delivery" <?= (!$pay_jazzcash && !$pay_easypaisa && !$pay_bank) || $pay_cod ? 'checked' : '' ?>>
                            <strong><i class="bi bi-cash text-success me-1"></i> Cash on Delivery</strong>
                            <p class="mb-0 ms-4 text-muted small">Pay when you receive your order</p>
                        </label>
                        <?php endif; ?>

                        <?php if ($pay_jazzcash): ?>
                        <label class="payment-option" onclick="showPaymentDetails('jazzcash')">
                            <input type="radio" name="payment_method" value="JazzCash">
                            <strong><i class="bi bi-phone-fill me-1" style="color:#ffc107"></i> JazzCash</strong>
                            <p class="mb-0 ms-4 text-muted small">Send to: <?= htmlspecialchars($jc_number) ?></p>
                        </label>
                        <?php endif; ?>

                        <?php if ($pay_easypaisa): ?>
                        <label class="payment-option" onclick="showPaymentDetails('easypaisa')">
                            <input type="radio" name="payment_method" value="Easypaisa">
                            <strong><i class="bi bi-phone-fill me-1 text-success"></i> Easypaisa</strong>
                            <p class="mb-0 ms-4 text-muted small">Send to: <?= htmlspecialchars($ep_number) ?></p>
                        </label>
                        <?php endif; ?>

                        <?php if ($pay_bank): ?>
                        <label class="payment-option" onclick="showPaymentDetails('bank')">
                            <input type="radio" name="payment_method" value="Bank Transfer">
                            <strong><i class="bi bi-bank me-1 text-primary"></i> Bank Transfer</strong>
                            <p class="mb-0 ms-4 text-muted small"><?= htmlspecialchars($bk_name) ?> — <?= htmlspecialchars($bk_account) ?></p>
                        </label>
                        <?php endif; ?>

                        <?php if (!$pay_cod && !$pay_jazzcash && !$pay_easypaisa && !$pay_bank): ?>
                        <div class="alert alert-warning">No payment methods are enabled. Please contact the store admin.</div>
                        <?php endif; ?>

                        <!-- COD Details -->
                        <?php if ($pay_cod): ?>
                        <div id="details-cod" class="payment-details" style="display:block">
                            <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:10px;padding:1rem;margin-top:.5rem">
                                <p class="mb-1 fw-bold text-success"><i class="bi bi-check-circle-fill me-2"></i>Cash on Delivery Selected</p>
                                <p class="mb-0 text-muted small">Our delivery agent will collect payment when your order arrives.</p>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- JazzCash Details -->
                        <?php if ($pay_jazzcash): ?>
                        <div id="details-jazzcash" class="payment-details" style="display:none">
                            <div style="background:#fff8e1;border:2px solid #ffc107;border-radius:10px;padding:1rem;margin-top:.5rem">
                                <p class="mb-2 fw-bold"><i class="bi bi-phone-fill me-2 text-warning"></i>Pay via JazzCash</p>
                                <div class="d-flex justify-content-between mb-1 small">
                                    <span class="text-muted">Account Name</span>
                                    <strong><?= htmlspecialchars($store_name) ?></strong>
                                </div>
                                <div class="d-flex justify-content-between mb-1 small">
                                    <span class="text-muted">JazzCash Number</span>
                                    <strong><?= htmlspecialchars($jc_number) ?></strong>
                                </div>
                                <div class="d-flex justify-content-between small">
                                    <span class="text-muted">Amount to Send</span>
                                    <strong class="text-danger">PKR <?= number_format($grand_total, 0) ?></strong>
                                </div>
                                <div class="mt-2 p-2 rounded small" style="background:#fffbeb;color:#92400e">
                                    <i class="bi bi-info-circle me-1"></i>Send to <strong><?= htmlspecialchars($jc_number) ?></strong> then click Place Order.
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- Easypaisa Details -->
                        <?php if ($pay_easypaisa): ?>
                        <div id="details-easypaisa" class="payment-details" style="display:none">
                            <div style="background:#e8f5e9;border:2px solid #4caf50;border-radius:10px;padding:1rem;margin-top:.5rem">
                                <p class="mb-2 fw-bold"><i class="bi bi-phone-fill me-2 text-success"></i>Pay via Easypaisa</p>
                                <div class="d-flex justify-content-between mb-1 small">
                                    <span class="text-muted">Account Name</span>
                                    <strong><?= htmlspecialchars($store_name) ?></strong>
                                </div>
                                <div class="d-flex justify-content-between mb-1 small">
                                    <span class="text-muted">Easypaisa Number</span>
                                    <strong><?= htmlspecialchars($ep_number) ?></strong>
                                </div>
                                <div class="d-flex justify-content-between small">
                                    <span class="text-muted">Amount to Send</span>
                                    <strong class="text-danger">PKR <?= number_format($grand_total, 0) ?></strong>
                                </div>
                                <div class="mt-2 p-2 rounded small" style="background:#f0fdf4;color:#166534">
                                    <i class="bi bi-info-circle me-1"></i>Send to <strong><?= htmlspecialchars($ep_number) ?></strong> then click Place Order.
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>

                        <!-- Bank Details -->
                        <?php if ($pay_bank): ?>
                        <div id="details-bank" class="payment-details" style="display:none">
                            <div style="background:#e3f2fd;border:2px solid #2196f3;border-radius:10px;padding:1rem;margin-top:.5rem">
                                <p class="mb-2 fw-bold"><i class="bi bi-bank me-2 text-primary"></i>Bank Transfer</p>
                                <div class="d-flex justify-content-between mb-1 small">
                                    <span class="text-muted">Account Name</span>
                                    <strong><?= htmlspecialchars($store_name) ?></strong>
                                </div>
                                <div class="d-flex justify-content-between mb-1 small">
                                    <span class="text-muted">Bank</span>
                                    <strong><?= htmlspecialchars($bk_name) ?></strong>
                                </div>
                                <div class="d-flex justify-content-between mb-1 small">
                                    <span class="text-muted">Account #</span>
                                    <strong><?= htmlspecialchars($bk_account) ?></strong>
                                </div>
                                <div class="d-flex justify-content-between mb-1 small">
                                    <span class="text-muted">IBAN</span>
                                    <strong><?= htmlspecialchars($bk_iban) ?></strong>
                                </div>
                                <div class="d-flex justify-content-between small">
                                    <span class="text-muted">Amount</span>
                                    <strong class="text-danger">PKR <?= number_format($grand_total, 0) ?></strong>
                                </div>
                            </div>
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- Place Order Button inside form, below payment -->
                    <div class="checkout-card" style="background: linear-gradient(135deg,#B91C1C,#991B1B); border:none">
                        <div class="d-flex justify-content-between align-items-center text-white mb-3">
                            <div>
                                <div class="small opacity-75">Order Total</div>
                                <div class="fs-4 fw-bold">PKR <?= number_format($grand_total, 0) ?></div>
                            </div>
                            <i class="bi bi-shield-check fs-1 opacity-50"></i>
                        </div>
                        <button type="submit" name="place_order" class="btn btn-light btn-lg w-100 fw-bold" style="border-radius:10px;font-size:1.1rem">
                            <i class="bi bi-check-circle-fill me-2 text-danger"></i>Place Order Now
                        </button>
                        <p class="text-white text-center mt-2 mb-0 small opacity-75">
                            <i class="bi bi-lock-fill me-1"></i>Secure & Encrypted Checkout
                        </p>
                    </div>
                </form>
            </div>

            <div class="col-lg-5">
                <div class="order-summary">
                    <h4 class="mb-4 fw-bold"><i class="bi bi-receipt me-2 text-danger"></i>Order Summary</h4>

                    <?php foreach ($cart_items as $item): ?>
                        <div class="d-flex justify-content-between align-items-center mb-2 pb-2 border-bottom">
                            <div>
                                <div class="small fw-semibold"><?= htmlspecialchars($item['name']) ?></div>
                                <div class="small text-muted">Qty: <?= $item['quantity'] ?> × PKR <?= number_format($item['price'], 0) ?></div>
                            </div>
                            <strong class="text-danger">PKR <?= number_format($item['subtotal'], 0) ?></strong>
                        </div>
                    <?php endforeach; ?>

                    <div class="d-flex justify-content-between mb-1 mt-3">
                        <span class="text-muted">Subtotal</span>
                        <strong>PKR <?= number_format($total, 0) ?></strong>
                    </div>
                    <div class="d-flex justify-content-between mb-3">
                        <span class="text-muted">Shipping</span>
                        <strong>PKR <?= number_format($shipping, 0) ?></strong>
                    </div>
                    <div class="d-flex justify-content-between p-3 rounded-3 mb-4" style="background:#fef2f2">
                        <span class="fw-bold fs-5">Total</span>
                        <span class="fw-bold fs-5 text-danger">PKR <?= number_format($grand_total, 0) ?></span>
                    </div>

                    <div class="d-flex align-items-center gap-2 mb-2 small text-muted">
                        <i class="bi bi-shield-check text-success"></i> 100% Secure Payment
                    </div>
                    <div class="d-flex align-items-center gap-2 mb-2 small text-muted">
                        <i class="bi bi-truck text-primary"></i> Delivery in 2-3 business days
                    </div>
                    <div class="d-flex align-items-center gap-2 small text-muted">
                        <i class="bi bi-arrow-counterclockwise text-warning"></i> Easy returns & exchanges
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function showPaymentDetails(method) {
            // Hide all panels
            document.querySelectorAll('.payment-details').forEach(d => d.style.display = 'none');
            // Show selected
            const panel = document.getElementById('details-' + method);
            if (panel) panel.style.display = 'block';
        }

        // Highlight selected payment method
        document.querySelectorAll('.payment-option').forEach(option => {
            option.addEventListener('click', function() {
                document.querySelectorAll('.payment-option').forEach(o => o.classList.remove('selected'));
                this.classList.add('selected');
                this.querySelector('input[type="radio"]').checked = true;
            });
        });

        // Set initial selected
        document.querySelector('.payment-option input:checked').parentElement.classList.add('selected');
    </script>
</body>
</html>

