<?php
/**
 * Kaggle Pakistan Medicines Dataset Importer
 * 
 * INSTRUCTIONS:
 * 1. Download the CSV file from: https://www.kaggle.com/datasets/muhammadabdullah222/pakistan-medicines-dataset
 * 2. Place the CSV file in the 'admin/data/' folder
 * 3. Run this script by visiting: http://localhost/your-project/import_kaggle_medicines.php
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);
set_time_limit(300); // 5 minutes timeout

require_once('api/config.php');

// Configuration
$csv_file = 'admin/data/pakistan_medicines.csv'; // Update this path if needed
$batch_size = 50; // Import 50 products at a time
$start_from = isset($_GET['offset']) ? intval($_GET['offset']) : 0;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Import Kaggle Medicines Dataset</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 2rem;
        }
        .import-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            max-width: 800px;
            margin: 0 auto;
        }
        .progress-bar {
            transition: width 0.3s ease;
        }
        .log-item {
            padding: 0.5rem;
            margin: 0.25rem 0;
            border-radius: 5px;
            font-family: monospace;
            font-size: 0.9rem;
        }
        .log-success { background: #d4edda; color: #155724; }
        .log-error { background: #f8d7da; color: #721c24; }
        .log-info { background: #d1ecf1; color: #0c5460; }
    </style>
</head>
<body>
    <div class="import-card">
        <h2 class="text-center mb-4">
            <i class="bi bi-cloud-download"></i> Import Kaggle Medicines Dataset
        </h2>

        <?php
        // Check if CSV file exists
        if (!file_exists($csv_file)) {
            ?>
            <div class="alert alert-warning">
                <h5><i class="bi bi-exclamation-triangle"></i> CSV File Not Found</h5>
                <p>Please follow these steps:</p>
                <ol>
                    <li>Go to: <a href="https://www.kaggle.com/datasets/muhammadabdullah222/pakistan-medicines-dataset" target="_blank">Kaggle Dataset</a></li>
                    <li>Click "Download" button (you may need to login to Kaggle)</li>
                    <li>Extract the CSV file</li>
                    <li>Create folder: <code>admin/data/</code></li>
                    <li>Place the CSV file as: <code><?= $csv_file ?></code></li>
                    <li>Refresh this page</li>
                </ol>
            </div>
            <?php
            exit;
        }

        // Check database connection
        if (!$conn) {
            ?>
            <div class="alert alert-danger">
                <h5>Database Connection Failed</h5>
                <p>Please check your database configuration in <code>api/config.php</code></p>
            </div>
            <?php
            exit;
        }

        // Start import process
        echo '<div class="alert alert-info">';
        echo '<strong>Starting import...</strong><br>';
        echo 'File: ' . $csv_file . '<br>';
        echo 'File size: ' . number_format(filesize($csv_file) / 1024, 2) . ' KB<br>';
        echo '</div>';

        // Open CSV file
        $file = fopen($csv_file, 'r');
        if (!$file) {
            echo '<div class="alert alert-danger">Failed to open CSV file</div>';
            exit;
        }

        // Read header row
        $headers = fgetcsv($file);
        echo '<div class="log-item log-info">CSV Headers: ' . implode(', ', $headers) . '</div>';

        // Map CSV columns to database fields
        $column_map = [];
        foreach ($headers as $index => $header) {
            $header_lower = strtolower(trim($header));
            
            // Map common column names
            if (in_array($header_lower, ['medicine name', 'name', 'product name', 'drug name'])) {
                $column_map['name'] = $index;
            } elseif (in_array($header_lower, ['formula', 'generic name', 'composition', 'ingredients'])) {
                $column_map['formula'] = $index;
            } elseif (in_array($header_lower, ['company', 'manufacturer', 'brand'])) {
                $column_map['company'] = $index;
            } elseif (in_array($header_lower, ['price', 'mrp', 'retail price'])) {
                $column_map['price'] = $index;
            } elseif (in_array($header_lower, ['pack size', 'packaging', 'pack'])) {
                $column_map['pack_size'] = $index;
            } elseif (in_array($header_lower, ['category', 'type', 'class'])) {
                $column_map['category'] = $index;
            } elseif (in_array($header_lower, ['description', 'details', 'info'])) {
                $column_map['description'] = $index;
            }
        }

        echo '<div class="log-item log-info">Detected columns: ' . json_encode($column_map) . '</div>';

        // Import data
        $imported = 0;
        $skipped = 0;
        $errors = 0;
        $row_number = 0;

        echo '<div class="mt-4"><h5>Import Progress:</h5><div id="log-container">';

        while (($data = fgetcsv($file)) !== false) {
            $row_number++;
            
            // Skip empty rows
            if (empty(array_filter($data))) {
                continue;
            }

            try {
                // Extract data from CSV
                $name = isset($column_map['name']) ? trim($data[$column_map['name']]) : '';
                $formula = isset($column_map['formula']) ? trim($data[$column_map['formula']]) : '';
                $company = isset($column_map['company']) ? trim($data[$column_map['company']]) : '';
                $pack_size = isset($column_map['pack_size']) ? trim($data[$column_map['pack_size']]) : '';
                
                // Get price and clean it
                $price = isset($column_map['price']) ? trim($data[$column_map['price']]) : '0';
                $price = preg_replace('/[^0-9.]/', '', $price); // Remove non-numeric characters
                $price = floatval($price);
                
                // If price is 0 or too low, generate random price
                if ($price < 10) {
                    $price = rand(50, 2000);
                }

                // Build description
                $description_parts = [];
                if ($formula) $description_parts[] = "Formula: $formula";
                if ($company) $description_parts[] = "Manufacturer: $company";
                if ($pack_size) $description_parts[] = "Pack Size: $pack_size";
                
                $description = !empty($description_parts) 
                    ? implode(' | ', $description_parts) 
                    : 'Quality medicine from Pakistan';

                // Determine category
                $category = 'prescription';
                $name_lower = strtolower($name);
                if (strpos($name_lower, 'vitamin') !== false || strpos($name_lower, 'supplement') !== false) {
                    $category = 'vitamins';
                } elseif (strpos($name_lower, 'cream') !== false || strpos($name_lower, 'ointment') !== false) {
                    $category = 'skincare';
                } elseif (strpos($name_lower, 'bandage') !== false || strpos($name_lower, 'gauze') !== false) {
                    $category = 'firstaid';
                }

                // Validate required fields
                if (empty($name)) {
                    $skipped++;
                    echo '<div class="log-item log-error">Row ' . $row_number . ': Skipped (no name)</div>';
                    continue;
                }

                // Check if product already exists
                $check_stmt = $conn->prepare("SELECT id FROM products WHERE name = ? LIMIT 1");
                $check_stmt->bind_param("s", $name);
                $check_stmt->execute();
                $result = $check_stmt->get_result();
                
                if ($result->num_rows > 0) {
                    $skipped++;
                    echo '<div class="log-item log-info">Row ' . $row_number . ': Skipped (duplicate) - ' . htmlspecialchars($name) . '</div>';
                    continue;
                }

                // Generate random stock
                $stock = rand(20, 200);

                // Insert product
                $stmt = $conn->prepare("INSERT INTO products (name, description, price, category, stock_quantity) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param("ssdsi", $name, $description, $price, $category, $stock);
                
                if ($stmt->execute()) {
                    $imported++;
                    echo '<div class="log-item log-success">Row ' . $row_number . ': ✓ Imported - ' . htmlspecialchars($name) . ' (PKR ' . number_format($price, 2) . ')</div>';
                } else {
                    $errors++;
                    echo '<div class="log-item log-error">Row ' . $row_number . ': Error - ' . $conn->error . '</div>';
                }

                // Flush output for real-time display
                if ($imported % 10 == 0) {
                    flush();
                    ob_flush();
                }

            } catch (Exception $e) {
                $errors++;
                echo '<div class="log-item log-error">Row ' . $row_number . ': Exception - ' . $e->getMessage() . '</div>';
            }
        }

        fclose($file);

        echo '</div></div>';

        // Summary
        echo '<div class="alert alert-success mt-4">';
        echo '<h5>Import Complete!</h5>';
        echo '<ul>';
        echo '<li><strong>Total Rows Processed:</strong> ' . $row_number . '</li>';
        echo '<li><strong>Successfully Imported:</strong> ' . $imported . '</li>';
        echo '<li><strong>Skipped (duplicates/invalid):</strong> ' . $skipped . '</li>';
        echo '<li><strong>Errors:</strong> ' . $errors . '</li>';
        echo '</ul>';
        echo '</div>';

        echo '<div class="text-center mt-4">';
        echo '<a href="admin/products.php" class="btn btn-primary btn-lg">View Products in Admin Panel</a>';
        echo '</div>';
        ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
