﻿<?php
session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

require_once('../api/config.php');

if (!$conn) {
    die("Database connection failed.");
}

// Handle Add Category
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add') {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $icon = $_POST['icon'] ?? 'ðŸ“¦';
    $color = $_POST['color'] ?? '#B91C1C';
    
    $stmt = $conn->prepare("INSERT INTO categories (name, description) VALUES (?, ?)");
    $stmt->bind_param("ss", $name, $description);
    
    if ($stmt->execute()) {
        $success_message = "Category added successfully!";
    }
}

// Handle Edit Category
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit') {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $description = $_POST['description'];
    
    $stmt = $conn->prepare("UPDATE categories SET name = ?, description = ? WHERE id = ?");
    $stmt->bind_param("ssi", $name, $description, $id);
    
    if ($stmt->execute()) {
        $success_message = "Category updated successfully!";
    }
}

// Handle Delete Category
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM categories WHERE id = ?");
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        $success_message = "Category deleted successfully!";
    }
}

// Get categories with product count and revenue
$result = $conn->query("SELECT c.*, 
    COUNT(DISTINCT p.id) as product_count,
    COALESCE(SUM(oi.quantity * oi.price), 0) as total_revenue,
    COALESCE(SUM(oi.quantity), 0) as total_sold
    FROM categories c 
    LEFT JOIN products p ON c.name = p.category 
    LEFT JOIN order_items oi ON p.id = oi.product_id
    GROUP BY c.id 
    ORDER BY total_revenue DESC");

// Category icons and colors mapping
$category_config = [
    'prescription' => ['icon' => 'ðŸ’Š', 'color' => '#EF4444', 'bg' => '#FEE2E2'],
    'vitamins' => ['icon' => 'ðŸ’‰', 'color' => '#10B981', 'bg' => '#D1FAE5'],
    'firstaid' => ['icon' => 'ðŸ©¹', 'color' => '#F59E0B', 'bg' => '#FEF3C7'],
    'devices' => ['icon' => 'ðŸ©º', 'color' => '#3B82F6', 'bg' => '#DBEAFE'],
    'personal' => ['icon' => 'ðŸ§´', 'color' => '#8B5CF6', 'bg' => '#EDE9FE'],
    'baby' => ['icon' => 'ðŸ‘¶', 'color' => '#EC4899', 'bg' => '#FCE7F3'],
    'skincare' => ['icon' => 'âœ¨', 'color' => '#06B6D4', 'bg' => '#CFFAFE'],
    'supplements' => ['icon' => 'ðŸŒ¿', 'color' => '#84CC16', 'bg' => '#ECFCCB']
];

// Get total stats
$total_categories = $result->num_rows;
$total_products_query = $conn->query("SELECT COUNT(*) as count FROM products");
$total_products = $total_products_query->fetch_assoc()['count'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Categories Management - MEDIX Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #B91C1C;
            --secondary-color: #991B1B;
            --sidebar-width: 250px;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
            background: linear-gradient(135deg, #F3F4F6 0%, #E5E7EB 100%);
            color: #1F2937;
        }
        
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            height: 100vh;
            width: var(--sidebar-width);
            background: linear-gradient(180deg, var(--primary-color), var(--secondary-color));
            color: white;
            overflow-y: auto;
            z-index: 1000;
            box-shadow: 4px 0 20px rgba(0,0,0,0.15);
        }
        
        .sidebar-header {
            padding: 1.5rem;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .sidebar-header h4 {
            font-weight: 700;
            font-size: 1.25rem;
        }
        
        .sidebar-menu {
            padding: 1rem 0;
        }
        
        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 0.75rem 1.5rem;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            transition: all 0.3s ease;
            font-weight: 500;
            border-left: 4px solid transparent;
        }
        
        .sidebar-menu a:hover {
            background: rgba(255, 255, 255, 0.1);
            color: white;
            border-left-color: white;
        }
        
        .sidebar-menu a.active {
            background: rgba(255, 255, 255, 0.15);
            color: white;
            border-left-color: white;
        }
        
        .sidebar-menu a i {
            margin-right: 0.75rem;
            font-size: 1.2rem;
        }
        
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 2rem;
            min-height: 100vh;
        }
        
        .top-bar {
            background: white;
            padding: 1.5rem 2rem;
            margin: -2rem -2rem 2rem -2rem;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            border-bottom: 3px solid var(--primary-color);
            border-radius: 0 0 16px 16px;
        }
        
        .top-bar h4 {
            font-weight: 700;
            color: #111827;
            font-size: 1.5rem;
            margin-bottom: 0.25rem;
        }
        
        .stat-card {
            background: white;
            border-radius: 16px;
            padding: 1.75rem;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            border: 1px solid #E5E7EB;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
        }
        
        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-color), var(--secondary-color));
        }
        
        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 24px rgba(0,0,0,0.12);
        }
        
        .category-card {
            background: white;
            border-radius: 16px;
            padding: 2rem;
            box-shadow: 0 4px 12px rgba(0,0,0,0.08);
            border: 2px solid #E5E7EB;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            height: 100%;
        }
        
        .category-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 6px;
            background: var(--cat-color, #B91C1C);
        }
        
        .category-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 16px 32px rgba(0,0,0,0.15);
            border-color: var(--cat-color, #B91C1C);
        }
        
        .category-icon {
            width: 80px;
            height: 80px;
            border-radius: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 2.5rem;
            margin: 0 auto 1.5rem;
            background: var(--cat-bg, #FEE2E2);
        }
        
        .category-card h5 {
            font-weight: 700;
            font-size: 1.25rem;
            margin-bottom: 0.75rem;
            color: #111827;
        }
        
        .category-card p {
            color: #6B7280;
            font-size: 0.875rem;
            margin-bottom: 1.5rem;
            min-height: 40px;
        }
        
        .category-stats {
            display: flex;
            justify-content: space-around;
            padding: 1rem 0;
            border-top: 2px solid #F3F4F6;
            margin-top: auto;
        }
        
        .category-stat {
            text-align: center;
        }
        
        .category-stat-value {
            font-size: 1.5rem;
            font-weight: 700;
            color: var(--cat-color, #B91C1C);
        }
        
        .category-stat-label {
            font-size: 0.75rem;
            color: #6B7280;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }
        
        .btn-danger {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            border: none;
            font-weight: 600;
            padding: 0.75rem 1.5rem;
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        
        .btn-danger:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 16px rgba(185, 28, 28, 0.4);
        }
        
        .btn-action {
            padding: 0.5rem 1rem;
            border-radius: 8px;
            font-weight: 600;
            font-size: 0.875rem;
            transition: all 0.3s ease;
        }
        
        .btn-action:hover {
            transform: translateY(-2px);
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .category-card {
            animation: fadeIn 0.5s ease-out;
        }
        
        .modal-header {
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            color: white;
            border-radius: 16px 16px 0 0;
        }
        
        .modal-content {
            border-radius: 16px;
            border: none;
        }
        
        .form-control, .form-select {
            border: 2px solid #E5E7EB;
            border-radius: 10px;
            padding: 0.75rem;
            transition: all 0.3s ease;
        }
        
        .form-control:focus, .form-select:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(185, 28, 28, 0.1);
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h4 class="mb-0"><i class="bi bi-heart-pulse-fill me-2"></i>MEDIX Admin</h4>
            <small class="text-white-50">Administrator Panel</small>
        </div>
        <div class="sidebar-menu">
            <a href="index.php">
                <i class="bi bi-speedometer2"></i> Dashboard
            </a>
            <a href="products.php">
                <i class="bi bi-box-seam"></i> Products
            </a>
            <a href="orders.php">
                <i class="bi bi-cart-check"></i> Orders
            </a>
            <a href="customers.php">
                <i class="bi bi-people"></i> Customers
            </a>
            <a href="categories.php" class="active">
                <i class="bi bi-tags"></i> Categories
            </a>
            <a href="reports.php">
                <i class="bi bi-graph-up"></i> Reports
            </a>
            <a href="messages.php">
                <i class="bi bi-envelope"></i> Messages
            </a>
            <a href="settings.php">
                <i class="bi bi-gear"></i> Settings
            </a>
            <hr class="text-white-50">
            <a href="logout.php">
                <i class="bi bi-box-arrow-right"></i> Logout
            </a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="top-bar">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h4><i class="bi bi-tags-fill me-2"></i>Categories Management</h4>
                    <small class="text-muted">Organize and manage product categories</small>
                </div>
                <button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#addCategoryModal">
                    <i class="bi bi-plus-circle me-2"></i>Add New Category
                </button>
            </div>
        </div>

        <?php if (isset($success_message)): ?>
            <div class="alert alert-success alert-dismissible fade show" style="border-radius: 12px; border-left: 4px solid #10B981;">
                <i class="bi bi-check-circle-fill me-2"></i><?= $success_message ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <!-- Summary Stats -->
        <div class="row g-4 mb-4">
            <div class="col-md-4">
                <div class="stat-card text-center">
                    <i class="bi bi-tags-fill" style="font-size: 2.5rem; color: var(--primary-color);"></i>
                    <h3 class="mt-2 mb-0" style="font-size: 2.5rem; font-weight: 700; color: var(--primary-color);"><?= $total_categories ?></h3>
                    <p class="text-muted mb-0" style="font-size: 0.875rem; text-transform: uppercase; letter-spacing: 0.5px;">Total Categories</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card text-center">
                    <i class="bi bi-box-seam-fill" style="font-size: 2.5rem; color: #3B82F6;"></i>
                    <h3 class="mt-2 mb-0" style="font-size: 2.5rem; font-weight: 700; color: #3B82F6;"><?= $total_products ?></h3>
                    <p class="text-muted mb-0" style="font-size: 0.875rem; text-transform: uppercase; letter-spacing: 0.5px;">Total Products</p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-card text-center">
                    <i class="bi bi-graph-up-arrow" style="font-size: 2.5rem; color: #10B981;"></i>
                    <h3 class="mt-2 mb-0" style="font-size: 2.5rem; font-weight: 700; color: #10B981;">
                        <?= $total_categories > 0 ? number_format($total_products / $total_categories, 1) : 0 ?>
                    </h3>
                    <p class="text-muted mb-0" style="font-size: 0.875rem; text-transform: uppercase; letter-spacing: 0.5px;">Avg Products/Category</p>
                </div>
            </div>
        </div>

        <!-- Categories Grid -->
        <div class="row g-4">
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while ($category = $result->fetch_assoc()): 
                    $config = $category_config[strtolower($category['name'])] ?? ['icon' => 'ðŸ“¦', 'color' => '#B91C1C', 'bg' => '#FEE2E2'];
                ?>
                <div class="col-md-4 col-lg-3">
                    <div class="category-card" style="--cat-color: <?= $config['color'] ?>; --cat-bg: <?= $config['bg'] ?>;">
                        <div class="category-icon">
                            <?= $config['icon'] ?>
                        </div>
                        <h5 class="text-center"><?= ucfirst(htmlspecialchars($category['name'])) ?></h5>
                        <p class="text-center"><?= htmlspecialchars($category['description']) ?></p>
                        
                        <div class="category-stats">
                            <div class="category-stat">
                                <div class="category-stat-value"><?= $category['product_count'] ?></div>
                                <div class="category-stat-label">Products</div>
                            </div>
                            <div class="category-stat">
                                <div class="category-stat-value"><?= $category['total_sold'] ?></div>
                                <div class="category-stat-label">Sold</div>
                            </div>
                            <div class="category-stat">
                                <div class="category-stat-value">PKR <?= number_format($category['total_revenue'], 0) ?></div>
                                <div class="category-stat-label">Revenue</div>
                            </div>
                        </div>
                        
                        <div class="d-flex gap-2 mt-3">
                            <button class="btn btn-sm btn-outline-primary btn-action flex-fill" onclick="editCategory(<?= $category['id'] ?>, '<?= htmlspecialchars($category['name']) ?>', '<?= htmlspecialchars($category['description']) ?>')">
                                <i class="bi bi-pencil"></i> Edit
                            </button>
                            <a href="?delete=<?= $category['id'] ?>" class="btn btn-sm btn-outline-danger btn-action" onclick="return confirm('Delete this category? This will not delete products.')">
                                <i class="bi bi-trash"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col-12">
                    <div class="text-center py-5" style="background: white; border-radius: 16px;">
                        <i class="bi bi-tags" style="font-size: 5rem; color: #D1D5DB;"></i>
                        <h4 class="mt-3 text-muted">No Categories Yet</h4>
                        <p class="text-muted">Start by adding your first product category</p>
                        <button class="btn btn-danger mt-3" data-bs-toggle="modal" data-bs-target="#addCategoryModal">
                            <i class="bi bi-plus-circle me-2"></i>Add First Category
                        </button>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Add Category Modal -->
    <div class="modal fade" id="addCategoryModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-plus-circle me-2"></i>Add New Category</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="add">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Category Name *</label>
                            <input type="text" class="form-control" name="name" placeholder="e.g., Vitamins" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Description *</label>
                            <textarea class="form-control" name="description" rows="3" placeholder="Brief description of this category" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger">
                            <i class="bi bi-check-circle me-1"></i>Add Category
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Edit Category Modal -->
    <div class="modal fade" id="editCategoryModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><i class="bi bi-pencil me-2"></i>Edit Category</h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                </div>
                <form method="POST">
                    <div class="modal-body">
                        <input type="hidden" name="action" value="edit">
                        <input type="hidden" name="id" id="edit_id">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Category Name *</label>
                            <input type="text" class="form-control" name="name" id="edit_name" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label fw-bold">Description *</label>
                            <textarea class="form-control" name="description" id="edit_description" rows="3" required></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-danger">
                            <i class="bi bi-check-circle me-1"></i>Update Category
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function editCategory(id, name, description) {
            document.getElementById('edit_id').value = id;
            document.getElementById('edit_name').value = name;
            document.getElementById('edit_description').value = description;
            new bootstrap.Modal(document.getElementById('editCategoryModal')).show();
        }
        
        // Auto-dismiss alerts
        setTimeout(function() {
            const alerts = document.querySelectorAll('.alert');
            alerts.forEach(alert => {
                const bsAlert = new bootstrap.Alert(alert);
                bsAlert.close();
            });
        }, 5000);
    </script>
</body>
</html>

