<?php
header('Content-Type: application/json');
session_start();
require_once 'config.php';
require_once 'mailer.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}

$name     = trim($_POST['name'] ?? '');
$email    = trim($_POST['email'] ?? '');
$phone    = trim($_POST['phone'] ?? '');
$password = $_POST['password'] ?? '';

if (!$name || !$email || !$password) {
    echo json_encode(['success' => false, 'message' => 'Name, email and password are required.']);
    exit;
}
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo json_encode(['success' => false, 'message' => 'Invalid email address.']);
    exit;
}
if (strlen($password) < 6) {
    echo json_encode(['success' => false, 'message' => 'Password must be at least 6 characters.']);
    exit;
}
if (!$conn) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed.']);
    exit;
}

// Ensure tables
$conn->query("CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) DEFAULT '',
    username VARCHAR(150) DEFAULT '',
    email VARCHAR(200) UNIQUE NOT NULL,
    phone VARCHAR(30) DEFAULT '',
    password VARCHAR(255) NOT NULL,
    email_verified TINYINT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$conn->query("ALTER TABLE users ADD COLUMN IF NOT EXISTS email_verified TINYINT DEFAULT 0");

$conn->query("CREATE TABLE IF NOT EXISTS email_verifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(200) NOT NULL,
    otp VARCHAR(6) NOT NULL,
    expires_at DATETIME NOT NULL,
    verified TINYINT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

// Check if email already registered AND verified
$chk = $conn->prepare("SELECT id, email_verified FROM users WHERE email=?");
$chk->bind_param("s", $email); $chk->execute();
$existing = $chk->get_result()->fetch_assoc();
$chk->close();

if ($existing && $existing['email_verified']) {
    echo json_encode(['success' => false, 'message' => 'This email is already registered. Please login instead.']);
    exit;
}

// Hash password
$hashed = password_hash($password, PASSWORD_DEFAULT);

if ($existing) {
    // Update existing unverified account
    $u = $conn->prepare("UPDATE users SET name=?, username=?, phone=?, password=? WHERE email=?");
    $u->bind_param("sssss", $name, $name, $phone, $hashed, $email);
    $u->execute();
} else {
    // Insert new unverified account
    $stmt = $conn->prepare("INSERT INTO users (name, username, email, phone, password, email_verified) VALUES (?,?,?,?,?,0)");
    $stmt->bind_param("sssss", $name, $name, $email, $phone, $hashed);
    if (!$stmt->execute()) {
        echo json_encode(['success' => false, 'message' => 'Registration failed: ' . $conn->error]);
        exit;
    }
    $stmt->close();
}

// Generate 6-digit OTP
$otp = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
$exp = date('Y-m-d H:i:s', strtotime('+15 minutes'));

// Delete old OTPs for this email
$conn->query("DELETE FROM email_verifications WHERE email='" . $conn->real_escape_string($email) . "'");

// Save OTP
$ins = $conn->prepare("INSERT INTO email_verifications (email, otp, expires_at) VALUES (?,?,?)");
$ins->bind_param("sss", $email, $otp, $exp);
$ins->execute();
$ins->close();

// Store in session for verify page
$_SESSION['pending_email']    = $email;
$_SESSION['pending_name']     = $name;
$_SESSION['pending_password'] = $hashed;

// Send OTP email
$content = '
    <h2>Verify Your Email</h2>
    <p>Hi <strong>' . htmlspecialchars($name) . '</strong>, welcome to MEDIX!</p>
    <p>Your email verification code is:</p>
    <div style="text-align:center;margin:30px 0">
        <div style="background:linear-gradient(135deg,#B91C1C,#7F1D1D);color:white;font-size:42px;font-weight:900;letter-spacing:12px;padding:20px 40px;border-radius:16px;display:inline-block">' . $otp . '</div>
    </div>
    <p style="text-align:center;color:#64748b">This code expires in <strong>15 minutes</strong>.</p>
    <p style="color:#64748b;font-size:13px">If you did not create a MEDIX account, please ignore this email.</p>';
$html = emailTemplate('Verify Your Email', $content);
$sent = sendMail($email, $name, 'Your MEDIX Verification Code: ' . $otp, $html, $conn);

echo json_encode([
    'success'  => true,
    'message'  => 'Account created! Please check your email for the verification code.',
    'redirect' => 'verify_email.php',
    'otp_sent' => $sent
]);
?>
