<?php
require_once('api/config.php');
echo "<style>body{font-family:sans-serif;padding:2rem;background:#f8fafc} table{border-collapse:collapse;width:100%} td,th{border:1px solid #ddd;padding:8px;font-size:13px}</style>";
echo "<h3>Latest Messages & Attachments</h3>";

if (!$conn) { echo "DB failed"; exit; }

// Ensure column exists
$conn->query("ALTER TABLE contact_messages ADD COLUMN IF NOT EXISTS attachment VARCHAR(255) DEFAULT NULL");

$r = $conn->query("SELECT id, email, message, attachment, created_at FROM contact_messages ORDER BY id DESC LIMIT 5");
echo "<table><tr><th>ID</th><th>Email</th><th>Message</th><th>Attachment (DB value)</th><th>File on disk?</th><th>Image</th></tr>";
while ($row = $r->fetch_assoc()) {
    $att = $row['attachment'];
    $disk = $att ? (file_exists(__DIR__.'/'.$att) ? '✅ YES' : '❌ NO - path: '.__DIR__.'/'.$att) : 'NULL';
    $img = '';
    if ($att && preg_match('/\.(jpg|jpeg|png|gif|webp)$/i', $att)) {
        $img = "<img src='/ppp/$att' style='max-height:80px' onerror=\"this.src='';this.alt='BROKEN PATH'\">";
    }
    echo "<tr>
        <td>{$row['id']}</td>
        <td>{$row['email']}</td>
        <td>".htmlspecialchars(substr($row['message'],0,30))."</td>
        <td>".($att ?: '<em>NULL</em>')."</td>
        <td>$disk</td>
        <td>$img</td>
    </tr>";
}
echo "</table>";

echo "<hr><h4>uploads/messages/ folder contents:</h4>";
$dir = __DIR__.'/uploads/messages/';
if (!is_dir($dir)) {
    echo "<p style='color:red'>Folder does not exist! Creating...</p>";
    mkdir($dir, 0755, true);
} else {
    $files = array_diff(scandir($dir), ['.','..']);
    if (empty($files)) {
        echo "<p style='color:orange'>Folder is EMPTY — no files have been uploaded yet</p>";
    } else {
        foreach ($files as $f) {
            echo "<div><a href='/ppp/uploads/messages/$f' target='_blank'>$f</a> (".round(filesize($dir.$f)/1024,1)." KB)</div>";
        }
    }
}
?>
