<?php
// Simple test to check messages system
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Messages System Test</h1>";

// Test 1: Check if config file exists
echo "<h3>Test 1: Config File</h3>";
if (file_exists('api/config.php')) {
    echo "✅ Config file exists<br>";
    require_once('api/config.php');
    
    if (isset($conn) && $conn) {
        echo "✅ Database connected<br>";
        
        // Test 2: Check if table exists
        echo "<h3>Test 2: Table Check</h3>";
        $result = $conn->query("SHOW TABLES LIKE 'contact_messages'");
        if ($result && $result->num_rows > 0) {
            echo "✅ Table exists<br>";
            
            // Test 3: Count messages
            echo "<h3>Test 3: Message Count</h3>";
            $count_result = $conn->query("SELECT COUNT(*) as count FROM contact_messages");
            if ($count_result) {
                $count = $count_result->fetch_assoc()['count'];
                echo "✅ Total messages: $count<br>";
            }
        } else {
            echo "❌ Table does NOT exist<br>";
            echo "<a href='setup_contact_messages.php'>Click here to create table</a><br>";
        }
    } else {
        echo "❌ Database connection failed<br>";
    }
} else {
    echo "❌ Config file not found<br>";
}

echo "<hr>";
echo "<h3>Next Steps:</h3>";
echo "<ol>";
echo "<li><a href='setup_contact_messages.php'>Run Setup Script</a></li>";
echo "<li><a href='admin/test_messages.php'>Run Debug Script</a></li>";
echo "<li><a href='contact.html'>Test Contact Form</a></li>";
echo "<li><a href='admin/messages.php'>View Messages (Admin)</a></li>";
echo "</ol>";
?>
