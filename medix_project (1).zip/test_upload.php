<?php
session_start();
$_SESSION['admin_logged_in'] = true; // bypass auth for testing

$result = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['image'])) {
    $file = $_FILES['image'];
    
    // Try to create upload folder
    $upload_dir = __DIR__ . '/uploads/products/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }
    
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $filename = 'test_' . time() . '.' . $ext;
    $filepath = $upload_dir . $filename;
    
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        $url = 'uploads/products/' . $filename;
        $result = "<div style='color:green;padding:1rem;background:#f0fdf4;border-radius:8px;margin:1rem 0'>
            ✅ Upload SUCCESS!<br>
            File: $filename<br>
            URL: $url<br>
            <img src='$url' style='max-width:200px;margin-top:1rem;border-radius:8px'>
        </div>";
    } else {
        $result = "<div style='color:red;padding:1rem;background:#fef2f2;border-radius:8px;margin:1rem 0'>
            ❌ Upload FAILED<br>
            Error: " . $file['error'] . "<br>
            Upload dir: $upload_dir<br>
            Dir exists: " . (is_dir($upload_dir) ? 'YES' : 'NO') . "<br>
            Dir writable: " . (is_writable($upload_dir) ? 'YES' : 'NO') . "
        </div>";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Upload Test</title>
    <style>body{font-family:Arial;padding:2rem;max-width:600px;margin:0 auto}</style>
</head>
<body>
    <h2>Image Upload Test</h2>
    <?= $result ?>
    
    <form method="POST" enctype="multipart/form-data" style="background:#f8f9fa;padding:2rem;border-radius:12px">
        <div style="margin-bottom:1rem">
            <label style="font-weight:bold;display:block;margin-bottom:.5rem">Select Image:</label>
            <input type="file" name="image" accept="image/*" required style="padding:.5rem;border:1px solid #ddd;border-radius:8px;width:100%">
        </div>
        <button type="submit" style="background:#B91C1C;color:white;padding:.75rem 2rem;border:none;border-radius:8px;cursor:pointer;font-size:1rem">
            Upload Image
        </button>
    </form>
    
    <div style="margin-top:2rem;background:#fff3cd;padding:1rem;border-radius:8px">
        <strong>Debug Info:</strong><br>
        Upload dir: <?= __DIR__ . '/uploads/products/' ?><br>
        Dir exists: <?= is_dir(__DIR__ . '/uploads/products/') ? '✅ YES' : '❌ NO' ?><br>
        Dir writable: <?= is_writable(__DIR__ . '/uploads/products/') ? '✅ YES' : '❌ NO (permission issue)' ?><br>
        PHP upload_max_filesize: <?= ini_get('upload_max_filesize') ?><br>
        PHP post_max_size: <?= ini_get('post_max_size') ?>
    </div>
</body>
</html>
