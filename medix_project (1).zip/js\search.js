/**
 * MEDIX Fast Search
 */
class MedixSearch {
    constructor(inputId, suggestionsId, options = {}) {
        this.input = document.getElementById(inputId);
        this.box = document.getElementById(suggestionsId);
        this.selectedIndex = -1;
        this.cache = {};
        this.debounceTimer = null;
        this.apiPath = options.apiPath || 'api/search_suggestions.php';
        this.redirectPath = options.redirectPath || 'products.php';
        this.minChars = 1; // Start searching from 1 character

        if (!this.input || !this.box) return;
        this.init();
    }

    init() {
        this.input.addEventListener('input', () => this.onInput());
        this.input.addEventListener('keydown', (e) => this.onKeyDown(e));
        this.input.addEventListener('focus', () => {
            if (this.input.value.length >= this.minChars) this.onInput();
        });
        document.addEventListener('click', (e) => {
            if (!this.input.closest('.search-container')?.contains(e.target) &&
                !this.box.contains(e.target)) {
                this.hide();
            }
        });
    }

    onInput() {
        const q = this.input.value.trim();
        clearTimeout(this.debounceTimer);

        if (q.length < this.minChars) { this.hide(); return; }

        // Instant cache hit
        if (this.cache[q]) {
            this.render(this.cache[q], q);
            return;
        }

        // Show loading immediately
        this.showLoading();

        // Fast debounce: 150ms
        this.debounceTimer = setTimeout(() => this.fetch(q), 150);
    }

    fetch(q) {
        fetch(`${this.apiPath}?q=${encodeURIComponent(q)}`)
            .then(r => r.json())
            .then(data => {
                this.cache[q] = data;
                // Also cache partial matches
                if (q.length > 2) {
                    this.cache[q.slice(0, -1)] = this.cache[q.slice(0, -1)] || data;
                }
                this.render(data, q);
            })
            .catch(() => this.hide());
    }

    render(data, q) {
        this.selectedIndex = -1;

        if (data.length === 0) {
            this.box.innerHTML = `
                <div class="s-empty">
                    <i class="bi bi-search"></i>
                    No results for "<strong>${this.escape(q)}</strong>"
                    <a href="${this.redirectPath}?search=${encodeURIComponent(q)}">Search all →</a>
                </div>`;
            this.show();
            return;
        }

        const html = `
            <div class="s-header">
                <i class="bi bi-lightning-charge-fill"></i> Results
                <a href="${this.redirectPath}?search=${encodeURIComponent(q)}" class="s-view-all">See all →</a>
            </div>
            ${data.map((item, i) => `
                <div class="s-item" data-index="${i}" onclick="window.location.href='${this.redirectPath}?search=${encodeURIComponent(item.name)}'">
                    <div class="s-item-icon"><i class="bi bi-capsule-pill"></i></div>
                    <div class="s-item-info">
                        <div class="s-item-name">${this.highlight(item.name, q)}</div>
                        <div class="s-item-meta">
                            <span class="s-cat">${item.category}</span>
                            <span class="s-price">${item.price}</span>
                        </div>
                    </div>
                    <div class="s-item-stock ${item.in_stock ? 'in' : 'out'}">
                        ${item.in_stock ? '<i class="bi bi-check-circle-fill"></i>' : '<i class="bi bi-x-circle-fill"></i>'}
                    </div>
                </div>
            `).join('')}
            <div class="s-footer" onclick="window.location.href='${this.redirectPath}?search=${encodeURIComponent(q)}'">
                <i class="bi bi-search me-2"></i>Search all results for "<strong>${this.escape(q)}</strong>"
            </div>`;

        this.box.innerHTML = html;
        this.show();
    }

    showLoading() {
        this.box.innerHTML = `<div class="s-loading"><div class="s-spinner"></div> Searching...</div>`;
        this.show();
    }

    show() { this.box.style.display = 'block'; }
    hide() { this.box.style.display = 'none'; }

    onKeyDown(e) {
        const items = this.box.querySelectorAll('.s-item');
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            this.selectedIndex = Math.min(this.selectedIndex + 1, items.length - 1);
            this.updateActive(items);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            this.selectedIndex = Math.max(this.selectedIndex - 1, -1);
            this.updateActive(items);
        } else if (e.key === 'Enter') {
            if (this.selectedIndex >= 0 && items[this.selectedIndex]) {
                e.preventDefault();
                items[this.selectedIndex].click();
            } else if (this.input.value.trim()) {
                window.location.href = `${this.redirectPath}?search=${encodeURIComponent(this.input.value.trim())}`;
            }
        } else if (e.key === 'Escape') {
            this.hide();
        }
    }

    updateActive(items) {
        items.forEach((el, i) => el.classList.toggle('active', i === this.selectedIndex));
        if (this.selectedIndex >= 0 && items[this.selectedIndex]) {
            items[this.selectedIndex].scrollIntoView({ block: 'nearest' });
        }
    }

    highlight(text, q) {
        const safe = q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        return text.replace(new RegExp(`(${safe})`, 'gi'), '<mark>$1</mark>');
    }

    escape(text) {
        return text.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
    }
}

// Inject CSS once
(function() {
    if (document.getElementById('medix-search-css')) return;
    const style = document.createElement('style');
    style.id = 'medix-search-css';
    style.textContent = `
        .search-container { position: relative; }
        .s-dropdown {
            position: absolute; top: calc(100% + 6px); left: 0; right: 0;
            background: white; border-radius: 16px;
            box-shadow: 0 20px 60px rgba(0,0,0,.18);
            z-index: 99999; overflow: hidden;
            border: 1px solid #f1f5f9; display: none;
            max-height: 420px; overflow-y: auto;
            animation: fadeIn .15s ease;
        }
        @keyframes fadeIn { from { opacity:0; transform:translateY(-8px); } to { opacity:1; transform:translateY(0); } }
        .s-header { padding:.6rem 1rem; font-size:.72rem; font-weight:700; color:#94a3b8; text-transform:uppercase; letter-spacing:.5px; background:#f8fafc; display:flex; justify-content:space-between; align-items:center; }
        .s-view-all { color:#B91C1C; text-decoration:none; font-weight:600; font-size:.75rem; text-transform:none; letter-spacing:0; }
        .s-item { padding:.75rem 1rem; cursor:pointer; display:flex; align-items:center; gap:.75rem; border-bottom:1px solid #f8fafc; transition:background .1s; }
        .s-item:hover, .s-item.active { background:#fef2f2; }
        .s-item-icon { width:36px; height:36px; background:#fee2e2; border-radius:10px; display:flex; align-items:center; justify-content:center; color:#B91C1C; font-size:1rem; flex-shrink:0; }
        .s-item-info { flex:1; min-width:0; }
        .s-item-name { font-weight:600; font-size:.875rem; color:#1e293b; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
        .s-item-name mark { background:none; color:#B91C1C; font-weight:800; padding:0; }
        .s-item-meta { display:flex; gap:.5rem; margin-top:.2rem; align-items:center; }
        .s-cat { font-size:.7rem; background:#f1f5f9; color:#64748b; padding:.15rem .5rem; border-radius:20px; font-weight:500; }
        .s-price { font-size:.75rem; color:#B91C1C; font-weight:700; }
        .s-item-stock { font-size:.9rem; flex-shrink:0; }
        .s-item-stock.in { color:#10b981; }
        .s-item-stock.out { color:#ef4444; }
        .s-footer { padding:.75rem 1rem; font-size:.8rem; color:#64748b; cursor:pointer; background:#f8fafc; text-align:center; transition:background .15s; }
        .s-footer:hover { background:#f1f5f9; color:#B91C1C; }
        .s-empty { padding:1.25rem 1rem; text-align:center; color:#94a3b8; font-size:.875rem; display:flex; flex-direction:column; gap:.5rem; align-items:center; }
        .s-empty i { font-size:1.5rem; }
        .s-empty a { color:#B91C1C; text-decoration:none; font-weight:600; }
        .s-loading { padding:1rem; text-align:center; color:#94a3b8; font-size:.875rem; display:flex; align-items:center; justify-content:center; gap:.5rem; }
        .s-spinner { width:16px; height:16px; border:2px solid #f1f5f9; border-top-color:#B91C1C; border-radius:50%; animation:spin .5s linear infinite; }
        @keyframes spin { to { transform:rotate(360deg); } }
    `;
    document.head.appendChild(style);
})();
