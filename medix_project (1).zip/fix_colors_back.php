<?php
// Revert all blue back to red in CSS and all PHP/HTML files
$files = [
    'css/style.css',
    'products.php',
    'checkout.php',
    'cart.php',
    'order_success.php',
    'about.html',
    'contact.html',
    'register.html',
    'login.html',
    'index.html',
];

$replacements = [
    '#1D4ED8' => '#B91C1C',
    '#1E40AF' => '#991B1B',
    '#1E3A8A' => '#7F1D1D',
    '#2563EB' => '#DC2626',
    '#EFF6FF' => '#FEF2F2',
    '#DBEAFE' => '#FEE2E2',
    'rgba(29,78,216'   => 'rgba(185,28,28',
    'rgba(29, 78, 216' => 'rgba(185, 28, 28',
    'rgba(30,58,138'   => 'rgba(127,29,29',
    'rgba(30, 58, 138' => 'rgba(127, 29, 29',
    'rgba(37,99,235'   => 'rgba(220,38,38',
    'rgba(37, 99, 235' => 'rgba(220, 38, 38',
];

$total = 0;
foreach ($files as $file) {
    $path = __DIR__ . '/' . $file;
    if (!file_exists($path)) { echo "SKIP: $file\n"; continue; }
    $content = file_get_contents($path);
    $original = $content;
    foreach ($replacements as $old => $new) {
        $content = str_replace($old, $new, $content);
    }
    // Also fix the Bootstrap override block in index.html that was changed to blue
    if ($content !== $original) {
        file_put_contents($path, $content);
        echo "FIXED: $file\n";
        $total++;
    } else {
        echo "OK: $file\n";
    }
}
echo "\nDone! Reverted $total files back to red theme.\n";
?>
