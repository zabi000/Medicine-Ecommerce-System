<?php
require_once('api/config.php');
echo "<h3>Contact Form Debug</h3>";
if (!$conn) { echo "DB FAILED"; exit; }

// Check table
$t = $conn->query("SHOW TABLES LIKE 'contact_messages'");
if (!$t || $t->num_rows == 0) {
    echo "<p style='color:red'>contact_messages table MISSING — creating...</p>";
    $conn->query("CREATE TABLE IF NOT EXISTS contact_messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        first_name VARCHAR(100) DEFAULT '',
        last_name VARCHAR(100) DEFAULT '',
        email VARCHAR(200) NOT NULL,
        phone VARCHAR(30) DEFAULT '',
        subject VARCHAR(200) DEFAULT 'General',
        message TEXT NOT NULL,
        attachment VARCHAR(255) DEFAULT NULL,
        status ENUM('new','read','replied') DEFAULT 'new',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    echo "<p style='color:green'>Created!</p>";
} else {
    echo "<p style='color:green'>✅ Table exists</p>";
}

// Show recent messages
$r = $conn->query("SELECT * FROM contact_messages ORDER BY id DESC LIMIT 5");
echo "<h4>Recent messages:</h4>";
if ($r && $r->num_rows > 0) {
    echo "<table border=1 cellpadding=6><tr><th>ID</th><th>Name</th><th>Email</th><th>Subject</th><th>Message</th><th>Date</th></tr>";
    while ($row = $r->fetch_assoc()) {
        echo "<tr><td>{$row['id']}</td><td>{$row['first_name']} {$row['last_name']}</td><td>{$row['email']}</td><td>{$row['subject']}</td><td>".substr($row['message'],0,50)."</td><td>{$row['created_at']}</td></tr>";
    }
    echo "</table>";
} else {
    echo "<p style='color:orange'>No messages yet</p>";
}

// Test submit
echo "<h4>Test Submit:</h4>";
echo "<form method='POST' action='api/submit_contact.php'>
<input type='hidden' name='firstName' value='Test'>
<input type='hidden' name='lastName' value='User'>
<input type='hidden' name='email' value='test@test.com'>
<input type='hidden' name='phone' value='0300-1234567'>
<input type='hidden' name='subject' value='general'>
<input type='hidden' name='message' value='Test message from debug page'>
<button type='submit' style='background:#B91C1C;color:white;padding:.5rem 1rem;border:none;border-radius:8px'>Send Test Message</button>
</form>";
?>
