<?php
// ============================================================
//  MEDIX — Database & App Configuration
//  Edit the values below when deploying to live server
// ============================================================

// --- Database Credentials ---
// LOCAL:  host=localhost, user=root, pass='', db=medicare_db
// LIVE:   Change to your hosting provider's DB credentials
define('DB_HOST', 'localhost');
define('DB_USER', 'root');       // Change on live server
define('DB_PASS', '');           // Change on live server
define('DB_NAME', 'medicare_db'); // Change on live server

// --- App Base Path ---
// LOCAL:  '/ppp'   (because site is at localhost/ppp/)
// LIVE:   ''       (if site is at domain root e.g. yourdomain.com/)
//         '/medix' (if site is at yourdomain.com/medix/)
define('APP_BASE', getenv('APP_BASE') ?: _detectBase());

function _detectBase() {
    // Auto-detect: if running on localhost with /ppp/ subfolder
    $host = $_SERVER['HTTP_HOST'] ?? '';
    $uri  = $_SERVER['REQUEST_URI'] ?? '';
    if (str_contains($host, 'localhost') || str_contains($host, '127.0.0.1')) {
        return '/ppp';
    }
    // On live server — site is at domain root
    return '';
}

// --- Create database connection ---
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    $conn = null; // Pages will show gracefully without DB
}
if ($conn) {
    $conn->set_charset('utf8mb4');
}

// Backward compatibility
function getDBConnection() {
    global $conn;
    return $conn;
}
?>
