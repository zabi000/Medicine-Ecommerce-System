<?php
require_once('api/config.php');

echo "<h2>Database Debug</h2>";

// Check connection
if (!$conn) {
    echo "<p style='color:red'>❌ Database NOT connected</p>";
    exit;
}
echo "<p style='color:green'>✅ Database connected</p>";

// Count products
$result = $conn->query("SELECT COUNT(*) as total FROM products");
$count = $result->fetch_assoc()['total'];
echo "<p>Total products in database: <strong>$count</strong></p>";

// Test search for 'pain'
$stmt = $conn->prepare("SELECT name, category FROM products WHERE name LIKE ? OR description LIKE ? LIMIT 10");
$s = "%pain%";
$stmt->bind_param("ss", $s, $s);
$stmt->execute();
$res = $stmt->get_result();
echo "<h3>Search 'pain' results (" . $res->num_rows . "):</h3><ul>";
while ($r = $res->fetch_assoc()) echo "<li>{$r['name']} ({$r['category']})</li>";
echo "</ul>";

// Show first 10 products
$result = $conn->query("SELECT name, category FROM products LIMIT 10");
echo "<h3>First 10 products in DB:</h3><ul>";
while ($r = $result->fetch_assoc()) echo "<li>{$r['name']} ({$r['category']})</li>";
echo "</ul>";
?>
