<?php
session_start();
require_once('api/config.php');
require_once('api/mailer.php');

$result = '';
$sent = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $to = trim($_POST['to_email'] ?? '');
    if (!$to) {
        $result = '<div class="alert alert-danger">Please enter an email address.</div>';
    } else {
        $content = '
            <h2>Test Email from MEDIX</h2>
            <p>This is a test email to verify your Mailtrap SMTP configuration is working correctly.</p>
            <div class="info-box">
                <div class="info-row"><span class="info-label">Sent at</span><span class="info-value">' . date('Y-m-d H:i:s') . '</span></div>
                <div class="info-row"><span class="info-label">Server</span><span class="info-value">localhost/ppp</span></div>
            </div>
            <p style="color:#059669;font-weight:700">✅ If you see this in Mailtrap, your email system is working!</p>';
        $html = emailTemplate('Test Email', $content, 'This is a test email from MEDIX Pharmacy.');
        $sent = sendMail($to, 'Test Recipient', 'MEDIX Test Email - ' . date('H:i:s'), $html, $conn);
        if ($sent) {
            $result = '<div class="alert alert-success"><i class="bi bi-check-circle-fill me-2"></i><strong>Email sent successfully!</strong> Check your Mailtrap inbox at <a href="https://mailtrap.io" target="_blank">mailtrap.io</a></div>';
        } else {
            $result = '<div class="alert alert-danger"><i class="bi bi-exclamation-triangle me-2"></i><strong>Email failed.</strong> Check your SMTP credentials in <a href="admin/settings.php">Admin Settings</a>.</div>';
        }
    }
}

// Load current SMTP settings
$smtp_user = getSetting($conn, 'smtp_user', '');
$smtp_host = getSetting($conn, 'smtp_host', 'sandbox.smtp.mailtrap.io');
$smtp_port = getSetting($conn, 'smtp_port', '2525');
$admin_email = getSetting($conn, 'admin_email', '');

function getSetting($conn, $key, $default = '') {
    if (!$conn) return $default;
    $r = $conn->query("SELECT value FROM site_settings WHERE `key`='" . $conn->real_escape_string($key) . "'");
    if ($r && $row = $r->fetch_assoc()) return $row['value'];
    return $default;
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Test Email - MEDIX</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body style="background:#f8fafc;padding:2rem;font-family:sans-serif">
<div style="max-width:600px;margin:0 auto">
    <h3><i class="bi bi-envelope-check me-2 text-danger"></i>Test Mailtrap Email</h3>

    <div class="card mb-4 border-0 shadow-sm" style="border-radius:12px">
        <div class="card-body p-4">
            <h6 class="fw-bold mb-3">Current SMTP Configuration:</h6>
            <?php if (!$smtp_user): ?>
            <div class="alert alert-warning">
                <i class="bi bi-exclamation-triangle me-2"></i>
                SMTP not configured yet. <a href="admin/settings.php">Go to Admin Settings</a> to add your Mailtrap credentials.
            </div>
            <?php else: ?>
            <table class="table table-sm">
                <tr><td class="text-muted">Host</td><td><strong><?= htmlspecialchars($smtp_host) ?></strong></td></tr>
                <tr><td class="text-muted">Port</td><td><strong><?= htmlspecialchars($smtp_port) ?></strong></td></tr>
                <tr><td class="text-muted">Username</td><td><strong><?= htmlspecialchars($smtp_user) ?></strong></td></tr>
                <tr><td class="text-muted">Admin Email</td><td><strong><?= htmlspecialchars($admin_email ?: 'Not set') ?></strong></td></tr>
            </table>
            <?php endif; ?>
        </div>
    </div>

    <?= $result ?>

    <div class="card border-0 shadow-sm" style="border-radius:12px">
        <div class="card-body p-4">
            <h6 class="fw-bold mb-3">Send Test Email:</h6>
            <form method="POST">
                <div class="mb-3">
                    <label class="form-label fw-semibold">Send test to email:</label>
                    <input type="email" name="to_email" class="form-control"
                           value="<?= htmlspecialchars($_POST['to_email'] ?? $admin_email) ?>"
                           placeholder="any@email.com" required>
                    <small class="text-muted">Use any email — it will appear in your Mailtrap inbox</small>
                </div>
                <button type="submit" class="btn btn-danger px-4">
                    <i class="bi bi-send-fill me-2"></i>Send Test Email
                </button>
                <a href="admin/settings.php" class="btn btn-outline-secondary ms-2">
                    <i class="bi bi-gear me-1"></i>Edit SMTP Settings
                </a>
            </form>
        </div>
    </div>

    <div class="mt-4 p-3 rounded-3" style="background:#eff6ff;border:1px solid #93c5fd">
        <h6 class="fw-bold text-primary mb-2"><i class="bi bi-info-circle me-2"></i>Setup Instructions:</h6>
        <ol class="mb-0 small">
            <li>Go to <a href="admin/settings.php">Admin Settings</a> → Email & SMTP section</li>
            <li>Enter: Host = <code>sandbox.smtp.mailtrap.io</code>, Port = <code>2525</code></li>
            <li>Enter your Mailtrap Username and Password</li>
            <li>Click <strong>Save All Settings</strong></li>
            <li>Come back here and click <strong>Send Test Email</strong></li>
            <li>Check <a href="https://mailtrap.io" target="_blank">mailtrap.io</a> inbox — email should appear within seconds</li>
        </ol>
    </div>
</div>
</body>
</html>
