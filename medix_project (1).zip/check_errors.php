<?php
// Enable ALL error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);

echo "<h1>Error Check</h1>";
echo "<p>PHP Version: " . phpversion() . "</p>";

// Test 1: Basic PHP
echo "<p>✓ PHP is working</p>";

// Test 2: Database file exists
if (file_exists('api/config.php')) {
    echo "<p>✓ api/config.php exists</p>";
    
    // Try to include it
    try {
        require_once('api/config.php');
        echo "<p>✓ api/config.php loaded</p>";
        
        if (isset($conn)) {
            echo "<p>✓ \$conn variable exists</p>";
            
            if ($conn) {
                echo "<p style='color:green;font-weight:bold;'>✓ DATABASE CONNECTED!</p>";
                
                // Test query
                $result = $conn->query("SELECT 1");
                if ($result) {
                    echo "<p>✓ Can execute queries</p>";
                } else {
                    echo "<p style='color:red;'>✗ Cannot execute queries: " . $conn->error . "</p>";
                }
            } else {
                echo "<p style='color:red;'>✗ Database connection is NULL</p>";
                echo "<p>Check your database credentials in api/config.php</p>";
            }
        } else {
            echo "<p style='color:red;'>✗ \$conn variable not set</p>";
        }
    } catch (Exception $e) {
        echo "<p style='color:red;'>✗ Error loading config: " . $e->getMessage() . "</p>";
    }
} else {
    echo "<p style='color:red;'>✗ api/config.php NOT FOUND!</p>";
}

echo "<hr>";
echo "<h2>Next Steps:</h2>";
echo "<ol>";
echo "<li>If you see 'DATABASE CONNECTED' above, your database is working</li>";
echo "<li>If not, check your database credentials in api/config.php</li>";
echo "<li>Make sure MySQL/MariaDB is running</li>";
echo "<li>Make sure database 'medicare_db' exists</li>";
echo "</ol>";

echo "<hr>";
echo "<a href='admin/customers.php' style='display:inline-block;padding:10px 20px;background:#007bff;color:white;text-decoration:none;'>Try Customers Page</a>";
?>
