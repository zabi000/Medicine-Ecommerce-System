<!DOCTYPE html>
<html>
<head>
    <title>Fix MEDIX - Add Products Now</title>
    <style>
        body { font-family: Arial; background: #f5f5f5; padding: 20px; }
        .box { background: white; padding: 20px; margin: 20px auto; max-width: 800px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h1 { color: #B91C1C; text-align: center; }
        .success { color: #10B981; font-weight: bold; font-size: 18px; }
        .error { color: #EF4444; font-weight: bold; font-size: 18px; }
        .btn { display: inline-block; padding: 15px 30px; background: #B91C1C; color: white; text-decoration: none; border-radius: 5px; margin: 10px 5px; font-weight: bold; }
        .btn:hover { background: #991B1B; }
        pre { background: #f0f0f0; padding: 10px; border-radius: 5px; overflow-x: auto; }
    </style>
</head>
<body>
    <div class="box">
        <h1>🔧 FIX MEDIX - Add Products Now</h1>
        
        <?php
        // Database connection
        $host = 'localhost';
        $user = 'root';
        $pass = '';
        $db = 'medicare_db';
        
        echo "<h2>Step 1: Connecting to MySQL...</h2>";
        $conn = new mysqli($host, $user, $pass);
        
        if ($conn->connect_error) {
            echo "<p class='error'>❌ MySQL is NOT running!</p>";
            echo "<p><strong>SOLUTION:</strong></p>";
            echo "<ol>";
            echo "<li>Open XAMPP Control Panel</li>";
            echo "<li>Click START next to MySQL</li>";
            echo "<li>Wait until it turns GREEN</li>";
            echo "<li>Refresh this page</li>";
            echo "</ol>";
            die();
        }
        
        echo "<p class='success'>✅ MySQL Connected!</p>";
        
        // Create database
        echo "<h2>Step 2: Creating Database...</h2>";
        $conn->query("CREATE DATABASE IF NOT EXISTS $db");
        $conn->select_db($db);
        echo "<p class='success'>✅ Database '$db' ready!</p>";
        
        // Create products table
        echo "<h2>Step 3: Creating Products Table...</h2>";
        $conn->query("DROP TABLE IF EXISTS products");
        $sql = "CREATE TABLE products (
            id INT AUTO_INCREMENT PRIMARY KEY,
            name VARCHAR(200) NOT NULL,
            description TEXT,
            price DECIMAL(10, 2) NOT NULL,
            category VARCHAR(50) NOT NULL,
            stock INT DEFAULT 100,
            icon VARCHAR(10) DEFAULT '💊',
            image_url VARCHAR(255),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )";
        
        if ($conn->query($sql)) {
            echo "<p class='success'>✅ Products table created!</p>";
        } else {
            echo "<p class='error'>❌ Error: " . $conn->error . "</p>";
        }
        
        // Insert products
        echo "<h2>Step 4: Adding 20 Products...</h2>";
        
        $products = [
            ['Panadol Extra', 'For tough pain and fever - effective pain relief medication', 50.00, 'prescription', '💊'],
            ['Augmentin 625mg', 'Broad spectrum antibiotic - treats bacterial infections', 240.00, 'prescription', '💊'],
            ['Brufen 400mg', 'Relief from inflammation and pain - anti-inflammatory medication', 35.00, 'prescription', '💊'],
            ['Disprin', 'Dissolvable aspirin for heart health - blood thinner', 15.00, 'prescription', '💊'],
            ['Viagra 100mg', 'Treatment for erectile dysfunction - mens health medication', 800.00, 'prescription', '💊'],
            ['Vitamin C 1000mg', 'Immune system support - boosts immunity', 12.99, 'vitamins', '💉'],
            ['Vitamin D3 2000IU', 'Bone health and immunity - supports calcium absorption', 14.99, 'vitamins', '💉'],
            ['Multivitamin Complex', 'Complete daily nutrition - all essential vitamins', 19.99, 'vitamins', '💉'],
            ['Omega-3 Fish Oil', 'Heart and brain health - supports cardiovascular function', 24.99, 'vitamins', '💉'],
            ['Calcium + Vitamin D', 'Bone strength supplement - prevents osteoporosis', 16.99, 'vitamins', '💉'],
            ['Probiotic Capsules', 'Digestive health support - improves gut bacteria', 22.99, 'vitamins', '💉'],
            ['First Aid Kit', 'Complete emergency medical kit - bandages, antiseptic, gauze', 29.99, 'firstaid', '🩹'],
            ['Bandages Pack', 'Assorted sterile bandages - various sizes', 8.99, 'firstaid', '🩹'],
            ['Antiseptic Cream', 'Wound care and infection prevention', 7.99, 'firstaid', '🩹'],
            ['Digital Thermometer', 'Fast and accurate temperature reading', 15.99, 'devices', '🌡️'],
            ['Blood Pressure Monitor', 'Digital BP measurement device - automatic', 45.99, 'devices', '🌡️'],
            ['Infrared Thermometer', 'Non-contact temperature scanner', 34.99, 'devices', '🌡️'],
            ['Glucose Meter Kit', 'Blood sugar monitoring system', 39.99, 'devices', '🩺'],
            ['Pulse Oximeter', 'Oxygen saturation monitor - tracks SpO2', 29.99, 'devices', '🩺'],
            ['Hand Sanitizer 500ml', 'Antibacterial hand gel - kills 99.9% germs', 4.99, 'personal', '🧴']
        ];
        
        $stmt = $conn->prepare("INSERT INTO products (name, description, price, category, icon, stock) VALUES (?, ?, ?, ?, ?, 100)");
        
        $count = 0;
        foreach ($products as $p) {
            $stmt->bind_param("ssdss", $p[0], $p[1], $p[2], $p[3], $p[4]);
            if ($stmt->execute()) {
                $count++;
            }
        }
        
        echo "<p class='success'>✅ Added $count products successfully!</p>";
        
        // Verify
        echo "<h2>Step 5: Verification...</h2>";
        $result = $conn->query("SELECT COUNT(*) as total FROM products");
        $row = $result->fetch_assoc();
        echo "<p class='success'>✅ Total products in database: <strong>" . $row['total'] . "</strong></p>";
        
        // Show sample products
        echo "<h3>Sample Products:</h3>";
        $result = $conn->query("SELECT name, price, category FROM products LIMIT 5");
        echo "<pre>";
        while ($row = $result->fetch_assoc()) {
            echo "• " . $row['name'] . " - PKR " . $row['price'] . " (" . $row['category'] . ")\n";
        }
        echo "</pre>";
        
        $conn->close();
        ?>
        
        <div style="text-align: center; margin-top: 30px; padding: 20px; background: #D1FAE5; border-radius: 10px;">
            <h2 style="color: #065F46;">🎉 SUCCESS! Everything is Fixed!</h2>
            <p style="font-size: 18px;">Your MEDIX pharmacy now has 20 products in the database</p>
            <a href="products.php" class="btn" style="background: #10B981;">View Products Page</a>
            <a href="index.html" class="btn">Go to Homepage</a>
        </div>
    </div>
</body>
</html>
