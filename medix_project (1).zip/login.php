<?php
session_set_cookie_params(['lifetime' => 28800, 'path' => '/', 'samesite' => 'Lax']);
session_start();

// Already logged in
if (isset($_SESSION['user_id'])) {
    header('Location: user/profile.php');
    exit;
}

require_once('api/config.php');

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if (!$email || !$password) {
        $error = 'Email and password are required.';
    } elseif (!$conn) {
        $error = 'Database connection failed.';
    } else {
        $stmt = $conn->prepare("SELECT id, name, username, email, password FROM users WHERE email=?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$user) {
            $error = 'No account found with this email.';
        } elseif (!password_verify($password, $user['password'])) {
            $error = 'Incorrect password. Please try again.';
        } else {
            session_regenerate_id(true);
            $display_name = $user['name'] ?: $user['username'] ?: $user['email'];
            $_SESSION['user_id']    = $user['id'];
            $_SESSION['user_name']  = $display_name;
            $_SESSION['user_email'] = $user['email'];
            $redirect = $_GET['redirect'] ?? 'index.php';
            header('Location: ' . $redirect);
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Login - MEDIX Pharmacy</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
* { font-family: 'Inter', sans-serif; }
body {
    background: linear-gradient(135deg, #fef2f2 0%, #fff 50%, #fef2f2 100%);
    min-height: 100vh;
    display: flex;
    flex-direction: column;
}
.navbar-brand { font-weight: 800; font-size: 1.5rem; color: #B91C1C !important; }
.login-wrapper {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 2rem 1rem;
}
.login-card {
    background: white;
    border-radius: 24px;
    box-shadow: 0 20px 60px rgba(185,28,28,.1);
    overflow: hidden;
    width: 100%;
    max-width: 440px;
}
.login-header {
    background: linear-gradient(135deg, #B91C1C, #7F1D1D);
    padding: 2.5rem 2rem;
    text-align: center;
    color: white;
}
.login-header .icon {
    width: 70px; height: 70px;
    background: rgba(255,255,255,.15);
    border-radius: 50%;
    display: flex; align-items: center; justify-content: center;
    margin: 0 auto 1rem;
    font-size: 2rem;
}
.login-body { padding: 2rem; }
.form-label { font-weight: 600; font-size: .875rem; color: #374151; }
.input-group-text { background: #f8fafc; border-right: none; color: #94a3b8; border-radius: 10px 0 0 10px !important; }
.form-control { border-left: none; border-radius: 0 10px 10px 0 !important; padding: .7rem .875rem; font-size: .9rem; }
.form-control:focus { border-color: #B91C1C; box-shadow: 0 0 0 3px rgba(185,28,28,.1); }
.input-group:focus-within .input-group-text { border-color: #B91C1C; }
.btn-login { background: linear-gradient(135deg,#B91C1C,#991B1B); border: none; padding: .875rem; font-weight: 700; font-size: 1rem; border-radius: 12px; transition: all .3s; }
.btn-login:hover { transform: translateY(-2px); box-shadow: 0 8px 25px rgba(185,28,28,.35); }
.divider { position: relative; text-align: center; margin: 1.5rem 0; }
.divider::before { content: ''; position: absolute; top: 50%; left: 0; right: 0; height: 1px; background: #e2e8f0; }
.divider span { background: white; padding: 0 1rem; color: #94a3b8; font-size: .8rem; position: relative; }
</style>
</head>
<body>
<nav class="navbar navbar-expand-lg bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand" href="index.php">
            <i class="bi bi-heart-pulse-fill me-2"></i>MEDIX
        </a>
        <div class="ms-auto">
            <a href="register.html" class="btn btn-outline-danger btn-sm px-3">
                <i class="bi bi-person-plus me-1"></i>Register
            </a>
        </div>
    </div>
</nav>

<div class="login-wrapper">
    <div class="login-card">
        <div class="login-header">
            <div class="icon"><i class="bi bi-box-arrow-in-right"></i></div>
            <h3 class="mb-1 fw-bold">Welcome Back</h3>
            <p class="mb-0" style="opacity:.8;font-size:.9rem">Login to your MEDIX account</p>
        </div>

        <div class="login-body">
            <?php if ($error): ?>
            <div class="alert alert-danger py-2 mb-3">
                <i class="bi bi-exclamation-triangle me-2"></i><?= htmlspecialchars($error) ?>
            </div>
            <?php endif; ?>
            <?php if (isset($_GET['registered'])): ?>
            <div class="alert alert-success py-2 mb-3">
                <i class="bi bi-check-circle me-2"></i>Account created! Please log in.
            </div>
            <?php endif; ?>

            <form method="POST">
                <div class="mb-3">
                    <label class="form-label">Email Address</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-envelope"></i></span>
                        <input type="email" class="form-control" name="email"
                               value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                               placeholder="ahmed@email.com" required autocomplete="email">
                    </div>
                </div>
                <div class="mb-4">
                    <label class="form-label">Password</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="bi bi-lock"></i></span>
                        <input type="password" class="form-control" name="password" id="pw"
                               placeholder="Your password" required autocomplete="current-password">
                        <button class="btn btn-outline-secondary" type="button"
                                onclick="let i=document.getElementById('pw');i.type=i.type==='password'?'text':'password'">
                            <i class="bi bi-eye"></i>
                        </button>
                    </div>
                </div>
                <button type="submit" class="btn btn-danger btn-login w-100 text-white">
                    <i class="bi bi-box-arrow-in-right me-2"></i>Login
                </button>
                <div class="text-end mt-2">
                    <a href="forgot_password.php" class="text-muted small text-decoration-none" style="font-size:.8rem">
                        <i class="bi bi-key me-1"></i>Forgot Password?
                    </a>
                </div>
            </form>

            <div class="divider"><span>Don't have an account?</span></div>

            <a href="register.html" class="btn btn-outline-danger w-100" style="border-radius:12px;font-weight:600">
                <i class="bi bi-person-plus me-2"></i>Create New Account
            </a>

            <p class="text-center mt-3 mb-0" style="font-size:.75rem;color:#94a3b8">
                <i class="bi bi-shield-check me-1"></i>Your data is secure and encrypted
            </p>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
