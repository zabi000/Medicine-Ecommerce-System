﻿<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Page Load Test</title>
    <style>
        body { font-family: Arial; padding: 50px; background: #f0f0f0; }
        .box { background: white; padding: 30px; border-radius: 10px; max-width: 600px; margin: 0 auto; }
        h1 { color: #B91C1C; }
        .info { background: #e3f2fd; padding: 15px; border-radius: 5px; margin: 10px 0; }
    </style>
</head>
<body>
    <div class="box">
        <h1>âœ“ Page Load Test</h1>
        <div class="info">
            <strong>Current File:</strong> <?= __FILE__ ?><br>
            <strong>Current Page:</strong> test_page_load.php<br>
            <strong>Session Active:</strong> Yes<br>
            <strong>Time:</strong> <?= date('Y-m-d H:i:s') ?>
        </div>
        <p>If you can see this page, PHP is working correctly.</p>
        <hr>
        <h3>Test Links:</h3>
        <p><a href="customers.php" style="color: #B91C1C; font-weight: bold;">â†’ Go to Customers Page</a></p>
        <p><a href="products.php" style="color: #B91C1C; font-weight: bold;">â†’ Go to Products Page</a></p>
        <p><a href="index.php" style="color: #B91C1C; font-weight: bold;">â†’ Go to Dashboard</a></p>
    </div>
</body>
</html>

