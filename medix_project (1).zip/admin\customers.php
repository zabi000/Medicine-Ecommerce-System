﻿<?php
error_reporting(E_ALL);
ini_set("display_errors", 1);
session_start();
if (!isset($_SESSION["admin_logged_in"])) {
    header("Location: login.php");
    exit();
}
require_once("../api/config.php");
$success_message = $_SESSION["success_message"] ?? null;
$error_message   = $_SESSION["error_message"] ?? null;
unset($_SESSION["success_message"], $_SESSION["error_message"]);
if (!$conn) { die("<h3 style=color:red;padding:2rem>Database connection failed.</h3>"); }
$cols = [];
$r = $conn->query("SHOW COLUMNS FROM users");
if ($r) while ($c = $r->fetch_assoc()) $cols[] = $c["Field"];
// Build insert with all available name columns
if ($_SERVER["REQUEST_METHOD"] === "POST" && ($_POST["action"] ?? "") === "add") {
    $name  = trim($_POST["name"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $phone = trim($_POST["phone"] ?? "");
    $pass  = password_hash($_POST["password"] ?: "medix123", PASSWORD_DEFAULT);
    if (!$name || !$email) {
        $_SESSION["error_message"] = "Name and email are required.";
    } else {
        $chk = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $chk->bind_param("s", $email);
        $chk->execute();
        if ($chk->get_result()->num_rows > 0) {
            $_SESSION["error_message"] = "Email already exists.";
        } else {
            // Build dynamic insert based on available columns
            $insert_cols = ["email", "phone", "password"];
            $insert_vals = [$email, $phone, $pass];
            $types = "sss";
            if (in_array("name", $cols)) { $insert_cols[] = "name"; $insert_vals[] = $name; $types .= "s"; }
            if (in_array("username", $cols)) { $insert_cols[] = "username"; $insert_vals[] = $name; $types .= "s"; }
            $placeholders = implode(",", array_fill(0, count($insert_cols), "?"));
            $col_list = implode(",", $insert_cols);
            $stmt = $conn->prepare("INSERT INTO users ($col_list) VALUES ($placeholders)");
            $stmt->bind_param($types, ...$insert_vals);
            if ($stmt->execute()) { $_SESSION["success_message"] = "Customer \"$name\" added successfully!"; }
            else { $_SESSION["error_message"] = "Error: " . $conn->error; }
        }
    }
    header("Location: customers.php"); exit();
}
if (isset($_GET["delete"])) {
    $id = intval($_GET["delete"]);
    $conn->query("DELETE FROM users WHERE id = $id");
    $_SESSION["success_message"] = "Customer deleted.";
    header("Location: customers.php"); exit();
}
$customers = $conn->query("SELECT u.*, COUNT(o.id) as total_orders, COALESCE(SUM(o.total_amount),0) as total_spent FROM users u LEFT JOIN orders o ON u.id = o.user_id GROUP BY u.id ORDER BY u.created_at DESC");
$total   = $conn->query("SELECT COUNT(*) as c FROM users")->fetch_assoc()["c"] ?? 0;
$active  = $conn->query("SELECT COUNT(DISTINCT user_id) as c FROM orders WHERE created_at >= DATE_SUB(NOW(), INTERVAL 30 DAY)")->fetch_assoc()["c"] ?? 0;
$new_wk  = $conn->query("SELECT COUNT(*) as c FROM users WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)")->fetch_assoc()["c"] ?? 0;
$avg_val = $conn->query("SELECT COALESCE(AVG(total_amount),0) as a FROM orders")->fetch_assoc()["a"] ?? 0;
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Customers - MEDIX Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<style>
:root{--sw:280px}
body{font-family:Arial,sans-serif;background:#f8fafc}
.sidebar{position:fixed;top:0;left:0;width:var(--sw);height:100vh;background:linear-gradient(180deg,#B91C1C,#7F1D1D);overflow-y:auto;z-index:1000}
.sb-brand{padding:1.5rem;border-bottom:1px solid rgba(255,255,255,.1);color:white}
.mi{display:flex;align-items:center;gap:.75rem;padding:.875rem 1.5rem;color:rgba(255,255,255,.8);text-decoration:none;border-left:3px solid transparent;transition:all .2s}
.mi:hover,.mi.active{background:rgba(255,255,255,.12);color:white;border-left-color:white}
.mi i{width:20px}
.mdiv{height:1px;background:rgba(255,255,255,.1);margin:.5rem 1.5rem}
.main{margin-left:var(--sw);padding:2rem}
.topbar{background:white;border-bottom:1px solid #e2e8f0;padding:1rem 2rem;margin:-2rem -2rem 2rem;display:flex;justify-content:space-between;align-items:center}
.sc{background:white;border-radius:16px;padding:1.5rem;box-shadow:0 1px 3px rgba(0,0,0,.08);text-align:center}
.sc i{font-size:2.5rem}
.tc{background:white;border-radius:16px;padding:1.5rem;box-shadow:0 1px 3px rgba(0,0,0,.08)}
.table thead th{font-size:.72rem;font-weight:700;color:#94a3b8;text-transform:uppercase;border-bottom:2px solid #f1f5f9;padding:.75rem 1rem}
.table tbody td{padding:.875rem 1rem;vertical-align:middle;border-bottom:1px solid #f8fafc}
.av{width:40px;height:40px;border-radius:50%;background:linear-gradient(135deg,#B91C1C,#991B1B);color:white;display:flex;align-items:center;justify-content:center;font-weight:700;flex-shrink:0}
.es{text-align:center;padding:4rem 2rem;color:#94a3b8}
.es i{font-size:4rem;display:block;margin-bottom:1rem}
</style>
</head>
<body>
<div class="sidebar">
    <div class="sb-brand"><h4 class="mb-0 fw-bold"><i class="bi bi-heart-pulse-fill me-2"></i>MEDIX</h4><small style="opacity:.6">Admin Portal</small></div>
    <a href="index.php" class="mi"><i class="bi bi-speedometer2"></i>Dashboard</a>
    <a href="products.php" class="mi"><i class="bi bi-box-seam"></i>Products</a>
    <a href="orders.php" class="mi"><i class="bi bi-cart-check"></i>Orders</a>
    <a href="customers.php" class="mi active"><i class="bi bi-people"></i>Customers</a>
    <a href="categories.php" class="mi"><i class="bi bi-tags"></i>Categories</a>
    <a href="messages.php" class="mi"><i class="bi bi-envelope"></i>Messages</a>
    <a href="reports.php" class="mi"><i class="bi bi-graph-up"></i>Reports</a>
    <a href="settings.php" class="mi"><i class="bi bi-gear"></i>Settings</a>
    <div class="mdiv"></div>
    <a href="database.php" class="mi"><i class="bi bi-database"></i>Database</a>
    <a href="import_medicines.php" class="mi" style="color:#10B981"><i class="bi bi-capsule-pill"></i>Import Medicines</a>
    <div class="mdiv"></div>
    <a href="logout.php" class="mi"><i class="bi bi-box-arrow-right"></i>Logout</a>
</div>
<div class="main">
    <div class="topbar">
        <div><h4 class="mb-0 fw-bold">Customers</h4><small class="text-muted">Manage customer accounts</small></div>
        <button class="btn btn-danger px-4" data-bs-toggle="modal" data-bs-target="#addModal"><i class="bi bi-person-plus me-2"></i>Add Customer</button>
    </div>
<?php if ($success_message): ?>
<div class="alert alert-success alert-dismissible fade show m-3"><i class="bi bi-check-circle me-2"></i><?= htmlspecialchars($success_message) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
<?php endif; ?>
<?php if ($error_message): ?>
<div class="alert alert-danger alert-dismissible fade show m-3"><i class="bi bi-exclamation-triangle me-2"></i><?= htmlspecialchars($error_message) ?><button type="button" class="btn-close" data-bs-dismiss="alert"></button></div>
<?php endif; ?>
<div class="row g-3 mb-4">
<div class="col-md-3"><div class="sc"><i class="bi bi-people text-primary"></i><h3 class="mt-2 mb-0 fw-bold"><?= $total ?></h3><p class="text-muted mb-0 small">Total Customers</p></div></div>
<div class="col-md-3"><div class="sc"><i class="bi bi-person-check text-success"></i><h3 class="mt-2 mb-0 fw-bold"><?= $active ?></h3><p class="text-muted mb-0 small">Active (30 days)</p></div></div>
<div class="col-md-3"><div class="sc"><i class="bi bi-person-plus text-info"></i><h3 class="mt-2 mb-0 fw-bold"><?= $new_wk ?></h3><p class="text-muted mb-0 small">New This Week</p></div></div>
<div class="col-md-3"><div class="sc"><i class="bi bi-cash-stack text-warning"></i><h3 class="mt-2 mb-0 fw-bold">PKR <?= number_format($avg_val,0) ?></h3><p class="text-muted mb-0 small">Avg Order Value</p></div></div>
</div>
<div class="tc">
<div class="d-flex justify-content-between align-items-center mb-3">
<h6 class="mb-0 fw-bold"><i class="bi bi-people me-2 text-danger"></i>All Customers <span class="badge bg-danger ms-2"><?= $total ?></span></h6>
<input type="text" class="form-control" style="width:240px" placeholder="Search by name..." oninput="filterTable(this.value)">
</div>
<div class="table-responsive">
<table class="table" id="ct">
<thead><tr><th>Customer</th><th>Email</th><th>Phone</th><th>Orders</th><th>Total Spent</th><th>Joined</th><th>Status</th><th>Action</th></tr></thead>
<tbody>
<?php if ($customers && $customers->num_rows > 0): while ($c = $customers->fetch_assoc()): $dn = $c["name"] ?? $c["username"] ?? "Unknown"; $in = strtoupper(substr($dn,0,1)); ?>
<tr data-name="<?= strtolower(htmlspecialchars($dn)) ?>">
<td><div class="d-flex align-items-center gap-2"><div class="av"><?= $in ?></div><div><div class="fw-semibold"><?= htmlspecialchars($dn) ?></div><small class="text-muted">ID #<?= $c["id"] ?></small></div></div></td>
<td class="text-muted"><?= htmlspecialchars($c["email"]) ?></td>
<td class="text-muted"><?= htmlspecialchars($c["phone"] ?? "â€”") ?></td>
<td><span class="badge bg-primary bg-opacity-10 text-primary"><?= $c["total_orders"] ?> orders</span></td>
<td class="fw-bold text-danger">PKR <?= number_format($c["total_spent"],0) ?></td>
<td class="text-muted small"><?= date("M d, Y", strtotime($c["created_at"])) ?></td>
<td><span class="badge <?= $c["total_orders"] > 0 ? "bg-success" : "bg-secondary" ?>"><?= $c["total_orders"] > 0 ? "Active" : "New" ?></span></td>
<td><a href="?delete=<?= $c["id"] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Delete?')"><i class="bi bi-trash"></i></a></td>
</tr>
<?php endwhile; else: ?>
<tr><td colspan="8"><div class="es"><i class="bi bi-people"></i><h5>No Customers Yet</h5><p class="small text-muted">Add customers manually or they appear when users register.</p><button class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#addModal"><i class="bi bi-person-plus me-2"></i>Add First Customer</button></div></td></tr>
<?php endif; ?>
</tbody></table></div></div></div>
<div class="modal fade" id="addModal" tabindex="-1">
<div class="modal-dialog"><div class="modal-content">
<div class="modal-header bg-danger text-white"><h5 class="modal-title"><i class="bi bi-person-plus me-2"></i>Add New Customer</h5><button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button></div>
<form method="POST"><div class="modal-body">
<input type="hidden" name="action" value="add">
<div class="mb-3"><label class="form-label fw-semibold">Full Name <span class="text-danger">*</span></label><input type="text" class="form-control" name="name" placeholder="Ahmed Khan" required></div>
<div class="mb-3"><label class="form-label fw-semibold">Email <span class="text-danger">*</span></label><input type="email" class="form-control" name="email" placeholder="ahmed@email.com" required></div>
<div class="mb-3"><label class="form-label fw-semibold">Phone</label><input type="text" class="form-control" name="phone" placeholder="+92-300-1234567"></div>
<div class="mb-3"><label class="form-label fw-semibold">Password</label><input type="password" class="form-control" name="password" placeholder="Leave blank = medix123"><small class="text-muted">Default: <strong>medix123</strong></small></div>
</div>
<div class="modal-footer"><button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button><button type="submit" class="btn btn-danger px-4"><i class="bi bi-check-circle me-1"></i>Add Customer</button></div>
</form></div></div></div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function filterTable(q){document.querySelectorAll("#ct tbody tr[data-name]").forEach(r=>{r.style.display=r.dataset.name.includes(q.toLowerCase())?"":"none"});}
setTimeout(()=>{document.querySelectorAll(".alert").forEach(a=>bootstrap.Alert.getOrCreateInstance(a)?.close());},4000);
</script>
</body></html>
