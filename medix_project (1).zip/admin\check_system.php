﻿<!DOCTYPE html>
<html>
<head>
    <title>System Check - MEDIX</title>
    <style>
        body { font-family: Arial; padding: 20px; background: #f5f5f5; }
        .box { background: white; padding: 20px; margin: 10px 0; border-radius: 8px; }
        .success { color: #10B981; font-weight: bold; }
        .error { color: #EF4444; font-weight: bold; }
        .btn { padding: 15px 30px; background: #B91C1C; color: white; text-decoration: none; border-radius: 5px; display: inline-block; margin: 10px 5px; }
    </style>
</head>
<body>
    <h1>ðŸ” MEDIX System Check</h1>
    
    <div class="box">
        <h2>1. PHP Status</h2>
        <?php
        echo "<p class='success'>âœ… PHP is working!</p>";
        echo "<p>PHP Version: " . phpversion() . "</p>";
        ?>
    </div>
    
    <div class="box">
        <h2>2. MySQL Connection</h2>
        <?php
        $conn = @new mysqli('localhost', 'root', '', 'medicare_db');
        if ($conn->connect_error) {
            echo "<p class='error'>âŒ MySQL Error: " . $conn->connect_error . "</p>";
            echo "<p><strong>Solution:</strong> Start MySQL in XAMPP Control Panel</p>";
        } else {
            echo "<p class='success'>âœ… MySQL Connected!</p>";
            $conn->close();
        }
        ?>
    </div>
    
    <div class="box">
        <h2>3. Database File</h2>
        <?php
        $sqlFile = '../database/import_this.sql';
        if (file_exists($sqlFile)) {
            $size = filesize($sqlFile);
            echo "<p class='success'>âœ… SQL file found!</p>";
            echo "<p>File size: " . number_format($size) . " bytes</p>";
            echo "<p>Location: " . realpath($sqlFile) . "</p>";
        } else {
            echo "<p class='error'>âŒ SQL file not found!</p>";
            echo "<p>Looking for: " . realpath('../database/') . "/import_this.sql</p>";
        }
        ?>
    </div>
    
    <div class="box">
        <h2>4. Admin Files</h2>
        <?php
        $files = ['customers.php', 'settings.php', 'products.php'];
        foreach ($files as $file) {
            if (file_exists($file)) {
                echo "<p class='success'>âœ… $file exists (" . filesize($file) . " bytes)</p>";
            } else {
                echo "<p class='error'>âŒ $file missing</p>";
            }
        }
        ?>
    </div>
    
    <div class="box">
        <h2>5. Next Steps</h2>
        <?php
        $conn = @new mysqli('localhost', 'root', '', 'medicare_db');
        if ($conn->connect_error) {
            echo "<p class='error'>âš ï¸ MySQL is not running!</p>";
            echo "<p><strong>DO THIS:</strong></p>";
            echo "<ol>";
            echo "<li>Open XAMPP Control Panel</li>";
            echo "<li>Click 'Start' next to MySQL</li>";
            echo "<li>Wait until it turns GREEN</li>";
            echo "<li>Refresh this page</li>";
            echo "</ol>";
        } else {
            echo "<p class='success'>âœ… Everything is ready!</p>";
            echo "<p>You can now import the database:</p>";
            echo "<a href='auto_import_database.php' class='btn'>Import Database Now</a>";
            $conn->close();
        }
        ?>
    </div>
    
    <div class="box">
        <h2>ðŸ“‹ Summary</h2>
        <p>Copy this information and tell me what you see:</p>
        <textarea style='width:100%; height:100px; font-family:monospace;'>
<?php
echo "PHP: " . phpversion() . "\n";
$conn = @new mysqli('localhost', 'root', '', 'medicare_db');
echo "MySQL: " . ($conn->connect_error ? "NOT CONNECTED - " . $conn->connect_error : "CONNECTED") . "\n";
echo "SQL File: " . (file_exists('../database/import_this.sql') ? "EXISTS" : "MISSING") . "\n";
echo "Customers.php: " . (file_exists('customers.php') ? filesize('customers.php') . " bytes" : "MISSING") . "\n";
echo "Settings.php: " . (file_exists('settings.php') ? filesize('settings.php') . " bytes" : "MISSING") . "\n";
?>
        </textarea>
    </div>
</body>
</html>

