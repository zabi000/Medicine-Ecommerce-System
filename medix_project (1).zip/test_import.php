<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h2>Testing Database Connection</h2>";

// Test 1: Check if config file exists
if (file_exists('api/config.php')) {
    echo "✓ Config file exists<br>";
    require_once('api/config.php');
} else {
    echo "✗ Config file NOT found<br>";
    exit;
}

// Test 2: Check database connection
if ($conn) {
    echo "✓ Database connected<br>";
} else {
    echo "✗ Database connection failed<br>";
    exit;
}

// Test 3: Check if products table exists
$result = $conn->query("SHOW TABLES LIKE 'products'");
if ($result && $result->num_rows > 0) {
    echo "✓ Products table exists<br>";
} else {
    echo "✗ Products table NOT found<br>";
    exit;
}

// Test 4: Try to insert one medicine
echo "<br><h3>Testing Insert...</h3>";

$name = "Test Medicine Panadol 500mg (Tablet)";
$description = "Manufacturer: GSK | Uses: Fever, mild pain | Side Effects: Liver damage (high dose)";
$price = 35.0;
$category = "prescription";
$stock = 100;

// Check if already exists
$check = $conn->prepare("SELECT id FROM products WHERE name = ?");
$check->bind_param("s", $name);
$check->execute();
$result = $check->get_result();

if ($result->num_rows > 0) {
    echo "⊘ Test product already exists (this is OK)<br>";
} else {
    $stmt = $conn->prepare("INSERT INTO products (name, description, price, category, stock_quantity) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssdsi", $name, $description, $price, $category, $stock);
    
    if ($stmt->execute()) {
        echo "✓ Successfully inserted test product!<br>";
        echo "Product ID: " . $stmt->insert_id . "<br>";
    } else {
        echo "✗ Insert failed: " . $conn->error . "<br>";
    }
}

// Test 5: Count products
$result = $conn->query("SELECT COUNT(*) as total FROM products");
$row = $result->fetch_assoc();
echo "<br><h3>Current Products: " . $row['total'] . "</h3>";

echo "<br><hr>";
echo "<h3>✅ All tests passed! Ready to import.</h3>";
echo '<a href="import_medicines_direct.php" style="display: inline-block; padding: 15px 30px; background: #B91C1C; color: white; text-decoration: none; border-radius: 8px; font-size: 18px; margin-top: 20px;">Start Import Now</a>';
?>
