<?php
// Quick test of submit_contact.php
session_start();
// Simulate a logged-in user
$_SESSION['user_email'] = 'test@test.com';
$_SESSION['user_name']  = 'Test User';

echo "<h3>Testing submit_contact.php</h3>";

// Test 1: DB connection
require_once('api/config.php');
if (!$conn) {
    echo "<p style='color:red'>❌ DB connection FAILED</p>";
} else {
    echo "<p style='color:green'>✅ DB connected</p>";
}

// Test 2: Table exists
$t = $conn->query("SHOW TABLES LIKE 'contact_messages'");
if ($t && $t->num_rows > 0) {
    echo "<p style='color:green'>✅ contact_messages table exists</p>";
    // Check columns
    $cols = $conn->query("SHOW COLUMNS FROM contact_messages");
    $col_names = [];
    while ($c = $cols->fetch_assoc()) $col_names[] = $c['Field'];
    echo "<p>Columns: " . implode(', ', $col_names) . "</p>";
} else {
    echo "<p style='color:orange'>⚠️ contact_messages table missing — will be created on first message</p>";
}

// Test 3: Direct insert
$test_insert = $conn->query("INSERT INTO contact_messages (first_name, last_name, email, phone, subject, message, status) VALUES ('Test','User','test@test.com','','Test','Test message from API test','new')");
if ($test_insert) {
    $id = $conn->insert_id;
    echo "<p style='color:green'>✅ Direct insert works! ID: $id</p>";
    $conn->query("DELETE FROM contact_messages WHERE id=$id");
    echo "<p style='color:green'>✅ Test row cleaned up</p>";
} else {
    echo "<p style='color:red'>❌ Insert failed: " . $conn->error . "</p>";
}

// Test 4: Simulate the API call
echo "<h4>Simulating API call:</h4>";
$_POST['firstName'] = 'Test';
$_POST['lastName']  = 'User';
$_POST['email']     = 'test@test.com';
$_POST['phone']     = '0300-1234567';
$_POST['subject']   = 'Test Subject';
$_POST['message']   = 'This is a test message';
$_SERVER['REQUEST_METHOD'] = 'POST';

ob_start();
include('api/submit_contact.php');
$output = ob_get_clean();
echo "<pre style='background:#f8f9fa;padding:1rem;border-radius:8px'>$output</pre>";

$decoded = json_decode($output, true);
if ($decoded && $decoded['success']) {
    echo "<p style='color:green'>✅ API works! Message sent successfully.</p>";
    echo "<p>Reference: " . $decoded['reference'] . "</p>";
} else {
    echo "<p style='color:red'>❌ API failed: " . ($decoded['message'] ?? 'Unknown error') . "</p>";
}
?>
