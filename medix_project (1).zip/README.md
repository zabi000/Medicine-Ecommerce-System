# MEDIX - Online Pharmacy E-Commerce Website

A complete e-commerce website for medicine and healthcare products built with HTML, CSS, JavaScript, PHP, and MySQL.

## ✅ Status: FULLY WORKING!

Your complete pharmacy website is ready to use with admin panel, product management, and all features working!

## 🚀 Quick Start

1. **Open Website**: [http://localhost/ppp/](http://localhost/ppp/)
2. **Admin Panel**: [http://localhost/ppp/admin/login.php](http://localhost/ppp/admin/login.php)
   - Username: `admin`
   - Password: `admin123`
3. **Optional**: Import database from `database/import_this.sql` for 1000 products

## Features

### Main Website
- 🏥 Professional red & white design with MEDIX branding
- 🛒 Shopping cart functionality with local storage
- 👤 User registration and login system
- 💊 Product catalog with categories and search
- 📱 Fully responsive Bootstrap 5 design
- 🌐 Language selector (English/Urdu)
- 💬 Live chat button
- 📧 Newsletter popup
- ⭐ Customer testimonials
- 💳 Payment methods display

### Admin Panel
- 📊 Dashboard with statistics and charts
- 📦 Product management (Add, Edit, Delete)
- 🛒 Order management with status updates
- 👥 Customer list and statistics
- 🏷️ Category management
- 📈 Sales reports with Chart.js
- ⚙️ Settings configuration
- 🔐 Secure login system

## Color Scheme

- Primary: #B91C1C (Darker Red)
- Secondary: #991B1B (Deep Red)
- Accent: #DC2626 (Bright Red)
- Background: White (#FFFFFF)
- Text: #1A1A1A (Dark Gray)

## Installation

### Option 1: Use Without Database (Recommended for Quick Start)
1. Make sure XAMPP is running (Apache only)
2. Open [http://localhost/ppp/](http://localhost/ppp/)
3. Login to admin: [http://localhost/ppp/admin/login.php](http://localhost/ppp/admin/login.php)
4. Admin works with 30 fake products - no database needed!

### Option 2: Import Database for Real Data
1. Start MySQL in XAMPP Control Panel
2. Open [http://localhost/phpmyadmin](http://localhost/phpmyadmin)
3. Click "Import" tab
4. Choose file: `C:\xampp\htdocs\ppp\database\import_this.sql`
5. Click "Go" button
6. Done! Now you have 1000 products + real data

## File Structure

```
ppp/
├── index.html              # Homepage with featured products
├── products.php            # Product catalog page
├── cart.php               # Shopping cart
├── login.html             # User login
├── register.html          # User registration
├── about.html             # About page
├── contact.html           # Contact page
├── css/
│   └── style.css          # Main stylesheet (red theme)
├── js/
│   ├── main.js            # Main JavaScript
│   └── cart.js            # Cart functionality
├── admin/
│   ├── login.php          # Admin login
│   ├── index.php          # Dashboard
│   ├── products.php       # Product management
│   ├── orders.php         # Order management
│   ├── customers.php      # Customer list
│   ├── categories.php     # Category management
│   ├── reports.php        # Sales reports
│   ├── settings.php       # Settings
│   └── logout.php         # Logout
├── api/
│   ├── config.php         # Database configuration
│   ├── register.php       # User registration API
│   ├── login.php          # User authentication API
│   └── get_products.php   # Product API
├── database/
│   ├── import_this.sql    # Complete database (1000 products)
│   └── schema.sql         # Database structure
└── images/
    ├── hero-bg.jpg        # Hero background
    ├── products/          # Product images
    ├── brands/            # Brand logos
    └── ads/               # Advertisement images
```

## Technologies Used

- **Frontend**: HTML5, CSS3, JavaScript (ES6+), Bootstrap 5
- **Backend**: PHP 7.4+
- **Database**: MySQL 5.7+ (optional - works without it!)
- **Charts**: Chart.js
- **Icons**: Bootstrap Icons
- **Storage**: LocalStorage for cart

## Admin Panel Features

### Dashboard
- Total sales statistics
- Order counts
- Customer statistics
- Product inventory count
- Sales trend chart (Chart.js)
- Order status pie chart
- Recent orders table
- Top selling products
- Low stock alerts

### Products Management
- View all products in table
- Add new products (modal form)
- Edit product details
- Delete products
- Stock level indicators (color-coded)
- Category filtering
- Product status (Active/Inactive)
- PKR currency support

### Orders Management
- View all orders
- Order statistics dashboard
- Update order status (Pending → Processing → Delivered)
- View order details
- Customer information
- Status filtering

### Customers
- Customer list with statistics
- Total orders per customer
- Total spent per customer
- Join date tracking
- Active/New status indicators

### Categories
- View all categories
- Add new categories
- Delete categories
- Product count per category
- 6 default categories included

### Reports
- Sales reports with date filtering
- Revenue charts
- Top 10 selling products
- Daily sales trends
- Revenue by product

### Settings
- Store information
- Contact details
- Currency settings
- Shipping configuration
- Admin password change

## Default Credentials

### Admin Panel
- URL: [http://localhost/ppp/admin/login.php](http://localhost/ppp/admin/login.php)
- Username: `admin`
- Password: `admin123`

### Database
- Host: `localhost`
- Username: `root`
- Password: (empty)
- Database: `medicare_db`

## Sample Data (After Database Import)

- **Products**: 1000 medicine items with PKR prices
- **Customers**: 8 sample customers
- **Orders**: 15 sample orders
- **Categories**: 6 product categories
- **Order Items**: 27 order line items

## Security Features

- Session-based authentication
- Password hashing with PHP password_hash()
- SQL injection prevention with prepared statements
- Input validation on both client and server side
- Logout functionality
- Protected admin routes

## Browser Support

- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)
- Mobile browsers (responsive design)

## Help & Documentation

- **START_HERE.txt** - Quick start guide
- **CLICK_HERE_TO_START.html** - Interactive setup guide
- **ADMIN_SETUP_GUIDE.md** - Detailed admin panel guide
- **IMPORT_DATABASE_NOW.txt** - Database import instructions
- **ADMIN_STATUS_REPORT.md** - Current status and features

## Troubleshooting

### Can't access website?
- Make sure XAMPP Apache is running (green in Control Panel)
- Check URL: [http://localhost/ppp/](http://localhost/ppp/)

### Admin panel not working?
- Admin works WITHOUT database (shows fake data)
- Login: admin / admin123
- If you want real data, import database

### Products not showing?
- Admin shows 30 fake products by default
- Import database for 1000 real products
- Or add products manually via "Add New Product"

### Charts not loading?
- Check internet connection (Chart.js from CDN)
- Refresh page with Ctrl + F5

## What's Working Right Now

✅ Main website with all pages  
✅ Admin login system  
✅ Dashboard with fake statistics  
✅ Products page (30 fake items)  
✅ Orders management  
✅ Customer list  
✅ Categories management  
✅ Reports with charts  
✅ Settings page  
✅ Shopping cart  
✅ User authentication  

## License

This project is open source and available for educational purposes.

---

**Made with ❤️ for MEDIX Pharmacy**

Need help? Open `CLICK_HERE_TO_START.html` in your browser!
