-- ============================================
-- MEDIX PHARMACY - COMPLETE DATABASE SETUP
-- Import this file in phpMyAdmin
-- ============================================

-- Create database
CREATE DATABASE IF NOT EXISTS medicare_db;
USE medicare_db;

-- Drop existing tables to start fresh
DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS categories;
DROP TABLE IF EXISTS users;

-- ============================================
-- CREATE TABLES
-- ============================================

-- Users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20),
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Categories table
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Products table
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    category VARCHAR(50) NOT NULL,
    stock_quantity INT DEFAULT 0,
    icon VARCHAR(10) DEFAULT '💊',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Orders table
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    status ENUM('pending', 'processing', 'delivered', 'cancelled') DEFAULT 'pending',
    shipping_address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Order items table
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- ============================================
-- INSERT SAMPLE DATA
-- ============================================

-- Insert sample users (customers)
INSERT INTO users (username, name, email, phone, password, created_at) VALUES
('john_doe', 'John Doe', 'john@example.com', '+1-555-0101', '$2y$10$abcdefghijklmnopqrstuvwxyz', DATE_SUB(NOW(), INTERVAL 30 DAY)),
('jane_smith', 'Jane Smith', 'jane@example.com', '+1-555-0102', '$2y$10$abcdefghijklmnopqrstuvwxyz', DATE_SUB(NOW(), INTERVAL 25 DAY)),
('mike_johnson', 'Mike Johnson', 'mike@example.com', '+1-555-0103', '$2y$10$abcdefghijklmnopqrstuvwxyz', DATE_SUB(NOW(), INTERVAL 20 DAY)),
('sarah_williams', 'Sarah Williams', 'sarah@example.com', '+1-555-0104', '$2y$10$abcdefghijklmnopqrstuvwxyz', DATE_SUB(NOW(), INTERVAL 15 DAY)),
('david_brown', 'David Brown', 'david@example.com', '+1-555-0105', '$2y$10$abcdefghijklmnopqrstuvwxyz', DATE_SUB(NOW(), INTERVAL 10 DAY)),
('emily_davis', 'Emily Davis', 'emily@example.com', '+1-555-0106', '$2y$10$abcdefghijklmnopqrstuvwxyz', DATE_SUB(NOW(), INTERVAL 5 DAY)),
('robert_miller', 'Robert Miller', 'robert@example.com', '+1-555-0107', '$2y$10$abcdefghijklmnopqrstuvwxyz', DATE_SUB(NOW(), INTERVAL 3 DAY)),
('lisa_wilson', 'Lisa Wilson', 'lisa@example.com', '+1-555-0108', '$2y$10$abcdefghijklmnopqrstuvwxyz', DATE_SUB(NOW(), INTERVAL 2 DAY));

-- Insert categories
INSERT INTO categories (name, description) VALUES
('prescription', 'Doctor prescribed medicines and treatments'),
('vitamins', 'Health supplements, vitamins and minerals'),
('firstaid', 'Emergency medical supplies and first aid kits'),
('devices', 'Medical devices and healthcare equipment'),
('personal', 'Personal care and hygiene products'),
('baby', 'Baby care products and infant supplies');

-- Insert 20 products
INSERT INTO products (name, description, price, category, stock_quantity, icon) VALUES
('Paracetamol 500mg', 'Effective pain relief and fever reducer. Safe for adults and children over 12 years.', 5.99, 'prescription', 245, '💊'),
('Vitamin D3 1000 IU', 'Essential for bone health and immune system support. 60 capsules per bottle.', 14.99, 'vitamins', 189, '💉'),
('Cough Syrup 100ml', 'Relieves dry and wet cough. Suitable for adults and children over 6 years.', 8.99, 'prescription', 156, '💊'),
('First Aid Kit', 'Complete emergency medical kit with bandages, antiseptic, and essential supplies.', 24.99, 'firstaid', 78, '🩹'),
('Digital Thermometer', 'Fast and accurate temperature reading in 10 seconds. LCD display.', 12.99, 'devices', 134, '🌡️'),
('Multivitamin Pack', 'Complete daily nutrition with 30 essential vitamins and minerals. 30-day supply.', 23.99, 'vitamins', 167, '💉'),
('Blood Pressure Monitor', 'Digital BP monitor with large display and memory function. Clinically validated.', 39.99, 'devices', 92, '🩺'),
('Antibiotic Cream 15g', 'Topical antibiotic for wound care and infection prevention. Fast healing.', 6.99, 'firstaid', 203, '🩹'),
('Ibuprofen 400mg', 'Anti-inflammatory pain reliever for headaches, muscle pain, and fever.', 7.99, 'prescription', 198, '💊'),
('Omega-3 Fish Oil', 'Heart and brain health support. 1000mg per capsule. 60 capsules.', 19.99, 'vitamins', 145, '💉'),
('Hand Sanitizer 500ml', 'Antibacterial hand gel with 70% alcohol. Kills 99.9% of germs.', 4.99, 'personal', 312, '🧴'),
('Pulse Oximeter', 'Measures blood oxygen saturation and pulse rate. Portable and accurate.', 29.99, 'devices', 87, '🩺'),
('Vitamin C 1000mg', 'Immune system booster. Antioxidant support. 100 tablets.', 12.99, 'vitamins', 221, '💉'),
('Bandages Assorted Pack', 'Sterile adhesive bandages in various sizes. 100 pieces per box.', 8.99, 'firstaid', 176, '🩹'),
('Aspirin 100mg', 'Blood thinner and pain relief. Reduces risk of heart attack. 30 tablets.', 6.99, 'prescription', 234, '💊'),
('Calcium + Vitamin D', 'Bone strength and density support. 600mg calcium + 400 IU Vitamin D.', 16.99, 'vitamins', 156, '💉'),
('Infrared Thermometer', 'Non-contact temperature scanner. Instant reading. Suitable for all ages.', 34.99, 'devices', 64, '🌡️'),
('Antiseptic Solution 250ml', 'Disinfectant for wounds and skin. Prevents infection. Hospital grade.', 9.99, 'firstaid', 189, '🩹'),
('Probiotic Capsules', 'Digestive health support with 10 billion CFU. 30 capsules.', 22.99, 'vitamins', 123, '💉'),
('Face Masks (50 Pack)', 'Disposable 3-ply surgical masks. Breathable and comfortable. FDA approved.', 12.99, 'personal', 267, '😷');

-- Insert orders (15 orders with different statuses and dates)
INSERT INTO orders (user_id, total_amount, status, shipping_address, created_at) VALUES
-- Delivered orders (older)
(1, 45.97, 'delivered', '123 Main St, New York, NY 10001', DATE_SUB(NOW(), INTERVAL 15 DAY)),
(2, 29.99, 'delivered', '456 Oak Ave, Los Angeles, CA 90001', DATE_SUB(NOW(), INTERVAL 14 DAY)),
(3, 67.96, 'delivered', '789 Pine Rd, Chicago, IL 60601', DATE_SUB(NOW(), INTERVAL 13 DAY)),
(4, 39.99, 'delivered', '321 Elm St, Houston, TX 77001', DATE_SUB(NOW(), INTERVAL 12 DAY)),
(5, 52.97, 'delivered', '654 Maple Dr, Phoenix, AZ 85001', DATE_SUB(NOW(), INTERVAL 11 DAY)),
(6, 24.99, 'delivered', '987 Cedar Ln, Philadelphia, PA 19101', DATE_SUB(NOW(), INTERVAL 10 DAY)),
-- Processing orders (recent)
(7, 76.95, 'processing', '147 Birch Way, San Antonio, TX 78201', DATE_SUB(NOW(), INTERVAL 3 DAY)),
(1, 34.99, 'processing', '123 Main St, New York, NY 10001', DATE_SUB(NOW(), INTERVAL 2 DAY)),
(3, 89.96, 'processing', '789 Pine Rd, Chicago, IL 60601', DATE_SUB(NOW(), INTERVAL 2 DAY)),
-- Pending orders (very recent)
(2, 19.99, 'pending', '456 Oak Ave, Los Angeles, CA 90001', DATE_SUB(NOW(), INTERVAL 1 DAY)),
(4, 42.98, 'pending', '321 Elm St, Houston, TX 77001', DATE_SUB(NOW(), INTERVAL 1 DAY)),
(8, 15.99, 'pending', '258 Spruce Ct, San Diego, CA 92101', NOW()),
-- Cancelled order
(5, 29.99, 'cancelled', '654 Maple Dr, Phoenix, AZ 85001', DATE_SUB(NOW(), INTERVAL 5 DAY)),
-- More recent orders
(6, 127.94, 'delivered', '987 Cedar Ln, Philadelphia, PA 19101', DATE_SUB(NOW(), INTERVAL 8 DAY)),
(7, 56.97, 'processing', '147 Birch Way, San Antonio, TX 78201', DATE_SUB(NOW(), INTERVAL 1 DAY));

-- Insert order items (products in each order)
INSERT INTO order_items (order_id, product_id, quantity, price) VALUES
-- Order 1 items
(1, 1, 2, 5.99),
(1, 4, 1, 24.99),
(1, 8, 2, 6.99),
-- Order 2 items
(2, 12, 1, 29.99),
-- Order 3 items
(3, 7, 1, 39.99),
(3, 2, 2, 14.99),
-- Order 4 items
(4, 7, 1, 39.99),
-- Order 5 items
(5, 6, 1, 23.99),
(5, 10, 1, 19.99),
(5, 15, 1, 6.99),
-- Order 6 items
(6, 4, 1, 24.99),
-- Order 7 items
(7, 17, 2, 34.99),
(7, 15, 1, 6.99),
-- Order 8 items
(8, 17, 1, 34.99),
-- Order 9 items
(9, 7, 2, 39.99),
(9, 13, 1, 12.99),
-- Order 10 items
(10, 10, 1, 19.99),
-- Order 11 items
(11, 2, 2, 14.99),
(11, 13, 1, 12.99),
-- Order 12 items
(12, 5, 1, 12.99),
-- Order 13 items (cancelled)
(13, 12, 1, 29.99),
-- Order 14 items
(14, 7, 2, 39.99),
(14, 6, 2, 23.99),
-- Order 15 items
(15, 1, 3, 5.99),
(15, 7, 1, 39.99);

-- ============================================
-- VERIFICATION QUERIES
-- ============================================

-- Show counts
SELECT 'Users' as Table_Name, COUNT(*) as Count FROM users
UNION ALL
SELECT 'Categories', COUNT(*) FROM categories
UNION ALL
SELECT 'Products', COUNT(*) FROM products
UNION ALL
SELECT 'Orders', COUNT(*) FROM orders
UNION ALL
SELECT 'Order Items', COUNT(*) FROM order_items;

-- ============================================
-- SETUP COMPLETE!
-- ============================================
-- Database: medicare_db
-- Users: 8 customers
-- Categories: 6 categories
-- Products: 20 products
-- Orders: 15 orders
-- Order Items: 27 items
-- 
-- Now login to admin panel:
-- URL: http://localhost/ppp/admin/login.php
-- Username: admin
-- Password: admin123
-- ===========================================
