﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Import Real Medicines - MEDIX</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: "Segoe UI", Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #B91C1C, #991B1B);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .container {
            background: white;
            border-radius: 20px;
            padding: 3rem;
            max-width: 800px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }
        h1 {
            color: #B91C1C;
            text-align: center;
            margin-bottom: 2rem;
        }
        .step {
            background: #F9FAFB;
            padding: 1rem;
            margin: 1rem 0;
            border-radius: 8px;
            border-left: 4px solid #B91C1C;
        }
        .success {
            background: #D1FAE5;
            border-left-color: #10B981;
            color: #065F46;
        }
        .error {
            background: #FEE2E2;
            border-left-color: #EF4444;
            color: #991B1B;
        }
        .info {
            background: #DBEAFE;
            border-left-color: #3B82F6;
            color: #1E40AF;
        }
        .btn {
            display: inline-block;
            background: #B91C1C;
            color: white;
            padding: 1rem 2rem;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
            margin: 0.5rem;
            transition: all 0.3s;
        }
        .btn:hover {
            background: #991B1B;
            transform: translateY(-2px);
        }
        .btn-green {
            background: #10B981;
        }
        .btn-green:hover {
            background: #059669;
        }
        .buttons {
            text-align: center;
            margin-top: 2rem;
        }
        .medicine-list {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 0.5rem;
            margin: 1rem 0;
            font-size: 0.9rem;
        }
        .medicine-item {
            background: #F3F4F6;
            padding: 0.5rem;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>ðŸ’Š Import Real Medicines Database</h1>
        
        <?php
        set_time_limit(300);
        
        // Database configuration
        $host = 'localhost';
        $user = 'root';
        $pass = '';
        $dbname = 'medicare_db';
        
        // Path to SQL file
        $sqlFile = '../database/real_medicines_import.sql';
        
        echo '<div class="step info">
                <strong>Step 1:</strong> Checking SQL file...
              </div>';
        
        if (!file_exists($sqlFile)) {
            echo '<div class="step error">
                    <strong>âŒ Error:</strong> SQL file not found at: ' . $sqlFile . '
                  </div>';
            echo '<div class="buttons">
                    <a href="index.php" class="btn">Back to Dashboard</a>
                  </div>
                </div>
            </body>
            </html>';
            exit;
        }
        
        echo '<div class="step success">
                <strong>âœ… Success:</strong> Real medicines SQL file found!
              </div>';
        
        // Connect to MySQL
        echo '<div class="step info">
                <strong>Step 2:</strong> Connecting to MySQL...
              </div>';
        
        $conn = new mysqli($host, $user, $pass);
        
        if ($conn->connect_error) {
            echo '<div class="step error">
                    <strong>âŒ Error:</strong> Could not connect to MySQL: ' . $conn->connect_error . '
                    <br><br>
                    <strong>Solution:</strong> Make sure MySQL is running in XAMPP Control Panel (should be green)
                  </div>';
            echo '<div class="buttons">
                    <a href="index.php" class="btn">Back to Dashboard</a>
                  </div>
                </div>
            </body>
            </html>';
            exit;
        }
        
        echo '<div class="step success">
                <strong>âœ… Success:</strong> Connected to MySQL!
              </div>';
        
        // Read SQL file
        echo '<div class="step info">
                <strong>Step 3:</strong> Reading real medicines SQL file...
              </div>';
        
        $sql = file_get_contents($sqlFile);
        
        if ($sql === false) {
            echo '<div class="step error">
                    <strong>âŒ Error:</strong> Could not read SQL file
                  </div>';
            echo '<div class="buttons">
                    <a href="index.php" class="btn">Back to Dashboard</a>
                  </div>
                </div>
            </body>
            </html>';
            exit;
        }
        
        echo '<div class="step success">
                <strong>âœ… Success:</strong> SQL file loaded! (' . number_format(strlen($sql)) . ' characters)
              </div>';
        
        // Execute SQL
        echo '<div class="step info">
                <strong>Step 4:</strong> Importing real medicines database... (this may take 10-30 seconds)
              </div>';
        
        // Execute multi-query
        if ($conn->multi_query($sql)) {
            // Wait for all queries to complete
            do {
                if ($result = $conn->store_result()) {
                    $result->free();
                }
            } while ($conn->more_results() && $conn->next_result());
            
            echo '<div class="step success">
                    <strong>âœ… SUCCESS!</strong> Real medicines database imported successfully!
                  </div>';
            
            // Verify data
            echo '<div class="step info">
                    <strong>Step 5:</strong> Verifying imported data...
                  </div>';
            
            $conn->select_db($dbname);
            
            // Count data
            $result = $conn->query("SELECT COUNT(*) as count FROM companies");
            $companyCount = $result ? $result->fetch_assoc()['count'] : 0;
            
            $result = $conn->query("SELECT COUNT(*) as count FROM products");
            $productCount = $result ? $result->fetch_assoc()['count'] : 0;
            
            $result = $conn->query("SELECT COUNT(*) as count FROM medicines");
            $medicineCount = $result ? $result->fetch_assoc()['count'] : 0;
            
            $result = $conn->query("SELECT COUNT(*) as count FROM users");
            $userCount = $result ? $result->fetch_assoc()['count'] : 0;
            
            echo '<div class="step success">
                    <strong>âœ… Database Verified!</strong><br><br>
                    ðŸ¢ Companies: <strong>' . $companyCount . '</strong> (GSK, Pfizer, Abbott, Novartis, etc.)<br>
                    ðŸ’Š Products: <strong>' . $productCount . '</strong><br>
                    ðŸ’‰ Medicines: <strong>' . $medicineCount . '</strong> (Real medicines with images)<br>
                    ðŸ‘¥ Users: <strong>' . $userCount . '</strong> (Admin + Sample customer)
                  </div>';
            
            // Show real medicines
            echo '<div class="step success">
                    <strong>ðŸŽ¯ Real Medicines Added:</strong><br><br>
                    <div class="medicine-list">
                        <div class="medicine-item">ðŸ’Š Panadol Extra - PKR 50.00</div>
                        <div class="medicine-item">ðŸ’Š Augmentin 625mg - PKR 240.00</div>
                        <div class="medicine-item">ðŸ’Š Brufen 400mg - PKR 35.00</div>
                        <div class="medicine-item">ðŸ’Š Disprin - PKR 15.00</div>
                        <div class="medicine-item">ðŸ’Š Viagra 100mg - PKR 800.00</div>
                    </div>
                    <br>All medicines include real product images and company logos!
                  </div>';
            
            echo '<div class="step success" style="text-align: center; font-size: 1.2rem;">
                    <strong>ðŸŽ‰ ALL DONE!</strong><br><br>
                    Your MEDIX pharmacy now has real medicines with:<br>
                    âœ“ Real product images<br>
                    âœ“ Company logos (GSK, Pfizer, Abbott, etc.)<br>
                    âœ“ Authentic pricing in PKR<br>
                    âœ“ Professional medicine descriptions
                  </div>';
            
            echo '<div class="buttons">
                    <a href="../products.php" class="btn btn-green">View Real Products</a>
                    <a href="index.php" class="btn">Admin Dashboard</a>
                    <a href="../index.html" class="btn">Main Website</a>
                  </div>';
            
        } else {
            echo '<div class="step error">
                    <strong>âŒ Error:</strong> ' . $conn->error . '
                  </div>';
            echo '<div class="buttons">
                    <a href="index.php" class="btn">Back to Dashboard</a>
                  </div>';
        }
        
        $conn->close();
        ?>
    </div>
</body>
</html>
