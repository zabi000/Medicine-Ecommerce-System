<?php
$file = __DIR__ . '/index.html';
$html = file_get_contents($file);

// Remove the entire deals section using regex
$html = preg_replace(
    '/<!-- Featured Deals Slider -->.*?<\/section>\s*<section class="featured-products">/s',
    '<section class="featured-products">',
    $html
);

file_put_contents($file, $html);
echo "<p style='color:green;font-family:sans-serif;padding:1rem'>✅ Deals section removed! <a href='index.php'>View Homepage</a></p>";
?>
