<?php
header('Content-Type: application/json');
require_once 'config.php';

if (!$conn) { echo json_encode([]); exit; }

// Ensure table exists
$conn->query("CREATE TABLE IF NOT EXISTS offers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    product_id INT NOT NULL,
    discount_percent DECIMAL(5,2) NOT NULL,
    offer_label VARCHAR(100) DEFAULT 'SALE',
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    is_active TINYINT(1) DEFAULT 1,
    show_on_homepage TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$homepage_only = isset($_GET['homepage']) ? ' AND o.show_on_homepage=1' : '';
$limit = isset($_GET['limit']) ? ' LIMIT ' . intval($_GET['limit']) : ' LIMIT 12';

$sql = "
    SELECT o.id, o.discount_percent, o.offer_label,
           p.id AS product_id, p.name, p.price AS original_price,
           p.image_url, p.category, p.stock_quantity,
           ROUND(p.price * (1 - o.discount_percent/100), 2) AS sale_price
    FROM offers o
    JOIN products p ON o.product_id = p.id
    WHERE o.is_active = 1
      AND CURDATE() BETWEEN o.start_date AND o.end_date
      AND p.stock_quantity > 0
      $homepage_only
    ORDER BY o.discount_percent DESC
    $limit
";

$result = $conn->query($sql);
$offers = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $offers[] = $row;
    }
}
echo json_encode($offers);
?>
