﻿<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

echo "<h2>Debug Customers Page</h2>";

// Step 1: Session check
echo "<h3>Step 1: Session</h3>";
if (isset($_SESSION['admin_logged_in'])) {
    echo "âœ… Logged in as: " . $_SESSION['admin_username'] . "<br>";
} else {
    echo "âŒ NOT logged in - <a href='quick_login.php'>Click here to login</a><br>";
    echo "<br>Setting session now for testing...<br>";
    $_SESSION['admin_logged_in'] = true;
    $_SESSION['admin_username'] = 'admin';
    echo "âœ… Session set. <a href='debug_customers.php'>Refresh</a><br>";
}

// Step 2: Config file
echo "<h3>Step 2: Config File</h3>";
if (file_exists('../api/config.php')) {
    echo "âœ… config.php found<br>";
    require_once('../api/config.php');
} else {
    echo "âŒ config.php NOT found at ../api/config.php<br>";
    die();
}

// Step 3: DB Connection
echo "<h3>Step 3: Database</h3>";
if ($conn) {
    echo "âœ… Database connected<br>";
} else {
    echo "âŒ Database NOT connected<br>";
    die();
}

// Step 4: Users table
echo "<h3>Step 4: Users Table</h3>";
$r = $conn->query("SHOW TABLES LIKE 'users'");
if ($r && $r->num_rows > 0) {
    echo "âœ… users table exists<br>";
} else {
    echo "âŒ users table does NOT exist<br>";
    echo "Creating it now...<br>";
    $conn->query("CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100),
        email VARCHAR(100) UNIQUE,
        phone VARCHAR(20),
        password VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    echo "âœ… users table created<br>";
}

// Step 5: Columns
echo "<h3>Step 5: Users Table Columns</h3>";
$cols = $conn->query("SHOW COLUMNS FROM users");
while ($c = $cols->fetch_assoc()) {
    echo "- " . $c['Field'] . " (" . $c['Type'] . ")<br>";
}

// Step 6: Count users
echo "<h3>Step 6: User Count</h3>";
$count = $conn->query("SELECT COUNT(*) as c FROM users")->fetch_assoc()['c'];
echo "Total users: $count<br>";

// Step 7: Orders table
echo "<h3>Step 7: Orders Table</h3>";
$r2 = $conn->query("SHOW TABLES LIKE 'orders'");
if ($r2 && $r2->num_rows > 0) {
    echo "âœ… orders table exists<br>";
    $oc = $conn->query("SELECT COUNT(*) as c FROM orders")->fetch_assoc()['c'];
    echo "Total orders: $oc<br>";
} else {
    echo "âŒ orders table does NOT exist<br>";
}

echo "<br><hr>";
echo "<h3>âœ… All checks done!</h3>";
echo "<a href='customers.php' class='btn btn-danger' style='padding:10px 20px;background:#B91C1C;color:white;text-decoration:none;border-radius:8px;'>Go to Customers Page</a>";
?>

