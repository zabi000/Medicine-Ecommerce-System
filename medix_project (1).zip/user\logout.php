<?php
session_start();
// Clear only user session keys (not cart)
unset($_SESSION['user_id'], $_SESSION['user_name'], $_SESSION['user_email']);
// If nothing left, destroy
if (empty($_SESSION)) {
    session_destroy();
}
header('Location: ../index.php');
exit();
?>
