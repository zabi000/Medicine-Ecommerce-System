<?php
session_start();
// Load offers from database for the homepage
require_once('api/config.php');

// User session state
$user_logged_in = isset($_SESSION['user_id']) && $_SESSION['user_id'] > 0;
$user_name      = $_SESSION['user_name'] ?? '';

$homepage_offers = [];
$store_phone = '+92-300-1234567';
$store_email = 'info@medix.com';
$store_name_setting = 'MEDIX Pharmacy';

// Fetch real products for the "Today's Best Deals" section
$deal_products = [];
if ($conn) {
    $dp = $conn->query("SELECT id, name, price, image_url, category FROM products WHERE stock_quantity > 0 ORDER BY RAND() LIMIT 4");
    if ($dp) while ($row = $dp->fetch_assoc()) $deal_products[] = $row;
}

$homepage_offers = [];
$store_phone = '+92-300-1234567';
$store_email = 'info@medix.com';
$store_name_setting = 'MEDIX Pharmacy';

if ($conn) {
    // Load store settings
    $conn->query("CREATE TABLE IF NOT EXISTS site_settings (`key` VARCHAR(100) PRIMARY KEY, `value` TEXT) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $sr = $conn->query("SELECT `key`, `value` FROM site_settings WHERE `key` IN ('store_phone','store_email','store_name')");
    if ($sr) while ($row = $sr->fetch_assoc()) {
        if ($row['key'] === 'store_phone') $store_phone = $row['value'];
        if ($row['key'] === 'store_email') $store_email = $row['value'];
        if ($row['key'] === 'store_name')  $store_name_setting = $row['value'];
    }
    // Ensure table exists
    $conn->query("CREATE TABLE IF NOT EXISTS offers (
        id INT AUTO_INCREMENT PRIMARY KEY,
        product_id INT NOT NULL,
        discount_percent DECIMAL(5,2) NOT NULL,
        offer_label VARCHAR(100) DEFAULT 'SALE',
        start_date DATE NOT NULL,
        end_date DATE NOT NULL,
        is_active TINYINT(1) DEFAULT 1,
        show_on_homepage TINYINT(1) DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $or = $conn->query("
        SELECT o.id, o.discount_percent, o.offer_label,
               p.id AS product_id, p.name, p.price AS original_price,
               p.image_url, p.category,
               ROUND(p.price * (1 - o.discount_percent/100), 2) AS sale_price
        FROM offers o
        JOIN products p ON o.product_id = p.id
        WHERE o.is_active = 1
          AND CURDATE() BETWEEN o.start_date AND o.end_date
          AND o.show_on_homepage = 1
          AND p.stock_quantity > 0
        ORDER BY o.discount_percent DESC
        LIMIT 8
    ");
    if ($or) while ($row = $or->fetch_assoc()) $homepage_offers[] = $row;
}

$has_offers = count($homepage_offers) > 0;

// Include the main homepage — output buffering to inject offers
ob_start();
include('index.html');
$html = ob_get_clean();

// --- Inject offers carousel slide ---
if ($has_offers) {
    // Build the offers slide HTML
    $cards_html = '';
    foreach ($homepage_offers as $o) {
        $img = !empty($o['image_url'])
            ? '<img src="' . (defined('APP_BASE') ? APP_BASE : '/ppp') . '/' . htmlspecialchars($o['image_url']) . '" alt="' . htmlspecialchars($o['name']) . '" style="max-height:120px;max-width:100%;object-fit:contain" onerror="this.style.display=\'none\'">'
            : '<i class="bi bi-capsule-pill" style="font-size:3rem;color:#FECACA"></i>';
        $savings = number_format($o['original_price'] - $o['sale_price'], 0);
        $cards_html .= '
        <div style="min-width:200px;max-width:220px;flex-shrink:0">
            <div style="background:white;border-radius:16px;padding:1rem;box-shadow:0 4px 16px rgba(0,0,0,0.08);height:100%;position:relative">
                <span style="position:absolute;top:8px;left:8px;background:linear-gradient(135deg,#B91C1C,#DC2626);color:white;padding:3px 10px;border-radius:20px;font-size:.65rem;font-weight:800">' . htmlspecialchars($o['offer_label']) . '</span>
                <span style="position:absolute;top:8px;right:8px;background:#FEF2F2;color:#B91C1C;padding:3px 8px;border-radius:20px;font-size:.7rem;font-weight:700">-' . number_format($o['discount_percent'], 0) . '%</span>
                <div style="height:100px;display:flex;align-items:center;justify-content:center;margin-bottom:.75rem;margin-top:1rem">' . $img . '</div>
                <div style="font-size:.8rem;font-weight:700;color:#0F172A;margin-bottom:.5rem;line-height:1.3;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">' . htmlspecialchars($o['name']) . '</div>
                <div style="text-decoration:line-through;color:#94A3B8;font-size:.72rem">PKR ' . number_format($o['original_price'], 0) . '</div>
                <div style="color:#B91C1C;font-weight:800;font-size:1.1rem;letter-spacing:-.5px">PKR ' . number_format($o['sale_price'], 0) . '</div>
                <div style="color:#059669;font-size:.7rem;font-weight:600;margin-bottom:.75rem">Save PKR ' . $savings . '</div>
                <form action="cart.php" method="POST">
                    <input type="hidden" name="product_id" value="' . $o['product_id'] . '">
                    <button type="submit" style="background:linear-gradient(135deg,#B91C1C,#DC2626);color:white;border:none;border-radius:8px;padding:.4rem .875rem;font-size:.78rem;font-weight:700;width:100%;cursor:pointer">
                        <i class="bi bi-cart-plus"></i> Add to Cart
                    </button>
                </form>
            </div>
        </div>';
    }

    $offers_slide = '
    <!-- LIVE OFFERS SLIDE (injected by index.php) -->
    <div class="carousel-item">
        <div class="ad-slide" style="background:linear-gradient(135deg,#7F1D1D 0%,#B91C1C 50%,#DC2626 100%);min-height:400px;padding:2rem 3rem;display:flex;flex-direction:column;justify-content:center">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:1.5rem;flex-wrap:wrap;gap:1rem">
                <div>
                    <div style="background:rgba(255,255,255,.2);display:inline-flex;align-items:center;gap:.5rem;padding:.4rem 1rem;border-radius:20px;color:white;font-size:.8rem;font-weight:700;margin-bottom:.75rem">
                        <i class="bi bi-lightning-charge-fill"></i> LIVE OFFERS — LIMITED TIME
                    </div>
                    <h2 style="color:white;font-size:2rem;font-weight:800;margin:0">Special Discounts</h2>
                    <p style="color:rgba(255,255,255,.8);margin:.25rem 0 0;font-size:.95rem">Grab these deals before they expire!</p>
                </div>
                <a href="products.php" style="background:rgba(255,255,255,.2);color:white;padding:.6rem 1.5rem;border-radius:30px;text-decoration:none;font-weight:600;font-size:.85rem;border:2px solid rgba(255,255,255,.4);transition:all .2s" onmouseover="this.style.background=\'rgba(255,255,255,.35)\'" onmouseout="this.style.background=\'rgba(255,255,255,.2)\'">
                    View All Products <i class="bi bi-arrow-right ms-1"></i>
                </a>
            </div>
            <div style="display:flex;gap:1rem;overflow-x:auto;padding-bottom:.5rem;scrollbar-width:thin;scrollbar-color:rgba(255,255,255,.3) transparent">
                ' . $cards_html . '
            </div>
        </div>
    </div>';

    // Add indicator button for the new slide
    $indicator_count = substr_count($html, 'data-bs-slide-to=');
    $new_indicator = '<button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="' . $indicator_count . '"></button>';

    // Inject the slide before the carousel controls — using unique surrounding text
    $html = str_replace(
        '<button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">',
        $offers_slide . "\n                <button class=\"carousel-control-prev\" type=\"button\" data-bs-target=\"#heroCarousel\" data-bs-slide=\"prev\">",
        $html
    );

    // Add indicator for the new slide (4th slide = index 3)
    $html = str_replace(
        '<button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="2"></button>',
        '<button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="2"></button>
                    <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="3"></button>',
        $html
    );
}

// --- Inject offers grid section (already in HTML, but ensure it shows) ---
if ($has_offers) {
    // The section is hidden by default via display:none, make it visible
    $html = str_replace(
        'id="offers-section" style="background: linear-gradient(180deg,#fff5f5,#fff); padding: 4rem 0; display:none"',
        'id="offers-section" style="background: linear-gradient(180deg,#fff5f5,#fff); padding: 4rem 0;"',
        $html
    );

    // Inject the offers grid directly (no JS fetch needed)
    $grid_html = '';
    foreach ($homepage_offers as $o) {
        $img_html = !empty($o['image_url'])
            ? '<img src="/ppp/' . htmlspecialchars($o['image_url']) . '" alt="' . htmlspecialchars($o['name']) . '" style="max-width:100%;max-height:150px;object-fit:contain" onerror="this.style.display=\'none\'">'
            : '<i class="bi bi-capsule-pill" style="font-size:4rem;color:#FECACA"></i>';
        $savings = round($o['original_price'] - $o['sale_price']);
        $grid_html .= '
        <div class="col-6 col-md-4 col-lg-3">
            <div style="background:white;border-radius:20px;box-shadow:0 2px 12px rgba(0,0,0,0.07);overflow:hidden;transition:all .3s;height:100%" onmouseenter="this.style.transform=\'translateY(-6px)\';this.style.boxShadow=\'0 16px 40px rgba(185,28,28,0.15)\'" onmouseleave="this.style.transform=\'\';this.style.boxShadow=\'0 2px 12px rgba(0,0,0,0.07)\'">
                <div style="background:linear-gradient(145deg,#fff5f5,#fafafa);height:160px;display:flex;align-items:center;justify-content:center;position:relative;overflow:hidden">
                    <span style="position:absolute;top:10px;left:10px;background:linear-gradient(135deg,#B91C1C,#DC2626);color:white;padding:4px 12px;border-radius:20px;font-size:.7rem;font-weight:800">' . htmlspecialchars($o['offer_label']) . '</span>
                    <span style="position:absolute;top:10px;right:10px;background:#FEF2F2;color:#B91C1C;padding:4px 10px;border-radius:20px;font-size:.75rem;font-weight:700">-' . number_format($o['discount_percent'], 0) . '%</span>
                    ' . $img_html . '
                </div>
                <div style="padding:1rem">
                    <p style="margin:0 0 .25rem;font-size:.75rem;color:#94A3B8;text-transform:uppercase;letter-spacing:.5px">' . htmlspecialchars($o['category'] ?? 'Medicine') . '</p>
                    <h6 style="font-weight:700;font-size:.9rem;color:#0F172A;line-height:1.35;margin-bottom:.5rem;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden">' . htmlspecialchars($o['name']) . '</h6>
                    <div style="display:flex;align-items:center;gap:.5rem;margin-bottom:.25rem">
                        <span style="text-decoration:line-through;color:#94A3B8;font-size:.8rem">PKR ' . number_format($o['original_price'], 0) . '</span>
                        <span style="background:#FEF2F2;color:#B91C1C;padding:2px 8px;border-radius:10px;font-size:.7rem;font-weight:700">Save PKR ' . number_format($savings, 0) . '</span>
                    </div>
                    <div style="color:#B91C1C;font-weight:800;font-size:1.2rem;letter-spacing:-.5px;margin-bottom:.75rem">PKR ' . number_format($o['sale_price'], 0) . '</div>
                    <form action="cart.php" method="POST">
                        <input type="hidden" name="product_id" value="' . $o['product_id'] . '">
                        <button type="submit" class="btn btn-danger btn-sm w-100" style="border-radius:10px;font-weight:600">
                            <i class="bi bi-cart-plus me-1"></i>Add to Cart
                        </button>
                    </form>
                </div>
            </div>
        </div>';
    }

    // Replace the empty offers grid placeholder
    $html = str_replace(
        '<div class="row g-4" id="offersGrid">
                <!-- Loaded dynamically -->
            </div>',
        '<div class="row g-4" id="offersGrid">' . $grid_html . '</div>',
        $html
    );

    // Remove the JS fetch code since we inject server-side
    $html = preg_replace("/fetch\('api\/get_offers\.php.*?catch\(\(\) => \{\}\);/s", "// Offers loaded server-side", $html);
}

// --- Inject dynamic store contact info ---
$html = str_replace(
    '<i class="bi bi-telephone-fill me-1"></i> +92-300-1234567',
    '<i class="bi bi-telephone-fill me-1"></i> ' . htmlspecialchars($store_phone),
    $html
);
$html = str_replace(
    '<i class="bi bi-envelope-fill me-1"></i> info@medix.com',
    '<i class="bi bi-envelope-fill me-1"></i> ' . htmlspecialchars($store_email),
    $html
);

// --- Inject user login/logout state in navbar ---
if ($user_logged_in) {
    $first = htmlspecialchars(explode(' ', $user_name)[0]);
    $logged_in_html = '
        <div class="dropdown">
            <button class="btn btn-outline-light btn-sm dropdown-toggle" type="button" data-bs-toggle="dropdown" style="border-radius:20px">
                <i class="bi bi-person-check-fill me-1"></i>' . $first . '
            </button>
            <ul class="dropdown-menu dropdown-menu-end shadow" style="border-radius:12px;border:none;min-width:200px">
                <li class="px-3 py-2">
                    <div class="fw-bold" style="font-size:.9rem">' . htmlspecialchars($user_name) . '</div>
                    <div class="text-muted" style="font-size:.75rem">' . htmlspecialchars($_SESSION['user_email'] ?? '') . '</div>
                </li>
                <li><hr class="dropdown-divider my-1"></li>
                <li><a class="dropdown-item py-2" href="user/profile.php"><i class="bi bi-person me-2 text-danger"></i>My Profile & Orders</a></li>
                <li><a class="dropdown-item py-2" href="user/profile.php?tab=messages"><i class="bi bi-chat-dots me-2 text-danger"></i>Messages</a></li>
                <li><a class="dropdown-item py-2 text-danger" href="user/logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
            </ul>
        </div>';

    // Try multiple patterns to find and replace the login button
    // Pattern 1: wrapped in navUserArea div
    $html = preg_replace(
        '/<div id="navUserArea">.*?<\/div>/s',
        '<div id="navUserArea">' . $logged_in_html . '</div>',
        $html
    );
    // Pattern 2: bare login link (fallback)
    $html = preg_replace(
        '/<a\s+href="login\.php"[^>]*>\s*<i class="bi bi-person[^"]*"><\/i>\s*Login\s*<\/a>/',
        $logged_in_html,
        $html
    );
} else {
    $html = str_replace('href="login.html"', 'href="login.php"', $html);
}

// --- Inject real product IDs into deal cards ---
if (count($deal_products) >= 4) {
    $html = str_replace('name="product_id" value="1"', 'name="product_id" value="' . $deal_products[0]['id'] . '"', $html);
    $html = str_replace('name="product_id" value="3"', 'name="product_id" value="' . $deal_products[1]['id'] . '"', $html);
    $html = str_replace('name="product_id" value="5"', 'name="product_id" value="' . $deal_products[2]['id'] . '"', $html);
    $html = str_replace('name="product_id" value="7"', 'name="product_id" value="' . $deal_products[3]['id'] . '"', $html);
}

echo $html;
?>
