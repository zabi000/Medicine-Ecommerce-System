﻿<?php
ini_set('session.gc_maxlifetime', 28800);
session_set_cookie_params(28800);
session_start();

// Already logged in — redirect
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    header('Location: index.php');
    exit();
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    // Check against DB-stored password first, fallback to hardcoded
    require_once('../api/config.php');

    $admin_pass_ok = false;

    if ($conn) {
        // Try to get password from site_settings
        $r = $conn->query("SHOW TABLES LIKE 'site_settings'");
        if ($r && $r->num_rows > 0) {
            $pr = $conn->query("SELECT value FROM site_settings WHERE `key`='admin_password'");
            if ($pr && $row = $pr->fetch_assoc()) {
                $admin_pass_ok = password_verify($password, $row['value']);
            }
        }
    }

    // Fallback: default credentials
    if (!$admin_pass_ok && $username === 'admin' && $password === 'admin123') {
        $admin_pass_ok = true;
    }

    if ($username === 'admin' && $admin_pass_ok) {
        session_regenerate_id(true); // Prevent session fixation
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username']  = $username;
        $_SESSION['login_time']      = time();
        $_SESSION['last_activity']   = time();
        header('Location: index.php');
        exit();
    } else {
        $error = 'Invalid username or password.';
        // Small delay to slow brute force
        sleep(1);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login - MEDIX</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
* { font-family: 'Inter', sans-serif; }
body {
    background: linear-gradient(135deg, #B91C1C, #7F1D1D);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
}
.login-card {
    background: white;
    border-radius: 20px;
    box-shadow: 0 25px 60px rgba(0,0,0,0.35);
    overflow: hidden;
    width: 100%;
    max-width: 400px;
}
.login-header {
    background: linear-gradient(135deg, #B91C1C, #991B1B);
    color: white;
    padding: 2.5rem 2rem;
    text-align: center;
}
.login-body { padding: 2rem; }
.form-control:focus {
    border-color: #B91C1C;
    box-shadow: 0 0 0 3px rgba(185,28,28,0.15);
}
.input-group-text { background: #f8fafc; border-right: none; }
.form-control { border-left: none; }
.btn-login {
    background: linear-gradient(135deg, #B91C1C, #991B1B);
    border: none;
    padding: .875rem;
    font-weight: 700;
    font-size: 1rem;
    border-radius: 10px;
    transition: all .2s;
}
.btn-login:hover {
    background: linear-gradient(135deg, #991B1B, #7F1D1D);
    transform: translateY(-1px);
    box-shadow: 0 6px 18px rgba(185,28,28,.4);
}
</style>
</head>
<body>
<div class="login-card">
    <div class="login-header">
        <i class="bi bi-heart-pulse-fill" style="font-size:2.5rem"></i>
        <h3 class="mt-2 mb-0 fw-bold">MEDIX Admin</h3>
        <p class="mb-0" style="opacity:.75;font-size:.9rem">Secure Administrator Access</p>
    </div>
    <div class="login-body">
        <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show py-2">
            <i class="bi bi-exclamation-triangle me-2"></i><?= htmlspecialchars($error) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        <?php if (isset($_GET['timeout'])): ?>
        <div class="alert alert-warning py-2">
            <i class="bi bi-clock me-2"></i>Session expired. Please log in again.
        </div>
        <?php endif; ?>

        <form method="POST" autocomplete="off">
            <div class="mb-3">
                <label class="form-label fw-semibold">Username</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-person text-muted"></i></span>
                    <input type="text" class="form-control" name="username" placeholder="admin" required autocomplete="username">
                </div>
            </div>
            <div class="mb-4">
                <label class="form-label fw-semibold">Password</label>
                <div class="input-group">
                    <span class="input-group-text"><i class="bi bi-lock text-muted"></i></span>
                    <input type="password" class="form-control" name="password" placeholder="••••••••" required autocomplete="current-password" id="pw">
                    <button class="btn btn-outline-secondary" type="button" onclick="let i=document.getElementById('pw');i.type=i.type==='password'?'text':'password'">
                        <i class="bi bi-eye"></i>
                    </button>
                </div>
            </div>
            <button type="submit" class="btn btn-danger btn-login w-100 text-white">
                <i class="bi bi-box-arrow-in-right me-2"></i>Login to Admin Panel
            </button>
        </form>

        <hr class="my-3">
        <div class="text-center">
            <a href="../index.php" class="text-muted small text-decoration-none">
                <i class="bi bi-arrow-left me-1"></i>Back to Website
            </a>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
