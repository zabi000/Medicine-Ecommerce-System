<?php
require_once('api/config.php');

echo "<h1>MEDIX Website Status Check</h1>";
echo "<style>
    body { font-family: Arial, sans-serif; padding: 20px; background: #f5f5f5; }
    .status-box { background: white; padding: 20px; margin: 10px 0; border-radius: 8px; border-left: 4px solid #ccc; }
    .success { border-left-color: #10B981; }
    .error { border-left-color: #EF4444; }
    .warning { border-left-color: #F59E0B; }
    a { color: #B91C1C; text-decoration: none; font-weight: bold; }
    a:hover { text-decoration: underline; }
</style>";

// Test 1: Database Connection
echo "<div class='status-box " . ($conn ? "success" : "error") . "'>";
echo "<h3>1. Database Connection</h3>";
if ($conn) {
    echo "<p>✓ Database connected successfully</p>";
} else {
    echo "<p>✗ Database connection failed</p>";
}
echo "</div>";

// Test 2: Products Table
if ($conn) {
    $products_check = $conn->query("SELECT COUNT(*) as count FROM products");
    $product_count = $products_check ? $products_check->fetch_assoc()['count'] : 0;
    
    echo "<div class='status-box " . ($product_count > 0 ? "success" : "warning") . "'>";
    echo "<h3>2. Products Table</h3>";
    echo "<p>Products in database: <strong>$product_count</strong></p>";
    echo "</div>";
}

// Test 3: Check Key Files
$files_to_check = [
    'index.html' => 'Homepage',
    'products.php' => 'Products Page',
    'cart.php' => 'Cart Page',
    'checkout.php' => 'Checkout Page',
    'admin/index.php' => 'Admin Dashboard',
    'admin/products.php' => 'Admin Products',
    'admin/orders.php' => 'Admin Orders',
    'admin/messages.php' => 'Admin Messages',
    'admin/categories.php' => 'Admin Categories',
    'admin/reports.php' => 'Admin Reports'
];

echo "<div class='status-box success'>";
echo "<h3>3. Key Files Status</h3>";
echo "<table style='width: 100%; border-collapse: collapse;'>";
echo "<tr style='background: #f9f9f9;'><th style='text-align: left; padding: 10px;'>File</th><th style='text-align: left; padding: 10px;'>Status</th><th style='text-align: left; padding: 10px;'>Action</th></tr>";

foreach ($files_to_check as $file => $name) {
    $exists = file_exists($file);
    $status = $exists ? "✓ Exists" : "✗ Missing";
    $color = $exists ? "green" : "red";
    
    echo "<tr>";
    echo "<td style='padding: 10px;'>$name</td>";
    echo "<td style='padding: 10px; color: $color;'>$status</td>";
    echo "<td style='padding: 10px;'>";
    if ($exists) {
        echo "<a href='$file' target='_blank'>Open →</a>";
    } else {
        echo "<span style='color: #999;'>N/A</span>";
    }
    echo "</td>";
    echo "</tr>";
}
echo "</table>";
echo "</div>";

// Test 4: Quick Links
echo "<div class='status-box'>";
echo "<h3>4. Quick Access Links</h3>";
echo "<div style='display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px;'>";
echo "<a href='index.html' style='display: block; padding: 15px; background: #B91C1C; color: white; text-align: center; border-radius: 8px;'>Homepage</a>";
echo "<a href='products.php' style='display: block; padding: 15px; background: #3B82F6; color: white; text-align: center; border-radius: 8px;'>Products</a>";
echo "<a href='cart.php' style='display: block; padding: 15px; background: #10B981; color: white; text-align: center; border-radius: 8px;'>Cart</a>";
echo "<a href='admin/login.php' style='display: block; padding: 15px; background: #F59E0B; color: white; text-align: center; border-radius: 8px;'>Admin Login</a>";
echo "<a href='admin/index.php' style='display: block; padding: 15px; background: #8B5CF6; color: white; text-align: center; border-radius: 8px;'>Admin Dashboard</a>";
echo "<a href='check_product_images.php' style='display: block; padding: 15px; background: #EC4899; color: white; text-align: center; border-radius: 8px;'>Add Product Images</a>";
echo "</div>";
echo "</div>";

// Test 5: Recent Activity
if ($conn) {
    echo "<div class='status-box'>";
    echo "<h3>5. Recent Activity</h3>";
    
    $recent_orders = $conn->query("SELECT COUNT(*) as count FROM orders WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
    $order_count = $recent_orders ? $recent_orders->fetch_assoc()['count'] : 0;
    
    $recent_messages = $conn->query("SELECT COUNT(*) as count FROM contact_messages WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY)");
    $message_count = $recent_messages ? $recent_messages->fetch_assoc()['count'] : 0;
    
    echo "<p>Orders (Last 7 days): <strong>$order_count</strong></p>";
    echo "<p>Messages (Last 7 days): <strong>$message_count</strong></p>";
    echo "</div>";
}

echo "<div style='text-align: center; margin-top: 30px; padding: 20px; background: #DBEAFE; border-radius: 8px;'>";
echo "<h3 style='color: #1E40AF;'>✓ Website Status: OPERATIONAL</h3>";
echo "<p style='color: #1E40AF;'>All core files are present and database is connected.</p>";
echo "</div>";

$conn->close();
?>
