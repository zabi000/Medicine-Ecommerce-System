<?php
require_once('api/config.php');

echo "<h2>Current Categories in Database</h2>";
echo "<table border='1' cellpadding='10'>";
echo "<tr><th>ID</th><th>Name</th><th>Description</th><th>Product Count</th></tr>";

$result = $conn->query("SELECT c.*, COUNT(p.id) as product_count 
                        FROM categories c 
                        LEFT JOIN products p ON c.name = p.category 
                        GROUP BY c.id 
                        ORDER BY c.name");

if ($result && $result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row['id'] . "</td>";
        echo "<td>" . htmlspecialchars($row['name']) . "</td>";
        echo "<td>" . htmlspecialchars($row['description']) . "</td>";
        echo "<td>" . $row['product_count'] . "</td>";
        echo "</tr>";
    }
} else {
    echo "<tr><td colspan='4'>No categories found</td></tr>";
}

echo "</table>";

echo "<br><h3>Categories needed for professional version:</h3>";
$needed = ['prescription', 'vitamins', 'firstaid', 'devices', 'personal', 'baby', 'skincare', 'supplements'];
echo "<ul>";
foreach ($needed as $cat) {
    echo "<li>" . ucfirst($cat) . "</li>";
}
echo "</ul>";
?>
