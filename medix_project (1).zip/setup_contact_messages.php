<?php
/**
 * Setup Contact Messages Table
 * Run this file once to create the contact_messages table
 */

require_once('api/config.php');

if (!$conn) {
    die("Database connection failed!");
}

echo "<!DOCTYPE html>
<html>
<head>
    <title>Setup Contact Messages - MEDIX</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css' rel='stylesheet'>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; background: #f5f5f5; }
        .container { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h1 { color: #B91C1C; }
        .success { background: #D1FAE5; color: #065F46; padding: 15px; border-radius: 8px; margin: 10px 0; }
        .error { background: #FEE2E2; color: #991B1B; padding: 15px; border-radius: 8px; margin: 10px 0; }
        .info { background: #DBEAFE; color: #1E40AF; padding: 15px; border-radius: 8px; margin: 10px 0; }
    </style>
</head>
<body>
    <div class='container'>
        <h1>📧 Setup Contact Messages System</h1>";

// Read SQL file
$sql_file = 'database/contact_messages.sql';
if (!file_exists($sql_file)) {
    echo "<div class='error'>❌ SQL file not found: $sql_file</div>";
    echo "</div></body></html>";
    exit;
}

$sql = file_get_contents($sql_file);

// Execute SQL
if ($conn->query($sql)) {
    echo "<div class='success'>✅ Contact messages table created successfully!</div>";
    
    // Check if table exists
    $result = $conn->query("SHOW TABLES LIKE 'contact_messages'");
    if ($result && $result->num_rows > 0) {
        echo "<div class='info'>📊 Table 'contact_messages' is ready to use</div>";
        
        // Show table structure
        $structure = $conn->query("DESCRIBE contact_messages");
        echo "<h3>Table Structure:</h3>";
        echo "<table class='table table-bordered'>";
        echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
        while ($row = $structure->fetch_assoc()) {
            echo "<tr>";
            echo "<td>{$row['Field']}</td>";
            echo "<td>{$row['Type']}</td>";
            echo "<td>{$row['Null']}</td>";
            echo "<td>{$row['Key']}</td>";
            echo "<td>{$row['Default']}</td>";
            echo "</tr>";
        }
        echo "</table>";
    }
    
    echo "<h3>✅ Setup Complete!</h3>";
    echo "<p>The contact messages system is now ready. Users can submit messages through the contact form, and you can view them in the admin dashboard.</p>";
    
    echo "<div class='mt-4'>";
    echo "<a href='contact.html' class='btn btn-primary me-2'>📝 Test Contact Form</a>";
    echo "<a href='admin/messages.php' class='btn btn-danger me-2'>📧 View Messages (Admin)</a>";
    echo "<a href='admin/login.php' class='btn btn-secondary'>🔐 Admin Login</a>";
    echo "</div>";
    
} else {
    echo "<div class='error'>❌ Error creating table: " . $conn->error . "</div>";
}

echo "</div></body></html>";

$conn->close();
?>
