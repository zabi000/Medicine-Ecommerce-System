<?php
require_once('api/config.php');
echo "<h3>site_settings table contents:</h3>";
if (!$conn) { echo "DB connection failed!"; exit; }

// Create table if missing
$conn->query("CREATE TABLE IF NOT EXISTS site_settings (`key` VARCHAR(100) PRIMARY KEY, `value` TEXT) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$r = $conn->query("SELECT * FROM site_settings ORDER BY `key`");
if (!$r || $r->num_rows === 0) {
    echo "<p style='color:red'>Table is EMPTY — settings have never been saved!</p>";
    echo "<p>Go to <a href='admin/settings.php'>admin/settings.php</a>, toggle the payment methods, and click Save.</p>";
} else {
    echo "<table border=1 cellpadding=8><tr><th>Key</th><th>Value</th></tr>";
    while ($row = $r->fetch_assoc()) {
        echo "<tr><td>{$row['key']}</td><td>{$row['value']}</td></tr>";
    }
    echo "</table>";
}
?>
