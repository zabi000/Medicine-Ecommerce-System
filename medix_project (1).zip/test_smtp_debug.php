<?php
// Direct SMTP test with full debug output
$host = 'sandbox.smtp.mailtrap.io';
$port = 2525;
$user = 'cbb7f036e954bd';
$pass = '208a3f057d1b26';
$to   = 'test@example.com'; // Mailtrap catches all emails

echo "<style>body{font-family:monospace;padding:2rem;background:#1e1e2e;color:#cdd6f4} .ok{color:#a6e3a1} .err{color:#f38ba8} .info{color:#89b4fa}</style>";
echo "<h2 style='color:#cba6f7'>SMTP Debug Test</h2>";

// Step 1: DNS check
echo "<p class='info'>Step 1: Resolving $host...</p>";
$ip = gethostbyname($host);
if ($ip === $host) {
    echo "<p class='err'>❌ DNS resolution FAILED — cannot resolve $host</p>";
    echo "<p class='err'>This means your network cannot reach Mailtrap. Check internet connection.</p>";
} else {
    echo "<p class='ok'>✅ DNS resolved: $host → $ip</p>";
}

// Step 2: TCP connection
echo "<p class='info'>Step 2: Connecting to $host:$port...</p>";
$errno = 0; $errstr = '';
$socket = @fsockopen($host, $port, $errno, $errstr, 10);
if (!$socket) {
    echo "<p class='err'>❌ TCP connection FAILED: $errstr (error $errno)</p>";
    echo "<p class='err'>Port $port may be blocked by firewall. Try port 587 or 465.</p>";
    
    // Try other ports
    foreach ([587, 465, 25] as $p) {
        $s2 = @fsockopen($host, $p, $e2, $es2, 5);
        if ($s2) {
            echo "<p class='ok'>✅ Port $p is OPEN — try using port $p instead</p>";
            fclose($s2);
        } else {
            echo "<p class='err'>❌ Port $p also blocked</p>";
        }
    }
    exit;
}

echo "<p class='ok'>✅ TCP connected!</p>";

// Step 3: Read greeting
$line = fgets($socket, 515);
echo "<p class='info'>Server: " . htmlspecialchars(trim($line)) . "</p>";
if (substr($line, 0, 3) !== '220') {
    echo "<p class='err'>❌ Unexpected greeting</p>";
    fclose($socket); exit;
}

// Step 4: EHLO
fputs($socket, "EHLO localhost\r\n");
$caps = '';
while ($l = fgets($socket, 515)) {
    $caps .= htmlspecialchars(trim($l)) . '<br>';
    if (substr($l, 3, 1) === ' ') break;
}
echo "<p class='ok'>✅ EHLO response:<br>$caps</p>";

// Step 5: AUTH
fputs($socket, "AUTH LOGIN\r\n");
$r = fgets($socket, 515);
echo "<p class='info'>AUTH: " . htmlspecialchars(trim($r)) . "</p>";

fputs($socket, base64_encode($user) . "\r\n");
$r = fgets($socket, 515);
echo "<p class='info'>Username: " . htmlspecialchars(trim($r)) . "</p>";

fputs($socket, base64_encode($pass) . "\r\n");
$r = fgets($socket, 515);
echo "<p class='info'>Password: " . htmlspecialchars(trim($r)) . "</p>";

if (substr($r, 0, 3) === '235') {
    echo "<p class='ok'>✅ Authentication SUCCESSFUL!</p>";
    
    // Step 6: Send test email
    fputs($socket, "MAIL FROM: <noreply@medix.com>\r\n");
    $r = fgets($socket, 515); echo "<p class='info'>MAIL FROM: " . htmlspecialchars(trim($r)) . "</p>";
    
    fputs($socket, "RCPT TO: <$to>\r\n");
    $r = fgets($socket, 515); echo "<p class='info'>RCPT TO: " . htmlspecialchars(trim($r)) . "</p>";
    
    fputs($socket, "DATA\r\n");
    $r = fgets($socket, 515); echo "<p class='info'>DATA: " . htmlspecialchars(trim($r)) . "</p>";
    
    $msg = "From: MEDIX <noreply@medix.com>\r\nTo: Test <$to>\r\nSubject: SMTP Test\r\nMIME-Version: 1.0\r\nContent-Type: text/plain\r\n\r\nThis is a test email from MEDIX SMTP debug.\r\n.\r\n";
    fputs($socket, $msg);
    $r = fgets($socket, 515); echo "<p class='info'>Send: " . htmlspecialchars(trim($r)) . "</p>";
    
    if (substr($r, 0, 3) === '250') {
        echo "<p class='ok' style='font-size:1.2rem'>✅ EMAIL SENT SUCCESSFULLY! Check Mailtrap inbox.</p>";
    } else {
        echo "<p class='err'>❌ Send failed</p>";
    }
} else {
    echo "<p class='err'>❌ Authentication FAILED: " . htmlspecialchars(trim($r)) . "</p>";
    echo "<p class='err'>Check username/password in api/mailer.php</p>";
}

fputs($socket, "QUIT\r\n");
fclose($socket);

echo "<br><a href='test_email.php' style='color:#89b4fa'>→ Go to Email Test Page</a>";
?>
