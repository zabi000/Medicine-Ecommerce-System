<?php
// One-time script to save Mailtrap credentials to DB
require_once('api/config.php');
if (!$conn) die("DB failed");

$conn->query("CREATE TABLE IF NOT EXISTS site_settings (`key` VARCHAR(100) PRIMARY KEY, `value` TEXT) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$settings = [
    'smtp_host'       => 'sandbox.smtp.mailtrap.io',
    'smtp_port'       => '2525',
    'smtp_user'       => 'cbb7f036e954bd',
    'smtp_pass'       => '208a3f057d1b26',
    'smtp_from_email' => 'noreply@medix.com',
    'smtp_from_name'  => 'MEDIX Pharmacy',
    'admin_email'     => 'admin@medix.com',
];

foreach ($settings as $k => $v) {
    $k = $conn->real_escape_string($k);
    $v = $conn->real_escape_string($v);
    $conn->query("INSERT INTO site_settings (`key`,`value`) VALUES ('$k','$v') ON DUPLICATE KEY UPDATE `value`='$v'");
}

echo "<div style='font-family:sans-serif;padding:2rem;background:#f0fdf4;border:2px solid #22c55e;border-radius:12px;max-width:500px;margin:2rem auto'>";
echo "<h3 style='color:#166534'>✅ Mailtrap credentials saved!</h3>";
echo "<p>Now test it: <a href='test_email.php'>Send Test Email</a></p>";
echo "</div>";
?>
