<?php
require_once('api/config.php');
echo "<h2 style='font-family:Arial;padding:1rem'>Order Names Debug</h2>";

// Show last 5 orders with all name fields
$r = $conn->query("SELECT id, user_id, customer_name, customer_email, customer_phone, status, created_at FROM orders ORDER BY id DESC LIMIT 5");
echo "<table border='1' style='font-family:Arial;margin:1rem;border-collapse:collapse;font-size:14px'>";
echo "<tr style='background:#f0f0f0'><th>ID</th><th>user_id</th><th>customer_name</th><th>customer_email</th><th>customer_phone</th><th>status</th></tr>";
while ($o = $r->fetch_assoc()) {
    echo "<tr>";
    echo "<td>{$o['id']}</td>";
    echo "<td>{$o['user_id']}</td>";
    echo "<td style='color:" . ($o['customer_name'] ? 'green' : 'red') . "'>" . ($o['customer_name'] ?: 'NULL/EMPTY') . "</td>";
    echo "<td>" . ($o['customer_email'] ?: 'NULL/EMPTY') . "</td>";
    echo "<td>" . ($o['customer_phone'] ?: 'NULL/EMPTY') . "</td>";
    echo "<td>{$o['status']}</td>";
    echo "</tr>";
}
echo "</table>";

// Show users table
echo "<h3 style='font-family:Arial;padding:1rem'>Users Table (last 5)</h3>";
$r2 = $conn->query("SELECT id, name, username, email FROM users ORDER BY id DESC LIMIT 5");
echo "<table border='1' style='font-family:Arial;margin:1rem;border-collapse:collapse;font-size:14px'>";
echo "<tr style='background:#f0f0f0'><th>ID</th><th>name</th><th>username</th><th>email</th></tr>";
while ($u = $r2->fetch_assoc()) {
    echo "<tr><td>{$u['id']}</td><td>{$u['name']}</td><td>{$u['username']}</td><td>{$u['email']}</td></tr>";
}
echo "</table>";
?>
