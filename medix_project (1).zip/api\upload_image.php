<?php
header('Content-Type: application/json');

session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    echo json_encode(['success' => false, 'error' => 'Unauthorized']);
    exit();
}

if (!isset($_FILES['image'])) {
    echo json_encode(['success' => false, 'error' => 'No file uploaded']);
    exit();
}

$file = $_FILES['image'];
$allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
$max_size = 5 * 1024 * 1024; // 5MB

if (!in_array($file['type'], $allowed_types)) {
    echo json_encode(['success' => false, 'error' => 'Only JPG, PNG, GIF, WEBP allowed']);
    exit();
}

if ($file['size'] > $max_size) {
    echo json_encode(['success' => false, 'error' => 'File too large. Max 5MB']);
    exit();
}

// Create uploads folder - use document root
$base = defined('APP_BASE') ? APP_BASE : '/ppp';
$upload_dir = $_SERVER['DOCUMENT_ROOT'] . $base . '/uploads/products/';
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0755, true);
}

if (!is_dir($upload_dir)) {
    // Fallback: relative from api/ folder
    $upload_dir = __DIR__ . '/../uploads/products/';
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }
}

$ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
$filename = 'product_' . time() . '_' . rand(1000, 9999) . '.' . $ext;
$filepath = $upload_dir . $filename;

if (move_uploaded_file($file['tmp_name'], $filepath)) {
    $url = 'uploads/products/' . $filename;
    echo json_encode(['success' => true, 'url' => $url, 'filename' => $filename]);
} else {
    echo json_encode(['success' => false, 'error' => 'Upload failed. Check folder permissions.']);
}
?>
