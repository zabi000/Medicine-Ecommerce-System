<?php
session_start();
// Add test item to cart
$_SESSION['cart'] = [1 => 2];
echo "<div style='font-family:Arial;padding:2rem;text-align:center;background:#f8f9fa;min-height:100vh'>";
echo "<div style='background:white;padding:2rem;border-radius:16px;max-width:400px;margin:2rem auto;box-shadow:0 4px 20px rgba(0,0,0,.1)'>";
echo "<h2>✅ Cart Ready!</h2>";
echo "<p class='text-muted'>Test item added to cart</p>";
echo "<a href='checkout.php' style='display:block;padding:15px;background:#B91C1C;color:white;text-decoration:none;border-radius:10px;font-size:1.1rem;font-weight:bold'>Go to Checkout →</a>";
echo "<br><a href='products.php' style='color:#B91C1C'>Or browse real products</a>";
echo "</div></div>";
?>
