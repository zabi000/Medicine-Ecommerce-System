<?php
require_once('api/config.php');

echo "<h2 style='font-family:Arial;padding:1rem'>Syncing Order Customers to Users Table</h2>";

// Check if customer_email column exists
$col_chk = $conn->query("SHOW COLUMNS FROM orders LIKE 'customer_email'");
if (!$col_chk || $col_chk->num_rows == 0) {
    die("<p style='color:red;font-family:Arial;padding:1rem'>customer_email column not found in orders table.</p>");
}

// Count before
$before = $conn->query("SELECT COUNT(*) as c FROM users")->fetch_assoc()['c'];

// Sync all order customers
$result = $conn->query("INSERT IGNORE INTO users (name, username, email, phone, password)
    SELECT customer_name, customer_email, customer_email, customer_phone, 'guest_password'
    FROM orders
    WHERE customer_email IS NOT NULL AND customer_email != ''
      AND customer_email NOT IN (SELECT email FROM users WHERE email IS NOT NULL)
    GROUP BY customer_email");

$after = $conn->query("SELECT COUNT(*) as c FROM users")->fetch_assoc()['c'];
$added = $after - $before;

echo "<p style='color:green;font-family:Arial;padding:.5rem 1rem'>✅ Synced! Added $added new customers.</p>";
echo "<p style='font-family:Arial;padding:.5rem 1rem'>Total customers now: <strong>$after</strong></p>";

// Show all customers
$customers = $conn->query("SELECT id, name, email, phone, created_at FROM users ORDER BY id DESC LIMIT 20");
echo "<table border='1' style='font-family:Arial;margin:1rem;border-collapse:collapse'>";
echo "<tr style='background:#f0f0f0'><th>ID</th><th>Name</th><th>Email</th><th>Phone</th></tr>";
while ($c = $customers->fetch_assoc()) {
    echo "<tr><td>{$c['id']}</td><td>{$c['name']}</td><td>{$c['email']}</td><td>{$c['phone']}</td></tr>";
}
echo "</table>";

echo "<a href='admin/customers.php' style='padding:10px 20px;background:#B91C1C;color:white;text-decoration:none;border-radius:8px;font-family:Arial;margin:1rem;display:inline-block'>View Customers Page</a>";
?>
