<?php
/**
 * Direct Import for Pakistan Medicines Dataset
 * Optimized for the specific column structure provided
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);
set_time_limit(300);

require_once('api/config.php');

// Sample data embedded (you can paste more rows here)
$medicines_data = <<<CSV
Drug Name,Manufacturer,Strength,Form,Indication,Side Effects,Available In,Age Restriction,Prescription Required,Price
Panadol,GSK,500mg,Tablet,Fever mild pain,Liver damage (high dose),All cities,None,No,35
Arinac Forte,Abott,400mg + 60mg,Tablet,Cold flu fever nasal congestion,Nausea dizziness dry mouth etc,All cities,12+,Yes,
Arinac,Abbott,200mg + 30mg,N/A,Cold flu nasal congestion,Drowsiness high BP,All cities,12+,Yes,65
OMC-D,Sami Pharma,20mg,Tablet,Acidity gastric issues,Headache diarrhea,All cities,12+,Yes,100
Paracetamol,Various,500mg,Tablet,Fever pain,Liver issues (overdose),All cities,None,No,30
Calpol,GSK,500mg,Tablet,Fever and pain in children,Rare skin rash,All cities,0+,No,
Brufen,Abbott,400mg,Tablet,Pain inflammation,Stomach upset,All cities,12+,No,70
Azomax,Pfizer,500mg,Tablet,Infections (respiratory skin),Diarrhea nausea,All cities,12+,Yes,500
Amoxil,GSK,500mg,Capsule,Bacterial infections,Nausea allergy,All cities,All ages,Yes,150
Disprol,Various,500mg,Tablet,Fever pain,Rash allergy,All cities,None,No,40
Augmentin,GSK,625mg,Tablet,Strong bacterial infections,Diarrhea nausea,All cities,12+,Yes,600
Flagyl,Pfizer,400mg,Tablet,Stomach & intestinal infections,Metallic taste nausea,All cities,12+,Yes,80
Rigix,AGP,10mg,N/A,Allergy sneezing,Drowsiness,All cities,6+,No,50
Tamsol D,Himont,0.4mg + 0.5mg,Tablet,Prostate enlargement,Dizziness low BP,All cities,18+,Yes,200
Gravinate,Platinum Pharma,50mg,Tablet,Nausea vomiting motion sickness,Drowsiness,All cities,6+,No,50
Panadol Extra,GSK,500mg + 65mg,N/A,Headache fatigue pain,Liver issues jitteriness,All cities,12+,No,70
Panadol Extend,GSK,665mg,N/A,Long-lasting pain relief,Liver damage (high dose),All cities,12+,No,100
Disprin,Various,300mg,N/A,Headache blood thinner,Stomach bleeding,All cities,16+,No,30
Risek,Getz Pharma,20mg,N/A,Acidity ulcers,Headache stomach pain,All cities,12+,Yes,100
ORS Sachets,Various,N/A,Oral Powder,Dehydration,None,All cities,All ages,No,
Ventolin,GSK,4mg,Inhaler,Asthma breathing issues,Tremors fast heartbeat,All cities,5+,Yes,
Ponstan,Pfizer,250mg,N/A,Cramps toothache,Nausea headache,All cities,12+,Yes,20
Nuberol Forte,Sami Pharma,450mg + 35mg,N/A,N/A,Drowsiness,All cities,18+,Yes,55
Hydryllin,Searle,N/A,,Cough congestion,Drowsiness,All cities,2+,No,65
Losec,AstraZeneca,20mg,N/A,GERD ulcers,Constipation headache,All cities,12+,Yes,45
Cetamol Cold,GSK,500mg + 30mg,Tablet,Cold fever body aches,Drowsiness dry mouth,All cities,12+,No,25
Cetirizine,AGP,10mg,Tablet,Allergy sneezing,Drowsiness dizziness,All cities,6+,No,35
Actifed,GSK,N/A,,Cold runny nose cough,Drowsiness dry mouth,All cities,2+,No,40
Piriton,GSK,N/A,Tablet,Allergies flu symptoms,Drowsiness,All cities,1+,No,60
Naproxen,Bosch,250mg,Tablet,Joint pain cramps,Nausea dizziness,All cities,12+,Yes,15
Celebrex,Pfizer,200mg,Capsule,Arthritis back pain,Stomach issues,All cities,18+,Yes,
Cefspan,Searle,400mg,Tablet,Throat ear sinus infections,Diarrhea rash,All cities,All ages,Yes,
Levoflox,Getz,500mg,Tablet,Urinary & respiratory infections,Dizziness nausea,All cities,16+,Yes,
Erythrocin,Bosch,250mg,Tablet,Skin & respiratory infections,Nausea cramps,All cities,All ages,Yes,50
Montiget,Getz Pharma,10mg,Tablet,Allergy asthma,Headache abdominal pain,All cities,6+,Yes,
Zyrtec,UCB,10mg,Tablet,Allergy runny nose,Drowsiness dry mouth,All cities,6+,No,
Telfast,Sanofi,120mg,Tablet,Seasonal allergies,Dry mouth headache,All cities,12+,No,
Histac,AGP,10mg,Tablet,Allergy skin rash,Drowsiness,All cities,6+,No,8
Coughnil,Sami Pharma,N/A,,Cough throat irritation,Drowsiness,All cities,2+,No,35
Broxol,Searle,N/A,,Cough with mucus,Stomach upset,All cities,2+,No,20
Benylin,Janssen,N/A,,Flu dry cough,Drowsiness dizziness,All cities,2+,No,55
Claritek,Getz Pharma,500mg,Tablet,Throat lung infections,Nausea diarrhea,All cities,All ages,Yes,65
Zentel,GSK,400mg,Tablet,Worm infestation,Abdominal pain nausea,All cities,2+,No,60
Betnovate,GSK,N/A,Cream,Skin allergies eczema,Burning thinning skin,All cities,All ages,Yes,
Daktarin,Janssen,N/A,Cream,Fungal infections,Irritation redness,All cities,All ages,Yes,
Ciproxin,Bayer,500mg,Tablet,Urinary and GI infections,Nausea dizziness,All cities,18+,Yes,
Rivotril,Roche,0.5mg,Tablet,Anxiety seizures,Drowsiness dependency risk,All cities,18+,Yes,
Neurobion,Merck,N/A,Injection/Vitamin,B12 & nerve pain,Injection site pain,All cities,12+,No,
Entamizole,Searle,400mg + 500mg,Tablet,Amoebiasis GI infection,Metallic taste nausea,All cities,All ages,Yes,
Lomotil,Jonas Pharma,2.5mg,Tablet,Diarrhea,Dry mouth constipation,All cities,16+,Yes,
Zantac,GSK,150mg,N/A,Acid reflux ulcers,Constipation headache,All cities,12+,Yes,
Imodium,Janssen,2mg,Tablet,Diarrhea,Drowsiness dry mouth,All cities,12+,No,
Spasfon,PharmEvo,80mg,Tablet,Abdominal cramps,Nausea dizziness,All cities,12+,Yes,
Clarinase Repetabs,MSD,5mg + 120mg,Tablet,Cold sinus,Insomnia dry mouth,All cities,12+,Yes,90
Histazine,Hilton Pharma,10mg,Tablet,Allergy flu,Drowsiness,All cities,2+,No,80
Myteka,Getz Pharma,10mg,Tablet,Asthma allergy,Headache behavior change,All cities,6+,Yes,85
Caviplex,ATCO Pharma,N/A,Tablet,Multivitamin supplement,Nausea (rare),All cities,All ages,No,100
Volini Gel,Reckitt,1% Diclofenac,Gel,Muscle pain sprain,Skin irritation,All cities,12+,No,90
Metrogyl Gel,Unexo,2% Metronidazole,Gel,Acne skin infection,Burning sensation,All cities,12+,Yes,70
Silverex Gel,Maxitech Pharma,1% Silver Sulfadiazine,Gel,Burns wounds,Skin dryness,All cities,All ages,Yes,110
Dologel,Macleods,2% Lidocaine + 0.1% Benzalkonium + 1% Choline Salicylate,Gel,Mouth ulcers oral pain,Temporary numbness,All cities,5+,No,95
Fastum Gel,Menarini,2.5% Ketoprofen,Gel,Joint/muscle pain,Redness itching,All cities,18+,No,90
Moov Gel,Reckitt Benckiser,1.16% Diclofenac,N/A,Back pain sprain,Warmth rash,All cities,12+,No,150
Iodex Ultra Gel,GSK,5% Iodine Complex,Gel,Joint/muscle relief,Burning redness,All cities,12+,No,75
Dicloran Gel,Sami Pharma,1% Diclofenac,Gel,Arthritis pain,Peeling redness,All cities,12+,Yes,100
Burnol Gel,Dr. Morepen,0.2% Nitrofurazone + 0.5% Chlorhexidine,Gel,Minor burns,Stinging yellow stain,All cities,All ages,No,95
Neosporin Ointment,GSK,5000 IU Bacitracin + 3.5 mg Neomycin,Ointment,Infected cuts/allergy,Allergy itching,All cities,All ages,No,125
Refresh Eye Gel,Allergan,0.3% Carboxymethylcellulose,N/A,Eye dryness strain,Burning blurred vision,All cities,5+,No,180
Zytee Gel,Shield,8% Choline Salicylate + 2% Lidocaine,Gel,Mouth ulcers gum pain,Burning numbness,All cities,5+,No,170
Polyfax Skin Ointment,GlaxoSmithKline,500 IU Polymyxin B + 5 mg Bacitracin,Ointment (Blue),Bacterial skin infections,Itching redness,All cities,All ages,Yes,160
Polyfax Eye Ointment,GlaxoSmithKline,500 IU Polymyxin B + 5 mg Bacitracin,Ophthalmic Ointment,Bacterial eye infections,Temporary blurred vision,All cities,All ages,Yes,120
Bactroban,Mupri Pharma,2% Mupirocin,Gel,Bacterial skin infections,Itching burning,All cities,All ages,Yes,110
Soframycin,Franco-Indian Pharma,1% Framycetin,Gel,Wound healing cuts,Allergy redness,All cities,All ages,No,190
Dermovate,Novo Nordisk,0.05% Clobetasol Propionate,Gel,Severe eczema psoriasis,Skin thinning redness,All cities,12+,Yes,60
Lamisil Gel,NOVARTIS,1% Terbinafine,Gel,Fungal infections,Peeling dryness,All cities,12+,Yes,100
Canesten,Bayer,1% Clotrimazole,Gel,Vaginal/skin fungal infections,Irritation,All cities,12+,No,130
Finac Gel,Hilton Pharma,0.1% Tretinoin,N/A,Male pattern hair loss,Itching dry scalp,All cities,18+,Yes,250
Zindaclin Gel,GSK,1% Clindamycin,Gel,Acne vulgaris,Dry skin peeling,All cities,12+,Yes,180
Retin-A Gel,Janssen,0.025% Tretinoin,Gel,Acne anti-aging,Redness peeling,All cities,12+,Yes,170
Emla Gel,AstraZeneca,2.5% Lidocaine + 2.5% Prilocaine,N/A,Skin numbing for procedures,Burning numbness,All cities,12+,Yes,160
Voveran Emulgel,Novartis,1.16% Diclofenac Diethylamine,Gel,Joint/muscle inflammation,Skin irritation,All cities,12+,No,120
Terbinafine Gel,Sami Pharma,1% Terbinafine,Gel,Skin fungal infection,Rash dryness,All cities,12+,Yes,110
Aczone Gel,Ali Gohar Pharma,5% Dapsone,Gel,Acne vulgaris,Itching burning,All cities,12+,Yes,190
Aloe Vera Gel,Pure Leaf,N/A,Gel,Skin moisturizing sunburn,No major side effects,All cities,All ages,No,60
Candid-B Cream,Glenmark,1% Clotrimazole + 0.05% Beclomethasone,Gel (Clotrimazole + Beclomethasone),Fungal infections & inflammation,Skin thinning irritation,All cities,12+,Yes,100
CSV;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Import Pakistan Medicines</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 2rem;
        }
        .import-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            max-width: 900px;
            margin: 0 auto;
        }
        .log-item {
            padding: 0.5rem;
            margin: 0.25rem 0;
            border-radius: 5px;
            font-family: monospace;
            font-size: 0.85rem;
        }
        .log-success { background: #d4edda; color: #155724; }
        .log-error { background: #f8d7da; color: #721c24; }
        .log-info { background: #d1ecf1; color: #0c5460; }
        .log-warning { background: #fff3cd; color: #856404; }
    </style>
</head>
<body>
    <div class="import-card">
        <h2 class="text-center mb-4">
            <i class="bi bi-capsule"></i> Import Pakistan Medicines Dataset
        </h2>

        <?php
        if (!$conn) {
            echo '<div class="alert alert-danger">Database connection failed. Check api/config.php</div>';
            exit;
        }

        echo '<div class="alert alert-info"><strong>Starting import...</strong></div>';
        echo '<div id="log-container">';

        $lines = explode("\n", trim($medicines_data));
        $headers = str_getcsv(array_shift($lines)); // Remove header row

        $imported = 0;
        $skipped = 0;
        $errors = 0;

        foreach ($lines as $line_num => $line) {
            if (empty(trim($line))) continue;

            $data = str_getcsv($line);
            
            try {
                $drug_name = trim($data[0] ?? '');
                $manufacturer = trim($data[1] ?? '');
                $strength = trim($data[2] ?? '');
                $form = trim($data[3] ?? '');
                $indication = trim($data[4] ?? '');
                $side_effects = trim($data[5] ?? '');
                $age_restriction = trim($data[7] ?? '');
                $prescription_required = trim($data[8] ?? '');
                $price_raw = trim($data[9] ?? '');

                // Skip if no drug name
                if (empty($drug_name)) {
                    $skipped++;
                    echo '<div class="log-item log-warning">Row ' . ($line_num + 2) . ': Skipped (no name)</div>';
                    continue;
                }

                // Build product name
                $product_name = $drug_name;
                if ($strength && $strength != 'N/A') {
                    $product_name .= ' ' . $strength;
                }
                if ($form && $form != 'N/A') {
                    $product_name .= ' (' . $form . ')';
                }

                // Build description
                $desc_parts = [];
                if ($manufacturer) $desc_parts[] = "Manufacturer: $manufacturer";
                if ($indication) $desc_parts[] = "Uses: $indication";
                if ($side_effects) $desc_parts[] = "Side Effects: $side_effects";
                if ($age_restriction && $age_restriction != 'None') $desc_parts[] = "Age: $age_restriction";
                if ($prescription_required == 'Yes') $desc_parts[] = "⚠️ Prescription Required";
                
                $description = implode(' | ', $desc_parts);
                if (empty($description)) {
                    $description = "Quality medicine from Pakistan";
                }

                // Handle price
                $price = floatval($price_raw);
                if ($price <= 0 || empty($price_raw) || $price_raw == 'NaN') {
                    $price = rand(50, 500); // Generate random price
                }

                // Determine category
                $category = 'prescription';
                $name_lower = strtolower($product_name . ' ' . $indication);
                
                if (strpos($name_lower, 'vitamin') !== false || strpos($name_lower, 'supplement') !== false || strpos($name_lower, 'multivitamin') !== false) {
                    $category = 'vitamins';
                } elseif (strpos($name_lower, 'gel') !== false || strpos($name_lower, 'cream') !== false || strpos($name_lower, 'ointment') !== false || strpos($name_lower, 'skin') !== false) {
                    $category = 'skincare';
                } elseif (strpos($name_lower, 'bandage') !== false || strpos($name_lower, 'gauze') !== false || strpos($name_lower, 'burn') !== false) {
                    $category = 'firstaid';
                } elseif (strpos($form, 'Inhaler') !== false || strpos($form, 'Injection') !== false) {
                    $category = 'devices';
                }

                // Check for duplicates
                $check_stmt = $conn->prepare("SELECT id FROM products WHERE name = ? LIMIT 1");
                $check_stmt->bind_param("s", $product_name);
                $check_stmt->execute();
                $result = $check_stmt->get_result();
                
                if ($result->num_rows > 0) {
                    $skipped++;
                    echo '<div class="log-item log-info">Row ' . ($line_num + 2) . ': Skipped (duplicate) - ' . htmlspecialchars($product_name) . '</div>';
                    continue;
                }

                // Random stock
                $stock = rand(30, 200);

                // Insert product
                $stmt = $conn->prepare("INSERT INTO products (name, description, price, category, stock_quantity) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param("ssdsi", $product_name, $description, $price, $category, $stock);
                
                if ($stmt->execute()) {
                    $imported++;
                    echo '<div class="log-item log-success">✓ ' . htmlspecialchars($product_name) . ' - PKR ' . number_format($price, 2) . ' (' . $category . ')</div>';
                } else {
                    $errors++;
                    echo '<div class="log-item log-error">✗ Error: ' . $conn->error . '</div>';
                }

                if ($imported % 10 == 0) {
                    flush();
                    ob_flush();
                }

            } catch (Exception $e) {
                $errors++;
                echo '<div class="log-item log-error">✗ Exception: ' . $e->getMessage() . '</div>';
            }
        }

        echo '</div>';

        // Summary
        echo '<div class="alert alert-success mt-4">';
        echo '<h5><i class="bi bi-check-circle"></i> Import Complete!</h5>';
        echo '<ul class="mb-0">';
        echo '<li><strong>Successfully Imported:</strong> ' . $imported . ' products</li>';
        echo '<li><strong>Skipped:</strong> ' . $skipped . ' (duplicates/invalid)</li>';
        echo '<li><strong>Errors:</strong> ' . $errors . '</li>';
        echo '</ul>';
        echo '</div>';

        echo '<div class="text-center mt-4">';
        echo '<a href="admin/products.php" class="btn btn-danger btn-lg"><i class="bi bi-box-seam me-2"></i>View Products</a>';
        echo '<a href="products.php" class="btn btn-primary btn-lg ms-2"><i class="bi bi-shop me-2"></i>View Store</a>';
        echo '</div>';
        ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
