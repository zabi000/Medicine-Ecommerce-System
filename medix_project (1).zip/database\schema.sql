-- Create database
CREATE DATABASE IF NOT EXISTS medicare_db;
USE medicare_db;

-- Users table
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20) NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Products table
CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(200) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    category VARCHAR(50) NOT NULL,
    icon VARCHAR(10) DEFAULT '💊',
    image_url VARCHAR(500) DEFAULT NULL,
    stock INT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Orders table
CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    total_amount DECIMAL(10, 2) NOT NULL,
    status VARCHAR(50) DEFAULT 'pending',
    shipping_address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Order items table
CREATE TABLE IF NOT EXISTS order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT NOT NULL,
    quantity INT NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Insert sample products
INSERT INTO products (name, description, price, category, icon, stock) VALUES
('Paracetamol 500mg', 'Pain relief and fever reducer', 5.99, 'prescription', '💊', 100),
('Ibuprofen 400mg', 'Anti-inflammatory pain reliever', 7.99, 'prescription', '💊', 150),
('Vitamin C 1000mg', 'Immune system support', 12.99, 'vitamins', '💉', 200),
('First Aid Kit', 'Complete emergency medical kit', 29.99, 'firstaid', '🩹', 50),
('Digital Thermometer', 'Fast and accurate temperature reading', 15.99, 'devices', '🌡️', 75),
('Vitamin D3 2000IU', 'Bone health and immunity', 14.99, 'vitamins', '💉', 180),
('Bandages Pack', 'Assorted sterile bandages', 8.99, 'firstaid', '🩹', 120),
('Blood Pressure Monitor', 'Digital BP measurement device', 45.99, 'devices', '🌡️', 40),
('Aspirin 100mg', 'Blood thinner and pain relief', 6.99, 'prescription', '💊', 200),
('Multivitamin Complex', 'Complete daily nutrition', 19.99, 'vitamins', '💉', 150),
('Hand Sanitizer 500ml', 'Antibacterial hand gel', 4.99, 'personal', '🧴', 300),
('Face Masks (50 Pack)', 'Disposable surgical masks', 12.99, 'personal', '😷', 250),
('Omega-3 Fish Oil', 'Heart and brain health', 24.99, 'vitamins', '💉', 100),
('Glucose Meter Kit', 'Blood sugar monitoring system', 39.99, 'devices', '🩺', 60),
('Antiseptic Cream', 'Wound care and infection prevention', 7.99, 'firstaid', '🩹', 180),
('Calcium + Vitamin D', 'Bone strength supplement', 16.99, 'vitamins', '💉', 140),
('Pulse Oximeter', 'Oxygen saturation monitor', 29.99, 'devices', '🩺', 80),
('Cough Syrup', 'Relief from dry and wet cough', 8.99, 'prescription', '💊', 120),
('Probiotic Capsules', 'Digestive health support', 22.99, 'vitamins', '💉', 110),
('Infrared Thermometer', 'Non-contact temperature scanner', 34.99, 'devices', '🌡️', 55);

-- Categories table
CREATE TABLE IF NOT EXISTS categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default categories
INSERT INTO categories (name, description) VALUES
('prescription', 'Doctor prescribed medicines'),
('vitamins', 'Health supplements and vitamins'),
('firstaid', 'Emergency medical supplies'),
('devices', 'Medical devices and equipment'),
('personal', 'Personal care and hygiene'),
('baby', 'Baby care products');

-- Update products table to add username column for compatibility
ALTER TABLE users ADD COLUMN IF NOT EXISTS username VARCHAR(50) AFTER id;
UPDATE users SET username = email WHERE username IS NULL OR username = '';

-- Update products table to add stock_quantity column for compatibility
ALTER TABLE products ADD COLUMN IF NOT EXISTS stock_quantity INT DEFAULT 0 AFTER stock;
UPDATE products SET stock_quantity = stock WHERE stock_quantity = 0;

-- Add sample orders for testing
INSERT INTO orders (user_id, total_amount, status, shipping_address, created_at) VALUES
(1, 45.97, 'delivered', '123 Main St, City, State 12345', DATE_SUB(NOW(), INTERVAL 5 DAY)),
(1, 29.99, 'processing', '123 Main St, City, State 12345', DATE_SUB(NOW(), INTERVAL 2 DAY)),
(1, 15.99, 'pending', '123 Main St, City, State 12345', NOW());

-- Add sample order items
INSERT INTO order_items (order_id, product_id, quantity, price) VALUES
(1, 1, 2, 5.99),
(1, 4, 1, 29.99),
(2, 5, 1, 15.99),
(3, 3, 1, 12.99);
