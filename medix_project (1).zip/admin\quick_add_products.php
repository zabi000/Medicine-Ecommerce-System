﻿<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
set_time_limit(300);

echo "<!DOCTYPE html><html><head><title>Add 1000 Products</title>";
echo "<style>body{font-family:Arial;padding:20px;max-width:800px;margin:0 auto;background:#f5f5f5;}";
echo ".box{background:white;padding:20px;border-radius:10px;margin:20px 0;box-shadow:0 2px 10px rgba(0,0,0,0.1);}";
echo ".success{background:#D1FAE5;border:2px solid #10B981;color:#065F46;}";
echo ".error{background:#FEE2E2;border:2px solid #EF4444;color:#991B1B;}";
echo ".btn{padding:15px 30px;background:#B91C1C;color:white;text-decoration:none;border-radius:8px;display:inline-block;margin:10px 5px;}";
echo "</style></head><body>";

echo "<h1>ðŸ¥ Add 1000 Medicine Products</h1>";

// Step 1: Check database connection
echo "<div class='box'>";
echo "<h3>Step 1: Checking Database Connection...</h3>";

$conn = new mysqli('localhost', 'root', '', 'medicare_db');

if ($conn->connect_error) {
    echo "<div class='box error'>";
    echo "<h3>âŒ Database Connection Failed!</h3>";
    echo "<p>Error: " . $conn->connect_error . "</p>";
    echo "<p><strong>Solution:</strong></p>";
    echo "<ol>";
    echo "<li>Make sure XAMPP MySQL is running</li>";
    echo "<li>Import database first: <a href='setup.php'>Go to Setup Page</a></li>";
    echo "</ol>";
    echo "</div></body></html>";
    exit();
}

echo "<p>âœ… Database connected successfully!</p>";
echo "</div>";

// Step 2: Check if products table exists
echo "<div class='box'>";
echo "<h3>Step 2: Checking Products Table...</h3>";

$result = $conn->query("SHOW TABLES LIKE 'products'");
if ($result->num_rows == 0) {
    echo "<div class='box error'>";
    echo "<h3>âŒ Products table not found!</h3>";
    echo "<p><strong>You need to import the database first.</strong></p>";
    echo "<p><a href='setup.php' class='btn'>Go to Setup Page</a></p>";
    echo "</div></body></html>";
    exit();
}

echo "<p>âœ… Products table exists!</p>";
echo "</div>";

// Step 3: Generate and insert products
echo "<div class='box'>";
echo "<h3>Step 3: Adding 1000 Products...</h3>";
echo "<p>Please wait, this may take 1-2 minutes...</p>";
flush();

$medicines = [
    'Panadol', 'Disprin', 'Brufen', 'Ponstan', 'Calpol', 'Augmentin', 'Zithromax', 'Ciproxin',
    'Flagyl', 'Cefspan', 'Glucophage', 'Diamicron', 'Amaryl', 'Januvia', 'Concor', 'Norvasc',
    'Diovan', 'Lasix', 'Centrum', 'Neurobion', 'Ossopan', 'Fefol', 'Evion', 'Becosules',
    'Calpol', 'Nurofen', 'Voltaren', 'Celebrex', 'Arcoxia', 'Naprosyn', 'Indocin', 'Feldene'
];

$types = ['Tab', 'Cap', 'Syp', 'Inj', 'Susp', 'Drops', 'Cream', 'Ointment'];
$dosages = ['50mg', '100mg', '200mg', '250mg', '500mg', '1000mg', '5mg', '10mg', '20mg', '40mg'];
$categories = ['prescription', 'vitamins', 'firstaid', 'devices', 'personal'];
$icons = ['ðŸ’Š', 'ðŸ’‰', 'ðŸ©¹', 'ðŸŒ¡ï¸', 'ðŸ§´'];

$inserted = 0;
$errors = 0;

for ($i = 1; $i <= 1000; $i++) {
    $type = $types[array_rand($types)];
    $medicine = $medicines[array_rand($medicines)];
    $dosage = $dosages[array_rand($dosages)];
    $category = $categories[array_rand($categories)];
    $icon = $icons[array_rand($icons)];
    
    $name = "$type $medicine $dosage";
    $description = "High quality $medicine medication. Manufactured under GMP standards. Effective and safe for use.";
    $price = rand(50, 5000); // PKR
    $stock = rand(20, 300);
    
    $stmt = $conn->prepare("INSERT INTO products (name, description, price, category, stock_quantity, icon) VALUES (?, ?, ?, ?, ?, ?)");
    
    if ($stmt) {
        $stmt->bind_param("ssdsis", $name, $description, $price, $category, $stock, $icon);
        
        if ($stmt->execute()) {
            $inserted++;
        } else {
            $errors++;
        }
        $stmt->close();
    } else {
        $errors++;
    }
    
    if ($i % 100 == 0) {
        echo "<p>âœ“ Inserted $i products...</p>";
        flush();
    }
}

echo "</div>";

// Step 4: Show results
echo "<div class='box success'>";
echo "<h2>âœ… Complete!</h2>";
echo "<p><strong>Successfully added:</strong> $inserted products</p>";
echo "<p><strong>Errors:</strong> $errors</p>";
echo "<p><strong>Currency:</strong> PKR (Pakistani Rupees)</p>";
echo "<p><strong>Price Range:</strong> PKR 50 - PKR 5000</p>";
echo "<p><strong>Stock Range:</strong> 20 - 300 units</p>";
echo "</div>";

echo "<div class='box'>";
echo "<h3>What's Next?</h3>";
echo "<a href='products.php' class='btn'>ðŸ“¦ View in Admin Panel</a>";
echo "<a href='../products.php' class='btn' style='background:#10B981;'>ðŸ›’ View on Website</a>";
echo "<a href='setup.php' class='btn' style='background:#6B7280;'>âš™ï¸ Back to Setup</a>";
echo "</div>";

$conn->close();
echo "</body></html>";
?>

