<?php
/**
 * Add Skincare and Vitamin Products
 * Run this file once to add new products to the database
 */

require_once('api/config.php');

if (!$conn) {
    die("Database connection failed!");
}

echo "<!DOCTYPE html>
<html>
<head>
    <title>Add Skincare & Vitamins - MEDIX</title>
    <style>
        body { font-family: Arial, sans-serif; max-width: 800px; margin: 50px auto; padding: 20px; background: #f5f5f5; }
        .container { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h1 { color: #B91C1C; }
        .success { background: #D1FAE5; color: #065F46; padding: 15px; border-radius: 8px; margin: 10px 0; }
        .error { background: #FEE2E2; color: #991B1B; padding: 15px; border-radius: 8px; margin: 10px 0; }
        .info { background: #DBEAFE; color: #1E40AF; padding: 15px; border-radius: 8px; margin: 10px 0; }
        .btn { display: inline-block; background: #B91C1C; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px; margin-top: 20px; }
        .btn:hover { background: #991B1B; }
        .product-list { margin-top: 20px; }
        .product-item { padding: 10px; border-bottom: 1px solid #eee; }
    </style>
</head>
<body>
    <div class='container'>
        <h1>🛍️ Add Skincare & Vitamin Products</h1>";

// Read SQL file
$sql_file = 'database/add_skincare_vitamins.sql';
if (!file_exists($sql_file)) {
    echo "<div class='error'>❌ SQL file not found: $sql_file</div>";
    echo "<p>Please make sure the file exists in the database folder.</p>";
    echo "</div></body></html>";
    exit;
}

$sql = file_get_contents($sql_file);

// Split into individual queries
$queries = array_filter(array_map('trim', explode(';', $sql)));

$success_count = 0;
$error_count = 0;
$errors = [];

echo "<div class='info'>📦 Processing " . count($queries) . " SQL queries...</div>";

foreach ($queries as $query) {
    if (empty($query) || strpos($query, '--') === 0) {
        continue;
    }
    
    if ($conn->query($query)) {
        $success_count++;
    } else {
        $error_count++;
        $errors[] = $conn->error;
    }
}

echo "<div class='success'>✅ Successfully executed $success_count queries</div>";

if ($error_count > 0) {
    echo "<div class='error'>❌ Failed queries: $error_count</div>";
    foreach ($errors as $error) {
        echo "<div class='error'>Error: $error</div>";
    }
}

// Show added products
echo "<h2>📋 Product Summary</h2>";

// Count products by category
$skincare_count = $conn->query("SELECT COUNT(*) as count FROM products WHERE category = 'skincare'")->fetch_assoc()['count'];
$vitamins_count = $conn->query("SELECT COUNT(*) as count FROM products WHERE category = 'vitamins'")->fetch_assoc()['count'];
$total_count = $conn->query("SELECT COUNT(*) as count FROM products")->fetch_assoc()['count'];

echo "<div class='info'>";
echo "<strong>Total Products:</strong> $total_count<br>";
echo "<strong>Skincare Products:</strong> $skincare_count<br>";
echo "<strong>Vitamin Products:</strong> $vitamins_count";
echo "</div>";

// Show recent skincare products
echo "<h3>🧴 Recent Skincare Products</h3>";
echo "<div class='product-list'>";
$result = $conn->query("SELECT name, price, stock FROM products WHERE category = 'skincare' ORDER BY id DESC LIMIT 10");
while ($row = $result->fetch_assoc()) {
    echo "<div class='product-item'>";
    echo "<strong>{$row['name']}</strong> - Rs. " . number_format($row['price'], 2) . " (Stock: {$row['stock']})";
    echo "</div>";
}
echo "</div>";

// Show recent vitamin products
echo "<h3>💊 Recent Vitamin Products</h3>";
echo "<div class='product-list'>";
$result = $conn->query("SELECT name, price, stock FROM products WHERE category = 'vitamins' ORDER BY id DESC LIMIT 10");
while ($row = $result->fetch_assoc()) {
    echo "<div class='product-item'>";
    echo "<strong>{$row['name']}</strong> - Rs. " . number_format($row['price'], 2) . " (Stock: {$row['stock']})";
    echo "</div>";
}
echo "</div>";

echo "<div style='margin-top: 30px; text-align: center;'>";
echo "<a href='products.php' class='btn'>🛒 View All Products</a> ";
echo "<a href='index.html' class='btn'>🏠 Go to Homepage</a>";
echo "</div>";

echo "</div></body></html>";

$conn->close();
?>
