<?php
header('Content-Type: application/json');
session_start();
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit;
}

$email    = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';

if (!$email || !$password) {
    echo json_encode(['success' => false, 'message' => 'Email and password are required.']);
    exit;
}

if (!$conn) {
    echo json_encode(['success' => false, 'message' => 'Database connection failed.']);
    exit;
}

$stmt = $conn->prepare("SELECT id, name, username, email, password FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    echo json_encode(['success' => false, 'message' => 'No account found with this email.']);
    exit;
}

$user = $result->fetch_assoc();
$display_name = $user['name'] ?: $user['username'] ?: $user['email'];

if (password_verify($password, $user['password'])) {
    $_SESSION['user_id']    = $user['id'];
    $_SESSION['user_name']  = $display_name;
    $_SESSION['user_email'] = $user['email'];
    echo json_encode([
        'success' => true,
        'message' => 'Login successful!',
        'user'    => ['id' => $user['id'], 'name' => $display_name, 'email' => $user['email']]
    ]);
} else {
    echo json_encode(['success' => false, 'message' => 'Incorrect password. Please try again.']);
}

$stmt->close();
?>
