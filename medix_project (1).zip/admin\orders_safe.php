﻿<?php
session_start();

// Simple authentication check
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

// Database connection
require_once('../api/config.php');

// Check if new columns exist
$columns_check = $conn->query("SHOW COLUMNS FROM orders LIKE 'customer_name'");
$has_new_columns = ($columns_check && $columns_check->num_rows > 0);

// Handle Update Order Status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $order_id = intval($_POST['order_id']);
    $status = $_POST['status'];
    
    $valid_statuses = ['pending', 'processing', 'delivered', 'cancelled'];
    if (in_array($status, $valid_statuses)) {
        $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
        $stmt->bind_param("si", $status, $order_id);
        
        if ($stmt->execute()) {
            $success_message = "Order status updated successfully!";
        } else {
            $error_message = "Failed to update order status.";
        }
        $stmt->close();
    }
}

// Handle Confirm Payment
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['confirm_payment'])) {
    $order_id = intval($_POST['order_id']);
    
    $stmt = $conn->prepare("UPDATE orders SET status = 'processing' WHERE id = ?");
    $stmt->bind_param("i", $order_id);
    
    if ($stmt->execute()) {
        $success_message = "Payment confirmed! Order status updated.";
    } else {
        $error_message = "Failed to confirm payment.";
    }
    $stmt->close();
}

// Fetch orders based on available columns
if ($has_new_columns) {
    $result = $conn->query("SELECT o.*, 
        COALESCE(o.customer_name, u.name) as display_name,
        COALESCE(o.customer_email, u.email) as display_email
        FROM orders o 
        LEFT JOIN users u ON o.user_id = u.id 
        ORDER BY o.created_at DESC");
} else {
    $result = $conn->query("SELECT o.*, u.name as display_name, u.email as display_email 
        FROM orders o 
        LEFT JOIN users u ON o.user_id = u.id 
        ORDER BY o.created_at DESC");
}

if (!$result) {
    $error_message = "Error fetching orders: " . $conn->error;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Orders - MEDIX Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body { background: #f8f9fa; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .container { max-width: 1400px; padding: 2rem; }
        .page-header { background: white; padding: 2rem; border-radius: 12px; margin-bottom: 2rem; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .orders-table { background: white; border-radius: 12px; padding: 2rem; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .table { margin-bottom: 0; }
        .badge { padding: 0.5rem 0.75rem; font-size: 0.85rem; }
        .btn-sm { padding: 0.4rem 0.8rem; font-size: 0.85rem; }
    </style>
</head>
<body>
    <div class="container">
        <div class="page-header">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h2><i class="bi bi-cart-check me-2"></i>Orders Management</h2>
                    <p class="text-muted mb-0">View and manage customer orders</p>
                </div>
                <div>
                    <a href="index.php" class="btn btn-outline-secondary">
                        <i class="bi bi-arrow-left me-1"></i>Back to Dashboard
                    </a>
                </div>
            </div>
        </div>

        <?php if (isset($success_message)): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="bi bi-check-circle me-2"></i><?= $success_message ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger alert-dismissible fade show">
                <i class="bi bi-exclamation-triangle me-2"></i><?= $error_message ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if (!$has_new_columns): ?>
            <div class="alert alert-warning">
                <i class="bi bi-info-circle me-2"></i>
                <strong>Database Update Available:</strong> 
                <a href="../add_customer_info_to_orders.php" class="alert-link">Click here to add customer information columns</a>
            </div>
        <?php endif; ?>

        <div class="orders-table">
            <h4 class="mb-4">All Orders</h4>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead class="table-light">
                        <tr>
                            <th>Order ID</th>
                            <th>Customer</th>
                            <th>Email</th>
                            <th>Total</th>
                            <th>Status</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($result && $result->num_rows > 0): ?>
                            <?php while ($order = $result->fetch_assoc()): ?>
                            <tr>
                                <td><strong>#<?= $order['id'] ?></strong></td>
                                <td><?= htmlspecialchars($order['display_name'] ?? 'Guest') ?></td>
                                <td><?= htmlspecialchars($order['display_email'] ?? 'N/A') ?></td>
                                <td><strong>PKR <?= number_format($order['total_amount'], 2) ?></strong></td>
                                <td>
                                    <?php
                                    $badge_class = [
                                        'pending' => 'warning',
                                        'processing' => 'info',
                                        'delivered' => 'success',
                                        'cancelled' => 'danger'
                                    ];
                                    $class = $badge_class[$order['status']] ?? 'secondary';
                                    ?>
                                    <span class="badge bg-<?= $class ?>"><?= ucfirst($order['status']) ?></span>
                                </td>
                                <td><?= date('M d, Y', strtotime($order['created_at'])) ?></td>
                                <td>
                                    <div class="btn-group btn-group-sm">
                                        <button class="btn btn-outline-primary" data-bs-toggle="modal" data-bs-target="#viewModal<?= $order['id'] ?>">
                                            <i class="bi bi-eye"></i> View
                                        </button>
                                        <?php if ($order['status'] == 'pending'): ?>
                                            <form method="POST" style="display: inline;">
                                                <input type="hidden" name="order_id" value="<?= $order['id'] ?>">
                                                <input type="hidden" name="confirm_payment" value="1">
                                                <button type="submit" class="btn btn-success btn-sm">
                                                    <i class="bi bi-check"></i> Confirm
                                                </button>
                                            </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>

                            <!-- View Modal -->
                            <div class="modal fade" id="viewModal<?= $order['id'] ?>" tabindex="-1">
                                <div class="modal-dialog modal-lg">
                                    <div class="modal-content">
                                        <div class="modal-header bg-primary text-white">
                                            <h5 class="modal-title">Order #<?= $order['id'] ?> Details</h5>
                                            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <h6>Order Information</h6>
                                                    <p><strong>Order ID:</strong> #<?= $order['id'] ?></p>
                                                    <p><strong>Date:</strong> <?= date('F d, Y h:i A', strtotime($order['created_at'])) ?></p>
                                                    <p><strong>Status:</strong> <span class="badge bg-<?= $class ?>"><?= ucfirst($order['status']) ?></span></p>
                                                </div>
                                                <div class="col-md-6">
                                                    <h6>Customer Information</h6>
                                                    <p><strong>Name:</strong> <?= htmlspecialchars($order['display_name'] ?? 'Guest') ?></p>
                                                    <p><strong>Email:</strong> <?= htmlspecialchars($order['display_email'] ?? 'N/A') ?></p>
                                                    <p><strong>Address:</strong> <?= htmlspecialchars($order['shipping_address'] ?? 'N/A') ?></p>
                                                </div>
                                            </div>
                                            <hr>
                                            <h6>Order Items</h6>
                                            <?php
                                            $items = $conn->query("SELECT oi.*, p.name FROM order_items oi LEFT JOIN products p ON oi.product_id = p.id WHERE oi.order_id = " . $order['id']);
                                            if ($items && $items->num_rows > 0):
                                            ?>
                                                <table class="table table-sm">
                                                    <thead>
                                                        <tr>
                                                            <th>Product</th>
                                                            <th>Quantity</th>
                                                            <th>Price</th>
                                                            <th>Total</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php while ($item = $items->fetch_assoc()): ?>
                                                        <tr>
                                                            <td><?= htmlspecialchars($item['name'] ?? 'Product') ?></td>
                                                            <td><?= $item['quantity'] ?></td>
                                                            <td>PKR <?= number_format($item['price'], 2) ?></td>
                                                            <td>PKR <?= number_format($item['price'] * $item['quantity'], 2) ?></td>
                                                        </tr>
                                                        <?php endwhile; ?>
                                                    </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <td colspan="3" class="text-end"><strong>Grand Total:</strong></td>
                                                            <td><strong>PKR <?= number_format($order['total_amount'], 2) ?></strong></td>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            <?php else: ?>
                                                <p class="text-muted">No items found</p>
                                            <?php endif; ?>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="7" class="text-center py-5">
                                    <i class="bi bi-inbox" style="font-size: 3rem; color: #ccc;"></i>
                                    <p class="text-muted mt-3">No orders found</p>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

