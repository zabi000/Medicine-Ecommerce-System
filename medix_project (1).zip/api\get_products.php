<?php
require_once 'config.php';

$conn = getDBConnection();

$category = $_GET['category'] ?? '';
$limit = $_GET['limit'] ?? 0;

$sql = "SELECT *, image_url FROM products WHERE 1=1";

if (!empty($category)) {
    $sql .= " AND category = ?";
}

$sql .= " ORDER BY id DESC";

if ($limit > 0) {
    $sql .= " LIMIT ?";
}

$stmt = $conn->prepare($sql);

if (!empty($category) && $limit > 0) {
    $stmt->bind_param("si", $category, $limit);
} elseif (!empty($category)) {
    $stmt->bind_param("s", $category);
} elseif ($limit > 0) {
    $stmt->bind_param("i", $limit);
}

$stmt->execute();
$result = $stmt->get_result();

$products = [];
while ($row = $result->fetch_assoc()) {
    $products[] = $row;
}

echo json_encode($products);

$stmt->close();
$conn->close();
?>
