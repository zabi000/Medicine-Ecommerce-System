<?php
session_start();
require_once('api/config.php');
require_once('api/mailer.php');

// Ensure OTP table
if ($conn) {
    $conn->query("CREATE TABLE IF NOT EXISTS email_verifications (
        id INT AUTO_INCREMENT PRIMARY KEY,
        email VARCHAR(200) NOT NULL,
        otp VARCHAR(6) NOT NULL,
        expires_at DATETIME NOT NULL,
        verified TINYINT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

$step    = $_GET['step'] ?? 'verify';
$email   = $_SESSION['pending_email'] ?? '';
$name    = $_SESSION['pending_name'] ?? '';
$success = $error = '';

// If no pending registration, redirect
if (!$email && $step !== 'resend') {
    header('Location: register.html');
    exit;
}

// Handle OTP submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['verify_otp'])) {
    $otp_in = trim($_POST['otp'] ?? '');
    if (strlen($otp_in) !== 6 || !ctype_digit($otp_in)) {
        $error = 'Please enter the 6-digit OTP.';
    } else {
        $r = $conn->prepare("SELECT id FROM email_verifications WHERE email=? AND otp=? AND verified=0 AND expires_at > NOW()");
        $r->bind_param("ss", $email, $otp_in); $r->execute();
        $row = $r->get_result()->fetch_assoc();
        if (!$row) {
            $error = 'Invalid or expired OTP. Please try again or request a new one.';
        } else {
            // Mark as verified
            $conn->query("UPDATE email_verifications SET verified=1 WHERE email='" . $conn->real_escape_string($email) . "'");
            // Activate the user account
            $conn->query("UPDATE users SET email_verified=1 WHERE email='" . $conn->real_escape_string($email) . "'");
            // Clear session
            unset($_SESSION['pending_email'], $_SESSION['pending_name'], $_SESSION['pending_password']);
            $success = 'Email verified successfully! You can now login.';
            $step = 'done';
        }
    }
}

// Handle resend OTP
if (isset($_GET['resend']) || (isset($_POST['resend_otp']))) {
    if ($email) {
        $otp = str_pad(random_int(0, 999999), 6, '0', STR_PAD_LEFT);
        $exp = date('Y-m-d H:i:s', strtotime('+15 minutes'));
        $conn->query("DELETE FROM email_verifications WHERE email='" . $conn->real_escape_string($email) . "'");
        $ins = $conn->prepare("INSERT INTO email_verifications (email, otp, expires_at) VALUES (?,?,?)");
        $ins->bind_param("sss", $email, $otp, $exp);
        $ins->execute();

        // Send OTP email
        $content = '
            <h2>Email Verification</h2>
            <p>Hi <strong>' . htmlspecialchars($name) . '</strong>,</p>
            <p>Your MEDIX account verification code is:</p>
            <div style="text-align:center;margin:30px 0">
                <div style="background:linear-gradient(135deg,#B91C1C,#7F1D1D);color:white;font-size:42px;font-weight:900;letter-spacing:12px;padding:20px 40px;border-radius:16px;display:inline-block">' . $otp . '</div>
            </div>
            <p style="text-align:center;color:#64748b">This code expires in <strong>15 minutes</strong>.</p>
            <div class="info-box" style="border-left-color:#f59e0b">
                <p style="margin:0;font-size:13px;color:#92400e">If you did not create a MEDIX account, please ignore this email.</p>
            </div>';
        $html = emailTemplate('Verify Your Email', $content);
        $sent = sendMail($email, $name, 'Your MEDIX Verification Code: ' . $otp, $html, $conn);
        $success = $sent ? 'New OTP sent to ' . $email : 'OTP generated. Check your email.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>Verify Email - MEDIX</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
* { font-family: 'Inter', sans-serif; }
body { background: linear-gradient(135deg,#fef2f2,#fff,#fef2f2); min-height:100vh; display:flex; flex-direction:column; }
.wrapper { flex:1; display:flex; align-items:center; justify-content:center; padding:2rem 1rem; }
.card-box { background:white; border-radius:24px; box-shadow:0 20px 60px rgba(185,28,28,.1); width:100%; max-width:440px; overflow:hidden; }
.card-hdr { background:linear-gradient(135deg,#B91C1C,#7F1D1D); padding:2rem; text-align:center; color:white; }
.card-hdr .icon { width:70px; height:70px; background:rgba(255,255,255,.15); border-radius:50%; display:flex; align-items:center; justify-content:center; margin:0 auto 1rem; font-size:2rem; }
.card-body-p { padding:2rem; }
.otp-inputs { display:flex; gap:.5rem; justify-content:center; margin:1.5rem 0; }
.otp-input { width:50px; height:60px; text-align:center; font-size:1.5rem; font-weight:800; border:2px solid #e2e8f0; border-radius:12px; outline:none; transition:border-color .2s; }
.otp-input:focus { border-color:#B91C1C; box-shadow:0 0 0 3px rgba(185,28,28,.1); }
.btn-red { background:linear-gradient(135deg,#B91C1C,#991B1B); border:none; border-radius:10px; padding:.875rem; font-weight:700; color:white; width:100%; font-size:1rem; }
.btn-red:hover { background:linear-gradient(135deg,#991B1B,#7F1D1D); color:white; }
</style>
</head>
<body>
<nav class="navbar bg-white shadow-sm px-4">
    <a class="navbar-brand fw-bold text-danger" href="index.php"><i class="bi bi-heart-pulse-fill me-2"></i>MEDIX</a>
</nav>

<div class="wrapper">
<div class="card-box">
    <div class="card-hdr">
        <div class="icon"><i class="bi bi-envelope-check-fill"></i></div>
        <h4 class="mb-1 fw-bold"><?= $step === 'done' ? 'Email Verified!' : 'Verify Your Email' ?></h4>
        <p class="mb-0" style="opacity:.8;font-size:.875rem">
            <?= $step === 'done' ? 'Your account is now active' : 'Enter the 6-digit code sent to your email' ?>
        </p>
    </div>

    <div class="card-body-p">
        <?php if ($error): ?>
        <div class="alert alert-danger py-2 mb-3" style="border-radius:10px;border-left:4px solid #ef4444">
            <i class="bi bi-exclamation-triangle me-2"></i><?= htmlspecialchars($error) ?>
        </div>
        <?php endif; ?>
        <?php if ($success): ?>
        <div class="alert alert-success py-2 mb-3" style="border-radius:10px;border-left:4px solid #22c55e">
            <i class="bi bi-check-circle me-2"></i><?= htmlspecialchars($success) ?>
        </div>
        <?php endif; ?>

        <?php if ($step === 'done'): ?>
        <div class="text-center py-3">
            <i class="bi bi-check-circle-fill text-success" style="font-size:4rem"></i>
            <h5 class="mt-3 fw-bold">Account Activated!</h5>
            <p class="text-muted">You can now login with your email and password.</p>
            <a href="login.php" class="btn btn-red mt-2">
                <i class="bi bi-box-arrow-in-right me-2"></i>Login Now
            </a>
        </div>
        <?php else: ?>
        <p class="text-muted text-center small mb-1">Code sent to:</p>
        <p class="text-center fw-bold mb-3"><?= htmlspecialchars($email) ?></p>

        <form method="POST" id="otpForm">
            <div class="otp-inputs">
                <input type="text" class="otp-input" maxlength="1" id="o1" inputmode="numeric">
                <input type="text" class="otp-input" maxlength="1" id="o2" inputmode="numeric">
                <input type="text" class="otp-input" maxlength="1" id="o3" inputmode="numeric">
                <input type="text" class="otp-input" maxlength="1" id="o4" inputmode="numeric">
                <input type="text" class="otp-input" maxlength="1" id="o5" inputmode="numeric">
                <input type="text" class="otp-input" maxlength="1" id="o6" inputmode="numeric">
            </div>
            <input type="hidden" name="otp" id="otpHidden">
            <button type="submit" name="verify_otp" class="btn btn-red" id="verifyBtn">
                <i class="bi bi-shield-check me-2"></i>Verify Email
            </button>
        </form>

        <div class="text-center mt-3">
            <p class="text-muted small mb-2">Didn't receive the code?</p>
            <form method="POST" class="d-inline">
                <button type="submit" name="resend_otp" class="btn btn-outline-danger btn-sm px-4" style="border-radius:20px">
                    <i class="bi bi-arrow-clockwise me-1"></i>Resend OTP
                </button>
            </form>
        </div>
        <?php endif; ?>
    </div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
// Auto-advance OTP inputs
const inputs = document.querySelectorAll('.otp-input');
inputs.forEach((inp, i) => {
    inp.addEventListener('input', e => {
        const v = e.target.value.replace(/\D/g,'');
        e.target.value = v;
        if (v && i < inputs.length - 1) inputs[i+1].focus();
        updateHidden();
    });
    inp.addEventListener('keydown', e => {
        if (e.key === 'Backspace' && !e.target.value && i > 0) inputs[i-1].focus();
    });
    inp.addEventListener('paste', e => {
        e.preventDefault();
        const paste = (e.clipboardData || window.clipboardData).getData('text').replace(/\D/g,'');
        paste.split('').forEach((c, j) => { if (inputs[j]) inputs[j].value = c; });
        updateHidden();
        if (inputs[Math.min(paste.length, inputs.length-1)]) inputs[Math.min(paste.length, inputs.length-1)].focus();
    });
});

function updateHidden() {
    document.getElementById('otpHidden').value = Array.from(inputs).map(i => i.value).join('');
}

document.getElementById('otpForm')?.addEventListener('submit', function(e) {
    updateHidden();
    const otp = document.getElementById('otpHidden').value;
    if (otp.length !== 6) {
        e.preventDefault();
        alert('Please enter all 6 digits.');
    }
});

// Auto-focus first input
inputs[0]?.focus();
</script>
</body>
</html>
