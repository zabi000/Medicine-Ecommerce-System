PRODUCT IMAGES FOLDER
=====================

Place your medicine product images here.

FILE NAMING:
- product-1.jpg  = Paracetamol 500mg
- product-2.jpg  = Ibuprofen 400mg
- product-3.jpg  = Vitamin C 1000mg
- product-4.jpg  = First Aid Kit
- product-5.jpg  = Digital Thermometer
- product-6.jpg  = Vitamin D3 2000IU
- product-7.jpg  = Bandages Pack
- product-8.jpg  = Blood Pressure Monitor
- product-9.jpg  = Aspirin 100mg
- product-10.jpg = Multivitamin Complex
- product-11.jpg = Hand Sanitizer 500ml
- product-12.jpg = Face Masks (50 Pack)
- product-13.jpg = Omega-3 Fish Oil
- product-14.jpg = Glucose Meter Kit
- product-15.jpg = Antiseptic Cream
- product-16.jpg = Calcium + Vitamin D
- product-17.jpg = Pulse Oximeter
- product-18.jpg = Cough Syrup
- product-19.jpg = Probiotic Capsules
- product-20.jpg = Infrared Thermometer

DOWNLOAD FROM:
- Unsplash: https://unsplash.com/s/photos/medicine
- Pexels: https://www.pexels.com/search/pharmacy/
- Pixabay: https://pixabay.com/images/search/medicine/

IMAGE SPECS:
- Size: 500x500px (square)
- Format: JPG or PNG
- Background: White preferred
- Quality: High resolution

AFTER ADDING IMAGES:
Refresh your browser (Ctrl + Shift + R) to see them!
