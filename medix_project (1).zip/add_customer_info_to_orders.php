<?php
require_once('api/config.php');

echo "<!DOCTYPE html>
<html>
<head>
    <title>Add Customer Columns</title>
    <style>
        body { font-family: Arial, sans-serif; padding: 2rem; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 2rem; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .success { color: #10B981; font-weight: bold; padding: 10px; background: #D1FAE5; border-radius: 5px; margin: 10px 0; }
        .error { color: #EF4444; font-weight: bold; padding: 10px; background: #FEE2E2; border-radius: 5px; margin: 10px 0; }
        .warning { color: #F59E0B; font-weight: bold; padding: 10px; background: #FEF3C7; border-radius: 5px; margin: 10px 0; }
        table { width: 100%; border-collapse: collapse; margin: 20px 0; }
        th, td { padding: 10px; border: 1px solid #ddd; text-align: left; }
        th { background: #f0f0f0; }
        .btn { display: inline-block; padding: 15px 30px; background: #10B981; color: white; text-decoration: none; border-radius: 8px; margin: 10px 5px; font-weight: bold; }
        .btn:hover { background: #059669; }
    </style>
</head>
<body>
<div class='container'>";

echo "<h1>Adding Customer Information Columns</h1>";

// Check if columns already exist
$check_name = $conn->query("SHOW COLUMNS FROM orders LIKE 'customer_name'");
$check_email = $conn->query("SHOW COLUMNS FROM orders LIKE 'customer_email'");
$check_phone = $conn->query("SHOW COLUMNS FROM orders LIKE 'customer_phone'");

$name_exists = ($check_name && $check_name->num_rows > 0);
$email_exists = ($check_email && $check_email->num_rows > 0);
$phone_exists = ($check_phone && $check_phone->num_rows > 0);

// Add customer_name column
if (!$name_exists) {
    $sql1 = "ALTER TABLE orders ADD customer_name VARCHAR(100) AFTER user_id";
    if ($conn->query($sql1)) {
        echo "<div class='success'>✓ Added customer_name column</div>";
    } else {
        echo "<div class='error'>✗ Failed to add customer_name: " . $conn->error . "</div>";
    }
} else {
    echo "<div class='warning'>⚠ customer_name column already exists</div>";
}

// Add customer_email column
if (!$email_exists) {
    $sql2 = "ALTER TABLE orders ADD customer_email VARCHAR(100) AFTER customer_name";
    if ($conn->query($sql2)) {
        echo "<div class='success'>✓ Added customer_email column</div>";
    } else {
        echo "<div class='error'>✗ Failed to add customer_email: " . $conn->error . "</div>";
    }
} else {
    echo "<div class='warning'>⚠ customer_email column already exists</div>";
}

// Add customer_phone column
if (!$phone_exists) {
    $sql3 = "ALTER TABLE orders ADD customer_phone VARCHAR(20) AFTER customer_email";
    if ($conn->query($sql3)) {
        echo "<div class='success'>✓ Added customer_phone column</div>";
    } else {
        echo "<div class='error'>✗ Failed to add customer_phone: " . $conn->error . "</div>";
    }
} else {
    echo "<div class='warning'>⚠ customer_phone column already exists</div>";
}

echo "<h2>Current Orders Table Structure:</h2>";
$result = $conn->query("DESCRIBE orders");
echo "<table>";
echo "<tr><th>Field</th><th>Type</th><th>Null</th><th>Key</th><th>Default</th></tr>";
while ($row = $result->fetch_assoc()) {
    $highlight = in_array($row['Field'], ['customer_name', 'customer_email', 'customer_phone']) ? "style='background: #D1FAE5;'" : "";
    echo "<tr $highlight>";
    echo "<td><strong>{$row['Field']}</strong></td>";
    echo "<td>{$row['Type']}</td>";
    echo "<td>{$row['Null']}</td>";
    echo "<td>{$row['Key']}</td>";
    echo "<td>{$row['Default']}</td>";
    echo "</tr>";
}
echo "</table>";

// Verify all columns exist
$final_check_name = $conn->query("SHOW COLUMNS FROM orders LIKE 'customer_name'");
$final_check_email = $conn->query("SHOW COLUMNS FROM orders LIKE 'customer_email'");
$final_check_phone = $conn->query("SHOW COLUMNS FROM orders LIKE 'customer_phone'");

$all_exist = ($final_check_name->num_rows > 0) && ($final_check_email->num_rows > 0) && ($final_check_phone->num_rows > 0);

echo "<hr>";
if ($all_exist) {
    echo "<h2 style='color: #10B981;'>✅ Success! All columns added!</h2>";
    echo "<p style='font-size: 1.1rem;'>Your database is now ready. New orders will show the customer name from the checkout form.</p>";
    echo "<h3>Next Steps:</h3>";
    echo "<ol style='font-size: 1.1rem;'>";
    echo "<li>Go to <a href='products.php'>Products Page</a></li>";
    echo "<li>Add items to cart</li>";
    echo "<li>Go to <a href='checkout.php'>Checkout</a></li>";
    echo "<li>Enter your name: <strong>Jahanzaib</strong></li>";
    echo "<li>Place the order</li>";
    echo "<li>Check <a href='admin/orders.php'>Admin Orders</a> - you'll see 'Jahanzaib'!</li>";
    echo "</ol>";
    echo "<a href='products.php' class='btn'>Start Shopping</a>";
    echo "<a href='admin/orders.php' class='btn' style='background: #3B82F6;'>View Orders</a>";
} else {
    echo "<h2 style='color: #EF4444;'>❌ Some columns are missing!</h2>";
    echo "<p>Please refresh this page or contact support.</p>";
}

echo "</div></body></html>";
?>
