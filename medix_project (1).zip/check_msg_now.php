<?php
require_once('api/config.php');
$r = $conn->query("SELECT id, email, message, attachment FROM contact_messages ORDER BY id DESC LIMIT 3");
while ($row = $r->fetch_assoc()) {
    echo "ID: {$row['id']} | Email: {$row['email']} | Attachment: " . ($row['attachment'] ?: 'NULL') . "<br>";
    if ($row['attachment']) {
        $path = __DIR__ . '/' . $row['attachment'];
        echo "File exists: " . (file_exists($path) ? 'YES' : 'NO') . " | Path: $path<br>";
        echo "<img src='/ppp/{$row['attachment']}' style='max-height:100px'><br>";
    }
    echo "<hr>";
}
?>
