<?php
/**
 * Notification System for MEDIX Pharmacy
 * Handles Email and SMS notifications
 */

// Email Configuration
function sendOrderEmail($to, $name, $order_id, $order_items, $total, $address, $payment_method) {
    $subject = "Order Confirmation #$order_id - MEDIX Pharmacy";
    
    // Build items HTML
    $items_html = '';
    foreach ($order_items as $item) {
        $items_html .= "
        <tr>
            <td style='padding: 10px; border-bottom: 1px solid #eee;'>{$item['name']}</td>
            <td style='padding: 10px; border-bottom: 1px solid #eee; text-align: center;'>{$item['quantity']}</td>
            <td style='padding: 10px; border-bottom: 1px solid #eee; text-align: right;'>PKR " . number_format($item['price'], 2) . "</td>
            <td style='padding: 10px; border-bottom: 1px solid #eee; text-align: right;'>PKR " . number_format($item['subtotal'], 2) . "</td>
        </tr>";
    }
    
    $message = "
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset='UTF-8'>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; margin: 0; padding: 0; }
            .container { max-width: 600px; margin: 0 auto; background: #ffffff; }
            .header { background: linear-gradient(135deg, #B91C1C, #991B1B); color: white; padding: 30px 20px; text-align: center; }
            .header h1 { margin: 0; font-size: 28px; }
            .content { padding: 30px 20px; }
            .order-box { background: #f8f9fa; padding: 20px; margin: 20px 0; border-radius: 8px; border-left: 4px solid #B91C1C; }
            .order-box h3 { margin-top: 0; color: #B91C1C; }
            table { width: 100%; border-collapse: collapse; margin: 15px 0; }
            th { background: #f1f1f1; padding: 12px; text-align: left; font-weight: bold; }
            .total-row { background: #fff3cd; font-weight: bold; font-size: 1.1em; }
            .footer { background: #f8f9fa; padding: 20px; text-align: center; color: #666; font-size: 14px; }
            .button { display: inline-block; padding: 12px 30px; background: #B91C1C; color: white; text-decoration: none; border-radius: 5px; margin: 15px 0; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>🏥 MEDIX Pharmacy</h1>
                <p style='margin: 5px 0 0 0; font-size: 16px;'>Your Trusted Healthcare Partner</p>
            </div>
            
            <div class='content'>
                <h2 style='color: #B91C1C;'>Order Confirmation</h2>
                <p>Dear <strong>$name</strong>,</p>
                <p>Thank you for your order! We're excited to serve you.</p>
                
                <div class='order-box'>
                    <h3>📦 Order Information</h3>
                    <p><strong>Order Number:</strong> #$order_id</p>
                    <p><strong>Order Date:</strong> " . date('F d, Y h:i A') . "</p>
                    <p><strong>Payment Method:</strong> " . ucfirst($payment_method) . "</p>
                    <p><strong>Status:</strong> <span style='color: #f59e0b;'>⏳ Pending</span></p>
                </div>
                
                <div class='order-box'>
                    <h3>📍 Delivery Address</h3>
                    <p>$address</p>
                </div>
                
                <h3>🛒 Order Items</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th style='text-align: center;'>Qty</th>
                            <th style='text-align: right;'>Price</th>
                            <th style='text-align: right;'>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        $items_html
                        <tr class='total-row'>
                            <td colspan='3' style='padding: 15px; text-align: right;'>Grand Total:</td>
                            <td style='padding: 15px; text-align: right; color: #B91C1C;'>PKR " . number_format($total, 2) . "</td>
                        </tr>
                    </tbody>
                </table>
                
                <div style='text-align: center; margin: 30px 0;'>
                    <a href='http://localhost/ppp/order_success.php?order_id=$order_id' class='button'>Track Your Order</a>
                </div>
                
                <div style='background: #e3f2fd; padding: 15px; border-radius: 5px; margin: 20px 0;'>
                    <p style='margin: 0;'><strong>📞 Need Help?</strong></p>
                    <p style='margin: 5px 0 0 0;'>Contact us: +92-300-1234567 | support@medix.com</p>
                </div>
            </div>
            
            <div class='footer'>
                <p><strong>MEDIX Pharmacy</strong></p>
                <p>123 Healthcare Street, Karachi, Pakistan</p>
                <p>© " . date('Y') . " MEDIX. All rights reserved.</p>
            </div>
        </div>
    </body>
    </html>";
    
    // Email headers
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: MEDIX Pharmacy <noreply@medix.com>" . "\r\n";
    $headers .= "Reply-To: support@medix.com" . "\r\n";
    
    // Send email
    return mail($to, $subject, $message, $headers);
}

// SMS Configuration (using a simple SMS gateway)
function sendOrderSMS($phone, $name, $order_id, $total) {
    // Clean phone number
    $phone = preg_replace('/[^0-9]/', '', $phone);
    
    // SMS message (keep it short - 160 chars max)
    $message = "MEDIX: Dear $name, your order #$order_id (PKR " . number_format($total, 0) . ") is confirmed! Track: medix.com/track";
    
    // SMS Gateway Integration
    // You need to sign up for an SMS service like:
    // - Twilio (https://www.twilio.com)
    // - Nexmo/Vonage (https://www.vonage.com)
    // - SMS Gateway Pakistan (local providers)
    
    // Example with a generic SMS API:
    /*
    $api_url = "https://api.smsgateway.com/send";
    $api_key = "YOUR_API_KEY";
    
    $data = [
        'api_key' => $api_key,
        'to' => $phone,
        'message' => $message,
        'sender' => 'MEDIX'
    ];
    
    $ch = curl_init($api_url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);
    
    return json_decode($response, true);
    */
    
    // For now, log SMS to file (for testing)
    $log_file = __DIR__ . '/../logs/sms_log.txt';
    $log_dir = dirname($log_file);
    if (!file_exists($log_dir)) {
        mkdir($log_dir, 0777, true);
    }
    
    $log_entry = date('Y-m-d H:i:s') . " | To: $phone | Message: $message\n";
    file_put_contents($log_file, $log_entry, FILE_APPEND);
    
    return true; // Return true for testing
}

// Admin notification
function sendAdminNotification($order_id, $customer_name, $total) {
    $admin_email = "admin@medix.com"; // Change this to your admin email
    $subject = "New Order Received #$order_id";
    
    $message = "
    <!DOCTYPE html>
    <html>
    <body style='font-family: Arial, sans-serif;'>
        <h2 style='color: #B91C1C;'>🔔 New Order Alert</h2>
        <p>A new order has been placed on your store.</p>
        <div style='background: #f8f9fa; padding: 15px; border-radius: 5px;'>
            <p><strong>Order ID:</strong> #$order_id</p>
            <p><strong>Customer:</strong> $customer_name</p>
            <p><strong>Total Amount:</strong> PKR " . number_format($total, 2) . "</p>
            <p><strong>Time:</strong> " . date('F d, Y h:i A') . "</p>
        </div>
        <p><a href='http://localhost/ppp/admin/orders.php' style='display: inline-block; padding: 10px 20px; background: #B91C1C; color: white; text-decoration: none; border-radius: 5px;'>View Order</a></p>
    </body>
    </html>";
    
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: MEDIX System <system@medix.com>" . "\r\n";
    
    return mail($admin_email, $subject, $message, $headers);
}

// Order status update notification
function sendStatusUpdateEmail($to, $name, $order_id, $new_status) {
    $status_messages = [
        'pending' => ['icon' => '⏳', 'color' => '#f59e0b', 'message' => 'Your order is being processed'],
        'processing' => ['icon' => '📦', 'color' => '#3b82f6', 'message' => 'Your order is being prepared'],
        'delivered' => ['icon' => '✅', 'color' => '#10b981', 'message' => 'Your order has been delivered'],
        'cancelled' => ['icon' => '❌', 'color' => '#ef4444', 'message' => 'Your order has been cancelled']
    ];
    
    $status_info = $status_messages[$new_status] ?? $status_messages['pending'];
    
    $subject = "Order Status Update #$order_id - MEDIX Pharmacy";
    
    $message = "
    <!DOCTYPE html>
    <html>
    <body style='font-family: Arial, sans-serif; padding: 20px;'>
        <div style='max-width: 600px; margin: 0 auto; background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1);'>
            <div style='background: linear-gradient(135deg, #B91C1C, #991B1B); color: white; padding: 20px; text-align: center;'>
                <h1 style='margin: 0;'>🏥 MEDIX Pharmacy</h1>
            </div>
            <div style='padding: 30px;'>
                <h2 style='color: #B91C1C;'>Order Status Update</h2>
                <p>Dear <strong>$name</strong>,</p>
                <div style='background: {$status_info['color']}15; padding: 20px; border-radius: 8px; border-left: 4px solid {$status_info['color']}; margin: 20px 0;'>
                    <p style='font-size: 24px; margin: 0;'>{$status_info['icon']}</p>
                    <p style='font-size: 18px; font-weight: bold; margin: 10px 0; color: {$status_info['color']};'>" . ucfirst($new_status) . "</p>
                    <p style='margin: 0;'>{$status_info['message']}</p>
                </div>
                <p><strong>Order Number:</strong> #$order_id</p>
                <p><strong>Updated:</strong> " . date('F d, Y h:i A') . "</p>
                <div style='text-align: center; margin: 30px 0;'>
                    <a href='http://localhost/ppp/order_success.php?order_id=$order_id' style='display: inline-block; padding: 12px 30px; background: #B91C1C; color: white; text-decoration: none; border-radius: 5px;'>Track Order</a>
                </div>
            </div>
        </div>
    </body>
    </html>";
    
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
    $headers .= "From: MEDIX Pharmacy <noreply@medix.com>" . "\r\n";
    
    return mail($to, $subject, $message, $headers);
}
?>
