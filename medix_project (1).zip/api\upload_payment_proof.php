<?php
header('Content-Type: application/json');
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Invalid request']);
    exit;
}

$order_id = intval($_POST['order_id'] ?? 0);

if (!$order_id) {
    echo json_encode(['success' => false, 'message' => 'Order ID required']);
    exit;
}

if (!isset($_FILES['payment_proof']) || $_FILES['payment_proof']['error'] !== UPLOAD_ERR_OK) {
    echo json_encode(['success' => false, 'message' => 'No file uploaded or upload error']);
    exit;
}

$file = $_FILES['payment_proof'];
$allowed = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif', 'image/webp'];
$finfo = finfo_open(FILEINFO_MIME_TYPE);
$mime = finfo_file($finfo, $file['tmp_name']);
finfo_close($finfo);

if (!in_array($mime, $allowed)) {
    echo json_encode(['success' => false, 'message' => 'Only images allowed (JPG, PNG, GIF)']);
    exit;
}

if ($file['size'] > 5 * 1024 * 1024) {
    echo json_encode(['success' => false, 'message' => 'File too large. Max 5MB.']);
    exit;
}

$ext = pathinfo($file['name'], PATHINFO_EXTENSION);
$filename = 'payment_' . $order_id . '_' . time() . '.' . $ext;
$upload_dir = __DIR__ . '/../uploads/payments/';
$upload_path = $upload_dir . $filename;

if (!is_dir($upload_dir)) mkdir($upload_dir, 0755, true);

if (!move_uploaded_file($file['tmp_name'], $upload_path)) {
    echo json_encode(['success' => false, 'message' => 'Failed to save file']);
    exit;
}

if (!$conn) {
    echo json_encode(['success' => false, 'message' => 'DB connection failed']);
    exit;
}

// Ensure payment_proof column exists
$conn->query("ALTER TABLE orders ADD COLUMN IF NOT EXISTS payment_proof VARCHAR(255) DEFAULT NULL");
$conn->query("ALTER TABLE orders ADD COLUMN IF NOT EXISTS payment_proof_at TIMESTAMP NULL DEFAULT NULL");

$rel_path = 'uploads/payments/' . $filename;
$stmt = $conn->prepare("UPDATE orders SET payment_proof=?, payment_proof_at=NOW() WHERE id=?");
$stmt->bind_param("si", $rel_path, $order_id);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Screenshot uploaded successfully!', 'path' => $rel_path]);
} else {
    echo json_encode(['success' => false, 'message' => 'DB error: ' . $conn->error]);
}
$stmt->close();
?>
