<?php
require_once('api/config.php');

echo "<h1>Orders Page Fix - Verification</h1>";

// Check database connection
if (!$conn) {
    die("<p style='color: red;'>❌ Database connection failed!</p>");
}
echo "<p style='color: green;'>✅ Database connected</p>";

// Check if customer columns exist
$columns_check = $conn->query("SHOW COLUMNS FROM orders LIKE 'customer_name'");
$has_customer_columns = ($columns_check && $columns_check->num_rows > 0);

echo "<h2>Column Status:</h2>";
if ($has_customer_columns) {
    echo "<p style='color: green;'>✅ New customer columns exist</p>";
    echo "<p>The orders page will use customer information from the checkout form.</p>";
} else {
    echo "<p style='color: orange;'>⚠ New customer columns don't exist yet</p>";
    echo "<p>The orders page will use information from the users table (fallback mode).</p>";
    echo "<p><a href='add_customer_info_to_orders.php' style='background: #B91C1C; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Add Customer Columns Now</a></p>";
}

// Test the query
echo "<h2>Testing Orders Query:</h2>";
try {
    if ($has_customer_columns) {
        $sql = "SELECT o.*, 
            COALESCE(o.customer_name, u.name) as customer_name,
            COALESCE(o.customer_email, u.email) as customer_email
            FROM orders o 
            LEFT JOIN users u ON o.user_id = u.id 
            ORDER BY o.created_at DESC LIMIT 3";
    } else {
        $sql = "SELECT o.*, u.name as customer_name, u.email as customer_email
            FROM orders o 
            LEFT JOIN users u ON o.user_id = u.id 
            ORDER BY o.created_at DESC LIMIT 3";
    }
    
    $result = $conn->query($sql);
    
    if ($result) {
        echo "<p style='color: green;'>✅ Query works! Found {$result->num_rows} orders</p>";
        
        if ($result->num_rows > 0) {
            echo "<table border='1' cellpadding='10' style='border-collapse: collapse; width: 100%;'>";
            echo "<tr style='background: #f0f0f0;'><th>Order ID</th><th>Customer</th><th>Email</th><th>Total</th><th>Status</th></tr>";
            while ($order = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td><strong>#{$order['id']}</strong></td>";
                echo "<td>" . htmlspecialchars($order['customer_name'] ?? 'Guest') . "</td>";
                echo "<td>" . htmlspecialchars($order['customer_email'] ?? 'N/A') . "</td>";
                echo "<td>PKR " . number_format($order['total_amount'], 2) . "</td>";
                echo "<td><span style='padding: 5px 10px; background: #FEF3C7; border-radius: 5px;'>{$order['status']}</span></td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p>No orders in database yet.</p>";
        }
    } else {
        echo "<p style='color: red;'>❌ Query failed: " . $conn->error . "</p>";
    }
} catch (Exception $e) {
    echo "<p style='color: red;'>❌ Error: " . $e->getMessage() . "</p>";
}

echo "<hr>";
echo "<h2>✅ Orders Page Status:</h2>";
echo "<p style='font-size: 1.2rem; color: green;'><strong>The orders page should work now!</strong></p>";
echo "<p><a href='admin/orders.php' style='background: #10B981; color: white; padding: 15px 30px; text-decoration: none; border-radius: 8px; font-size: 1.1rem; display: inline-block;'>Open Orders Page</a></p>";

echo "<hr>";
echo "<h3>How It Works:</h3>";
echo "<ul>";
echo "<li>The orders page now checks if customer columns exist</li>";
echo "<li>If columns exist: Uses customer info from checkout form</li>";
echo "<li>If columns don't exist: Uses info from users table (fallback)</li>";
echo "<li>Either way, the page will work!</li>";
echo "</ul>";
?>
