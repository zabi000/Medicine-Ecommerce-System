﻿<?php
session_start();if(!isset($_SESSION["admin_logged_in"])){header("Location: login.php");exit();}$ok=null;if($_SERVER["REQUEST_METHOD"]==="POST"){$ok="Settings saved!";}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Settings - MEDIX Admin</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
*{font-family:'Inter',sans-serif}
:root{--primary:#B91C1C;--sw:280px}
body{background:#f1f5f9;margin:0}
.sidebar{position:fixed;top:0;left:0;width:var(--sw);height:100vh;background:linear-gradient(160deg,#B91C1C 0%,#7F1D1D 100%);overflow-y:auto;z-index:1000;box-shadow:4px 0 20px rgba(0,0,0,.15)}
.sb-brand{padding:1.75rem 1.5rem;border-bottom:1px solid rgba(255,255,255,.1);color:white}
.sb-brand h4{font-weight:800;letter-spacing:.5px}
.mi{display:flex;align-items:center;gap:.75rem;padding:.875rem 1.5rem;color:rgba(255,255,255,.75);text-decoration:none;border-left:3px solid transparent;transition:all .2s;font-size:.9rem}
.mi:hover,.mi.active{background:rgba(255,255,255,.12);color:white;border-left-color:white}
.mi i{width:20px;font-size:1rem}
.mdiv{height:1px;background:rgba(255,255,255,.1);margin:.5rem 1.5rem}
.main{margin-left:var(--sw);padding:0}
.topbar{background:white;padding:1.25rem 2rem;display:flex;justify-content:space-between;align-items:center;box-shadow:0 1px 3px rgba(0,0,0,.08);position:sticky;top:0;z-index:100}
.content{padding:2rem}

/* Settings Nav Tabs */
.settings-nav{display:flex;gap:.5rem;flex-wrap:wrap;margin-bottom:2rem}
.s-tab{padding:.6rem 1.25rem;border-radius:10px;border:2px solid #e2e8f0;background:white;color:#64748b;font-weight:600;font-size:.85rem;cursor:pointer;transition:all .2s;display:flex;align-items:center;gap:.5rem}
.s-tab:hover{border-color:#B91C1C;color:#B91C1C}
.s-tab.active{background:#B91C1C;border-color:#B91C1C;color:white}

/* Cards */
.s-panel{display:none}
.s-panel.active{display:block}
.s-card{background:white;border-radius:16px;box-shadow:0 1px 3px rgba(0,0,0,.08);overflow:hidden;margin-bottom:1.5rem}
.s-card-header{padding:1.25rem 1.75rem;border-bottom:1px solid #f1f5f9;display:flex;align-items:center;gap:.75rem;background:linear-gradient(135deg,#fafafa,white)}
.s-card-header .icon-box{width:42px;height:42px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0}
.s-card-header h6{margin:0;font-weight:700;font-size:1rem;color:#1e293b}
.s-card-header small{color:#64748b;font-size:.8rem}
.s-card-body{padding:1.75rem}
.form-label{font-weight:600;font-size:.85rem;color:#374151;margin-bottom:.4rem}
.form-control,.form-select{border-radius:10px;border:1.5px solid #e2e8f0;padding:.625rem .875rem;font-size:.9rem;transition:all .2s}
.form-control:focus,.form-select:focus{border-color:#B91C1C;box-shadow:0 0 0 3px rgba(185,28,28,.1)}
.btn-save{background:linear-gradient(135deg,#B91C1C,#991B1B);border:none;padding:.7rem 2rem;font-weight:700;border-radius:10px;font-size:.9rem;transition:all .2s}
.btn-save:hover{transform:translateY(-2px);box-shadow:0 6px 20px rgba(185,28,28,.3)}
.input-icon{position:relative}
.input-icon i{position:absolute;left:.875rem;top:50%;transform:translateY(-50%);color:#94a3b8;font-size:.9rem}
.input-icon input,.input-icon select{padding-left:2.5rem}

/* System status */
.status-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:1rem;margin-bottom:1.5rem}
.status-item{background:#f8fafc;border-radius:12px;padding:1rem;text-align:center;border:1px solid #e2e8f0}
.status-item .val{font-size:1.25rem;font-weight:800;color:#1e293b}
.status-item .lbl{font-size:.72rem;color:#64748b;margin-top:.2rem}
.status-dot{display:inline-block;width:8px;height:8px;border-radius:50%;background:#10b981;margin-right:.4rem;animation:pulse-dot 2s infinite}
@keyframes pulse-dot{0%,100%{opacity:1}50%{opacity:.4}}

/* Payment toggles */
.pay-option{display:flex;align-items:center;justify-content:space-between;padding:1rem 1.25rem;border:1.5px solid #e2e8f0;border-radius:12px;margin-bottom:.75rem;transition:all .2s}
.pay-option:hover{border-color:#B91C1C;background:#fef2f2}
.pay-option .pay-info{display:flex;align-items:center;gap:.75rem}
.pay-icon{width:40px;height:40px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.2rem}

/* Notification toggles */
.notif-item{display:flex;align-items:center;justify-content:space-between;padding:.875rem 0;border-bottom:1px solid #f1f5f9}
.notif-item:last-child{border-bottom:none}
.form-check-input:checked{background-color:#B91C1C;border-color:#B91C1C}

/* Social links */
.social-item{display:flex;align-items:center;gap:.75rem;margin-bottom:1rem}
.social-icon{width:42px;height:42px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:1.2rem;flex-shrink:0}

/* Days grid */
.days-grid{display:flex;gap:.5rem;flex-wrap:wrap}
.day-btn{width:48px;height:48px;border-radius:10px;border:2px solid #e2e8f0;background:white;font-weight:700;font-size:.8rem;cursor:pointer;transition:all .2s;display:flex;align-items:center;justify-content:center}
.day-btn.on{background:#B91C1C;border-color:#B91C1C;color:white}
.day-btn:hover{border-color:#B91C1C}

/* Alert */
.s-alert{background:linear-gradient(135deg,#f0fdf4,#dcfce7);border:1px solid #bbf7d0;border-radius:12px;padding:1rem 1.25rem;display:flex;align-items:center;gap:.75rem;color:#166534;font-weight:500;margin-bottom:1.5rem}
</style>
</head>
<body><div class="sidebar">
<div class="sb-brand"><h4 class="mb-0"><i class="bi bi-heart-pulse-fill me-2"></i>MEDIX</h4><small style="opacity:.6">Admin Portal</small></div>
<a href="index.php" class="mi"><i class="bi bi-speedometer2"></i>Dashboard</a>
<a href="products.php" class="mi"><i class="bi bi-box-seam"></i>Products</a>
<a href="orders.php" class="mi"><i class="bi bi-cart-check"></i>Orders</a>
<a href="customers.php" class="mi"><i class="bi bi-people"></i>Customers</a>
<a href="categories.php" class="mi"><i class="bi bi-tags"></i>Categories</a>
<a href="messages.php" class="mi"><i class="bi bi-envelope"></i>Messages</a>
<a href="reports.php" class="mi"><i class="bi bi-graph-up"></i>Reports</a>
<a href="settings.php" class="mi active"><i class="bi bi-gear"></i>Settings</a>
<div class="mdiv"></div>
<a href="import_medicines.php" class="mi" style="color:#10B981"><i class="bi bi-capsule-pill"></i>Import Medicines</a>
<div class="mdiv"></div>
<a href="logout.php" class="mi"><i class="bi bi-box-arrow-right"></i>Logout</a>
</div><div class="main">
<div class="topbar">
<div><h4 class="mb-0 fw-bold">Settings</h4><small class="text-muted">Manage your store configuration</small></div>
<div class="d-flex align-items-center gap-2">
<span style="background:#f0fdf4;border:1px solid #bbf7d0;color:#166534;padding:.4rem .875rem;border-radius:8px;font-size:.8rem;font-weight:600"><span class="status-dot"></span>System Online</span>
</div>
</div>
<div class="content">
<?php if($ok):?><div class="s-alert"><i class="bi bi-check-circle-fill" style="font-size:1.2rem"></i><?=$ok?></div><?php endif;?>

<!-- Settings Navigation Tabs -->
<div class="settings-nav">
<button class="s-tab active" onclick="showPanel('store',this)"><i class="bi bi-shop"></i>Store</button>
<button class="s-tab" onclick="showPanel('shipping',this)"><i class="bi bi-truck"></i>Shipping</button>
<button class="s-tab" onclick="showPanel('payment',this)"><i class="bi bi-credit-card"></i>Payment</button>
<button class="s-tab" onclick="showPanel('hours',this)"><i class="bi bi-clock"></i>Hours</button>
<button class="s-tab" onclick="showPanel('security',this)"><i class="bi bi-shield-lock"></i>Security</button>
<button class="s-tab" onclick="showPanel('notifications',this)"><i class="bi bi-bell"></i>Notifications</button>
<button class="s-tab" onclick="showPanel('social',this)"><i class="bi bi-share"></i>Social</button>
<button class="s-tab" onclick="showPanel('system',this)"><i class="bi bi-cpu"></i>System</button>
</div><!-- STORE PANEL -->
<div id="panel-store" class="s-panel active">
<div class="s-card">
<div class="s-card-header"><div class="icon-box" style="background:#fee2e2;color:#B91C1C"><i class="bi bi-shop-window"></i></div><div><h6>Store Information</h6><small>Basic details shown to customers</small></div></div>
<div class="s-card-body">
<form method="POST"><div class="row g-3">
<div class="col-md-6"><label class="form-label">Store Name</label><div class="input-icon"><i class="bi bi-building"></i><input type="text" class="form-control" name="store_name" value="MEDIX Pharmacy"></div></div>
<div class="col-md-6"><label class="form-label">Tagline</label><div class="input-icon"><i class="bi bi-chat-quote"></i><input type="text" class="form-control" name="tagline" value="Your Trusted Online Pharmacy"></div></div>
<div class="col-md-6"><label class="form-label">Contact Email</label><div class="input-icon"><i class="bi bi-envelope"></i><input type="email" class="form-control" name="email" value="info@medix.com.pk"></div></div>
<div class="col-md-6"><label class="form-label">Support Email</label><div class="input-icon"><i class="bi bi-headset"></i><input type="email" class="form-control" name="support_email" value="support@medix.com.pk"></div></div>
<div class="col-md-4"><label class="form-label">Phone</label><div class="input-icon"><i class="bi bi-telephone"></i><input type="text" class="form-control" name="phone" value="+92-300-1234567"></div></div>
<div class="col-md-4"><label class="form-label">WhatsApp</label><div class="input-icon"><i class="bi bi-whatsapp"></i><input type="text" class="form-control" name="whatsapp" value="+92-300-1234567"></div></div>
<div class="col-md-4"><label class="form-label">Currency</label><select class="form-select" name="currency"><option>PKR (â‚¨)</option><option>USD ($)</option><option>EUR (â‚¬)</option></select></div>
<div class="col-12"><label class="form-label">Address</label><textarea class="form-control" rows="2" name="address">123 Main Street, Karachi, Sindh, Pakistan</textarea></div>
<div class="col-md-6"><label class="form-label">City</label><input type="text" class="form-control" name="city" value="Karachi"></div>
<div class="col-md-6"><label class="form-label">Country</label><input type="text" class="form-control" name="country" value="Pakistan"></div>
</div><div class="mt-4"><button type="submit" class="btn btn-danger btn-save"><i class="bi bi-save me-2"></i>Save Store Info</button></div></form>
</div></div></div><!-- SHIPPING PANEL -->
<div id="panel-shipping" class="s-panel">
<div class="s-card">
<div class="s-card-header"><div class="icon-box" style="background:#dbeafe;color:#2563eb"><i class="bi bi-truck"></i></div><div><h6>Shipping & Delivery</h6><small>Configure delivery options and costs</small></div></div>
<div class="s-card-body"><form method="POST"><div class="row g-3">
<div class="col-md-6"><label class="form-label">Free Shipping Threshold (PKR)</label><div class="input-icon"><i class="bi bi-gift"></i><input type="number" class="form-control" name="free_shipping" value="5000"></div><small class="text-muted">Orders above this get free shipping</small></div>
<div class="col-md-6"><label class="form-label">Standard Shipping (PKR)</label><div class="input-icon"><i class="bi bi-box"></i><input type="number" class="form-control" name="shipping_cost" value="250"></div></div>
<div class="col-md-6"><label class="form-label">Express Shipping (PKR)</label><div class="input-icon"><i class="bi bi-lightning"></i><input type="number" class="form-control" name="express_shipping" value="500"></div></div>
<div class="col-md-6"><label class="form-label">Delivery Time</label><div class="input-icon"><i class="bi bi-clock"></i><input type="text" class="form-control" name="delivery_time" value="2-3 business days"></div></div>
<div class="col-md-6"><label class="form-label">Delivery Cities</label><input type="text" class="form-control" name="cities" value="Karachi, Lahore, Islamabad, Peshawar, Quetta"></div>
<div class="col-md-6"><label class="form-label">Courier Partner</label><select class="form-select" name="courier"><option>TCS Courier</option><option>Leopards Courier</option><option>M&P Courier</option><option>Pakistan Post</option></select></div>
</div><div class="mt-4"><button type="submit" class="btn btn-danger btn-save"><i class="bi bi-save me-2"></i>Save Shipping</button></div></form></div></div></div>

<!-- PAYMENT PANEL -->
<div id="panel-payment" class="s-panel">
<div class="s-card">
<div class="s-card-header"><div class="icon-box" style="background:#d1fae5;color:#059669"><i class="bi bi-credit-card"></i></div><div><h6>Payment Methods</h6><small>Configure accepted payment options</small></div></div>
<div class="s-card-body"><form method="POST">
<div class="pay-option"><div class="pay-info"><div class="pay-icon" style="background:#d1fae5;color:#059669"><i class="bi bi-cash"></i></div><div><div class="fw-semibold">Cash on Delivery</div><small class="text-muted">Most popular in Pakistan</small></div></div><div class="form-check form-switch mb-0"><input class="form-check-input" type="checkbox" checked style="width:2.5rem;height:1.25rem"></div></div>
<div class="pay-option"><div class="pay-info"><div class="pay-icon" style="background:#fef3c7;color:#d97706"><i class="bi bi-phone"></i></div><div><div class="fw-semibold">Easypaisa</div><small class="text-muted">Mobile wallet</small></div></div><div class="form-check form-switch mb-0"><input class="form-check-input" type="checkbox" checked style="width:2.5rem;height:1.25rem"></div></div>
<div class="pay-option"><div class="pay-info"><div class="pay-icon" style="background:#fee2e2;color:#dc2626"><i class="bi bi-phone-fill"></i></div><div><div class="fw-semibold">JazzCash</div><small class="text-muted">Mobile wallet</small></div></div><div class="form-check form-switch mb-0"><input class="form-check-input" type="checkbox" style="width:2.5rem;height:1.25rem"></div></div>
<div class="pay-option"><div class="pay-info"><div class="pay-icon" style="background:#dbeafe;color:#2563eb"><i class="bi bi-bank"></i></div><div><div class="fw-semibold">Bank Transfer</div><small class="text-muted">Direct bank transfer</small></div></div><div class="form-check form-switch mb-0"><input class="form-check-input" type="checkbox" style="width:2.5rem;height:1.25rem"></div></div>
<hr><div class="row g-3 mt-1">
<div class="col-md-4"><label class="form-label">Account Name</label><input type="text" class="form-control" value="MEDIX Pharmacy" name="bank_name"></div>
<div class="col-md-4"><label class="form-label">Account Number</label><input type="text" class="form-control" value="0123-4567890-01" name="bank_account"></div>
<div class="col-md-4"><label class="form-label">Bank Name</label><input type="text" class="form-control" value="HBL - Habib Bank" name="bank"></div>
</div>
<div class="mt-4"><button type="submit" class="btn btn-danger btn-save"><i class="bi bi-save me-2"></i>Save Payment</button></div></form></div></div></div>

<!-- HOURS PANEL -->
<div id="panel-hours" class="s-panel">
<div class="s-card">
<div class="s-card-header"><div class="icon-box" style="background:#f3e8ff;color:#9333ea"><i class="bi bi-clock-history"></i></div><div><h6>Business Hours</h6><small>When your store is open</small></div></div>
<div class="s-card-body"><form method="POST"><div class="row g-3">
<div class="col-md-3"><label class="form-label">Opening Time</label><input type="time" class="form-control" value="09:00" name="opening_time"></div>
<div class="col-md-3"><label class="form-label">Closing Time</label><input type="time" class="form-control" value="21:00" name="closing_time"></div>
<div class="col-md-3"><label class="form-label">Order Cutoff</label><input type="time" class="form-control" value="18:00" name="cutoff_time"><small class="text-muted">Last order for same-day</small></div>
<div class="col-md-3"><label class="form-label">Timezone</label><select class="form-select" name="timezone"><option>Asia/Karachi (PKT +5)</option><option>UTC</option></select></div>
<div class="col-12"><label class="form-label">Working Days</label><div class="days-grid mt-1">
<div class="day-btn on" onclick="this.classList.toggle('on')">Mon</div>
<div class="day-btn on" onclick="this.classList.toggle('on')">Tue</div>
<div class="day-btn on" onclick="this.classList.toggle('on')">Wed</div>
<div class="day-btn on" onclick="this.classList.toggle('on')">Thu</div>
<div class="day-btn on" onclick="this.classList.toggle('on')">Fri</div>
<div class="day-btn on" onclick="this.classList.toggle('on')">Sat</div>
<div class="day-btn" onclick="this.classList.toggle('on')">Sun</div>
</div></div>
</div><div class="mt-4"><button type="submit" class="btn btn-danger btn-save"><i class="bi bi-save me-2"></i>Save Hours</button></div></form></div></div></div>

<!-- SECURITY PANEL -->
<div id="panel-security" class="s-panel">
<div class="s-card">
<div class="s-card-header"><div class="icon-box" style="background:#fee2e2;color:#B91C1C"><i class="bi bi-shield-lock"></i></div><div><h6>Security Settings</h6><small>Manage admin access and password</small></div></div>
<div class="s-card-body"><form method="POST"><div class="row g-3">
<div class="col-md-4"><label class="form-label">Current Password</label><div class="input-icon"><i class="bi bi-lock"></i><input type="password" class="form-control" name="current_password" placeholder="Current password"></div></div>
<div class="col-md-4"><label class="form-label">New Password</label><div class="input-icon"><i class="bi bi-key"></i><input type="password" class="form-control" name="new_password" placeholder="New password"></div></div>
<div class="col-md-4"><label class="form-label">Confirm Password</label><div class="input-icon"><i class="bi bi-key-fill"></i><input type="password" class="form-control" name="confirm_password" placeholder="Confirm password"></div></div>
<div class="col-12"><div style="background:#fef2f2;border:1px solid #fecaca;border-radius:10px;padding:.875rem 1rem;display:flex;align-items:center;gap:.75rem;color:#991b1b;font-size:.875rem"><i class="bi bi-exclamation-triangle-fill" style="font-size:1.1rem"></i><span>Default credentials: <strong>admin / admin123</strong> â€” Change after deployment!</span></div></div>
</div><div class="mt-4"><button type="submit" class="btn btn-danger btn-save"><i class="bi bi-key me-2"></i>Update Password</button></div></form></div></div></div>

<!-- NOTIFICATIONS PANEL -->
<div id="panel-notifications" class="s-panel">
<div class="s-card">
<div class="s-card-header"><div class="icon-box" style="background:#fef3c7;color:#d97706"><i class="bi bi-bell-fill"></i></div><div><h6>Notification Settings</h6><small>Configure alerts and notifications</small></div></div>
<div class="s-card-body"><form method="POST">
<div class="notif-item"><div><div class="fw-semibold">New Order Alerts</div><small class="text-muted">Get notified when a new order is placed</small></div><div class="form-check form-switch mb-0"><input class="form-check-input" type="checkbox" checked style="width:2.5rem;height:1.25rem"></div></div>
<div class="notif-item"><div><div class="fw-semibold">Low Stock Alerts</div><small class="text-muted">Alert when product stock falls below 10</small></div><div class="form-check form-switch mb-0"><input class="form-check-input" type="checkbox" checked style="width:2.5rem;height:1.25rem"></div></div>
<div class="notif-item"><div><div class="fw-semibold">Customer Registration</div><small class="text-muted">Alert when a new customer registers</small></div><div class="form-check form-switch mb-0"><input class="form-check-input" type="checkbox" checked style="width:2.5rem;height:1.25rem"></div></div>
<div class="notif-item"><div><div class="fw-semibold">Order Status Updates</div><small class="text-muted">Notify customers when order status changes</small></div><div class="form-check form-switch mb-0"><input class="form-check-input" type="checkbox" checked style="width:2.5rem;height:1.25rem"></div></div>
<div class="notif-item"><div><div class="fw-semibold">Contact Form Messages</div><small class="text-muted">Alert when customer sends a message</small></div><div class="form-check form-switch mb-0"><input class="form-check-input" type="checkbox" checked style="width:2.5rem;height:1.25rem"></div></div>
<div class="notif-item"><div><div class="fw-semibold">Daily Sales Report</div><small class="text-muted">Receive daily summary via email</small></div><div class="form-check form-switch mb-0"><input class="form-check-input" type="checkbox" style="width:2.5rem;height:1.25rem"></div></div>
<div class="mt-3"><label class="form-label">Notification Email</label><div class="input-icon"><i class="bi bi-envelope"></i><input type="email" class="form-control" name="notif_email" value="admin@medix.com.pk"></div></div>
<div class="mt-4"><button type="submit" class="btn btn-danger btn-save"><i class="bi bi-save me-2"></i>Save Notifications</button></div></form></div></div></div>

<!-- SOCIAL PANEL -->
<div id="panel-social" class="s-panel">
<div class="s-card">
<div class="s-card-header"><div class="icon-box" style="background:#dbeafe;color:#2563eb"><i class="bi bi-share-fill"></i></div><div><h6>Social Media Links</h6><small>Connect your social accounts</small></div></div>
<div class="s-card-body"><form method="POST"><div class="row g-3">
<div class="col-md-6"><div class="social-item"><div class="social-icon" style="background:#dbeafe;color:#1877f2"><i class="bi bi-facebook"></i></div><div class="flex-grow-1"><label class="form-label mb-1">Facebook</label><input type="url" class="form-control" name="facebook" value="https://facebook.com/medixpharmacy"></div></div></div>
<div class="col-md-6"><div class="social-item"><div class="social-icon" style="background:#fce7f3;color:#e1306c"><i class="bi bi-instagram"></i></div><div class="flex-grow-1"><label class="form-label mb-1">Instagram</label><input type="url" class="form-control" name="instagram" value="https://instagram.com/medixpharmacy"></div></div></div>
<div class="col-md-6"><div class="social-item"><div class="social-icon" style="background:#f1f5f9;color:#1da1f2"><i class="bi bi-twitter-x"></i></div><div class="flex-grow-1"><label class="form-label mb-1">Twitter / X</label><input type="url" class="form-control" name="twitter" value="https://twitter.com/medixpharmacy"></div></div></div>
<div class="col-md-6"><div class="social-item"><div class="social-icon" style="background:#d1fae5;color:#25d366"><i class="bi bi-whatsapp"></i></div><div class="flex-grow-1"><label class="form-label mb-1">WhatsApp Business</label><input type="text" class="form-control" name="whatsapp_link" value="+923001234567"></div></div></div>
</div><div class="mt-4"><button type="submit" class="btn btn-danger btn-save"><i class="bi bi-save me-2"></i>Save Social Links</button></div></form></div></div></div>

<!-- SYSTEM PANEL -->
<div id="panel-system" class="s-panel">
<div class="s-card">
<div class="s-card-header"><div class="icon-box" style="background:#f3e8ff;color:#9333ea"><i class="bi bi-cpu"></i></div><div><h6>System Information</h6><small>Current server and system status</small></div></div>
<div class="s-card-body">

<!-- Database Access Buttons -->
<div class="row g-3 mb-4">
<div class="col-md-6">
<a href="database.php" style="display:flex;align-items:center;gap:1rem;padding:1.25rem;background:linear-gradient(135deg,#1e293b,#334155);border-radius:14px;text-decoration:none;color:white;transition:all .2s" onmouseover="this.style.transform='translateY(-3px)'" onmouseout="this.style.transform='none'">
<div style="width:48px;height:48px;background:rgba(255,255,255,.1);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.5rem"><i class="bi bi-database-fill"></i></div>
<div><div style="font-weight:700;font-size:1rem">Database Manager</div><div style="font-size:.8rem;opacity:.7">Browse tables, run SQL queries</div></div>
<i class="bi bi-arrow-right ms-auto"></i>
</a>
</div>
<div class="col-md-6">
<a href="http://localhost/phpmyadmin" target="_blank" style="display:flex;align-items:center;gap:1rem;padding:1.25rem;background:linear-gradient(135deg,#1e40af,#2563eb);border-radius:14px;text-decoration:none;color:white;transition:all .2s" onmouseover="this.style.transform='translateY(-3px)'" onmouseout="this.style.transform='none'">
<div style="width:48px;height:48px;background:rgba(255,255,255,.1);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.5rem"><i class="bi bi-box-arrow-up-right"></i></div>
<div><div style="font-weight:700;font-size:1rem">phpMyAdmin</div><div style="font-size:.8rem;opacity:.7">Full database administration</div></div>
<i class="bi bi-arrow-right ms-auto"></i>
</a>
</div>
<div class="col-md-6">
<a href="../setup_and_import.php" style="display:flex;align-items:center;gap:1rem;padding:1.25rem;background:linear-gradient(135deg,#065f46,#059669);border-radius:14px;text-decoration:none;color:white;transition:all .2s" onmouseover="this.style.transform='translateY(-3px)'" onmouseout="this.style.transform='none'">
<div style="width:48px;height:48px;background:rgba(255,255,255,.1);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.5rem"><i class="bi bi-cloud-download-fill"></i></div>
<div><div style="font-weight:700;font-size:1rem">Import Medicines</div><div style="font-size:.8rem;opacity:.7">Import Pakistan medicines data</div></div>
<i class="bi bi-arrow-right ms-auto"></i>
</a>
</div>
<div class="col-md-6">
<a href="import_medicines.php" style="display:flex;align-items:center;gap:1rem;padding:1.25rem;background:linear-gradient(135deg,#7c3aed,#6d28d9);border-radius:14px;text-decoration:none;color:white;transition:all .2s" onmouseover="this.style.transform='translateY(-3px)'" onmouseout="this.style.transform='none'">
<div style="width:48px;height:48px;background:rgba(255,255,255,.1);border-radius:12px;display:flex;align-items:center;justify-content:center;font-size:1.5rem"><i class="bi bi-capsule-pill"></i></div>
<div><div style="font-weight:700;font-size:1rem">Import from SQL</div><div style="font-size:.8rem;opacity:.7">Import from SQL file</div></div>
<i class="bi bi-arrow-right ms-auto"></i>
</a>
</div>
</div>

<div class="status-grid">
<div class="status-item"><div class="val">v2.0</div><div class="lbl">App Version</div></div>
<div class="status-item"><div class="val">PHP 8.2</div><div class="lbl">PHP Version</div></div>
<div class="status-item"><div class="val">MySQL</div><div class="lbl">Database</div></div>
<div class="status-item"><div class="val">Apache</div><div class="lbl">Web Server</div></div>
<div class="status-item"><div class="val">XAMPP</div><div class="lbl">Environment</div></div>
<div class="status-item"><div class="val" style="color:#10b981">Online</div><div class="lbl">Status</div></div>
</div>
<div class="row g-3">
<div class="col-md-6"><div style="background:#f8fafc;border-radius:10px;padding:1rem;border:1px solid #e2e8f0"><div class="fw-semibold mb-2"><i class="bi bi-database me-2 text-primary"></i>Database</div><div class="text-muted small">Name: medicare_db</div><div class="text-muted small">Host: localhost</div><div class="text-muted small">User: root</div></div></div>
<div class="col-md-6"><div style="background:#f8fafc;border-radius:10px;padding:1rem;border:1px solid #e2e8f0"><div class="fw-semibold mb-2"><i class="bi bi-folder me-2 text-warning"></i>File Paths</div><div class="text-muted small">Root: /ppp/</div><div class="text-muted small">Uploads: /ppp/uploads/</div><div class="text-muted small">Admin: /ppp/admin/</div></div></div>
</div>
</div></div></div>

</div></div><script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script>
function showPanel(id, btn) {
    document.querySelectorAll('.s-panel').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.s-tab').forEach(b => b.classList.remove('active'));
    document.getElementById('panel-' + id).classList.add('active');
    btn.classList.add('active');
}
setTimeout(() => {
    document.querySelectorAll('.alert').forEach(a => bootstrap.Alert.getOrCreateInstance(a)?.close());
}, 4000);
</script>
</body></html>
