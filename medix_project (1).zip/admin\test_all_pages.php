﻿<?php
/**
 * Test All Admin Pages
 * This file tests all admin pages for errors
 */

session_start();
$_SESSION['admin_logged_in'] = true; // Simulate login

echo "<!DOCTYPE html>";
echo "<html><head>";
echo "<title>Admin Pages Test</title>";
echo "<link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css' rel='stylesheet'>";
echo "</head><body class='p-5'>";
echo "<div class='container'>";
echo "<h1 class='mb-4'>Admin Pages Test Results</h1>";

$pages = [
    'index.php' => 'Dashboard',
    'products.php' => 'Products Management',
    'orders.php' => 'Orders Management',
    'customers.php' => 'Customers Management',
    'categories.php' => 'Categories Management',
    'reports.php' => 'Reports',
    'settings.php' => 'Settings'
];

echo "<div class='list-group'>";

foreach ($pages as $file => $name) {
    $path = __DIR__ . '/' . $file;
    
    if (file_exists($path)) {
        // Check for syntax errors
        $output = [];
        $return_var = 0;
        exec("php -l " . escapeshellarg($path), $output, $return_var);
        
        if ($return_var === 0) {
            echo "<div class='list-group-item list-group-item-success'>";
            echo "<i class='bi bi-check-circle-fill'></i> ";
            echo "<strong>$name</strong> ($file) - <span class='text-success'>âœ“ No Errors</span>";
            echo "</div>";
        } else {
            echo "<div class='list-group-item list-group-item-danger'>";
            echo "<i class='bi bi-x-circle-fill'></i> ";
            echo "<strong>$name</strong> ($file) - <span class='text-danger'>âœ— Has Errors</span>";
            echo "<pre class='mt-2'>" . implode("\n", $output) . "</pre>";
            echo "</div>";
        }
    } else {
        echo "<div class='list-group-item list-group-item-warning'>";
        echo "<i class='bi bi-exclamation-triangle-fill'></i> ";
        echo "<strong>$name</strong> ($file) - <span class='text-warning'>âš  File Not Found</span>";
        echo "</div>";
    }
}

echo "</div>";

echo "<div class='mt-4 alert alert-info'>";
echo "<h5>Database Connection Test</h5>";
require_once('../api/config.php');
if ($conn) {
    echo "<p class='text-success mb-0'><i class='bi bi-check-circle-fill'></i> Database connection successful!</p>";
} else {
    echo "<p class='text-danger mb-0'><i class='bi bi-x-circle-fill'></i> Database connection failed!</p>";
}
echo "</div>";

echo "<div class='mt-3'>";
echo "<a href='index.php' class='btn btn-primary'>Go to Dashboard</a>";
echo "</div>";

echo "</div>";
echo "</body></html>";
?>

