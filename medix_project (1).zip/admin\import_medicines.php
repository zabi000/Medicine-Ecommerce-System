﻿<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit();
}

error_reporting(E_ALL);
ini_set('display_errors', 1);
set_time_limit(300);

require_once('../api/config.php');

// Check if import button was clicked
$do_import = isset($_POST['do_import']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Import Medicines - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body { background: #f8f9fa; padding: 2rem; }
        .import-card { background: white; border-radius: 15px; padding: 2rem; box-shadow: 0 4px 12px rgba(0,0,0,0.1); max-width: 1000px; margin: 0 auto; }
        .log-item { padding: 0.5rem; margin: 0.25rem 0; border-radius: 5px; font-family: monospace; font-size: 0.85rem; }
        .log-success { background: #d4edda; color: #155724; }
        .log-error { background: #f8d7da; color: #721c24; }
        .log-warning { background: #fff3cd; color: #856404; }
        .progress { height: 30px; margin-bottom: 1rem; }
    </style>
</head>
<body>
    <div class="import-card">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2><i class="bi bi-capsule-pill"></i> Import Pakistan Medicines</h2>
            <a href="products.php" class="btn btn-secondary"><i class="bi bi-arrow-left"></i> Back to Products</a>
        </div>

        <?php if (!$conn): ?>
            <div class="alert alert-danger">
                <i class="bi bi-exclamation-triangle"></i> Database connection failed. Please check your configuration.
            </div>
        <?php elseif (!$do_import): ?>
            <div class="alert alert-info">
                <i class="bi bi-info-circle"></i> <strong>Ready to import 20 Pakistan medicines!</strong><br>
                This will add authentic medicines with complete details to your database.
            </div>
            
            <div class="row mb-4">
                <div class="col-md-3 text-center p-3">
                    <i class="bi bi-capsule-pill text-danger" style="font-size: 3rem;"></i>
                    <h5 class="mt-2">20 Products</h5>
                    <small class="text-muted">Real medicines</small>
                </div>
                <div class="col-md-3 text-center p-3">
                    <i class="bi bi-lightning-charge-fill text-warning" style="font-size: 3rem;"></i>
                    <h5 class="mt-2">Instant</h5>
                    <small class="text-muted">~5 seconds</small>
                </div>
                <div class="col-md-3 text-center p-3">
                    <i class="bi bi-shield-check-fill text-success" style="font-size: 3rem;"></i>
                    <h5 class="mt-2">Safe</h5>
                    <small class="text-muted">Smart handling</small>
                </div>
                <div class="col-md-3 text-center p-3">
                    <i class="bi bi-tags-fill text-primary" style="font-size: 3rem;"></i>
                    <h5 class="mt-2">Categorized</h5>
                    <small class="text-muted">Auto-sorted</small>
                </div>
            </div>

            <form method="POST" class="text-center">
                <div class="mb-4">
                    <label class="form-label fw-bold">Import Mode:</label>
                    <div class="btn-group d-block" role="group">
                        <input type="radio" class="btn-check" name="import_mode" id="mode_skip" value="skip" checked>
                        <label class="btn btn-outline-warning" for="mode_skip">
                            <i class="bi bi-skip-forward"></i> Skip Existing
                        </label>
                        
                        <input type="radio" class="btn-check" name="import_mode" id="mode_update" value="update">
                        <label class="btn btn-outline-primary" for="mode_update">
                            <i class="bi bi-arrow-repeat"></i> Update Existing
                        </label>
                        
                        <input type="radio" class="btn-check" name="import_mode" id="mode_force" value="force">
                        <label class="btn btn-outline-danger" for="mode_force">
                            <i class="bi bi-plus-circle"></i> Add as New
                        </label>
                    </div>
                    <div class="mt-2">
                        <small class="text-muted">
                            <strong>Skip:</strong> Don't import duplicates | 
                            <strong>Update:</strong> Update existing products | 
                            <strong>Add as New:</strong> Import even if exists
                        </small>
                    </div>
                </div>
                
                <button type="submit" name="do_import" class="btn btn-danger btn-lg px-5 py-3">
                    <i class="bi bi-download me-2"></i>Start Import Now
                </button>
            </form>
        <?php else:
            // Get import mode
            $import_mode = $_POST['import_mode'] ?? 'skip';
            
            // Import medicines data
            $medicines = [
                ['Panadol', 'GSK', '500mg', 'Tablet', 'Fever, mild pain', 'Liver damage (high dose)', NULL, 'No', 35.0],
                ['Brufen', 'Abbott', '400mg', 'Tablet', 'Pain, inflammation', 'Stomach upset', '12+', 'No', 70.0],
                ['Azomax', 'Pfizer', '500mg', 'Tablet', 'Infections (respiratory, skin)', 'Diarrhea, nausea', '12+', 'Yes', 500.0],
                ['Augmentin', 'GSK', '625mg', 'Tablet', 'Strong bacterial infections', 'Diarrhea, nausea', '12+', 'Yes', 600.0],
                ['Flagyl', 'Pfizer', '400mg', 'Tablet', 'Stomach & intestinal infections', 'Metallic taste, nausea', '12+', 'Yes', 80.0],
                ['Disprin', 'Various', '300mg', 'Tablet', 'Headache, blood thinner', 'Stomach bleeding', '16+', 'No', 30.0],
                ['Risek', 'Getz Pharma', '20mg', 'Tablet', 'Acidity, ulcers', 'Headache, stomach pain', '12+', 'Yes', 100.0],
                ['Ponstan', 'Pfizer', '250mg', 'Tablet', 'Cramps, toothache', 'Nausea, headache', '12+', 'Yes', 20.0],
                ['Cetirizine', 'AGP', '10mg', 'Tablet', 'Allergy, sneezing', 'Drowsiness, dizziness', '6+', 'No', 35.0],
                ['Naproxen', 'Bosch', '250mg', 'Tablet', 'Joint pain, cramps', 'Nausea, dizziness', '12+', 'Yes', 15.0],
                ['Zentel', 'GSK', '400mg', 'Tablet', 'Worm infestation', 'Abdominal pain, nausea', '2+', 'No', 60.0],
                ['Betnovate', 'GSK', 'Cream', 'Cream', 'Skin allergies, eczema', 'Burning, thinning skin', 'All ages', 'Yes', 120.0],
                ['Daktarin', 'Janssen', 'Cream', 'Cream', 'Fungal infections', 'Irritation, redness', 'All ages', 'Yes', 130.0],
                ['Caviplex', 'ATCO Pharma', 'Multivitamin', 'Tablet', 'Multivitamin supplement', 'Nausea (rare)', 'All ages', 'No', 100.0],
                ['Volini Gel', 'Reckitt', '1% Diclofenac', 'Gel', 'Muscle pain, sprain', 'Skin irritation', '12+', 'No', 90.0],
                ['Metrogyl Gel', 'Unexo', '2% Metronidazole', 'Gel', 'Acne, skin infection', 'Burning sensation', '12+', 'Yes', 70.0],
                ['Silverex Gel', 'Maxitech Pharma', '1% Silver Sulfadiazine', 'Gel', 'Burns, wounds', 'Skin dryness', 'All ages', 'Yes', 110.0],
                ['Fastum Gel', 'Menarini', '2.5% Ketoprofen', 'Gel', 'Joint/muscle pain', 'Redness, itching', '18+', 'No', 90.0],
                ['Neosporin Ointment', 'GSK', '5000 IU Bacitracin', 'Ointment', 'Infected cuts/allergy', 'Allergy, itching', 'All ages', 'No', 125.0],
                ['Lamisil Gel', 'NOVARTIS', '1% Terbinafine', 'Gel', 'Fungal infections', 'Peeling, dryness', '12+', 'Yes', 100.0],
            ];

            echo '<div class="progress"><div class="progress-bar progress-bar-striped progress-bar-animated bg-success" style="width: 100%">Processing...</div></div>';
            echo '<div style="max-height: 400px; overflow-y: auto; border: 1px solid #ddd; border-radius: 8px; padding: 1rem; background: #f8f9fa;">';

            $imported = 0;
            $skipped = 0;
            $errors = 0;

            foreach ($medicines as $med) {
                list($drug_name, $manufacturer, $strength, $form, $indication, $side_effects, $age_restriction, $prescription_required, $price) = $med;

                try {
                    $product_name = trim($drug_name) . ' ' . trim($strength);
                    if ($form && $form != 'N/A') $product_name .= ' (' . trim($form) . ')';

                    $desc_parts = [];
                    if ($manufacturer) $desc_parts[] = "Manufacturer: $manufacturer";
                    if ($indication) $desc_parts[] = "Uses: $indication";
                    if ($side_effects) $desc_parts[] = "Side Effects: $side_effects";
                    if ($age_restriction) $desc_parts[] = "Age: $age_restriction";
                    if ($prescription_required == 'Yes') $desc_parts[] = "âš ï¸ Prescription Required";
                    
                    $description = implode(' | ', $desc_parts);
                    $final_price = $price ? floatval($price) : rand(50, 300);

                    $category = 'prescription';
                    $name_lower = strtolower($product_name . ' ' . $indication);
                    if (strpos($name_lower, 'vitamin') !== false || strpos($name_lower, 'supplement') !== false) {
                        $category = 'vitamins';
                    } elseif (strpos($name_lower, 'gel') !== false || strpos($name_lower, 'cream') !== false || strpos($name_lower, 'ointment') !== false) {
                        $category = 'skincare';
                    }

                    $check_stmt = $conn->prepare("SELECT id FROM products WHERE name = ? LIMIT 1");
                    $check_stmt->bind_param("s", $product_name);
                    $check_stmt->execute();
                    $result = $check_stmt->get_result();
                    
                    if ($result->num_rows > 0) {
                        $existing_row = $result->fetch_assoc();
                        $existing_id = $existing_row['id'];
                        
                        if ($import_mode == 'skip') {
                            $skipped++;
                            echo '<div class="log-item log-warning">âŠ˜ Skipped: ' . htmlspecialchars($product_name) . ' (already exists)</div>';
                        } elseif ($import_mode == 'update') {
                            $stock = rand(30, 200);
                            $update_stmt = $conn->prepare("UPDATE products SET description = ?, price = ?, category = ?, stock_quantity = ? WHERE id = ?");
                            $update_stmt->bind_param("sdsii", $description, $final_price, $category, $stock, $existing_id);
                            
                            if ($update_stmt->execute()) {
                                $imported++;
                                echo '<div class="log-item log-success">â†» Updated: ' . htmlspecialchars($product_name) . ' - PKR ' . number_format($final_price, 2) . '</div>';
                            } else {
                                $errors++;
                                echo '<div class="log-item log-error">âœ— Update Error: ' . $conn->error . '</div>';
                            }
                        } else { // force mode
                            $stock = rand(30, 200);
                            $stmt = $conn->prepare("INSERT INTO products (name, description, price, category, stock_quantity) VALUES (?, ?, ?, ?, ?)");
                            $stmt->bind_param("ssdsi", $product_name, $description, $final_price, $category, $stock);
                            
                            if ($stmt->execute()) {
                                $imported++;
                                echo '<div class="log-item log-success">âœ“ Added: ' . htmlspecialchars($product_name) . ' - PKR ' . number_format($final_price, 2) . ' (duplicate)</div>';
                            } else {
                                $errors++;
                                echo '<div class="log-item log-error">âœ— Error: ' . $conn->error . '</div>';
                            }
                        }
                    } else {
                        $stock = rand(30, 200);
                        $stmt = $conn->prepare("INSERT INTO products (name, description, price, category, stock_quantity) VALUES (?, ?, ?, ?, ?)");
                        $stmt->bind_param("ssdsi", $product_name, $description, $final_price, $category, $stock);
                        
                        if ($stmt->execute()) {
                            $imported++;
                            echo '<div class="log-item log-success">âœ“ ' . htmlspecialchars($product_name) . ' - PKR ' . number_format($final_price, 2) . '</div>';
                        } else {
                            $errors++;
                            echo '<div class="log-item log-error">âœ— Error: ' . $conn->error . '</div>';
                        }
                    }
                    flush();
                    ob_flush();
                } catch (Exception $e) {
                    $errors++;
                    echo '<div class="log-item log-error">âœ— Exception: ' . $e->getMessage() . '</div>';
                }
            }

            echo '</div>';
            echo '<div class="alert alert-success mt-4">';
            echo '<h5><i class="bi bi-check-circle-fill"></i> Import Complete!</h5>';
            echo '<p class="mb-3"><strong>Mode:</strong> ' . ucfirst($import_mode) . '</p>';
            echo '<div class="row text-center">';
            echo '<div class="col-md-4"><h3 class="text-success">' . $imported . '</h3><small>' . ($import_mode == 'update' ? 'Updated/Added' : 'Imported') . '</small></div>';
            echo '<div class="col-md-4"><h3 class="text-warning">' . $skipped . '</h3><small>Skipped</small></div>';
            echo '<div class="col-md-4"><h3 class="text-danger">' . $errors . '</h3><small>Errors</small></div>';
            echo '</div></div>';
            echo '<div class="text-center mt-4">';
            echo '<a href="products.php" class="btn btn-danger btn-lg me-2"><i class="bi bi-box-seam me-2"></i>View Products</a>';
            echo '<a href="import_medicines.php" class="btn btn-secondary btn-lg"><i class="bi bi-arrow-clockwise me-2"></i>Import Again</a>';
            echo '</div>';
        endif; ?>
    </div>
</body>
</html>

