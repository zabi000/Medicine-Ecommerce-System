﻿<?php
session_start();
require_once('../api/config.php');

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart System Diagnostic - MEDIX</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { padding: 2rem; background: #f8f9fa; }
        .diagnostic-card { background: white; border-radius: 12px; padding: 2rem; margin-bottom: 1.5rem; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        .status-ok { color: #10B981; font-weight: bold; }
        .status-error { color: #EF4444; font-weight: bold; }
        .status-warning { color: #F59E0B; font-weight: bold; }
        pre { background: #f1f5f9; padding: 1rem; border-radius: 8px; overflow-x: auto; }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="mb-4">ðŸ” Cart System Diagnostic</h1>
        
        <!-- Database Connection -->
        <div class="diagnostic-card">
            <h3>1. Database Connection</h3>
            <?php if ($conn): ?>
                <p class="status-ok">âœ“ Database connected successfully</p>
                <p><strong>Database:</strong> <?= DB_NAME ?></p>
            <?php else: ?>
                <p class="status-error">âœ— Database connection failed</p>
            <?php endif; ?>
        </div>

        <!-- Tables Check -->
        <div class="diagnostic-card">
            <h3>2. Database Tables</h3>
            <?php
            $required_tables = ['products', 'orders', 'order_items', 'users'];
            foreach ($required_tables as $table) {
                $result = $conn->query("SHOW TABLES LIKE '$table'");
                if ($result && $result->num_rows > 0) {
                    echo "<p class='status-ok'>âœ“ Table '$table' exists</p>";
                    
                    // Show row count
                    $count_result = $conn->query("SELECT COUNT(*) as count FROM $table");
                    $count = $count_result->fetch_assoc()['count'];
                    echo "<p class='ms-4'>Rows: $count</p>";
                } else {
                    echo "<p class='status-error'>âœ— Table '$table' missing</p>";
                }
            }
            ?>
        </div>

        <!-- Session Check -->
        <div class="diagnostic-card">
            <h3>3. Session Status</h3>
            <p><strong>Session ID:</strong> <?= session_id() ?></p>
            <p><strong>Cart Contents:</strong></p>
            <pre><?php print_r($_SESSION['cart'] ?? []); ?></pre>
            <?php if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])): ?>
                <p class="status-ok">âœ“ Cart has <?= count($_SESSION['cart']) ?> product(s)</p>
            <?php else: ?>
                <p class="status-warning">âš  Cart is empty</p>
            <?php endif; ?>
        </div>

        <!-- Recent Orders -->
        <div class="diagnostic-card">
            <h3>4. Recent Orders (Last 10)</h3>
            <?php
            $orders_result = $conn->query("SELECT o.*, u.name as username FROM orders o LEFT JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC LIMIT 10");
            
            if ($orders_result && $orders_result->num_rows > 0):
            ?>
                <div class="table-responsive">
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Customer</th>
                                <th>Amount</th>
                                <th>Status</th>
                                <th>Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($order = $orders_result->fetch_assoc()): ?>
                            <tr>
                                <td>#<?= $order['id'] ?></td>
                                <td><?= htmlspecialchars($order['username'] ?? 'Guest') ?></td>
                                <td>PKR <?= number_format($order['total_amount'], 2) ?></td>
                                <td><span class="badge bg-<?= $order['status'] == 'pending' ? 'warning' : 'success' ?>"><?= $order['status'] ?></span></td>
                                <td><?= date('M d, Y H:i', strtotime($order['created_at'])) ?></td>
                            </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
                <p class="status-ok">âœ“ Found <?= $orders_result->num_rows ?> recent orders</p>
            <?php else: ?>
                <p class="status-warning">âš  No orders found in database</p>
            <?php endif; ?>
        </div>

        <!-- Order Items Check -->
        <div class="diagnostic-card">
            <h3>5. Order Items (Last Order)</h3>
            <?php
            $last_order = $conn->query("SELECT id FROM orders ORDER BY created_at DESC LIMIT 1");
            if ($last_order && $last_order->num_rows > 0) {
                $order_id = $last_order->fetch_assoc()['id'];
                $items_result = $conn->query("SELECT oi.*, p.name FROM order_items oi LEFT JOIN products p ON oi.product_id = p.id WHERE oi.order_id = $order_id");
                
                if ($items_result && $items_result->num_rows > 0):
                ?>
                    <p><strong>Order #<?= $order_id ?> Items:</strong></p>
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($item = $items_result->fetch_assoc()): ?>
                                <tr>
                                    <td><?= htmlspecialchars($item['name'] ?? 'Unknown') ?></td>
                                    <td><?= $item['quantity'] ?></td>
                                    <td>PKR <?= number_format($item['price'], 2) ?></td>
                                    <td>PKR <?= number_format($item['price'] * $item['quantity'], 2) ?></td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                    <p class="status-ok">âœ“ Order items found</p>
                <?php else: ?>
                    <p class="status-error">âœ— No items found for order #<?= $order_id ?></p>
                <?php endif;
            } else {
                echo "<p class='status-warning'>âš  No orders to check</p>";
            }
            ?>
        </div>

        <!-- Test Actions -->
        <div class="diagnostic-card">
            <h3>6. Test Actions</h3>
            <div class="d-flex gap-2">
                <a href="../cart.php" class="btn btn-primary">View Cart</a>
                <a href="../checkout.php" class="btn btn-success">Go to Checkout</a>
                <a href="orders.php" class="btn btn-info">View Orders Admin</a>
                <a href="../products.php" class="btn btn-secondary">Add Products to Cart</a>
            </div>
        </div>

        <!-- PHP Info -->
        <div class="diagnostic-card">
            <h3>7. PHP Configuration</h3>
            <p><strong>PHP Version:</strong> <?= phpversion() ?></p>
            <p><strong>Session Save Path:</strong> <?= session_save_path() ?></p>
            <p><strong>Error Reporting:</strong> <?= error_reporting() ?></p>
            <p><strong>Display Errors:</strong> <?= ini_get('display_errors') ? 'On' : 'Off' ?></p>
        </div>

        <!-- Error Log -->
        <div class="diagnostic-card">
            <h3>8. Recent PHP Errors</h3>
            <?php
            $error_log_path = ini_get('error_log');
            if ($error_log_path && file_exists($error_log_path)) {
                $errors = file($error_log_path);
                $recent_errors = array_slice($errors, -20);
                echo "<pre>" . htmlspecialchars(implode('', $recent_errors)) . "</pre>";
            } else {
                echo "<p class='status-warning'>âš  Error log not found or not configured</p>";
                echo "<p>Check your PHP error log location in php.ini</p>";
            }
            ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

