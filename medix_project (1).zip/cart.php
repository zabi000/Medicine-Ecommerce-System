﻿<?php
session_start();

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Initialize cart if not exists
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
    error_log("Cart initialized");
}

// Block all cart actions for guests
$is_logged_in = isset($_SESSION['user_id']) && $_SESSION['user_id'] > 0;

// Handle AJAX cart update
if (isset($_POST['ajax_update']) && isset($_POST['product_id']) && isset($_POST['quantity'])) {
    if (!$is_logged_in) {
        header('Content-Type: application/json');
        echo json_encode(['success' => false, 'redirect' => 'login.php']);
        exit;
    }
    require_once('api/config.php');
    
    $product_id = (int)$_POST['product_id'];
    $quantity = (int)$_POST['quantity'];
    
    // Update quantity in session
    if ($quantity > 0) {
        $_SESSION['cart'][$product_id] = $quantity;
    } else {
        unset($_SESSION['cart'][$product_id]);
    }
    
    // Calculate new totals
    $cart_items = [];
    $total = 0;
    
    if (!empty($_SESSION['cart']) && $conn) {
        $ids = implode(',', array_keys($_SESSION['cart']));
        $result = $conn->query("SELECT * FROM products WHERE id IN ($ids)");
        
        if ($result) {
            while ($product = $result->fetch_assoc()) {
                $qty = $_SESSION['cart'][$product['id']];
                $subtotal = $product['price'] * $qty;
                $total += $subtotal;
                
                $cart_items[] = [
                    'id' => $product['id'],
                    'subtotal' => $subtotal
                ];
            }
        }
    }
    
    $shipping = 250;
    $grand_total = $total + $shipping;
    $cart_count = array_sum($_SESSION['cart']);
    
    // Find the item subtotal
    $item_subtotal = 0;
    foreach ($cart_items as $item) {
        if ($item['id'] == $product_id) {
            $item_subtotal = $item['subtotal'];
            break;
        }
    }
    
    // Return JSON response
    header('Content-Type: application/json');
    echo json_encode([
        'success' => true,
        'item_subtotal' => number_format($item_subtotal, 2),
        'subtotal' => number_format($total, 2),
        'total' => number_format($grand_total, 2),
        'cart_count' => $cart_count
    ]);
    exit;
}

// Add to cart
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['product_id'])) {
    if (!$is_logged_in) {
        header('Location: login.php?redirect=cart.php');
        exit;
    }
    require_once('api/config.php');
    $product_id = (int)$_POST['product_id'];
    $quantity = isset($_POST['quantity']) ? (int)$_POST['quantity'] : 1;

    // Check stock
    $stock_check = $conn ? $conn->query("SELECT stock_quantity, name FROM products WHERE id = $product_id") : false;
    if ($stock_check && $stock_check->num_rows > 0) {
        $prod = $stock_check->fetch_assoc();
        $available = (int)$prod['stock_quantity'];
        $already_in_cart = $_SESSION['cart'][$product_id] ?? 0;
        $total_requested = $already_in_cart + $quantity;

        if ($available <= 0) {
            $error_message = "Sorry, <strong>{$prod['name']}</strong> is out of stock.";
        } elseif ($total_requested > $available) {
            $_SESSION['cart'][$product_id] = $available;
            $error_message = "Only <strong>$available units</strong> available. Cart updated to maximum.";
        } else {
            $_SESSION['cart'][$product_id] = $total_requested;
            $success_message = "<strong>{$prod['name']}</strong> added to cart!";
        }
    } else {
        if (isset($_SESSION['cart'][$product_id])) {
            $_SESSION['cart'][$product_id] += $quantity;
        } else {
            $_SESSION['cart'][$product_id] = $quantity;
        }
        $success_message = "Product added to cart!";
    }
}

// Remove from cart
if (isset($_GET['remove'])) {
    $product_id = (int)$_GET['remove'];
    unset($_SESSION['cart'][$product_id]);
    header('Location: cart.php');
    exit;
}

// Update quantity - WITH stock validation
if (isset($_POST['update_cart'])) {
    require_once('api/config.php');
    $update_errors = [];
    foreach ($_POST['quantity'] as $product_id => $quantity) {
        $product_id = intval($product_id);
        $quantity   = intval($quantity);
        if ($quantity <= 0) {
            unset($_SESSION['cart'][$product_id]);
            continue;
        }
        // Check stock
        if ($conn) {
            $s = $conn->query("SELECT name, stock_quantity FROM products WHERE id = $product_id");
            if ($s && $row = $s->fetch_assoc()) {
                $available = (int)$row['stock_quantity'];
                if ($quantity > $available) {
                    $_SESSION['cart'][$product_id] = $available;
                    $update_errors[] = "<strong>{$row['name']}</strong>: Only $available available. Set to $available.";
                } else {
                    $_SESSION['cart'][$product_id] = $quantity;
                }
            } else {
                $_SESSION['cart'][$product_id] = $quantity;
            }
        } else {
            $_SESSION['cart'][$product_id] = $quantity;
        }
    }
    if (!empty($update_errors)) {
        $error_message = "⚠️ Stock adjusted:<br>" . implode('<br>', $update_errors);
    } else {
        $success_message = "Cart updated!";
    }
}

// Clear cart
if (isset($_GET['clear'])) {
    $_SESSION['cart'] = [];
    header('Location: cart.php');
    exit;
}

// Get cart items with product details
$cart_items = [];
$total = 0;

if (!empty($_SESSION['cart'])) {
    require_once('api/config.php');
    
    if ($conn) {
        $ids = implode(',', array_keys($_SESSION['cart']));
        $result = $conn->query("SELECT * FROM products WHERE id IN ($ids)");
        
        if ($result) {
            while ($product = $result->fetch_assoc()) {
                $quantity = $_SESSION['cart'][$product['id']];
                $subtotal = $product['price'] * $quantity;
                $total += $subtotal;
                
                $cart_items[] = [
                    'id'             => $product['id'],
                    'name'           => $product['name'],
                    'price'          => $product['price'],
                    'icon'           => $product['icon'] ?? '💊',
                    'quantity'       => $quantity,
                    'subtotal'       => $subtotal,
                    'stock_quantity' => (int)($product['stock_quantity'] ?? 0)
                ];
            }
        }
    }
}

$cart_count = array_sum($_SESSION['cart']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - Medix</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        :root {
            --primary-color: #B91C1C;
        }
        body {
            background: #f8f9fa;
        }
        .navbar {
            background: linear-gradient(135deg, var(--primary-color), #991B1B);
            padding: 1rem 0;
        }
        .navbar a {
            color: white !important;
            text-decoration: none;
        }
        .cart-container {
            padding: 3rem 0;
        }
        .cart-item {
            background: white;
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
        }
        .product-icon {
            font-size: 3rem;
            text-align: center;
        }
        .cart-summary {
            background: white;
            border-radius: 12px;
            padding: 2rem;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            position: sticky;
            top: 20px;
        }
        .btn-checkout {
            background: var(--primary-color);
            color: white;
            padding: 1rem;
            font-size: 1.1rem;
            border: none;
            border-radius: 8px;
            width: 100%;
        }
        .btn-checkout:hover {
            background: #991B1B;
            color: white;
        }
        .empty-cart {
            text-align: center;
            padding: 4rem 2rem;
            background: white;
            border-radius: 12px;
        }
        .empty-cart i {
            font-size: 5rem;
            color: #ccc;
        }
    </style>
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="d-flex justify-content-between align-items-center w-100">
                <a href="index.html" class="navbar-brand">
                    <i class="bi bi-heart-pulse-fill me-2"></i>
                    <span class="fw-bold">MEDIX</span>
                </a>
                <div class="d-flex gap-3">
                    <a href="index.html">Home</a>
                    <a href="products.php">Products</a>
                    <a href="about.html">About</a>
                    <a href="contact.html">Contact</a>
                </div>
                <div class="d-flex gap-2 align-items-center">
                    <?php if (isset($_SESSION['user_id'])): ?>
                    <div class="dropdown">
                        <button class="btn btn-outline-light btn-sm dropdown-toggle" data-bs-toggle="dropdown">
                            <i class="bi bi-person-circle me-1"></i><?= htmlspecialchars(explode(' ', $_SESSION['user_name'] ?? 'User')[0]) ?>
                        </button>
                        <ul class="dropdown-menu dropdown-menu-end">
                            <li><a class="dropdown-item" href="user/profile.php"><i class="bi bi-person me-2"></i>My Profile</a></li>
                            <li><a class="dropdown-item text-danger" href="user/logout.php"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
                        </ul>
                    </div>
                    <?php else: ?>
                    <a href="login.php" class="btn btn-outline-light btn-sm"><i class="bi bi-person me-1"></i>Login</a>
                    <?php endif; ?>
                    <a href="cart.php" class="position-relative">
                        <i class="bi bi-cart3 fs-4"></i>
                        <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                            <?= $cart_count ?>
                        </span>
                    </a>
                </div>
            </div>
        </div>
    </nav>

    <div class="cart-container container">
        <h2 class="mb-4">
            <i class="bi bi-cart3"></i> Shopping Cart
            <?php if ($cart_count > 0): ?>
                <span class="badge bg-danger" id="cart-count"><?= $cart_count ?></span>
            <?php endif; ?>
        </h2>

        <?php if (isset($success_message)): ?>
            <div class="alert alert-success alert-dismissible fade show">
                <i class="bi bi-check-circle me-2"></i><?= $success_message ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if (isset($error_message)): ?>
            <div class="alert alert-warning alert-dismissible fade show" style="border-left:4px solid #f97316">
                <i class="bi bi-exclamation-triangle-fill me-2"></i><?= $error_message ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        <?php endif; ?>

        <?php if (empty($cart_items)): ?>
            <div class="empty-cart">
                <i class="bi bi-cart-x"></i>
                <h3 class="mt-3">Your cart is empty</h3>
                <p class="text-muted">Add some products to get started!</p>
                <a href="products.php" class="btn btn-primary btn-lg mt-3">
                    <i class="bi bi-shop"></i> Continue Shopping
                </a>
            </div>
        <?php else: ?>
            <div class="row">
                <div class="col-lg-8">
                    <form method="POST">
                        <?php foreach ($cart_items as $item): ?>
                            <div class="cart-item">
                                <div class="row align-items-center">
                                    <div class="col-md-2 text-center">
                                        <?php
                                        $cart_img = $item['image_url'] ?? '';
                                        if (!empty($cart_img)):
                                            if (!str_starts_with($cart_img, 'http') && !str_starts_with($cart_img, '/')) {
                                                $cart_img = '/ppp/' . ltrim($cart_img, '/');
                                            }
                                        ?>
                                        <img src="<?= htmlspecialchars($cart_img) ?>" alt="<?= htmlspecialchars($item['name']) ?>"
                                             style="width:70px;height:70px;object-fit:cover;border-radius:10px;border:2px solid #f1f5f9"
                                             onerror="this.style.display='none';this.nextElementSibling.style.display='block'">
                                        <div class="product-icon" style="display:none"><?= $item['icon'] ?? '💊' ?></div>
                                        <?php else: ?>
                                        <div class="product-icon"><?= $item['icon'] ?? '💊' ?></div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-4">
                                        <h5><?= htmlspecialchars($item['name']) ?></h5>
                                        <p class="text-muted mb-0">PKR <?= number_format($item['price'], 2) ?> each</p>
                                        <?php $avail = $item['stock_quantity'] ?? 999; ?>
                                        <?php if ($avail <= 10): ?>
                                            <small style="color:#f97316;font-weight:600">
                                                <i class="bi bi-exclamation-triangle-fill me-1"></i>Only <?= $avail ?> left
                                            </small>
                                        <?php endif; ?>
                                    </div>
                                    <div class="col-md-3">
                                        <div class="input-group">
                                            <button type="button" class="btn btn-outline-secondary" onclick="decreaseQty(<?= $item['id'] ?>)">-</button>
                                            <input type="number" name="quantity[<?= $item['id'] ?>]" id="qty-<?= $item['id'] ?>"
                                                   value="<?= $item['quantity'] ?>"
                                                   min="1"
                                                   max="<?= $item['stock_quantity'] ?? 9999 ?>"
                                                   class="form-control text-center"
                                                   style="max-width: 80px;"
                                                   oninput="enforceMax(this)">
                                            <button type="button" class="btn btn-outline-secondary" onclick="increaseQty(<?= $item['id'] ?>)">+</button>
                                        </div>
                                        <small class="text-muted" style="font-size:.7rem">Max: <?= $item['stock_quantity'] ?? '∞' ?></small>
                                    </div>
                                    <div class="col-md-2 text-end">
                                        <h5 class="text-primary mb-0 item-subtotal">PKR <?= number_format($item['subtotal'], 2) ?></h5>
                                    </div>
                                    <div class="col-md-1 text-end">
                                        <a href="?remove=<?= $item['id'] ?>" class="btn btn-sm btn-outline-danger" onclick="return confirm('Remove this item?')">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>

                        <div class="d-flex gap-2 mt-3">
                            <button type="submit" name="update_cart" class="btn btn-outline-primary">
                                <i class="bi bi-arrow-clockwise"></i> Refresh Cart
                            </button>
                            <a href="?clear=1" class="btn btn-outline-danger" onclick="return confirm('Clear entire cart?')">
                                <i class="bi bi-trash"></i> Clear Cart
                            </a>
                            <a href="products.php" class="btn btn-outline-secondary ms-auto">
                                <i class="bi bi-arrow-left"></i> Continue Shopping
                            </a>
                        </div>
                        <p class="text-muted mt-2 mb-0"><small><i class="bi bi-info-circle"></i> Cart updates automatically when you change quantities</small></p>
                    </form>
                </div>

                <div class="col-lg-4">
                    <div class="cart-summary">
                        <h4 class="mb-4">Order Summary</h4>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Subtotal:</span>
                            <strong id="cart-subtotal">PKR <?= number_format($total, 2) ?></strong>
                        </div>
                        <div class="d-flex justify-content-between mb-2">
                            <span>Shipping:</span>
                            <strong>PKR 250.00</strong>
                        </div>
                        <div class="d-flex justify-content-between mb-2 text-success">
                            <span>Discount:</span>
                            <strong>- PKR 0.00</strong>
                        </div>
                        <hr>
                        <div class="d-flex justify-content-between mb-4">
                            <h5>Total:</h5>
                            <h5 class="text-primary" id="cart-total">PKR <?= number_format($total + 250, 2) ?></h5>
                        </div>

                        <?php
                        // Check if any item exceeds stock
                        $has_stock_issue = false;
                        $stock_issue_msg = '';
                        foreach ($cart_items as $item) {
                            $available = (int)($item['stock_quantity'] ?? 0);
                            // Only block if stock tracking is active (available > 0 means we track it)
                            // AND quantity exceeds available
                            if ($available > 0 && $item['quantity'] > $available) {
                                $has_stock_issue = true;
                                $stock_issue_msg .= "<li><strong>" . htmlspecialchars($item['name']) . "</strong>: You want {$item['quantity']} but only <strong>$available</strong> in stock.</li>";
                            }
                        }
                        ?>

                        <?php if ($has_stock_issue): ?>
                            <div class="alert alert-danger mb-3" style="border-radius:10px;font-size:.875rem">
                                <i class="bi bi-exclamation-triangle-fill me-2"></i>
                                <strong>Cannot checkout — stock issue:</strong>
                                <ul class="mb-0 mt-1"><?= $stock_issue_msg ?></ul>
                                <div class="mt-2 text-muted">Please reduce the quantity to match available stock.</div>
                            </div>
                            <button class="btn btn-checkout" disabled style="opacity:.5;cursor:not-allowed;background:#9ca3af;border:none">
                                <i class="bi bi-x-circle me-2"></i>Checkout Unavailable
                            </button>
                        <?php else: ?>
                            <a href="checkout.php" class="btn btn-checkout">
                                <i class="bi bi-credit-card me-2"></i>Proceed to Checkout
                            </a>
                        <?php endif; ?>
                        <div class="mt-3 text-center">
                            <small class="text-muted">
                                <i class="bi bi-shield-check"></i> Secure Checkout
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function enforceMax(input) {
            const max = parseInt(input.max);
            const val = parseInt(input.value);
            if (max && val > max) {
                input.value = max;
                input.style.borderColor = '#ef4444';
                input.title = 'Maximum available: ' + max;
                setTimeout(() => input.style.borderColor = '', 2000);
            }
        }

        function increaseQty(id) {
            const input = document.getElementById('qty-' + id);
            const max = parseInt(input.max) || 9999;
            const newVal = parseInt(input.value) + 1;
            if (newVal > max) {
                input.style.borderColor = '#ef4444';
                setTimeout(() => input.style.borderColor = '', 1500);
                // Show tooltip
                showStockMsg(id, 'Only ' + max + ' available!');
                return;
            }
            input.value = newVal;
            updateCartAjax(id, input.value);
        }
        
        function decreaseQty(id) {
            const input = document.getElementById('qty-' + id);
            if (parseInt(input.value) > 1) {
                input.value = parseInt(input.value) - 1;
                updateCartAjax(id, input.value);
            }
        }
        
        // Auto-update cart when quantity changes
        function showStockMsg(id, msg) {
            let el = document.getElementById('stock-msg-' + id);
            if (!el) {
                el = document.createElement('div');
                el.id = 'stock-msg-' + id;
                el.style.cssText = 'color:#ef4444;font-size:.75rem;font-weight:600;margin-top:.25rem';
                document.getElementById('qty-' + id).parentElement.after(el);
            }
            el.textContent = msg;
            setTimeout(() => el.textContent = '', 3000);
        }

        function updateCartAjax(productId, quantity) {
            // Show loading indicator
            const row = document.getElementById('qty-' + productId).closest('.cart-item');
            row.style.opacity = '0.6';
            
            // Send AJAX request
            const formData = new FormData();
            formData.append('ajax_update', '1');
            formData.append('product_id', productId);
            formData.append('quantity', quantity);
            
            fetch('cart.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.redirect) {
                    window.location.href = data.redirect;
                    return;
                }
                if (data.success) {
                    // Update subtotal for this item
                    const subtotalElement = row.querySelector('.item-subtotal');
                    if (subtotalElement) {
                        subtotalElement.textContent = 'PKR ' + data.item_subtotal;
                    }
                    
                    // Update cart totals
                    document.getElementById('cart-subtotal').textContent = 'PKR ' + data.subtotal;
                    document.getElementById('cart-total').textContent = 'PKR ' + data.total;
                    document.getElementById('cart-count').textContent = data.cart_count;
                    
                    // Update cart badge in navbar
                    const badges = document.querySelectorAll('.badge.bg-danger');
                    badges.forEach(badge => {
                        badge.textContent = data.cart_count;
                    });
                    
                    // Show success feedback
                    row.style.opacity = '1';
                    row.style.transition = 'all 0.3s';
                    row.style.background = '#f0fdf4';
                    setTimeout(() => {
                        row.style.background = 'white';
                    }, 500);
                } else {
                    alert('Failed to update cart');
                    row.style.opacity = '1';
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('Error updating cart');
                row.style.opacity = '1';
            });
        }
        
        // Also update when user types in the input
        document.addEventListener('DOMContentLoaded', function() {
            const qtyInputs = document.querySelectorAll('input[name^="quantity"]');
            qtyInputs.forEach(input => {
                input.addEventListener('change', function() {
                    const productId = this.name.match(/\d+/)[0];
                    const quantity = parseInt(this.value);
                    if (quantity > 0) {
                        updateCartAjax(productId, quantity);
                    }
                });
            });
        });
    </script>
</body>
</html>

