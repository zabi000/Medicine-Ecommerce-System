<?php
session_start();
header('Content-Type: application/json');

if (!isset($_SESSION['admin_logged_in'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit();
}

require_once('../api/config.php');

$id = intval($_GET['id'] ?? 0);
if (!$id || !$conn) {
    echo json_encode(['error' => 'Invalid request']);
    exit();
}

// Get order info
$col_check = $conn->query("SHOW COLUMNS FROM orders LIKE 'customer_name'");
$has_cust  = ($col_check && $col_check->num_rows > 0);

if ($has_cust) {
    $oq = $conn->query("SELECT o.*,
        CASE WHEN o.customer_name IS NOT NULL AND o.customer_name != '' THEN o.customer_name
             ELSE COALESCE(u.name, u.username, 'Guest') END AS cname,
        CASE WHEN o.customer_email IS NOT NULL AND o.customer_email != '' THEN o.customer_email
             ELSE COALESCE(u.email, '') END AS cemail,
        CASE WHEN o.customer_phone IS NOT NULL AND o.customer_phone != '' THEN o.customer_phone
             ELSE COALESCE(u.phone, '') END AS cphone
        FROM orders o LEFT JOIN users u ON o.user_id = u.id
        WHERE o.id = $id");
} else {
    $oq = $conn->query("SELECT o.*, COALESCE(u.name, u.username, 'Guest') AS cname,
        COALESCE(u.email,'') AS cemail, COALESCE(u.phone,'') AS cphone
        FROM orders o LEFT JOIN users u ON o.user_id = u.id
        WHERE o.id = $id");
}

if (!$oq || $oq->num_rows === 0) {
    echo json_encode(['error' => 'Order not found']);
    exit();
}

$order = $oq->fetch_assoc();

// Get order items with product details
$iq = $conn->query("SELECT oi.*, p.name, p.category, p.image_url
    FROM order_items oi
    LEFT JOIN products p ON oi.product_id = p.id
    WHERE oi.order_id = $id
    ORDER BY oi.id ASC");

$items = [];
if ($iq) {
    while ($row = $iq->fetch_assoc()) {
        $items[] = [
            'name'      => $row['name'] ?? 'Unknown Product',
            'category'  => $row['category'] ?? '',
            'quantity'  => (int)$row['quantity'],
            'price'     => (float)$row['price'],
            'image_url' => $row['image_url'] ?? '',
        ];
    }
}

echo json_encode([
    'order' => [
        'id'             => $order['id'],
        'cname'          => $order['cname'],
        'cemail'         => $order['cemail'],
        'cphone'         => $order['cphone'],
        'address'        => $order['shipping_address'] ?? '',
        'payment_method' => $order['payment_method'] ?? 'Cash on Delivery',
        'status'         => $order['status'],
        'total_amount'   => number_format((float)$order['total_amount'], 0),
        'created_at'     => date('M d, Y h:i A', strtotime($order['created_at'])),
        'payment_proof'  => $order['payment_proof'] ?? null,
        'payment_proof_at' => !empty($order['payment_proof_at']) ? date('M d, Y h:i A', strtotime($order['payment_proof_at'])) : null,
    ],
    'items' => $items
]);
?>
