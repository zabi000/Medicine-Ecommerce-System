<?php
require_once('api/config.php');

echo "<h2>Adding Professional Product Images</h2>";
echo "<p>This will add high-quality images to all products in your database...</p>";

// Professional medicine and healthcare product images from Unsplash
$category_images = [
    'vitamins' => [
        'https://images.unsplash.com/photo-1550572017-4a6e8e0b0b3f?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1607619056574-7b8d3ee536b2?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1505751172876-fa1923c5c528?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1471864190281-a93a3070b6de?w=500&h=500&fit=crop'
    ],
    'skincare' => [
        'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1570554886111-e80fcca6a029?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1612817288484-6f916006741a?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=500&h=500&fit=crop'
    ],
    'firstaid' => [
        'https://images.unsplash.com/photo-1603398938378-e54eab446dde?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1631549916768-4119b2e5f926?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1603791440384-56cd371ee9a7?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1585435557343-3b092031a831?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=500&h=500&fit=crop'
    ],
    'devices' => [
        'https://images.unsplash.com/photo-1530026405186-ed1f139313f8?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1581595220892-b0739db3ba8c?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1584362917165-526a968579e8?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1615486511484-92e172cc4fe0?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1582719471384-894fbb16e074?w=500&h=500&fit=crop'
    ],
    'prescription' => [
        'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1471864190281-a93a3070b6de?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1585435557343-3b092031a831?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1550572017-4a6e8e0b0b3f?w=500&h=500&fit=crop'
    ],
    'personal' => [
        'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1612817288484-6f916006741a?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1570554886111-e80fcca6a029?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=500&h=500&fit=crop'
    ],
    'baby' => [
        'https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1596461404969-9ae70f2830c1?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1555252333-9f8e92e65df9?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1515488042361-ee00e0ddd4e4?w=500&h=500&fit=crop'
    ],
    'supplements' => [
        'https://images.unsplash.com/photo-1550572017-4a6e8e0b0b3f?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1607619056574-7b8d3ee536b2?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1505751172876-fa1923c5c528?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1471864190281-a93a3070b6de?w=500&h=500&fit=crop',
        'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=500&h=500&fit=crop'
    ]
];

// Default fallback images
$default_images = [
    'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=500&h=500&fit=crop',
    'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=500&h=500&fit=crop',
    'https://images.unsplash.com/photo-1471864190281-a93a3070b6de?w=500&h=500&fit=crop',
    'https://images.unsplash.com/photo-1550572017-4a6e8e0b0b3f?w=500&h=500&fit=crop',
    'https://images.unsplash.com/photo-1603398938378-e54eab446dde?w=500&h=500&fit=crop'
];

if (!$conn) {
    die("<p style='color: red;'>Database connection failed!</p>");
}

// Get all products
$result = $conn->query("SELECT id, name, category FROM products ORDER BY id");

if (!$result) {
    die("<p style='color: red;'>Error fetching products: " . $conn->error . "</p>");
}

$updated_count = 0;
$image_index = [];

echo "<div style='background: white; padding: 20px; border-radius: 8px; margin: 20px 0;'>";
echo "<h3>Updating Products...</h3>";
echo "<table border='1' cellpadding='10' style='width: 100%; border-collapse: collapse;'>";
echo "<tr style='background: #B91C1C; color: white;'>";
echo "<th>ID</th><th>Product Name</th><th>Category</th><th>Image URL</th><th>Status</th>";
echo "</tr>";

while ($product = $result->fetch_assoc()) {
    $product_id = $product['id'];
    $product_name = $product['name'];
    $category = strtolower($product['category']);
    
    // Initialize index for this category if not exists
    if (!isset($image_index[$category])) {
        $image_index[$category] = 0;
    }
    
    // Get image for this category
    if (isset($category_images[$category])) {
        $images = $category_images[$category];
        $image_url = $images[$image_index[$category] % count($images)];
        $image_index[$category]++;
    } else {
        // Use default images if category not found
        $image_url = $default_images[$updated_count % count($default_images)];
    }
    
    // Update product with image
    $stmt = $conn->prepare("UPDATE products SET image_url = ? WHERE id = ?");
    $stmt->bind_param("si", $image_url, $product_id);
    
    if ($stmt->execute()) {
        $updated_count++;
        $status = "<span style='color: green; font-weight: bold;'>✓ Updated</span>";
    } else {
        $status = "<span style='color: red;'>✗ Failed</span>";
    }
    
    echo "<tr>";
    echo "<td>$product_id</td>";
    echo "<td>" . htmlspecialchars($product_name) . "</td>";
    echo "<td>" . htmlspecialchars($category) . "</td>";
    echo "<td style='font-size: 0.8em;'>" . htmlspecialchars($image_url) . "</td>";
    echo "<td>$status</td>";
    echo "</tr>";
    
    $stmt->close();
}

echo "</table>";
echo "</div>";

echo "<div style='background: #D1FAE5; padding: 20px; border-radius: 8px; border-left: 4px solid #10B981; margin: 20px 0;'>";
echo "<h3 style='color: #065F46; margin: 0 0 10px 0;'>✓ Success!</h3>";
echo "<p style='color: #065F46; margin: 0;'><strong>$updated_count products</strong> have been updated with professional images.</p>";
echo "</div>";

echo "<div style='background: #DBEAFE; padding: 20px; border-radius: 8px; border-left: 4px solid #3B82F6; margin: 20px 0;'>";
echo "<h3 style='color: #1E40AF; margin: 0 0 10px 0;'>ℹ️ Next Steps:</h3>";
echo "<ol style='color: #1E40AF; margin: 0;'>";
echo "<li>Visit <a href='products.php' style='color: #1E40AF; font-weight: bold;'>products.php</a> to see your products with images</li>";
echo "<li>Visit <a href='index.html' style='color: #1E40AF; font-weight: bold;'>homepage</a> to see featured products</li>";
echo "<li>You can change individual product images from the <a href='admin/products.php' style='color: #1E40AF; font-weight: bold;'>admin panel</a></li>";
echo "</ol>";
echo "</div>";

echo "<div style='text-align: center; margin: 30px 0;'>";
echo "<a href='products.php' style='background: linear-gradient(135deg, #B91C1C, #991B1B); color: white; padding: 15px 40px; border-radius: 10px; text-decoration: none; font-weight: bold; display: inline-block; margin-right: 10px;'>";
echo "View Products Page";
echo "</a>";
echo "<a href='index.html' style='background: linear-gradient(135deg, #3B82F6, #2563EB); color: white; padding: 15px 40px; border-radius: 10px; text-decoration: none; font-weight: bold; display: inline-block;'>";
echo "View Homepage";
echo "</a>";
echo "</div>";

$conn->close();
?>
