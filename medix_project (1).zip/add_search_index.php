<?php
require_once('api/config.php');
if (!$conn) die("DB failed");

// Add index on name column for faster search
$conn->query("ALTER TABLE products ADD FULLTEXT INDEX IF NOT EXISTS ft_name (name)");
$conn->query("CREATE INDEX IF NOT EXISTS idx_name ON products (name(50))");
$conn->query("CREATE INDEX IF NOT EXISTS idx_category ON products (category)");

echo "<p style='color:green;font-family:Arial;padding:1rem'>✅ Search indexes added! Search is now faster.</p>";
echo "<a href='products.php' style='padding:10px 20px;background:#B91C1C;color:white;text-decoration:none;border-radius:8px;font-family:Arial'>Test Search</a>";
?>
