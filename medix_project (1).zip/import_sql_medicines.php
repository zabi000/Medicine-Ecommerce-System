<?php
/**
 * Import Medicines from SQL File
 * Place your import_medicines.sql file in the database/ folder
 */

error_reporting(E_ALL);
ini_set('display_errors', 1);
set_time_limit(300);

require_once('api/config.php');

$sql_file = 'database/import_medicines.sql'; // Update this path if needed

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Import SQL Medicines</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        body {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 2rem;
        }
        .import-card {
            background: white;
            border-radius: 15px;
            padding: 2rem;
            box-shadow: 0 10px 40px rgba(0,0,0,0.2);
            max-width: 900px;
            margin: 0 auto;
        }
        .log-item {
            padding: 0.5rem;
            margin: 0.25rem 0;
            border-radius: 5px;
            font-family: monospace;
            font-size: 0.85rem;
        }
        .log-success { background: #d4edda; color: #155724; }
        .log-error { background: #f8d7da; color: #721c24; }
        .log-info { background: #d1ecf1; color: #0c5460; }
    </style>
</head>
<body>
    <div class="import-card">
        <h2 class="text-center mb-4">
            <i class="bi bi-database-fill-add"></i> Import SQL Medicines
        </h2>

        <?php
        // Check if SQL file exists
        if (!file_exists($sql_file)) {
            ?>
            <div class="alert alert-warning">
                <h5><i class="bi bi-exclamation-triangle"></i> SQL File Not Found</h5>
                <p>Please follow these steps:</p>
                <ol>
                    <li>Copy your <code>import_medicines.sql</code> file</li>
                    <li>Paste it in the <code>database/</code> folder</li>
                    <li>Make sure it's named: <code>import_medicines.sql</code></li>
                    <li>Refresh this page</li>
                </ol>
                <p class="mb-0"><strong>Current location expected:</strong> <code><?= $sql_file ?></code></p>
            </div>
            <?php
            exit;
        }

        // Check database connection
        if (!$conn) {
            ?>
            <div class="alert alert-danger">
                <h5>Database Connection Failed</h5>
                <p>Please check your database configuration in <code>api/config.php</code></p>
            </div>
            <?php
            exit;
        }

        echo '<div class="alert alert-info">';
        echo '<strong>Starting SQL import...</strong><br>';
        echo 'File: ' . $sql_file . '<br>';
        echo 'File size: ' . number_format(filesize($sql_file) / 1024, 2) . ' KB<br>';
        echo '</div>';

        // Read SQL file
        $sql_content = file_get_contents($sql_file);
        
        // Split into individual statements
        $statements = array_filter(
            array_map('trim', explode(';', $sql_content)),
            function($stmt) {
                return !empty($stmt) && 
                       !preg_match('/^--/', $stmt) && 
                       !preg_match('/^\/\*/', $stmt);
            }
        );

        echo '<div class="mt-4"><h5>Executing SQL Statements:</h5><div id="log-container">';

        $success_count = 0;
        $error_count = 0;

        foreach ($statements as $index => $statement) {
            $statement = trim($statement);
            
            if (empty($statement)) continue;

            try {
                if ($conn->query($statement)) {
                    $success_count++;
                    
                    // Show preview of statement
                    $preview = substr($statement, 0, 100);
                    if (strlen($statement) > 100) $preview .= '...';
                    
                    echo '<div class="log-item log-success">';
                    echo '✓ Statement ' . ($index + 1) . ': ' . htmlspecialchars($preview);
                    echo '</div>';
                    
                    // Check if it was an INSERT and show affected rows
                    if (stripos($statement, 'INSERT') === 0) {
                        $affected = $conn->affected_rows;
                        if ($affected > 0) {
                            echo '<div class="log-item log-info">';
                            echo '  → Inserted ' . $affected . ' row(s)';
                            echo '</div>';
                        }
                    }
                } else {
                    $error_count++;
                    echo '<div class="log-item log-error">';
                    echo '✗ Statement ' . ($index + 1) . ': ' . $conn->error;
                    echo '<br><small>' . htmlspecialchars(substr($statement, 0, 150)) . '...</small>';
                    echo '</div>';
                }
                
                // Flush output every 10 statements
                if ($index % 10 == 0) {
                    flush();
                    ob_flush();
                }
                
            } catch (Exception $e) {
                $error_count++;
                echo '<div class="log-item log-error">';
                echo '✗ Exception: ' . $e->getMessage();
                echo '</div>';
            }
        }

        echo '</div></div>';

        // Count products
        $result = $conn->query("SELECT COUNT(*) as total FROM products");
        $total_products = $result ? $result->fetch_assoc()['total'] : 0;

        // Summary
        echo '<div class="alert alert-success mt-4">';
        echo '<h5><i class="bi bi-check-circle"></i> Import Complete!</h5>';
        echo '<ul>';
        echo '<li><strong>SQL Statements Executed:</strong> ' . count($statements) . '</li>';
        echo '<li><strong>Successful:</strong> ' . $success_count . '</li>';
        echo '<li><strong>Errors:</strong> ' . $error_count . '</li>';
        echo '<li><strong>Total Products in Database:</strong> ' . $total_products . '</li>';
        echo '</ul>';
        echo '</div>';

        echo '<div class="text-center mt-4">';
        echo '<a href="admin/products.php" class="btn btn-danger btn-lg me-2">';
        echo '<i class="bi bi-box-seam me-2"></i>View Products in Admin';
        echo '</a>';
        echo '<a href="products.php" class="btn btn-primary btn-lg">';
        echo '<i class="bi bi-shop me-2"></i>View Store';
        echo '</a>';
        echo '</div>';
        ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
