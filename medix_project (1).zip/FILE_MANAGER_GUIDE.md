# File Manager System - Complete Guide

## Overview
A complete file upload and management system for the Medix admin panel that allows uploading, organizing, and managing various file types.

## Features

### 1. File Upload
- **Drag & Drop Interface** - Simply drag files into the upload zone
- **Click to Browse** - Traditional file selection
- **Multiple Categories**:
  - Images (JPG, JPEG, PNG, GIF, WEBP, SVG)
  - Documents (PDF, DOC, DOCX, TXT, XLSX, XLS)
  - Data Files (CSV, SQL, JSON, XML)
  - Archives (ZIP, RAR, 7Z)

### 2. File Management
- View all uploaded files with details
- Download any file
- Delete files
- Add descriptions to files
- Track upload date and time
- See file size and type

### 3. Statistics Dashboard
- Total files count
- Total images count
- Total documents count
- Total storage used (in MB)

### 4. Security Features
- File type validation
- Unique filename generation
- Secure file storage
- .htaccess protection
- Admin authentication required

## Setup Instructions

### Step 1: Run Setup Script
1. Open your browser
2. Navigate to: `http://your-domain.com/setup_file_manager.php`
3. The script will automatically:
   - Create the `uploaded_files` database table
   - Create upload directories (uploads/images, uploads/documents, etc.)
   - Set up security files
   - Test permissions

### Step 2: Access File Manager
1. Login to admin panel
2. Click "File Manager" in the sidebar
3. Start uploading files!

## File Structure Created

```
project/
├── admin/
│   └── file_manager.php          # Main file manager page
├── uploads/                       # Upload directory (created automatically)
│   ├── .htaccess                 # Security file
│   ├── images/                   # Image files
│   ├── documents/                # Document files
│   ├── data/                     # Data files (CSV, SQL, JSON)
│   └── temp/                     # Archive files
├── database/
│   └── file_manager.sql          # Database schema
└── setup_file_manager.php        # Setup script
```

## Database Table

The `uploaded_files` table stores:
- `id` - Unique file ID
- `original_name` - Original filename
- `stored_name` - Unique stored filename
- `file_path` - Full path to file
- `file_type` - File extension
- `file_size` - Size in bytes
- `category` - File category (images/documents/data/temp)
- `description` - Optional description
- `uploaded_by` - Admin who uploaded
- `uploaded_at` - Upload timestamp

## Usage Examples

### Upload Product Images
1. Go to File Manager
2. Select "Images" category
3. Upload product photos
4. Copy the file path to use in products

### Import Data Files
1. Select "Data Files" category
2. Upload CSV or SQL files
3. Use for bulk imports

### Store Documents
1. Select "Documents" category
2. Upload PDFs, invoices, reports
3. Download when needed

## Adding File Manager Link to Sidebar

Add this to any admin page sidebar:

```php
<a href="file_manager.php">
    <i class="bi bi-folder"></i> File Manager
</a>
```

## Supported File Types

### Images
- JPG, JPEG - Standard photos
- PNG - Transparent images
- GIF - Animated images
- WEBP - Modern format
- SVG - Vector graphics

### Documents
- PDF - Portable documents
- DOC, DOCX - Word documents
- TXT - Text files
- XLSX, XLS - Excel spreadsheets

### Data Files
- CSV - Comma-separated values
- SQL - Database dumps
- JSON - Data interchange
- XML - Structured data

### Archives
- ZIP - Compressed files
- RAR - WinRAR archives
- 7Z - 7-Zip archives

## Security Notes

1. **File Validation** - Only allowed file types can be uploaded
2. **Unique Names** - Files are renamed to prevent conflicts
3. **Directory Protection** - .htaccess prevents direct browsing
4. **Admin Only** - Requires admin login
5. **Size Limits** - Respects PHP upload limits

## Troubleshooting

### "Upload directory is not writable"
- Set permissions: `chmod 777 uploads/`
- Or use FTP client to set folder permissions

### "File type not allowed"
- Check if file extension is in allowed list
- Verify category selection matches file type

### "Upload failed"
- Check PHP upload_max_filesize in php.ini
- Check post_max_size in php.ini
- Verify disk space available

## Integration with Other Features

### Use with Products
1. Upload product images to File Manager
2. Copy image path
3. Use path in product image URL field

### Use with Import System
1. Upload CSV/SQL files
2. Process them through import pages
3. Keep organized in data/ folder

### Use for Backups
1. Export database to SQL
2. Upload to File Manager
3. Download when needed

## Future Enhancements

Possible additions:
- Image preview/thumbnail generation
- Bulk upload multiple files
- File search and filtering
- Folder organization
- File sharing links
- Image editing tools
- File versioning

## Support

For issues or questions:
1. Check setup was completed successfully
2. Verify file permissions
3. Check PHP error logs
4. Ensure database table exists

---

**File Manager is now ready to use!**

Access it at: `admin/file_manager.php`
