-- Add Skincare and Vitamin Products with Images

-- Skincare Products
INSERT INTO products (name, description, price, category, stock, image_url, icon) VALUES
('Vitamin C Serum', 'Brightening face serum with 20% Vitamin C for glowing skin', 1299.00, 'skincare', 45, 'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=400&h=400&fit=crop', '✨'),
('Hyaluronic Acid Moisturizer', 'Deep hydration cream with hyaluronic acid for all skin types', 899.00, 'skincare', 60, 'https://images.unsplash.com/photo-1556228578-8c89e6adf883?w=400&h=400&fit=crop', '💧'),
('Retinol Night Cream', 'Anti-aging night cream with retinol for wrinkle reduction', 1599.00, 'skincare', 35, 'https://images.unsplash.com/photo-1570194065650-d99fb4bedf0a?w=400&h=400&fit=crop', '🌙'),
('Niacinamide Face Serum', 'Pore minimizing serum with 10% niacinamide', 1099.00, 'skincare', 50, 'https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?w=400&h=400&fit=crop', '🎯'),
('Sunscreen SPF 50+', 'Broad spectrum UV protection for daily use', 799.00, 'skincare', 80, 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=400&h=400&fit=crop', '☀️'),
('Aloe Vera Gel', 'Pure aloe vera gel for soothing and healing skin', 499.00, 'skincare', 100, 'https://images.unsplash.com/photo-1596755389378-c31d21fd1273?w=400&h=400&fit=crop', '🌿'),
('Charcoal Face Mask', 'Deep cleansing activated charcoal mask', 699.00, 'skincare', 55, 'https://images.unsplash.com/photo-1598440947619-2c35fc9aa908?w=400&h=400&fit=crop', '🖤'),
('Rose Water Toner', 'Natural rose water facial toner for refreshing skin', 549.00, 'skincare', 70, 'https://images.unsplash.com/photo-1571875257727-256c39da42af?w=400&h=400&fit=crop', '🌹'),
('Collagen Cream', 'Anti-aging collagen boosting face cream', 1399.00, 'skincare', 40, 'https://images.unsplash.com/photo-1556228852-80c3b8de4a97?w=400&h=400&fit=crop', '💎'),
('Tea Tree Oil Serum', 'Acne treatment serum with tea tree oil', 899.00, 'skincare', 65, 'https://images.unsplash.com/photo-1612817288484-6f916006741a?w=400&h=400&fit=crop', '🌳'),
('Glycolic Acid Toner', 'Exfoliating toner with 7% glycolic acid', 999.00, 'skincare', 48, 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop', '✨'),
('Eye Cream Anti-Aging', 'Reduces dark circles and puffiness around eyes', 1199.00, 'skincare', 42, 'https://images.unsplash.com/photo-1617897903246-719242758050?w=400&h=400&fit=crop', '👁️');

-- Vitamin Products
INSERT INTO products (name, description, price, category, stock, image_url, icon) VALUES
('Vitamin D3 5000 IU', 'High potency vitamin D3 for bone and immune health', 899.00, 'vitamins', 120, 'https://images.unsplash.com/photo-1550572017-4a6e8e0b0b3f?w=400&h=400&fit=crop', '☀️'),
('Omega-3 Fish Oil', '1000mg EPA/DHA for heart and brain health', 1299.00, 'vitamins', 90, 'https://images.unsplash.com/photo-1526336024174-e58f5cdd8e13?w=400&h=400&fit=crop', '🐟'),
('Multivitamin Complete', 'Daily multivitamin with 25+ essential nutrients', 799.00, 'vitamins', 150, 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400&h=400&fit=crop', '💊'),
('Vitamin C 1000mg', 'Immune support with time-release vitamin C', 599.00, 'vitamins', 200, 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=400&h=400&fit=crop', '🍊'),
('Calcium + Vitamin D', 'Bone strength formula with calcium and vitamin D3', 699.00, 'vitamins', 110, 'https://images.unsplash.com/photo-1607619056574-7b8d3ee536b2?w=400&h=400&fit=crop', '🦴'),
('B-Complex Vitamins', 'Energy boost with all 8 B vitamins', 749.00, 'vitamins', 95, 'https://images.unsplash.com/photo-1471864190281-a93a3070b6de?w=400&h=400&fit=crop', '⚡'),
('Zinc 50mg', 'Immune system support and wound healing', 499.00, 'vitamins', 130, 'https://images.unsplash.com/photo-1550572017-4a6e8e0b0b3f?w=400&h=400&fit=crop', '🛡️'),
('Magnesium 400mg', 'Muscle relaxation and sleep support', 649.00, 'vitamins', 85, 'https://images.unsplash.com/photo-1607619056574-7b8d3ee536b2?w=400&h=400&fit=crop', '😴'),
('Iron Supplement', 'Gentle iron for energy and blood health', 599.00, 'vitamins', 100, 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400&h=400&fit=crop', '🔴'),
('Vitamin E 400 IU', 'Antioxidant support for skin and heart health', 699.00, 'vitamins', 75, 'https://images.unsplash.com/photo-1550572017-4a6e8e0b0b3f?w=400&h=400&fit=crop', '💚'),
('Biotin 10000mcg', 'Hair, skin, and nail health supplement', 799.00, 'vitamins', 140, 'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=400&h=400&fit=crop', '💇'),
('Probiotics 50 Billion', 'Digestive health with 10 probiotic strains', 1499.00, 'vitamins', 60, 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=400&h=400&fit=crop', '🦠'),
('Collagen Peptides', 'Hydrolyzed collagen for skin, joints, and bones', 1899.00, 'vitamins', 55, 'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=400&h=400&fit=crop', '✨'),
('CoQ10 200mg', 'Heart health and energy production support', 1399.00, 'vitamins', 70, 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400&h=400&fit=crop', '❤️'),
('Turmeric Curcumin', 'Anti-inflammatory with 95% curcuminoids', 999.00, 'vitamins', 80, 'https://images.unsplash.com/photo-1615485500834-bc10199bc727?w=400&h=400&fit=crop', '🟡'),
('Ashwagandha 1300mg', 'Stress relief and energy adaptogen', 1099.00, 'vitamins', 65, 'https://images.unsplash.com/photo-1608571423902-eed4a5ad8108?w=400&h=400&fit=crop', '🌿');

-- Update existing products to add image URLs if they don't have them
UPDATE products SET image_url = 'https://images.unsplash.com/photo-1584308666744-24d5c474f2ae?w=400&h=400&fit=crop' WHERE name LIKE '%Paracetamol%' AND image_url IS NULL;
UPDATE products SET image_url = 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=400&h=400&fit=crop' WHERE name LIKE '%Cough%' AND image_url IS NULL;
UPDATE products SET image_url = 'https://images.unsplash.com/photo-1550572017-4a6e8e0b0b3f?w=400&h=400&fit=crop' WHERE name LIKE '%Vitamin%' AND image_url IS NULL;
UPDATE products SET image_url = 'https://images.unsplash.com/photo-1603398938378-e54eab446dde?w=400&h=400&fit=crop' WHERE name LIKE '%First Aid%' AND image_url IS NULL;
UPDATE products SET image_url = 'https://images.unsplash.com/photo-1530026405186-ed1f139313f8?w=400&h=400&fit=crop' WHERE name LIKE '%Thermometer%' AND image_url IS NULL;
UPDATE products SET image_url = 'https://images.unsplash.com/photo-1615485500834-bc10199bc727?w=400&h=400&fit=crop' WHERE name LIKE '%Blood Pressure%' AND image_url IS NULL;
UPDATE products SET image_url = 'https://images.unsplash.com/photo-1471864190281-a93a3070b6de?w=400&h=400&fit=crop' WHERE name LIKE '%Antibiotic%' AND image_url IS NULL;
