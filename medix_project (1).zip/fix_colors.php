<?php
// Fix all red colors to blue across all frontend files
$files = ['products.php', 'checkout.php', 'cart.php', 'order_success.php', 'about.html', 'contact.html', 'register.html', 'login.html'];

$replacements = [
    '#B91C1C' => '#1D4ED8',
    '#991B1B' => '#1E40AF',
    '#7F1D1D' => '#1E3A8A',
    '#DC2626' => '#2563EB',
    '#FEF2F2' => '#EFF6FF',
    '#FEE2E2' => '#DBEAFE',
    'rgba(185,28,28' => 'rgba(29,78,216',
    'rgba(185, 28, 28' => 'rgba(29, 78, 216',
    'rgba(127,29,29' => 'rgba(30,58,138',
    'rgba(127, 29, 29' => 'rgba(30, 58, 138',
    'rgba(220,38,38' => 'rgba(37,99,235',
    'rgba(220, 38, 38' => 'rgba(37, 99, 235',
];

$total = 0;
foreach ($files as $file) {
    $path = __DIR__ . '/' . $file;
    if (!file_exists($path)) { echo "SKIP: $file (not found)\n"; continue; }
    $content = file_get_contents($path);
    $original = $content;
    foreach ($replacements as $old => $new) {
        $content = str_ireplace($old, $new, $content);
    }
    if ($content !== $original) {
        file_put_contents($path, $content);
        echo "FIXED: $file\n";
        $total++;
    } else {
        echo "OK (no change): $file\n";
    }
}

echo "\nDone! Fixed $total files.\n";
echo "Visit: http://localhost/ppp/index.html\n";
?>
